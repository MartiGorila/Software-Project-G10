import {
  require_react
} from "/node_modules/.vite/deps/chunk-2UC5YKPU.js?v=9e4a54a9";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=9e4a54a9";
export default require_react();
//# sourceMappingURL=react.js.map
