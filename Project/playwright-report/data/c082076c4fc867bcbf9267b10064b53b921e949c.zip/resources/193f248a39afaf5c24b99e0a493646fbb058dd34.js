import {
  require_leaflet_src
} from "/node_modules/.vite/deps/chunk-LUZB3UJO.js?v=9e4a54a9";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=9e4a54a9";
export default require_leaflet_src();
//# sourceMappingURL=leaflet.js.map
