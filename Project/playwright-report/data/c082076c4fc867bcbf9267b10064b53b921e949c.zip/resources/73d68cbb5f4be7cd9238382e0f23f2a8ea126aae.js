import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SavedContentPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { getCategoryIcon, getVisibleTags } from "/src/categoryIcons.ts";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useState = __vite__cjsImport4_react["useState"];
function formatBudget(budget) {
  return budget === null ? "Budget unknown" : `€${budget.toFixed(2)}`;
}
function formatSavedDate(iso) {
  return new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function formatEventTime(iso) {
  return new Date(iso).toLocaleString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function Tags({ tags }) {
  const { visibleTags, hiddenCount } = getVisibleTags(tags, 3);
  if (visibleTags.length === 0)
    return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "saved-card__tags", children: [
    visibleTags.map(
      (tag) => /* @__PURE__ */ jsxDEV("span", { children: [
        "#",
        tag.name
      ] }, tag.id, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 65,
        columnNumber: 7
      }, this)
    ),
    hiddenCount > 0 && /* @__PURE__ */ jsxDEV("span", { children: [
      "+",
      hiddenCount,
      " more"
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 67,
      columnNumber: 33
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
    lineNumber: 63,
    columnNumber: 5
  }, this);
}
_c = Tags;
function RouteStopRow({
  stop,
  eventExists,
  onOpenEventDetails,
  onCenterOnMap
}) {
  return /* @__PURE__ */ jsxDEV("li", { className: "saved-route-stop", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "saved-route-stop__number", children: stop.stopNumber }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 85,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "saved-route-stop__body", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "saved-route-stop__topline", children: [
        /* @__PURE__ */ jsxDEV("span", { className: `explore-card__badge explore-card__badge--${stop.type}`, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "explore-card__icon", "aria-hidden": "true", children: getCategoryIcon(stop.tags, stop.type) }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
            lineNumber: 89,
            columnNumber: 25
          }, this),
          stop.type
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 88,
          columnNumber: 21
        }, this),
        stop.eventTime && /* @__PURE__ */ jsxDEV("span", { className: "saved-card__meta", children: formatEventTime(stop.eventTime) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 92,
          columnNumber: 40
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 87,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("strong", { children: stop.name }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 94,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "saved-card__meta", children: formatBudget(stop.budget) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 95,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Tags, { tags: stop.tags }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 96,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "saved-card__actions", children: [
        stop.type === "event" && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "saved-card__button",
            onClick: () => onOpenEventDetails(stop.id),
            disabled: !eventExists,
            children: eventExists ? "Open full event details" : "Event unavailable"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
            lineNumber: 99,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "saved-card__button saved-card__button--secondary",
            onClick: () => onCenterOnMap([stop.lat, stop.lng]),
            children: "Center on map"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
            lineNumber: 108,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 97,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 86,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
}
_c2 = RouteStopRow;
function SavedRouteCard({
  route,
  events,
  onOpenEventDetails,
  onCenterOnMap,
  onRemoveRoute
}) {
  _s();
  const eventIds = new Set(events.map((event) => event.id));
  const [expanded, setExpanded] = useState(false);
  const previewStops = expanded ? route.stops : route.stops.slice(0, 2);
  const hiddenStopCount = Math.max(0, route.stops.length - previewStops.length);
  return /* @__PURE__ */ jsxDEV("article", { className: "saved-card saved-route-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "saved-card__header", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: route.title }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 143,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "saved-card__meta", children: [
          "Saved ",
          formatSavedDate(route.savedAt)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 144,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 142,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "saved-card__remove", onClick: () => onRemoveRoute(route.id), children: "Remove" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 146,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 141,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "saved-card__metrics", children: [
      /* @__PURE__ */ jsxDEV("span", { children: [
        route.summary.stops,
        " stops"
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 151,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: [
        "€",
        route.summary.knownBudget.toFixed(2),
        route.summary.hasUnknownBudget ? " known" : ""
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 152,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: [
        route.summary.totalDistance.toFixed(1),
        "km"
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 153,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 150,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("ol", { className: "saved-route-stops", children: previewStops.map(
      (stop) => /* @__PURE__ */ jsxDEV(
        RouteStopRow,
        {
          stop,
          eventExists: stop.type !== "event" || eventIds.has(stop.id),
          onOpenEventDetails,
          onCenterOnMap
        },
        `${route.id}-${stop.type}-${stop.id}`,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 157,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 155,
      columnNumber: 13
    }, this),
    route.stops.length > 2 && /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "saved-route-card__toggle",
        onClick: () => setExpanded((value) => !value),
        children: expanded ? "Show fewer stops" : `Show all stops · +${hiddenStopCount} more`
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 167,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
    lineNumber: 140,
    columnNumber: 5
  }, this);
}
_s(SavedRouteCard, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c3 = SavedRouteCard;
function SavedPlanCard({
  plan,
  onCenterOnMap,
  onRemovePlan
}) {
  return /* @__PURE__ */ jsxDEV("article", { className: "saved-card saved-card--plan", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "saved-card__header", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: plan.name }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 192,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "saved-card__meta", children: [
          "Saved ",
          formatSavedDate(plan.savedAt)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 193,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 191,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "saved-card__remove", onClick: () => onRemovePlan(plan.id), children: "Remove" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 195,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 190,
      columnNumber: 13
    }, this),
    plan.description && /* @__PURE__ */ jsxDEV("p", { children: plan.description }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 199,
      columnNumber: 34
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "saved-card__metrics", children: /* @__PURE__ */ jsxDEV("span", { children: formatBudget(plan.budget) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 201,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 200,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Tags, { tags: plan.tags }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 203,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "saved-card__actions", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "saved-card__button saved-card__button--secondary",
        onClick: () => onCenterOnMap([plan.lat, plan.lng]),
        children: "Center on map"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 205,
        columnNumber: 17
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 204,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
    lineNumber: 189,
    columnNumber: 5
  }, this);
}
_c4 = SavedPlanCard;
export default function SavedContentPanel({
  savedContent,
  events,
  onClose,
  onOpenEventDetails,
  onCenterOnMap,
  onRemovePlan,
  onRemoveRoute
}) {
  const empty = savedContent.routes.length === 0 && savedContent.plans.length === 0;
  return /* @__PURE__ */ jsxDEV("div", { className: "saved-backdrop", onClick: onClose, children: /* @__PURE__ */ jsxDEV("section", { className: "saved-panel", "aria-label": "Saved content", onClick: (event) => event.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "saved-panel__header", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "saved-panel__eyebrow", children: "Your library" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 233,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: "Saved content" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 234,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Routes and plans saved on this browser for your account." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 235,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 232,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "explore-panel__close", onClick: onClose, "aria-label": "Close saved content", children: "x" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 237,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 231,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "saved-panel__body", children: [
      empty && /* @__PURE__ */ jsxDEV("div", { className: "saved-panel__empty", children: "Nothing saved yet. Save a route from Planner or a plan from Explore." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 244,
        columnNumber: 11
      }, this),
      savedContent.routes.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "saved-section", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Saved Routes" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 251,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "saved-section__list", children: savedContent.routes.map(
          (route) => /* @__PURE__ */ jsxDEV(
            SavedRouteCard,
            {
              route,
              events,
              onOpenEventDetails,
              onCenterOnMap,
              onRemoveRoute
            },
            route.id,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
              lineNumber: 254,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 252,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 250,
        columnNumber: 11
      }, this),
      savedContent.plans.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "saved-section", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Saved Plans" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 269,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "saved-section__list", children: savedContent.plans.map(
          (plan) => /* @__PURE__ */ jsxDEV(
            SavedPlanCard,
            {
              plan,
              onCenterOnMap,
              onRemovePlan
            },
            plan.id,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
              lineNumber: 272,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
          lineNumber: 270,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
        lineNumber: 268,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
      lineNumber: 242,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
    lineNumber: 230,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx",
    lineNumber: 229,
    columnNumber: 5
  }, this);
}
_c5 = SavedContentPanel;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "Tags");
$RefreshReg$(_c2, "RouteStopRow");
$RefreshReg$(_c3, "SavedRouteCard");
$RefreshReg$(_c4, "SavedPlanCard");
$RefreshReg$(_c5, "SavedContentPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SavedContentPanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1Q2hCLFNBQVNBLGlCQUFpQkMsc0JBQXNCO0FBRWhELFNBQVNDLGdCQUFnQjtBQVl6QixTQUFTQyxhQUFhQyxRQUF1QjtBQUN6QyxTQUFPQSxXQUFXLE9BQU8sbUJBQW1CLElBQUlBLE9BQU9DLFFBQVEsQ0FBQyxDQUFDO0FBQ3JFO0FBRUEsU0FBU0MsZ0JBQWdCQyxLQUFhO0FBQ2xDLFNBQU8sSUFBSUMsS0FBS0QsR0FBRyxFQUFFRSxtQkFBbUIsU0FBUztBQUFBLElBQzdDQyxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsRUFDWixDQUFDO0FBQ0w7QUFFQSxTQUFTQyxnQkFBZ0JQLEtBQWE7QUFDbEMsU0FBTyxJQUFJQyxLQUFLRCxHQUFHLEVBQUVRLGVBQWUsU0FBUztBQUFBLElBQ3pDQyxTQUFTO0FBQUEsSUFDVE4sS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1osQ0FBQztBQUNMO0FBRUEsU0FBU0ksS0FBSyxFQUFFQyxLQUFzQixHQUFHO0FBQ3JDLFFBQU0sRUFBRUMsYUFBYUMsWUFBWSxJQUFJbkIsZUFBZWlCLE1BQU0sQ0FBQztBQUMzRCxNQUFJQyxZQUFZRSxXQUFXO0FBQUcsV0FBTztBQUVyQyxTQUNJLHVCQUFDLFNBQUksV0FBVSxvQkFDVkY7QUFBQUEsZ0JBQVlHO0FBQUFBLE1BQUksQ0FBQ0MsUUFDZCx1QkFBQyxVQUFrQjtBQUFBO0FBQUEsUUFBRUEsSUFBSUM7QUFBQUEsV0FBZEQsSUFBSUUsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsSUFDakM7QUFBQSxJQUNBTCxjQUFjLEtBQUssdUJBQUMsVUFBSztBQUFBO0FBQUEsTUFBRUE7QUFBQUEsTUFBWTtBQUFBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxPQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFUjtBQUFDTSxLQVpRVDtBQWNULFNBQVNVLGFBQWE7QUFBQSxFQUNsQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNSixHQUFHO0FBQ0MsU0FDSSx1QkFBQyxRQUFHLFdBQVUsb0JBQ1Y7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNEJBQTRCSCxlQUFLSSxjQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJEO0FBQUEsSUFDM0QsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsK0JBQUMsVUFBSyxXQUFXLDRDQUE0Q0osS0FBS0ssSUFBSSxJQUNsRTtBQUFBLGlDQUFDLFVBQUssV0FBVSxzQkFBcUIsZUFBWSxRQUFRakMsMEJBQWdCNEIsS0FBS1YsTUFBTVUsS0FBS0ssSUFBSSxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLFVBQzlGTCxLQUFLSztBQUFBQSxhQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0NMLEtBQUtNLGFBQWEsdUJBQUMsVUFBSyxXQUFVLG9CQUFvQnBCLDBCQUFnQmMsS0FBS00sU0FBUyxLQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsV0FMM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxZQUFRTixlQUFLSixRQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUI7QUFBQSxNQUNuQix1QkFBQyxTQUFJLFdBQVUsb0JBQW9CckIsdUJBQWF5QixLQUFLeEIsTUFBTSxLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsTUFDN0QsdUJBQUMsUUFBSyxNQUFNd0IsS0FBS1YsUUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQjtBQUFBLE1BQ3RCLHVCQUFDLFNBQUksV0FBVSx1QkFDVlU7QUFBQUEsYUFBS0ssU0FBUyxXQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1ILG1CQUFtQkYsS0FBS0gsRUFBRTtBQUFBLFlBQ3pDLFVBQVUsQ0FBQ0k7QUFBQUEsWUFFVkEsd0JBQWMsNEJBQTRCO0FBQUE7QUFBQSxVQU4vQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBRUo7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTUUsY0FBYyxDQUFDSCxLQUFLTyxLQUFLUCxLQUFLUSxHQUFHLENBQUM7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUh2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsT0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVSO0FBQUNDLE1BL0NRVjtBQWlEVCxTQUFTVyxlQUFlO0FBQUEsRUFDcEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FWO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FVO0FBT0osR0FBRztBQUFBQyxLQUFBO0FBQ0MsUUFBTUMsV0FBVyxJQUFJQyxJQUFJSixPQUFPbEIsSUFBSSxDQUFDdUIsVUFBVUEsTUFBTXBCLEVBQUUsQ0FBQztBQUN4RCxRQUFNLENBQUNxQixVQUFVQyxXQUFXLElBQUk3QyxTQUFTLEtBQUs7QUFDOUMsUUFBTThDLGVBQWVGLFdBQVdQLE1BQU1VLFFBQVFWLE1BQU1VLE1BQU1DLE1BQU0sR0FBRyxDQUFDO0FBQ3BFLFFBQU1DLGtCQUFrQkMsS0FBS0MsSUFBSSxHQUFHZCxNQUFNVSxNQUFNNUIsU0FBUzJCLGFBQWEzQixNQUFNO0FBRTVFLFNBQ0ksdUJBQUMsYUFBUSxXQUFVLCtCQUNmO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNCQUNYO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFFBQUlrQixnQkFBTWUsU0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDakIsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQjtBQUFBO0FBQUEsVUFBT2hELGdCQUFnQmlDLE1BQU1nQixPQUFPO0FBQUEsYUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBLFdBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxzQkFBcUIsU0FBUyxNQUFNZCxjQUFjRixNQUFNZCxFQUFFLEdBQUcsc0JBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSw2QkFBQyxVQUFNYztBQUFBQSxjQUFNaUIsUUFBUVA7QUFBQUEsUUFBTTtBQUFBLFdBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUNqQyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxRQUFFVixNQUFNaUIsUUFBUUMsWUFBWXBELFFBQVEsQ0FBQztBQUFBLFFBQUdrQyxNQUFNaUIsUUFBUUUsbUJBQW1CLFdBQVc7QUFBQSxXQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZGO0FBQUEsTUFDN0YsdUJBQUMsVUFBTW5CO0FBQUFBLGNBQU1pQixRQUFRRyxjQUFjdEQsUUFBUSxDQUFDO0FBQUEsUUFBRTtBQUFBLFdBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxTQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFFBQUcsV0FBVSxxQkFDVDJDLHVCQUFhMUI7QUFBQUEsTUFBSSxDQUFDTSxTQUNmO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFRztBQUFBLFVBQ0EsYUFBYUEsS0FBS0ssU0FBUyxXQUFXVSxTQUFTaUIsSUFBSWhDLEtBQUtILEVBQUU7QUFBQSxVQUMxRDtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBSkssR0FBR2MsTUFBTWQsRUFBRSxJQUFJRyxLQUFLSyxJQUFJLElBQUlMLEtBQUtILEVBQUU7QUFBQSxRQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS2lDO0FBQUEsSUFFcEMsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNDYyxNQUFNVSxNQUFNNUIsU0FBUyxLQUNsQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNMEIsWUFBWSxDQUFDYyxVQUFVLENBQUNBLEtBQUs7QUFBQSxRQUUzQ2YscUJBQVcscUJBQXFCLHFCQUFxQkssZUFBZTtBQUFBO0FBQUEsTUFMekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUE7QUFBQSxPQWpDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUNBO0FBRVI7QUFBQ1QsR0F4RFFKLGdCQUFjO0FBQUEsTUFBZEE7QUEwRFQsU0FBU3dCLGNBQWM7QUFBQSxFQUNuQkM7QUFBQUEsRUFDQWhDO0FBQUFBLEVBQ0FpQztBQUtKLEdBQUc7QUFDQyxTQUNJLHVCQUFDLGFBQVEsV0FBVSwrQkFDZjtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLDZCQUFDLFNBQ0c7QUFBQSwrQkFBQyxRQUFJRCxlQUFLdkMsUUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmLHVCQUFDLFVBQUssV0FBVSxvQkFBbUI7QUFBQTtBQUFBLFVBQU9sQixnQkFBZ0J5RCxLQUFLUixPQUFPO0FBQUEsYUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFdBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxzQkFBcUIsU0FBUyxNQUFNUyxhQUFhRCxLQUFLdEMsRUFBRSxHQUFHLHNCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0NzQyxLQUFLRSxlQUFlLHVCQUFDLE9BQUdGLGVBQUtFLGVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQzFDLHVCQUFDLFNBQUksV0FBVSx1QkFDWCxpQ0FBQyxVQUFNOUQsdUJBQWE0RCxLQUFLM0QsTUFBTSxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsUUFBSyxNQUFNMkQsS0FBSzdDLFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0I7QUFBQSxJQUN0Qix1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTWEsY0FBYyxDQUFDZ0MsS0FBSzVCLEtBQUs0QixLQUFLM0IsR0FBRyxDQUFDO0FBQUEsUUFBRTtBQUFBO0FBQUEsTUFIdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JBO0FBRVI7QUFBQzhCLE1BcENRSjtBQXNDVCx3QkFBd0JLLGtCQUFrQjtBQUFBLEVBQ3RDQztBQUFBQSxFQUNBNUI7QUFBQUEsRUFDQTZCO0FBQUFBLEVBQ0F2QztBQUFBQSxFQUNBQztBQUFBQSxFQUNBaUM7QUFBQUEsRUFDQXZCO0FBQ29CLEdBQUc7QUFDdkIsUUFBTTZCLFFBQVFGLGFBQWFHLE9BQU9sRCxXQUFXLEtBQUsrQyxhQUFhSSxNQUFNbkQsV0FBVztBQUVoRixTQUNJLHVCQUFDLFNBQUksV0FBVSxrQkFBaUIsU0FBU2dELFNBQ3JDLGlDQUFDLGFBQVEsV0FBVSxlQUFjLGNBQVcsaUJBQWdCLFNBQVMsQ0FBQ3hCLFVBQVVBLE1BQU00QixnQkFBZ0IsR0FDbEc7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHdCQUF1Qiw0QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLE9BQUUsd0VBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFdBSC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSx3QkFBdUIsU0FBU0osU0FBUyxjQUFXLHVCQUFzQixpQkFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDVkM7QUFBQUEsZUFDRyx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLG9GQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdIRixhQUFhRyxPQUFPbEQsU0FBUyxLQUMxQix1QkFBQyxhQUFRLFdBQVUsaUJBQ2Y7QUFBQSwrQkFBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUNoQix1QkFBQyxTQUFJLFdBQVUsdUJBQ1YrQyx1QkFBYUcsT0FBT2pEO0FBQUFBLFVBQUksQ0FBQ2lCLFVBQ3RCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFRztBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQTtBQUFBLFlBTEtBLE1BQU1kO0FBQUFBLFlBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1pQztBQUFBLFFBRXBDLEtBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUdIMkMsYUFBYUksTUFBTW5ELFNBQVMsS0FDekIsdUJBQUMsYUFBUSxXQUFVLGlCQUNmO0FBQUEsK0JBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmLHVCQUFDLFNBQUksV0FBVSx1QkFDVitDLHVCQUFhSSxNQUFNbEQ7QUFBQUEsVUFBSSxDQUFDeUMsU0FDckI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVHO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQTtBQUFBLFlBSEtBLEtBQUt0QztBQUFBQSxZQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJK0I7QUFBQSxRQUVsQyxLQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0F0Q1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdDQTtBQUFBLE9BcERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxREEsS0F0REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVEQTtBQUVSO0FBQUNpRCxNQXJFdUJQO0FBQWlCLElBQUF6QyxJQUFBVyxLQUFBc0MsS0FBQVQsS0FBQVE7QUFBQSxhQUFBaEQsSUFBQTtBQUFBLGFBQUFXLEtBQUE7QUFBQSxhQUFBc0MsS0FBQTtBQUFBLGFBQUFULEtBQUE7QUFBQSxhQUFBUSxLQUFBIiwibmFtZXMiOlsiZ2V0Q2F0ZWdvcnlJY29uIiwiZ2V0VmlzaWJsZVRhZ3MiLCJ1c2VTdGF0ZSIsImZvcm1hdEJ1ZGdldCIsImJ1ZGdldCIsInRvRml4ZWQiLCJmb3JtYXRTYXZlZERhdGUiLCJpc28iLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJob3VyIiwibWludXRlIiwiZm9ybWF0RXZlbnRUaW1lIiwidG9Mb2NhbGVTdHJpbmciLCJ3ZWVrZGF5IiwiVGFncyIsInRhZ3MiLCJ2aXNpYmxlVGFncyIsImhpZGRlbkNvdW50IiwibGVuZ3RoIiwibWFwIiwidGFnIiwibmFtZSIsImlkIiwiX2MiLCJSb3V0ZVN0b3BSb3ciLCJzdG9wIiwiZXZlbnRFeGlzdHMiLCJvbk9wZW5FdmVudERldGFpbHMiLCJvbkNlbnRlck9uTWFwIiwic3RvcE51bWJlciIsInR5cGUiLCJldmVudFRpbWUiLCJsYXQiLCJsbmciLCJfYzIiLCJTYXZlZFJvdXRlQ2FyZCIsInJvdXRlIiwiZXZlbnRzIiwib25SZW1vdmVSb3V0ZSIsIl9zIiwiZXZlbnRJZHMiLCJTZXQiLCJldmVudCIsImV4cGFuZGVkIiwic2V0RXhwYW5kZWQiLCJwcmV2aWV3U3RvcHMiLCJzdG9wcyIsInNsaWNlIiwiaGlkZGVuU3RvcENvdW50IiwiTWF0aCIsIm1heCIsInRpdGxlIiwic2F2ZWRBdCIsInN1bW1hcnkiLCJrbm93bkJ1ZGdldCIsImhhc1Vua25vd25CdWRnZXQiLCJ0b3RhbERpc3RhbmNlIiwiaGFzIiwidmFsdWUiLCJTYXZlZFBsYW5DYXJkIiwicGxhbiIsIm9uUmVtb3ZlUGxhbiIsImRlc2NyaXB0aW9uIiwiX2M0IiwiU2F2ZWRDb250ZW50UGFuZWwiLCJzYXZlZENvbnRlbnQiLCJvbkNsb3NlIiwiZW1wdHkiLCJyb3V0ZXMiLCJwbGFucyIsInN0b3BQcm9wYWdhdGlvbiIsIl9jNSIsIl9jMyJdLCJzb3VyY2VzIjpbIlNhdmVkQ29udGVudFBhbmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEFwaUV2ZW50LCBUYWcgfSBmcm9tICcuL2FwaSdcclxuaW1wb3J0IHsgZ2V0Q2F0ZWdvcnlJY29uLCBnZXRWaXNpYmxlVGFncyB9IGZyb20gJy4vY2F0ZWdvcnlJY29ucydcclxuaW1wb3J0IHR5cGUgeyBTYXZlZENvbnRlbnRTdGF0ZSwgU2F2ZWRQbGFuLCBTYXZlZFJvdXRlLCBTYXZlZFJvdXRlU3RvcCB9IGZyb20gJy4vc2F2ZWRDb250ZW50J1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5cclxudHlwZSBTYXZlZENvbnRlbnRQYW5lbFByb3BzID0ge1xyXG4gICAgc2F2ZWRDb250ZW50OiBTYXZlZENvbnRlbnRTdGF0ZVxyXG4gICAgZXZlbnRzOiBBcGlFdmVudFtdXHJcbiAgICBvbkNsb3NlOiAoKSA9PiB2b2lkXHJcbiAgICBvbk9wZW5FdmVudERldGFpbHM6IChldmVudElkOiBzdHJpbmcpID0+IHZvaWRcclxuICAgIG9uQ2VudGVyT25NYXA6IChwb3NpdGlvbjogW251bWJlciwgbnVtYmVyXSkgPT4gdm9pZFxyXG4gICAgb25SZW1vdmVQbGFuOiAocGxhbklkOiBzdHJpbmcpID0+IHZvaWRcclxuICAgIG9uUmVtb3ZlUm91dGU6IChyb3V0ZUlkOiBzdHJpbmcpID0+IHZvaWRcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0QnVkZ2V0KGJ1ZGdldDogbnVtYmVyIHwgbnVsbCkge1xyXG4gICAgcmV0dXJuIGJ1ZGdldCA9PT0gbnVsbCA/ICdCdWRnZXQgdW5rbm93bicgOiBg4oKsJHtidWRnZXQudG9GaXhlZCgyKX1gXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdFNhdmVkRGF0ZShpc286IHN0cmluZykge1xyXG4gICAgcmV0dXJuIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgICBkYXk6ICdudW1lcmljJyxcclxuICAgICAgICBtb250aDogJ3Nob3J0JyxcclxuICAgICAgICBob3VyOiAnMi1kaWdpdCcsXHJcbiAgICAgICAgbWludXRlOiAnMi1kaWdpdCcsXHJcbiAgICB9KVxyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRFdmVudFRpbWUoaXNvOiBzdHJpbmcpIHtcclxuICAgIHJldHVybiBuZXcgRGF0ZShpc28pLnRvTG9jYWxlU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgICB3ZWVrZGF5OiAnc2hvcnQnLFxyXG4gICAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICAgIG1vbnRoOiAnc2hvcnQnLFxyXG4gICAgICAgIGhvdXI6ICcyLWRpZ2l0JyxcclxuICAgICAgICBtaW51dGU6ICcyLWRpZ2l0JyxcclxuICAgIH0pXHJcbn1cclxuXHJcbmZ1bmN0aW9uIFRhZ3MoeyB0YWdzIH06IHsgdGFnczogVGFnW10gfSkge1xyXG4gICAgY29uc3QgeyB2aXNpYmxlVGFncywgaGlkZGVuQ291bnQgfSA9IGdldFZpc2libGVUYWdzKHRhZ3MsIDMpXHJcbiAgICBpZiAodmlzaWJsZVRhZ3MubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbFxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1jYXJkX190YWdzXCI+XHJcbiAgICAgICAgICAgIHt2aXNpYmxlVGFncy5tYXAoKHRhZykgPT4gKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0YWcuaWR9PiN7dGFnLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAge2hpZGRlbkNvdW50ID4gMCAmJiA8c3Bhbj4re2hpZGRlbkNvdW50fSBtb3JlPC9zcGFuPn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG5cclxuZnVuY3Rpb24gUm91dGVTdG9wUm93KHtcclxuICAgIHN0b3AsXHJcbiAgICBldmVudEV4aXN0cyxcclxuICAgIG9uT3BlbkV2ZW50RGV0YWlscyxcclxuICAgIG9uQ2VudGVyT25NYXAsXHJcbn06IHtcclxuICAgIHN0b3A6IFNhdmVkUm91dGVTdG9wXHJcbiAgICBldmVudEV4aXN0czogYm9vbGVhblxyXG4gICAgb25PcGVuRXZlbnREZXRhaWxzOiAoZXZlbnRJZDogc3RyaW5nKSA9PiB2b2lkXHJcbiAgICBvbkNlbnRlck9uTWFwOiAocG9zaXRpb246IFtudW1iZXIsIG51bWJlcl0pID0+IHZvaWRcclxufSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8bGkgY2xhc3NOYW1lPVwic2F2ZWQtcm91dGUtc3RvcFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNhdmVkLXJvdXRlLXN0b3BfX251bWJlclwiPntzdG9wLnN0b3BOdW1iZXJ9PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtcm91dGUtc3RvcF9fYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1yb3V0ZS1zdG9wX190b3BsaW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZXhwbG9yZS1jYXJkX19iYWRnZSBleHBsb3JlLWNhcmRfX2JhZGdlLS0ke3N0b3AudHlwZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX19pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+e2dldENhdGVnb3J5SWNvbihzdG9wLnRhZ3MsIHN0b3AudHlwZSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RvcC50eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7c3RvcC5ldmVudFRpbWUgJiYgPHNwYW4gY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fbWV0YVwiPntmb3JtYXRFdmVudFRpbWUoc3RvcC5ldmVudFRpbWUpfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzdHJvbmc+e3N0b3AubmFtZX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fbWV0YVwiPntmb3JtYXRCdWRnZXQoc3RvcC5idWRnZXQpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPFRhZ3MgdGFncz17c3RvcC50YWdzfSAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1jYXJkX19hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3N0b3AudHlwZSA9PT0gJ2V2ZW50JyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3BlbkV2ZW50RGV0YWlscyhzdG9wLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshZXZlbnRFeGlzdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtldmVudEV4aXN0cyA/ICdPcGVuIGZ1bGwgZXZlbnQgZGV0YWlscycgOiAnRXZlbnQgdW5hdmFpbGFibGUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNhdmVkLWNhcmRfX2J1dHRvbiBzYXZlZC1jYXJkX19idXR0b24tLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2VudGVyT25NYXAoW3N0b3AubGF0LCBzdG9wLmxuZ10pfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2VudGVyIG9uIG1hcFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbGk+XHJcbiAgICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIFNhdmVkUm91dGVDYXJkKHtcclxuICAgIHJvdXRlLFxyXG4gICAgZXZlbnRzLFxyXG4gICAgb25PcGVuRXZlbnREZXRhaWxzLFxyXG4gICAgb25DZW50ZXJPbk1hcCxcclxuICAgIG9uUmVtb3ZlUm91dGUsXHJcbn06IHtcclxuICAgIHJvdXRlOiBTYXZlZFJvdXRlXHJcbiAgICBldmVudHM6IEFwaUV2ZW50W11cclxuICAgIG9uT3BlbkV2ZW50RGV0YWlsczogKGV2ZW50SWQ6IHN0cmluZykgPT4gdm9pZFxyXG4gICAgb25DZW50ZXJPbk1hcDogKHBvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdKSA9PiB2b2lkXHJcbiAgICBvblJlbW92ZVJvdXRlOiAocm91dGVJZDogc3RyaW5nKSA9PiB2b2lkXHJcbn0pIHtcclxuICAgIGNvbnN0IGV2ZW50SWRzID0gbmV3IFNldChldmVudHMubWFwKChldmVudCkgPT4gZXZlbnQuaWQpKVxyXG4gICAgY29uc3QgW2V4cGFuZGVkLCBzZXRFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IHByZXZpZXdTdG9wcyA9IGV4cGFuZGVkID8gcm91dGUuc3RvcHMgOiByb3V0ZS5zdG9wcy5zbGljZSgwLCAyKVxyXG4gICAgY29uc3QgaGlkZGVuU3RvcENvdW50ID0gTWF0aC5tYXgoMCwgcm91dGUuc3RvcHMubGVuZ3RoIC0gcHJldmlld1N0b3BzLmxlbmd0aClcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInNhdmVkLWNhcmQgc2F2ZWQtcm91dGUtY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNhdmVkLWNhcmRfX2hlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8aDM+e3JvdXRlLnRpdGxlfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fbWV0YVwiPlNhdmVkIHtmb3JtYXRTYXZlZERhdGUocm91dGUuc2F2ZWRBdCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJzYXZlZC1jYXJkX19yZW1vdmVcIiBvbkNsaWNrPXsoKSA9PiBvblJlbW92ZVJvdXRlKHJvdXRlLmlkKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fbWV0cmljc1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e3JvdXRlLnN1bW1hcnkuc3RvcHN9IHN0b3BzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+4oKse3JvdXRlLnN1bW1hcnkua25vd25CdWRnZXQudG9GaXhlZCgyKX17cm91dGUuc3VtbWFyeS5oYXNVbmtub3duQnVkZ2V0ID8gJyBrbm93bicgOiAnJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj57cm91dGUuc3VtbWFyeS50b3RhbERpc3RhbmNlLnRvRml4ZWQoMSl9a208L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwic2F2ZWQtcm91dGUtc3RvcHNcIj5cclxuICAgICAgICAgICAgICAgIHtwcmV2aWV3U3RvcHMubWFwKChzdG9wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdXRlU3RvcFJvd1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2Ake3JvdXRlLmlkfS0ke3N0b3AudHlwZX0tJHtzdG9wLmlkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0b3A9e3N0b3B9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50RXhpc3RzPXtzdG9wLnR5cGUgIT09ICdldmVudCcgfHwgZXZlbnRJZHMuaGFzKHN0b3AuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbk9wZW5FdmVudERldGFpbHM9e29uT3BlbkV2ZW50RGV0YWlsc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DZW50ZXJPbk1hcD17b25DZW50ZXJPbk1hcH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvb2w+XHJcbiAgICAgICAgICAgIHtyb3V0ZS5zdG9wcy5sZW5ndGggPiAyICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzYXZlZC1yb3V0ZS1jYXJkX190b2dnbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkKCh2YWx1ZSkgPT4gIXZhbHVlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWQgPyAnU2hvdyBmZXdlciBzdG9wcycgOiBgU2hvdyBhbGwgc3RvcHMgwrcgKyR7aGlkZGVuU3RvcENvdW50fSBtb3JlYH1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvYXJ0aWNsZT5cclxuICAgIClcclxufVxyXG5cclxuZnVuY3Rpb24gU2F2ZWRQbGFuQ2FyZCh7XHJcbiAgICBwbGFuLFxyXG4gICAgb25DZW50ZXJPbk1hcCxcclxuICAgIG9uUmVtb3ZlUGxhbixcclxufToge1xyXG4gICAgcGxhbjogU2F2ZWRQbGFuXHJcbiAgICBvbkNlbnRlck9uTWFwOiAocG9zaXRpb246IFtudW1iZXIsIG51bWJlcl0pID0+IHZvaWRcclxuICAgIG9uUmVtb3ZlUGxhbjogKHBsYW5JZDogc3RyaW5nKSA9PiB2b2lkXHJcbn0pIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwic2F2ZWQtY2FyZCBzYXZlZC1jYXJkLS1wbGFuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9faGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMz57cGxhbi5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fbWV0YVwiPlNhdmVkIHtmb3JtYXRTYXZlZERhdGUocGxhbi5zYXZlZEF0KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInNhdmVkLWNhcmRfX3JlbW92ZVwiIG9uQ2xpY2s9eygpID0+IG9uUmVtb3ZlUGxhbihwbGFuLmlkKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtwbGFuLmRlc2NyaXB0aW9uICYmIDxwPntwbGFuLmRlc2NyaXB0aW9ufTwvcD59XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtY2FyZF9fbWV0cmljc1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdEJ1ZGdldChwbGFuLmJ1ZGdldCl9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPFRhZ3MgdGFncz17cGxhbi50YWdzfSAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNhdmVkLWNhcmRfX2FjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzYXZlZC1jYXJkX19idXR0b24gc2F2ZWQtY2FyZF9fYnV0dG9uLS1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2VudGVyT25NYXAoW3BsYW4ubGF0LCBwbGFuLmxuZ10pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIENlbnRlciBvbiBtYXBcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2FydGljbGU+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNhdmVkQ29udGVudFBhbmVsKHtcclxuICAgIHNhdmVkQ29udGVudCxcclxuICAgIGV2ZW50cyxcclxuICAgIG9uQ2xvc2UsXHJcbiAgICBvbk9wZW5FdmVudERldGFpbHMsXHJcbiAgICBvbkNlbnRlck9uTWFwLFxyXG4gICAgb25SZW1vdmVQbGFuLFxyXG4gICAgb25SZW1vdmVSb3V0ZSxcclxufTogU2F2ZWRDb250ZW50UGFuZWxQcm9wcykge1xyXG4gICAgY29uc3QgZW1wdHkgPSBzYXZlZENvbnRlbnQucm91dGVzLmxlbmd0aCA9PT0gMCAmJiBzYXZlZENvbnRlbnQucGxhbnMubGVuZ3RoID09PSAwXHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNhdmVkLWJhY2tkcm9wXCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNhdmVkLXBhbmVsXCIgYXJpYS1sYWJlbD1cIlNhdmVkIGNvbnRlbnRcIiBvbkNsaWNrPXsoZXZlbnQpID0+IGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpfT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtcGFuZWxfX2hlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNhdmVkLXBhbmVsX19leWVicm93XCI+WW91ciBsaWJyYXJ5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDI+U2F2ZWQgY29udGVudDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlJvdXRlcyBhbmQgcGxhbnMgc2F2ZWQgb24gdGhpcyBicm93c2VyIGZvciB5b3VyIGFjY291bnQuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxfX2Nsb3NlXCIgb25DbGljaz17b25DbG9zZX0gYXJpYS1sYWJlbD1cIkNsb3NlIHNhdmVkIGNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1wYW5lbF9fYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbXB0eSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtcGFuZWxfX2VtcHR5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb3RoaW5nIHNhdmVkIHlldC4gU2F2ZSBhIHJvdXRlIGZyb20gUGxhbm5lciBvciBhIHBsYW4gZnJvbSBFeHBsb3JlLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7c2F2ZWRDb250ZW50LnJvdXRlcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2F2ZWQtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPlNhdmVkIFJvdXRlczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNhdmVkLXNlY3Rpb25fX2xpc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2F2ZWRDb250ZW50LnJvdXRlcy5tYXAoKHJvdXRlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTYXZlZFJvdXRlQ2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtyb3V0ZS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlPXtyb3V0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50cz17ZXZlbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25PcGVuRXZlbnREZXRhaWxzPXtvbk9wZW5FdmVudERldGFpbHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNlbnRlck9uTWFwPXtvbkNlbnRlck9uTWFwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25SZW1vdmVSb3V0ZT17b25SZW1vdmVSb3V0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3NhdmVkQ29udGVudC5wbGFucy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2F2ZWQtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPlNhdmVkIFBsYW5zPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtc2VjdGlvbl9fbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzYXZlZENvbnRlbnQucGxhbnMubWFwKChwbGFuKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTYXZlZFBsYW5DYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3BsYW4uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFuPXtwbGFufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DZW50ZXJPbk1hcD17b25DZW50ZXJPbk1hcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uUmVtb3ZlUGxhbj17b25SZW1vdmVQbGFufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hcnRpL0RvY3VtZW50cy9HaXRIdWIvU29mdHdhcmUtUHJvamVjdC1HMTAvUHJvamVjdC9zcmMvU2F2ZWRDb250ZW50UGFuZWwudHN4In0=