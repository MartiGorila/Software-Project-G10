import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ExplorePanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { getCategoryIcon, getVisibleTags } from "/src/categoryIcons.ts";
const EARTH_RADIUS_KM = 6371;
function toRadians(value) {
  return value * Math.PI / 180;
}
function distanceKm(from, to) {
  const dLat = toRadians(to[0] - from[0]);
  const dLng = toRadians(to[1] - from[1]);
  const lat1 = toRadians(from[0]);
  const lat2 = toRadians(to[0]);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function formatBudget(budget) {
  return budget == null ? "Budget not set" : `€${budget.toFixed(2)}`;
}
function formatEventTime(iso) {
  return new Date(iso).toLocaleString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function formatVisibility(value) {
  if (value === "friends")
    return "Friends only";
  if (value === "private")
    return "Private";
  return "Public";
}
function matchesSelectedTags(itemTags, selectedTagIds) {
  if (selectedTagIds.size === 0)
    return true;
  const itemTagIds = new Set((itemTags ?? []).map((tag) => tag.id));
  return [...selectedTagIds].every((tagId) => itemTagIds.has(tagId));
}
export default function ExplorePanel({
  events,
  plans,
  mapCenter,
  selectedTagIds,
  tags,
  onClose,
  onSelectEvent,
  onSelectPlan,
  isLoggedIn,
  savedPlanIds,
  joinedEventIds,
  onSavePlan,
  onSubscribeEvent,
  onUnsubscribeEvent
}) {
  _s();
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [radiusKm, setRadiusKm] = useState(10);
  const [selectedItem, setSelectedItem] = useState(null);
  const [saveMessage, setSaveMessage] = useState("");
  const [updatingEventId, setUpdatingEventId] = useState(null);
  const activeTags = useMemo(
    () => tags.filter((tag) => selectedTagIds.has(tag.id)),
    [selectedTagIds, tags]
  );
  const handleSavePlan = (plan) => {
    const result = onSavePlan(plan);
    setSaveMessage(result.message);
  };
  const handleToggleEventSubscription = async (eventId) => {
    if (!isLoggedIn || updatingEventId)
      return;
    try {
      setUpdatingEventId(eventId);
      if (joinedEventIds.has(eventId)) {
        await onUnsubscribeEvent(eventId);
      } else {
        await onSubscribeEvent(eventId);
      }
    } finally {
      setUpdatingEventId(null);
    }
  };
  const results = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    const mixed = [
      ...typeFilter === "plans" ? [] : events.map((event) => ({
        type: "event",
        item: event,
        distanceKm: distanceKm(mapCenter, [event.lat, event.lng])
      })),
      ...typeFilter === "events" ? [] : plans.map((plan) => ({
        type: "plan",
        item: plan,
        distanceKm: distanceKm(mapCenter, [plan.lat, plan.lng])
      }))
    ];
    return mixed.filter(({ item }) => matchesSelectedTags(item.tags, selectedTagIds)).filter(({ item }) => {
      if (!normalizedQuery)
        return true;
      return [
        item.name,
        item.description ?? "",
        ...(item.tags ?? []).map((tag) => tag.name)
      ].some((value) => value.toLowerCase().includes(normalizedQuery));
    }).filter(({ distanceKm: distanceKm2 }) => distanceKm2 <= radiusKm).sort((a, b) => a.distanceKm - b.distanceKm || a.item.name.localeCompare(b.item.name));
  }, [events, mapCenter, plans, query, radiusKm, selectedTagIds, typeFilter]);
  return /* @__PURE__ */ jsxDEV("div", { className: "explore-backdrop", onClick: onClose, children: /* @__PURE__ */ jsxDEV("section", { className: "explore-panel", "aria-label": "Explore events and plans", onClick: (event) => event.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__header", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "explore-panel__eyebrow", children: "Browse nearby" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 169,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: "Explore events and plans" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 170,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Search the current map area using your active tag filters." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 171,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 168,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "explore-panel__close", onClick: onClose, "aria-label": "Close explore panel", children: "x" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 173,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
      lineNumber: 167,
      columnNumber: 17
    }, this),
    selectedItem ? /* @__PURE__ */ jsxDEV("div", { className: "explore-detail", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "explore-detail__back", onClick: () => {
        setSaveMessage("");
        setSelectedItem(null);
      }, children: "← Back to results" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 180,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "explore-detail__card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "explore-card__topline", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `explore-card__badge explore-card__badge--${selectedItem.type}`, children: [
            /* @__PURE__ */ jsxDEV("span", { className: "explore-card__icon", "aria-hidden": "true", children: getCategoryIcon(selectedItem.item.tags, selectedItem.type) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 189,
              columnNumber: 37
            }, this),
            selectedItem.type === "event" ? "Event" : "Plan"
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 188,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "explore-card__distance", children: [
            selectedItem.distanceKm.toFixed(1),
            "km away"
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 194,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 187,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: selectedItem.item.name }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 196,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: selectedItem.item.description ?? "No description yet." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 197,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "explore-card__meta", children: [
          /* @__PURE__ */ jsxDEV("span", { children: formatBudget(selectedItem.item.budget) }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 199,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatVisibility(selectedItem.item.visibility) }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 200,
            columnNumber: 33
          }, this),
          selectedItem.type === "event" && /* @__PURE__ */ jsxDEV("span", { children: formatEventTime(selectedItem.item.event_time) }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 201,
            columnNumber: 67
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 198,
          columnNumber: 29
        }, this),
        (selectedItem.item.tags?.length ?? 0) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "explore-card__tags", children: selectedItem.item.tags?.map(
          (tag) => /* @__PURE__ */ jsxDEV("span", { children: [
            "#",
            tag.name
          ] }, tag.id, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 206,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 204,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "explore-detail__actions", children: selectedItem.type === "event" ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "explore-detail__primary",
            onClick: () => {
              onSelectEvent(selectedItem.item.id);
              onClose();
            },
            children: "Open full event details"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 212,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "explore-detail__primary",
              onClick: () => {
                onSelectPlan([selectedItem.item.lat, selectedItem.item.lng]);
                onClose();
              },
              children: "Center on map"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 224,
              columnNumber: 41
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "explore-detail__secondary",
              onClick: () => handleSavePlan(selectedItem.item),
              disabled: !isLoggedIn || savedPlanIds.has(selectedItem.item.id),
              children: !isLoggedIn ? "Log in to save" : savedPlanIds.has(selectedItem.item.id) ? "Plan saved" : "Save plan"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 234,
              columnNumber: 41
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 223,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 210,
          columnNumber: 29
        }, this),
        saveMessage && /* @__PURE__ */ jsxDEV("div", { className: "explore-detail__message", children: saveMessage }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 249,
          columnNumber: 45
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 186,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
      lineNumber: 179,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__controls", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "explore-panel__search", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Search" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 256,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "search",
              value: query,
              onChange: (event) => setQuery(event.target.value),
              placeholder: "Search by name, tag, or description"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 257,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 255,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__segmented", "aria-label": "Type filter", children: ["all", "events", "plans"].map(
          (value) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: typeFilter === value ? "explore-panel__segment explore-panel__segment--active" : "explore-panel__segment",
              onClick: () => setTypeFilter(value),
              children: value === "all" ? "All" : value === "events" ? "Events" : "Plans"
            },
            value,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 266,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 264,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "explore-panel__radius", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Radius" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 277,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              min: 1,
              max: 100,
              value: radiusKm,
              onChange: (event) => setRadiusKm(Number(event.target.value) || 10)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 278,
              columnNumber: 33
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: "km" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 285,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 276,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 254,
        columnNumber: 25
      }, this),
      activeTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__active-tags", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Using filters:" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 291,
          columnNumber: 33
        }, this),
        activeTags.map(
          (tag) => /* @__PURE__ */ jsxDEV("strong", { children: [
            "#",
            tag.name
          ] }, tag.id, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
            lineNumber: 293,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 290,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__summary", children: [
        results.length,
        " result",
        results.length === 1 ? "" : "s",
        " within ",
        radiusKm,
        "km"
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 298,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__list", children: [
        results.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "explore-panel__empty", children: "No matching events or plans found in this radius." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
          lineNumber: 304,
          columnNumber: 13
        }, this),
        results.map((result) => {
          const { visibleTags, hiddenCount } = getVisibleTags(result.item.tags);
          return /* @__PURE__ */ jsxDEV(
            "article",
            {
              className: "explore-card",
              children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "explore-card__main",
                    onClick: () => {
                      setSaveMessage("");
                      setSelectedItem(result);
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "explore-card__topline", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: `explore-card__badge explore-card__badge--${result.type}`, children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "explore-card__icon", "aria-hidden": "true", children: getCategoryIcon(result.item.tags, result.type) }, void 0, false, {
                            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                            lineNumber: 325,
                            columnNumber: 53
                          }, this),
                          result.type === "event" ? "Event" : "Plan"
                        ] }, void 0, true, {
                          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                          lineNumber: 324,
                          columnNumber: 49
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "explore-card__distance", children: [
                          result.distanceKm.toFixed(1),
                          "km away"
                        ] }, void 0, true, {
                          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                          lineNumber: 330,
                          columnNumber: 49
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                        lineNumber: 323,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV("h3", { children: result.item.name }, void 0, false, {
                        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                        lineNumber: 332,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "explore-card__meta", children: [
                        /* @__PURE__ */ jsxDEV("span", { children: formatBudget(result.item.budget) }, void 0, false, {
                          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                          lineNumber: 334,
                          columnNumber: 45
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { children: formatVisibility(result.item.visibility) }, void 0, false, {
                          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                          lineNumber: 335,
                          columnNumber: 45
                        }, this),
                        result.type === "event" && /* @__PURE__ */ jsxDEV("span", { children: formatEventTime(result.item.event_time) }, void 0, false, {
                          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                          lineNumber: 336,
                          columnNumber: 73
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                        lineNumber: 333,
                        columnNumber: 45
                      }, this),
                      visibleTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "explore-card__tags", children: [
                        visibleTags.map(
                          (tag) => /* @__PURE__ */ jsxDEV("span", { children: [
                            "#",
                            tag.name
                          ] }, tag.id, true, {
                            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                            lineNumber: 341,
                            columnNumber: 23
                          }, this)
                        ),
                        hiddenCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "explore-card__tag-more", children: [
                          "+",
                          hiddenCount,
                          " more"
                        ] }, void 0, true, {
                          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                          lineNumber: 343,
                          columnNumber: 73
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                        lineNumber: 339,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                    lineNumber: 315,
                    columnNumber: 41
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "explore-card__actions", children: result.type === "event" ? /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "explore-card__action explore-card__action--event",
                    onClick: () => handleToggleEventSubscription(result.item.id),
                    disabled: !isLoggedIn || updatingEventId === result.item.id,
                    children: !isLoggedIn ? "Log in to subscribe" : updatingEventId === result.item.id ? "Updating..." : joinedEventIds.has(result.item.id) ? "Unsubscribe" : "Subscribe"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                    lineNumber: 349,
                    columnNumber: 21
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "explore-card__action explore-card__action--plan",
                    onClick: () => handleSavePlan(result.item),
                    disabled: !isLoggedIn || savedPlanIds.has(result.item.id),
                    children: !isLoggedIn ? "Log in to save" : savedPlanIds.has(result.item.id) ? "Saved" : "Save plan"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                    lineNumber: 364,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
                  lineNumber: 347,
                  columnNumber: 41
                }, this)
              ]
            },
            `${result.type}-${result.item.id}`,
            true,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
              lineNumber: 311,
              columnNumber: 17
            },
            this
          );
        })
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
        lineNumber: 302,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
      lineNumber: 253,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
    lineNumber: 166,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx",
    lineNumber: 165,
    columnNumber: 5
  }, this);
}
_s(ExplorePanel, "G5uvnF67FChE52Oc9oaTM7Dy5+w=");
_c = ExplorePanel;
var _c;
$RefreshReg$(_c, "ExplorePanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ExplorePanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUp3QixTQXNEWSxVQXREWjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFySnhCLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUVsQyxTQUFTQyxpQkFBaUJDLHNCQUFzQjtBQXVCaEQsTUFBTUMsa0JBQWtCO0FBRXhCLFNBQVNDLFVBQVVDLE9BQWU7QUFDOUIsU0FBT0EsUUFBUUMsS0FBS0MsS0FBSztBQUM3QjtBQUVBLFNBQVNDLFdBQVdDLE1BQXdCQyxJQUFzQjtBQUM5RCxRQUFNQyxPQUFPUCxVQUFVTSxHQUFHLENBQUMsSUFBSUQsS0FBSyxDQUFDLENBQUM7QUFDdEMsUUFBTUcsT0FBT1IsVUFBVU0sR0FBRyxDQUFDLElBQUlELEtBQUssQ0FBQyxDQUFDO0FBQ3RDLFFBQU1JLE9BQU9ULFVBQVVLLEtBQUssQ0FBQyxDQUFDO0FBQzlCLFFBQU1LLE9BQU9WLFVBQVVNLEdBQUcsQ0FBQyxDQUFDO0FBQzVCLFFBQU1LLElBQUlULEtBQUtVLElBQUlMLE9BQU8sQ0FBQyxLQUFLLElBQzFCTCxLQUFLVyxJQUFJSixJQUFJLElBQUlQLEtBQUtXLElBQUlILElBQUksSUFBSVIsS0FBS1UsSUFBSUosT0FBTyxDQUFDLEtBQUs7QUFDOUQsU0FBTyxJQUFJVCxrQkFBa0JHLEtBQUtZLE1BQU1aLEtBQUthLEtBQUtKLENBQUMsR0FBR1QsS0FBS2EsS0FBSyxJQUFJSixDQUFDLENBQUM7QUFDMUU7QUFFQSxTQUFTSyxhQUFhQyxRQUF1QjtBQUN6QyxTQUFPQSxVQUFVLE9BQU8sbUJBQW1CLElBQUlBLE9BQU9DLFFBQVEsQ0FBQyxDQUFDO0FBQ3BFO0FBRUEsU0FBU0MsZ0JBQWdCQyxLQUFhO0FBQ2xDLFNBQU8sSUFBSUMsS0FBS0QsR0FBRyxFQUFFRSxlQUFlLFNBQVM7QUFBQSxJQUN6Q0MsU0FBUztBQUFBLElBQ1RDLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxFQUNaLENBQUM7QUFDTDtBQUVBLFNBQVNDLGlCQUFpQjNCLE9BQXVEO0FBQzdFLE1BQUlBLFVBQVU7QUFBVyxXQUFPO0FBQ2hDLE1BQUlBLFVBQVU7QUFBVyxXQUFPO0FBQ2hDLFNBQU87QUFDWDtBQUVBLFNBQVM0QixvQkFBb0JDLFVBQTZCQyxnQkFBNkI7QUFDbkYsTUFBSUEsZUFBZUMsU0FBUztBQUFHLFdBQU87QUFDdEMsUUFBTUMsYUFBYSxJQUFJQyxLQUFLSixZQUFZLElBQUlLLElBQUksQ0FBQ0MsUUFBUUEsSUFBSUMsRUFBRSxDQUFDO0FBQ2hFLFNBQU8sQ0FBQyxHQUFHTixjQUFjLEVBQUVPLE1BQU0sQ0FBQ0MsVUFBVU4sV0FBV08sSUFBSUQsS0FBSyxDQUFDO0FBQ3JFO0FBRUEsd0JBQXdCRSxhQUFhO0FBQUEsRUFDakNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FiO0FBQUFBLEVBQ0FjO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2UsR0FBRztBQUFBQyxLQUFBO0FBQ2xCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJN0QsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzhELFlBQVlDLGFBQWEsSUFBSS9ELFNBQXFDLEtBQUs7QUFDOUUsUUFBTSxDQUFDZ0UsVUFBVUMsV0FBVyxJQUFJakUsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2tFLGNBQWNDLGVBQWUsSUFBSW5FLFNBQTZCLElBQUk7QUFDekUsUUFBTSxDQUFDb0UsYUFBYUMsY0FBYyxJQUFJckUsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3NFLGlCQUFpQkMsa0JBQWtCLElBQUl2RSxTQUF3QixJQUFJO0FBRTFFLFFBQU13RSxhQUFhekU7QUFBQUEsSUFDZixNQUFNa0QsS0FBS3dCLE9BQU8sQ0FBQ2pDLFFBQVFMLGVBQWVTLElBQUlKLElBQUlDLEVBQUUsQ0FBQztBQUFBLElBQ3JELENBQUNOLGdCQUFnQmMsSUFBSTtBQUFBLEVBQ3pCO0FBRUEsUUFBTXlCLGlCQUFpQkEsQ0FBQ0MsU0FBa0I7QUFDdEMsVUFBTUMsU0FBU3BCLFdBQVdtQixJQUFJO0FBQzlCTixtQkFBZU8sT0FBT0MsT0FBTztBQUFBLEVBQ2pDO0FBRUEsUUFBTUMsZ0NBQWdDLE9BQU9DLFlBQW9CO0FBQzdELFFBQUksQ0FBQzFCLGNBQWNpQjtBQUFpQjtBQUVwQyxRQUFJO0FBQ0FDLHlCQUFtQlEsT0FBTztBQUMxQixVQUFJeEIsZUFBZVgsSUFBSW1DLE9BQU8sR0FBRztBQUM3QixjQUFNckIsbUJBQW1CcUIsT0FBTztBQUFBLE1BQ3BDLE9BQU87QUFDSCxjQUFNdEIsaUJBQWlCc0IsT0FBTztBQUFBLE1BQ2xDO0FBQUEsSUFDSixVQUFDO0FBQ0dSLHlCQUFtQixJQUFJO0FBQUEsSUFDM0I7QUFBQSxFQUNKO0FBRUEsUUFBTVMsVUFBVWpGLFFBQVEsTUFBTTtBQUMxQixVQUFNa0Ysa0JBQWtCckIsTUFBTXNCLEtBQUssRUFBRUMsWUFBWTtBQUNqRCxVQUFNQyxRQUF1QjtBQUFBLE1BQ3pCLEdBQUl0QixlQUFlLFVBQVUsS0FBS2hCLE9BQU9QLElBQUksQ0FBQzhDLFdBQVc7QUFBQSxRQUNyREMsTUFBTTtBQUFBLFFBQ05DLE1BQU1GO0FBQUFBLFFBQ043RSxZQUFZQSxXQUFXd0MsV0FBVyxDQUFDcUMsTUFBTUcsS0FBS0gsTUFBTUksR0FBRyxDQUFDO0FBQUEsTUFDNUQsRUFBRTtBQUFBLE1BQ0YsR0FBSTNCLGVBQWUsV0FBVyxLQUFLZixNQUFNUixJQUFJLENBQUNvQyxVQUFVO0FBQUEsUUFDcERXLE1BQU07QUFBQSxRQUNOQyxNQUFNWjtBQUFBQSxRQUNObkUsWUFBWUEsV0FBV3dDLFdBQVcsQ0FBQzJCLEtBQUthLEtBQUtiLEtBQUtjLEdBQUcsQ0FBQztBQUFBLE1BQzFELEVBQUU7QUFBQSxJQUFFO0FBR1IsV0FBT0wsTUFDRlgsT0FBTyxDQUFDLEVBQUVjLEtBQUssTUFBTXRELG9CQUFvQnNELEtBQUt0QyxNQUFNZCxjQUFjLENBQUMsRUFDbkVzQyxPQUFPLENBQUMsRUFBRWMsS0FBSyxNQUFNO0FBQ2xCLFVBQUksQ0FBQ047QUFBaUIsZUFBTztBQUM3QixhQUFPO0FBQUEsUUFDSE0sS0FBS0c7QUFBQUEsUUFDTEgsS0FBS0ksZUFBZTtBQUFBLFFBQ3BCLElBQUlKLEtBQUt0QyxRQUFRLElBQUlWLElBQUksQ0FBQ0MsUUFBUUEsSUFBSWtELElBQUk7QUFBQSxNQUFDLEVBQzdDRSxLQUFLLENBQUN2RixVQUFVQSxNQUFNOEUsWUFBWSxFQUFFVSxTQUFTWixlQUFlLENBQUM7QUFBQSxJQUNuRSxDQUFDLEVBQ0FSLE9BQU8sQ0FBQyxFQUFFakUsd0JBQVcsTUFBTUEsZUFBY3dELFFBQVEsRUFDakQ4QixLQUFLLENBQUMvRSxHQUFHZ0YsTUFBTWhGLEVBQUVQLGFBQWF1RixFQUFFdkYsY0FBY08sRUFBRXdFLEtBQUtHLEtBQUtNLGNBQWNELEVBQUVSLEtBQUtHLElBQUksQ0FBQztBQUFBLEVBQzdGLEdBQUcsQ0FBQzVDLFFBQVFFLFdBQVdELE9BQU9hLE9BQU9JLFVBQVU3QixnQkFBZ0IyQixVQUFVLENBQUM7QUFFMUUsU0FDSSx1QkFBQyxTQUFJLFdBQVUsb0JBQW1CLFNBQVNaLFNBQ3ZDLGlDQUFDLGFBQVEsV0FBVSxpQkFBZ0IsY0FBVyw0QkFBMkIsU0FBUyxDQUFDbUMsVUFBVUEsTUFBTVksZ0JBQWdCLEdBQy9HO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsNkJBQUMsU0FDRztBQUFBLCtCQUFDLFVBQUssV0FBVSwwQkFBeUIsNkJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUN0RCx1QkFBQyxRQUFHLHdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxPQUFFLDBFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQUhqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsd0JBQXVCLFNBQVMvQyxTQUFTLGNBQVcsdUJBQXNCLGlCQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUNnQixlQUNHLHVCQUFDLFNBQUksV0FBVSxrQkFDWDtBQUFBLDZCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsd0JBQXVCLFNBQVMsTUFBTTtBQUNsRUcsdUJBQWUsRUFBRTtBQUNqQkYsd0JBQWdCLElBQUk7QUFBQSxNQUN4QixHQUFHLGlDQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXLDRDQUE0Q0QsYUFBYW9CLElBQUksSUFDMUU7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0JBQXFCLGVBQVksUUFDNUNyRiwwQkFBZ0JpRSxhQUFhcUIsS0FBS3RDLE1BQU1pQixhQUFhb0IsSUFBSSxLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ3BCLGFBQWFvQixTQUFTLFVBQVUsVUFBVTtBQUFBLGVBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSwwQkFBMEJwQjtBQUFBQSx5QkFBYTFELFdBQVdjLFFBQVEsQ0FBQztBQUFBLFlBQUU7QUFBQSxlQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLGFBUHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSTRDLHVCQUFhcUIsS0FBS0csUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzVCLHVCQUFDLE9BQUd4Qix1QkFBYXFCLEtBQUtJLGVBQWUseUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRCx1QkFBQyxTQUFJLFdBQVUsc0JBQ1g7QUFBQSxpQ0FBQyxVQUFNdkUsdUJBQWE4QyxhQUFhcUIsS0FBS2xFLE1BQU0sS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxVQUFNVywyQkFBaUJrQyxhQUFhcUIsS0FBS1csVUFBVSxLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3JEaEMsYUFBYW9CLFNBQVMsV0FBVyx1QkFBQyxVQUFNL0QsMEJBQWdCMkMsYUFBYXFCLEtBQUtZLFVBQVUsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxhQUgzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxTQUNFakMsYUFBYXFCLEtBQUt0QyxNQUFNbUQsVUFBVSxLQUFLLEtBQ3JDLHVCQUFDLFNBQUksV0FBVSxzQkFDVmxDLHVCQUFhcUIsS0FBS3RDLE1BQU1WO0FBQUFBLFVBQUksQ0FBQ0MsUUFDMUIsdUJBQUMsVUFBa0I7QUFBQTtBQUFBLFlBQUVBLElBQUlrRDtBQUFBQSxlQUFkbEQsSUFBSUMsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFFBQ2pDLEtBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFSix1QkFBQyxTQUFJLFdBQVUsMkJBQ1Z5Qix1QkFBYW9CLFNBQVMsVUFDbkI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTTtBQUNYbkMsNEJBQWNlLGFBQWFxQixLQUFLOUMsRUFBRTtBQUNsQ1Msc0JBQVE7QUFBQSxZQUNaO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQSxJQUVBLG1DQUNJO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTTtBQUNYRSw2QkFBYSxDQUFDYyxhQUFhcUIsS0FBS0MsS0FBS3RCLGFBQWFxQixLQUFLRSxHQUFHLENBQUM7QUFDM0R2Qyx3QkFBUTtBQUFBLGNBQ1o7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNd0IsZUFBZVIsYUFBYXFCLElBQUk7QUFBQSxjQUMvQyxVQUFVLENBQUNsQyxjQUFjQyxhQUFhVixJQUFJc0IsYUFBYXFCLEtBQUs5QyxFQUFFO0FBQUEsY0FFN0QsV0FBQ1ksYUFDSSxtQkFDQUMsYUFBYVYsSUFBSXNCLGFBQWFxQixLQUFLOUMsRUFBRSxJQUNqQyxlQUNBO0FBQUE7QUFBQSxZQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsYUF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQSxLQXBDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0NBO0FBQUEsUUFDQzJCLGVBQWUsdUJBQUMsU0FBSSxXQUFVLDJCQUEyQkEseUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxXQS9EMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdFQTtBQUFBLFNBdkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3RUEsSUFFQSxtQ0FDSTtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSx5QkFDYjtBQUFBLGlDQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLFVBQ1o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLE9BQU9SO0FBQUFBLGNBQ1AsVUFBVSxDQUFDeUIsVUFBVXhCLFNBQVN3QixNQUFNZ0IsT0FBT2hHLEtBQUs7QUFBQSxjQUNoRCxhQUFZO0FBQUE7QUFBQSxZQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJcUQ7QUFBQSxhQU56RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw0QkFBMkIsY0FBVyxlQUMvQyxXQUFDLE9BQU8sVUFBVSxPQUFPLEVBQVlrQztBQUFBQSxVQUFJLENBQUNsQyxVQUN4QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsTUFBSztBQUFBLGNBQ0wsV0FBV3lELGVBQWV6RCxRQUFRLDBEQUEwRDtBQUFBLGNBQzVGLFNBQVMsTUFBTTBELGNBQWMxRCxLQUFLO0FBQUEsY0FFakNBLG9CQUFVLFFBQVEsUUFBUUEsVUFBVSxXQUFXLFdBQVc7QUFBQTtBQUFBLFlBTHREQTtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFFBQ0gsS0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSx5QkFDYjtBQUFBLGlDQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLFVBQ1o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLEtBQUs7QUFBQSxjQUNMLEtBQUs7QUFBQSxjQUNMLE9BQU8yRDtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3FCLFVBQVVwQixZQUFZcUMsT0FBT2pCLE1BQU1nQixPQUFPaEcsS0FBSyxLQUFLLEVBQUU7QUFBQTtBQUFBLFlBTHJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt1RTtBQUFBLFVBRXZFLHVCQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLGFBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLE1BRUNtRSxXQUFXNEIsU0FBUyxLQUNqQix1QkFBQyxTQUFJLFdBQVUsOEJBQ1g7QUFBQSwrQkFBQyxVQUFLLDhCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUNuQjVCLFdBQVdqQztBQUFBQSxVQUFJLENBQUNDLFFBQ2IsdUJBQUMsWUFBb0I7QUFBQTtBQUFBLFlBQUVBLElBQUlrRDtBQUFBQSxlQUFkbEQsSUFBSUMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxRQUNuQztBQUFBLFdBSkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFHSix1QkFBQyxTQUFJLFdBQVUsMEJBQ1Z1QztBQUFBQSxnQkFBUW9CO0FBQUFBLFFBQU87QUFBQSxRQUFRcEIsUUFBUW9CLFdBQVcsSUFBSSxLQUFLO0FBQUEsUUFBSTtBQUFBLFFBQVNwQztBQUFBQSxRQUFTO0FBQUEsV0FEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1ZnQjtBQUFBQSxnQkFBUW9CLFdBQVcsS0FDaEIsdUJBQUMsU0FBSSxXQUFVLHdCQUF1QixpRUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFSHBCLFFBQVF6QyxJQUFJLENBQUNxQyxXQUFXO0FBQ3JCLGdCQUFNLEVBQUUyQixhQUFhQyxZQUFZLElBQUl0RyxlQUFlMEUsT0FBT1csS0FBS3RDLElBQUk7QUFDcEUsaUJBQ0k7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVHLFdBQVU7QUFBQSxjQUVWO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU07QUFDWG9CLHFDQUFlLEVBQUU7QUFDakJGLHNDQUFnQlMsTUFBTTtBQUFBLG9CQUMxQjtBQUFBLG9CQUVBO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsK0NBQUMsVUFBSyxXQUFXLDRDQUE0Q0EsT0FBT1UsSUFBSSxJQUNwRTtBQUFBLGlEQUFDLFVBQUssV0FBVSxzQkFBcUIsZUFBWSxRQUM1Q3JGLDBCQUFnQjJFLE9BQU9XLEtBQUt0QyxNQUFNMkIsT0FBT1UsSUFBSSxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0NWLE9BQU9VLFNBQVMsVUFBVSxVQUFVO0FBQUEsNkJBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0E7QUFBQSx3QkFDQSx1QkFBQyxVQUFLLFdBQVUsMEJBQTBCVjtBQUFBQSxpQ0FBT3BFLFdBQVdjLFFBQVEsQ0FBQztBQUFBLDBCQUFFO0FBQUEsNkJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQThFO0FBQUEsMkJBUGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBUUE7QUFBQSxzQkFDQSx1QkFBQyxRQUFJc0QsaUJBQU9XLEtBQUtHLFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNCO0FBQUEsc0JBQ3RCLHVCQUFDLFNBQUksV0FBVSxzQkFDZjtBQUFBLCtDQUFDLFVBQU10RSx1QkFBYXdELE9BQU9XLEtBQUtsRSxNQUFNLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXdDO0FBQUEsd0JBQ3hDLHVCQUFDLFVBQU1XLDJCQUFpQjRDLE9BQU9XLEtBQUtXLFVBQVUsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0Q7QUFBQSx3QkFDL0N0QixPQUFPVSxTQUFTLFdBQVcsdUJBQUMsVUFBTS9ELDBCQUFnQnFELE9BQU9XLEtBQUtZLFVBQVUsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0M7QUFBQSwyQkFIM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJSjtBQUFBLHNCQUNLSSxZQUFZSCxTQUFTLEtBQ2xCLHVCQUFDLFNBQUksV0FBVSxzQkFDVkc7QUFBQUEsb0NBQVloRTtBQUFBQSwwQkFBSSxDQUFDQyxRQUNkLHVCQUFDLFVBQWtCO0FBQUE7QUFBQSw0QkFBRUEsSUFBSWtEO0FBQUFBLCtCQUFkbEQsSUFBSUMsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE4QjtBQUFBLHdCQUNqQztBQUFBLHdCQUNBK0QsY0FBYyxLQUFLLHVCQUFDLFVBQUssV0FBVSwwQkFBeUI7QUFBQTtBQUFBLDBCQUFFQTtBQUFBQSwwQkFBWTtBQUFBLDZCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0RDtBQUFBLDJCQUpwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUE7QUFBQTtBQUFBLGtCQTdCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBK0JBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNkNUIsaUJBQU9VLFNBQVMsVUFDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLFNBQVMsTUFBTVIsOEJBQThCRixPQUFPVyxLQUFLOUMsRUFBRTtBQUFBLG9CQUMzRCxVQUFVLENBQUNZLGNBQWNpQixvQkFBb0JNLE9BQU9XLEtBQUs5QztBQUFBQSxvQkFFeEQsV0FBQ1ksYUFDSSx3QkFDQWlCLG9CQUFvQk0sT0FBT1csS0FBSzlDLEtBQzVCLGdCQUNBYyxlQUFlWCxJQUFJZ0MsT0FBT1csS0FBSzlDLEVBQUUsSUFDN0IsZ0JBQ0E7QUFBQTtBQUFBLGtCQVpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYUEsSUFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLFNBQVMsTUFBTWlDLGVBQWVFLE9BQU9XLElBQUk7QUFBQSxvQkFDekMsVUFBVSxDQUFDbEMsY0FBY0MsYUFBYVYsSUFBSWdDLE9BQU9XLEtBQUs5QyxFQUFFO0FBQUEsb0JBRXZELFdBQUNZLGFBQWEsbUJBQW1CQyxhQUFhVixJQUFJZ0MsT0FBT1csS0FBSzlDLEVBQUUsSUFBSSxVQUFVO0FBQUE7QUFBQSxrQkFObkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BLEtBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEJBO0FBQUE7QUFBQTtBQUFBLFlBN0RLLEdBQUdtQyxPQUFPVSxJQUFJLElBQUlWLE9BQU9XLEtBQUs5QyxFQUFFO0FBQUEsWUFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQStEQTtBQUFBLFFBRVIsQ0FBQztBQUFBLFdBMUVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyRUE7QUFBQSxTQTVISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkhBO0FBQUEsT0FwTlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNOQSxLQXZOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd05BO0FBRVI7QUFBQ2tCLEdBeFN1QmQsY0FBWTtBQUFBLEtBQVpBO0FBQVksSUFBQTREO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJ1c2VTdGF0ZSIsImdldENhdGVnb3J5SWNvbiIsImdldFZpc2libGVUYWdzIiwiRUFSVEhfUkFESVVTX0tNIiwidG9SYWRpYW5zIiwidmFsdWUiLCJNYXRoIiwiUEkiLCJkaXN0YW5jZUttIiwiZnJvbSIsInRvIiwiZExhdCIsImRMbmciLCJsYXQxIiwibGF0MiIsImEiLCJzaW4iLCJjb3MiLCJhdGFuMiIsInNxcnQiLCJmb3JtYXRCdWRnZXQiLCJidWRnZXQiLCJ0b0ZpeGVkIiwiZm9ybWF0RXZlbnRUaW1lIiwiaXNvIiwiRGF0ZSIsInRvTG9jYWxlU3RyaW5nIiwid2Vla2RheSIsImRheSIsIm1vbnRoIiwiaG91ciIsIm1pbnV0ZSIsImZvcm1hdFZpc2liaWxpdHkiLCJtYXRjaGVzU2VsZWN0ZWRUYWdzIiwiaXRlbVRhZ3MiLCJzZWxlY3RlZFRhZ0lkcyIsInNpemUiLCJpdGVtVGFnSWRzIiwiU2V0IiwibWFwIiwidGFnIiwiaWQiLCJldmVyeSIsInRhZ0lkIiwiaGFzIiwiRXhwbG9yZVBhbmVsIiwiZXZlbnRzIiwicGxhbnMiLCJtYXBDZW50ZXIiLCJ0YWdzIiwib25DbG9zZSIsIm9uU2VsZWN0RXZlbnQiLCJvblNlbGVjdFBsYW4iLCJpc0xvZ2dlZEluIiwic2F2ZWRQbGFuSWRzIiwiam9pbmVkRXZlbnRJZHMiLCJvblNhdmVQbGFuIiwib25TdWJzY3JpYmVFdmVudCIsIm9uVW5zdWJzY3JpYmVFdmVudCIsIl9zIiwicXVlcnkiLCJzZXRRdWVyeSIsInR5cGVGaWx0ZXIiLCJzZXRUeXBlRmlsdGVyIiwicmFkaXVzS20iLCJzZXRSYWRpdXNLbSIsInNlbGVjdGVkSXRlbSIsInNldFNlbGVjdGVkSXRlbSIsInNhdmVNZXNzYWdlIiwic2V0U2F2ZU1lc3NhZ2UiLCJ1cGRhdGluZ0V2ZW50SWQiLCJzZXRVcGRhdGluZ0V2ZW50SWQiLCJhY3RpdmVUYWdzIiwiZmlsdGVyIiwiaGFuZGxlU2F2ZVBsYW4iLCJwbGFuIiwicmVzdWx0IiwibWVzc2FnZSIsImhhbmRsZVRvZ2dsZUV2ZW50U3Vic2NyaXB0aW9uIiwiZXZlbnRJZCIsInJlc3VsdHMiLCJub3JtYWxpemVkUXVlcnkiLCJ0cmltIiwidG9Mb3dlckNhc2UiLCJtaXhlZCIsImV2ZW50IiwidHlwZSIsIml0ZW0iLCJsYXQiLCJsbmciLCJuYW1lIiwiZGVzY3JpcHRpb24iLCJzb21lIiwiaW5jbHVkZXMiLCJzb3J0IiwiYiIsImxvY2FsZUNvbXBhcmUiLCJzdG9wUHJvcGFnYXRpb24iLCJ2aXNpYmlsaXR5IiwiZXZlbnRfdGltZSIsImxlbmd0aCIsInRhcmdldCIsIk51bWJlciIsInZpc2libGVUYWdzIiwiaGlkZGVuQ291bnQiLCJfYyJdLCJzb3VyY2VzIjpbIkV4cGxvcmVQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBBcGlFdmVudCwgQXBpUGxhbiwgVGFnIH0gZnJvbSAnLi9hcGknXHJcbmltcG9ydCB7IGdldENhdGVnb3J5SWNvbiwgZ2V0VmlzaWJsZVRhZ3MgfSBmcm9tICcuL2NhdGVnb3J5SWNvbnMnXHJcblxyXG50eXBlIEV4cGxvcmVJdGVtID1cclxuICAgIHwgeyB0eXBlOiAnZXZlbnQnOyBpdGVtOiBBcGlFdmVudDsgZGlzdGFuY2VLbTogbnVtYmVyIH1cclxuICAgIHwgeyB0eXBlOiAncGxhbic7IGl0ZW06IEFwaVBsYW47IGRpc3RhbmNlS206IG51bWJlciB9XHJcblxyXG50eXBlIEV4cGxvcmVQYW5lbFByb3BzID0ge1xyXG4gICAgZXZlbnRzOiBBcGlFdmVudFtdXHJcbiAgICBwbGFuczogQXBpUGxhbltdXHJcbiAgICBtYXBDZW50ZXI6IFtudW1iZXIsIG51bWJlcl1cclxuICAgIHNlbGVjdGVkVGFnSWRzOiBTZXQ8bnVtYmVyPlxyXG4gICAgdGFnczogVGFnW11cclxuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWRcclxuICAgIG9uU2VsZWN0RXZlbnQ6IChldmVudElkOiBzdHJpbmcpID0+IHZvaWRcclxuICAgIG9uU2VsZWN0UGxhbjogKHBvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdKSA9PiB2b2lkXHJcbiAgICBpc0xvZ2dlZEluOiBib29sZWFuXHJcbiAgICBzYXZlZFBsYW5JZHM6IFNldDxzdHJpbmc+XHJcbiAgICBqb2luZWRFdmVudElkczogU2V0PHN0cmluZz5cclxuICAgIG9uU2F2ZVBsYW46IChwbGFuOiBBcGlQbGFuKSA9PiB7IHNhdmVkOiBib29sZWFuOyBtZXNzYWdlOiBzdHJpbmcgfVxyXG4gICAgb25TdWJzY3JpYmVFdmVudDogKGV2ZW50SWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxyXG4gICAgb25VbnN1YnNjcmliZUV2ZW50OiAoZXZlbnRJZDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+XHJcbn1cclxuXHJcbmNvbnN0IEVBUlRIX1JBRElVU19LTSA9IDYzNzFcclxuXHJcbmZ1bmN0aW9uIHRvUmFkaWFucyh2YWx1ZTogbnVtYmVyKSB7XHJcbiAgICByZXR1cm4gdmFsdWUgKiBNYXRoLlBJIC8gMTgwXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRpc3RhbmNlS20oZnJvbTogW251bWJlciwgbnVtYmVyXSwgdG86IFtudW1iZXIsIG51bWJlcl0pIHtcclxuICAgIGNvbnN0IGRMYXQgPSB0b1JhZGlhbnModG9bMF0gLSBmcm9tWzBdKVxyXG4gICAgY29uc3QgZExuZyA9IHRvUmFkaWFucyh0b1sxXSAtIGZyb21bMV0pXHJcbiAgICBjb25zdCBsYXQxID0gdG9SYWRpYW5zKGZyb21bMF0pXHJcbiAgICBjb25zdCBsYXQyID0gdG9SYWRpYW5zKHRvWzBdKVxyXG4gICAgY29uc3QgYSA9IE1hdGguc2luKGRMYXQgLyAyKSAqKiAyXHJcbiAgICAgICAgKyBNYXRoLmNvcyhsYXQxKSAqIE1hdGguY29zKGxhdDIpICogTWF0aC5zaW4oZExuZyAvIDIpICoqIDJcclxuICAgIHJldHVybiAyICogRUFSVEhfUkFESVVTX0tNICogTWF0aC5hdGFuMihNYXRoLnNxcnQoYSksIE1hdGguc3FydCgxIC0gYSkpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdEJ1ZGdldChidWRnZXQ6IG51bWJlciB8IG51bGwpIHtcclxuICAgIHJldHVybiBidWRnZXQgPT0gbnVsbCA/ICdCdWRnZXQgbm90IHNldCcgOiBg4oKsJHtidWRnZXQudG9GaXhlZCgyKX1gXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdEV2ZW50VGltZShpc286IHN0cmluZykge1xyXG4gICAgcmV0dXJuIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgIHdlZWtkYXk6ICdzaG9ydCcsXHJcbiAgICAgICAgZGF5OiAnbnVtZXJpYycsXHJcbiAgICAgICAgbW9udGg6ICdzaG9ydCcsXHJcbiAgICAgICAgaG91cjogJzItZGlnaXQnLFxyXG4gICAgICAgIG1pbnV0ZTogJzItZGlnaXQnLFxyXG4gICAgfSlcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0VmlzaWJpbGl0eSh2YWx1ZTogQXBpRXZlbnRbJ3Zpc2liaWxpdHknXSB8IEFwaVBsYW5bJ3Zpc2liaWxpdHknXSkge1xyXG4gICAgaWYgKHZhbHVlID09PSAnZnJpZW5kcycpIHJldHVybiAnRnJpZW5kcyBvbmx5J1xyXG4gICAgaWYgKHZhbHVlID09PSAncHJpdmF0ZScpIHJldHVybiAnUHJpdmF0ZSdcclxuICAgIHJldHVybiAnUHVibGljJ1xyXG59XHJcblxyXG5mdW5jdGlvbiBtYXRjaGVzU2VsZWN0ZWRUYWdzKGl0ZW1UYWdzOiBUYWdbXSB8IHVuZGVmaW5lZCwgc2VsZWN0ZWRUYWdJZHM6IFNldDxudW1iZXI+KSB7XHJcbiAgICBpZiAoc2VsZWN0ZWRUYWdJZHMuc2l6ZSA9PT0gMCkgcmV0dXJuIHRydWVcclxuICAgIGNvbnN0IGl0ZW1UYWdJZHMgPSBuZXcgU2V0KChpdGVtVGFncyA/PyBbXSkubWFwKCh0YWcpID0+IHRhZy5pZCkpXHJcbiAgICByZXR1cm4gWy4uLnNlbGVjdGVkVGFnSWRzXS5ldmVyeSgodGFnSWQpID0+IGl0ZW1UYWdJZHMuaGFzKHRhZ0lkKSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRXhwbG9yZVBhbmVsKHtcclxuICAgIGV2ZW50cyxcclxuICAgIHBsYW5zLFxyXG4gICAgbWFwQ2VudGVyLFxyXG4gICAgc2VsZWN0ZWRUYWdJZHMsXHJcbiAgICB0YWdzLFxyXG4gICAgb25DbG9zZSxcclxuICAgIG9uU2VsZWN0RXZlbnQsXHJcbiAgICBvblNlbGVjdFBsYW4sXHJcbiAgICBpc0xvZ2dlZEluLFxyXG4gICAgc2F2ZWRQbGFuSWRzLFxyXG4gICAgam9pbmVkRXZlbnRJZHMsXHJcbiAgICBvblNhdmVQbGFuLFxyXG4gICAgb25TdWJzY3JpYmVFdmVudCxcclxuICAgIG9uVW5zdWJzY3JpYmVFdmVudCxcclxufTogRXhwbG9yZVBhbmVsUHJvcHMpIHtcclxuICAgIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoJycpXHJcbiAgICBjb25zdCBbdHlwZUZpbHRlciwgc2V0VHlwZUZpbHRlcl0gPSB1c2VTdGF0ZTwnYWxsJyB8ICdldmVudHMnIHwgJ3BsYW5zJz4oJ2FsbCcpXHJcbiAgICBjb25zdCBbcmFkaXVzS20sIHNldFJhZGl1c0ttXSA9IHVzZVN0YXRlKDEwKVxyXG4gICAgY29uc3QgW3NlbGVjdGVkSXRlbSwgc2V0U2VsZWN0ZWRJdGVtXSA9IHVzZVN0YXRlPEV4cGxvcmVJdGVtIHwgbnVsbD4obnVsbClcclxuICAgIGNvbnN0IFtzYXZlTWVzc2FnZSwgc2V0U2F2ZU1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXHJcbiAgICBjb25zdCBbdXBkYXRpbmdFdmVudElkLCBzZXRVcGRhdGluZ0V2ZW50SWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcclxuXHJcbiAgICBjb25zdCBhY3RpdmVUYWdzID0gdXNlTWVtbyhcclxuICAgICAgICAoKSA9PiB0YWdzLmZpbHRlcigodGFnKSA9PiBzZWxlY3RlZFRhZ0lkcy5oYXModGFnLmlkKSksXHJcbiAgICAgICAgW3NlbGVjdGVkVGFnSWRzLCB0YWdzXSxcclxuICAgIClcclxuXHJcbiAgICBjb25zdCBoYW5kbGVTYXZlUGxhbiA9IChwbGFuOiBBcGlQbGFuKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gb25TYXZlUGxhbihwbGFuKVxyXG4gICAgICAgIHNldFNhdmVNZXNzYWdlKHJlc3VsdC5tZXNzYWdlKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVRvZ2dsZUV2ZW50U3Vic2NyaXB0aW9uID0gYXN5bmMgKGV2ZW50SWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGlmICghaXNMb2dnZWRJbiB8fCB1cGRhdGluZ0V2ZW50SWQpIHJldHVyblxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRVcGRhdGluZ0V2ZW50SWQoZXZlbnRJZClcclxuICAgICAgICAgICAgaWYgKGpvaW5lZEV2ZW50SWRzLmhhcyhldmVudElkKSkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgb25VbnN1YnNjcmliZUV2ZW50KGV2ZW50SWQpXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBvblN1YnNjcmliZUV2ZW50KGV2ZW50SWQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRVcGRhdGluZ0V2ZW50SWQobnVsbClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVzdWx0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRRdWVyeSA9IHF1ZXJ5LnRyaW0oKS50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgY29uc3QgbWl4ZWQ6IEV4cGxvcmVJdGVtW10gPSBbXHJcbiAgICAgICAgICAgIC4uLih0eXBlRmlsdGVyID09PSAncGxhbnMnID8gW10gOiBldmVudHMubWFwKChldmVudCkgPT4gKHtcclxuICAgICAgICAgICAgICAgIHR5cGU6ICdldmVudCcgYXMgY29uc3QsXHJcbiAgICAgICAgICAgICAgICBpdGVtOiBldmVudCxcclxuICAgICAgICAgICAgICAgIGRpc3RhbmNlS206IGRpc3RhbmNlS20obWFwQ2VudGVyLCBbZXZlbnQubGF0LCBldmVudC5sbmddKSxcclxuICAgICAgICAgICAgfSkpKSxcclxuICAgICAgICAgICAgLi4uKHR5cGVGaWx0ZXIgPT09ICdldmVudHMnID8gW10gOiBwbGFucy5tYXAoKHBsYW4pID0+ICh7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAncGxhbicgYXMgY29uc3QsXHJcbiAgICAgICAgICAgICAgICBpdGVtOiBwbGFuLFxyXG4gICAgICAgICAgICAgICAgZGlzdGFuY2VLbTogZGlzdGFuY2VLbShtYXBDZW50ZXIsIFtwbGFuLmxhdCwgcGxhbi5sbmddKSxcclxuICAgICAgICAgICAgfSkpKSxcclxuICAgICAgICBdXHJcblxyXG4gICAgICAgIHJldHVybiBtaXhlZFxyXG4gICAgICAgICAgICAuZmlsdGVyKCh7IGl0ZW0gfSkgPT4gbWF0Y2hlc1NlbGVjdGVkVGFncyhpdGVtLnRhZ3MsIHNlbGVjdGVkVGFnSWRzKSlcclxuICAgICAgICAgICAgLmZpbHRlcigoeyBpdGVtIH0pID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghbm9ybWFsaXplZFF1ZXJ5KSByZXR1cm4gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFtcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5kZXNjcmlwdGlvbiA/PyAnJyxcclxuICAgICAgICAgICAgICAgICAgICAuLi4oaXRlbS50YWdzID8/IFtdKS5tYXAoKHRhZykgPT4gdGFnLm5hbWUpLFxyXG4gICAgICAgICAgICAgICAgXS5zb21lKCh2YWx1ZSkgPT4gdmFsdWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhub3JtYWxpemVkUXVlcnkpKVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuZmlsdGVyKCh7IGRpc3RhbmNlS20gfSkgPT4gZGlzdGFuY2VLbSA8PSByYWRpdXNLbSlcclxuICAgICAgICAgICAgLnNvcnQoKGEsIGIpID0+IGEuZGlzdGFuY2VLbSAtIGIuZGlzdGFuY2VLbSB8fCBhLml0ZW0ubmFtZS5sb2NhbGVDb21wYXJlKGIuaXRlbS5uYW1lKSlcclxuICAgIH0sIFtldmVudHMsIG1hcENlbnRlciwgcGxhbnMsIHF1ZXJ5LCByYWRpdXNLbSwgc2VsZWN0ZWRUYWdJZHMsIHR5cGVGaWx0ZXJdKVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWJhY2tkcm9wXCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxcIiBhcmlhLWxhYmVsPVwiRXhwbG9yZSBldmVudHMgYW5kIHBsYW5zXCIgb25DbGljaz17KGV2ZW50KSA9PiBldmVudC5zdG9wUHJvcGFnYXRpb24oKX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxfX2hlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxfX2V5ZWJyb3dcIj5Ccm93c2UgbmVhcmJ5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDI+RXhwbG9yZSBldmVudHMgYW5kIHBsYW5zPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+U2VhcmNoIHRoZSBjdXJyZW50IG1hcCBhcmVhIHVzaW5nIHlvdXIgYWN0aXZlIHRhZyBmaWx0ZXJzLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJleHBsb3JlLXBhbmVsX19jbG9zZVwiIG9uQ2xpY2s9e29uQ2xvc2V9IGFyaWEtbGFiZWw9XCJDbG9zZSBleHBsb3JlIHBhbmVsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHhcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEl0ZW0gPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWRldGFpbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJleHBsb3JlLWRldGFpbF9fYmFja1wiIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNhdmVNZXNzYWdlKCcnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJdGVtKG51bGwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oaQIEJhY2sgdG8gcmVzdWx0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWRldGFpbF9fY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX3RvcGxpbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BleHBsb3JlLWNhcmRfX2JhZGdlIGV4cGxvcmUtY2FyZF9fYmFkZ2UtLSR7c2VsZWN0ZWRJdGVtLnR5cGV9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9faWNvblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dldENhdGVnb3J5SWNvbihzZWxlY3RlZEl0ZW0uaXRlbS50YWdzLCBzZWxlY3RlZEl0ZW0udHlwZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkSXRlbS50eXBlID09PSAnZXZlbnQnID8gJ0V2ZW50JyA6ICdQbGFuJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX19kaXN0YW5jZVwiPntzZWxlY3RlZEl0ZW0uZGlzdGFuY2VLbS50b0ZpeGVkKDEpfWttIGF3YXk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMz57c2VsZWN0ZWRJdGVtLml0ZW0ubmFtZX08L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+e3NlbGVjdGVkSXRlbS5pdGVtLmRlc2NyaXB0aW9uID8/ICdObyBkZXNjcmlwdGlvbiB5ZXQuJ308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9fbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntmb3JtYXRCdWRnZXQoc2VsZWN0ZWRJdGVtLml0ZW0uYnVkZ2V0KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdFZpc2liaWxpdHkoc2VsZWN0ZWRJdGVtLml0ZW0udmlzaWJpbGl0eSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEl0ZW0udHlwZSA9PT0gJ2V2ZW50JyAmJiA8c3Bhbj57Zm9ybWF0RXZlbnRUaW1lKHNlbGVjdGVkSXRlbS5pdGVtLmV2ZW50X3RpbWUpfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoc2VsZWN0ZWRJdGVtLml0ZW0udGFncz8ubGVuZ3RoID8/IDApID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX3RhZ3NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkSXRlbS5pdGVtLnRhZ3M/Lm1hcCgodGFnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e3RhZy5pZH0+I3t0YWcubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwbG9yZS1kZXRhaWxfX2FjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRJdGVtLnR5cGUgPT09ICdldmVudCcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZXhwbG9yZS1kZXRhaWxfX3ByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0RXZlbnQoc2VsZWN0ZWRJdGVtLml0ZW0uaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPcGVuIGZ1bGwgZXZlbnQgZGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImV4cGxvcmUtZGV0YWlsX19wcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0UGxhbihbc2VsZWN0ZWRJdGVtLml0ZW0ubGF0LCBzZWxlY3RlZEl0ZW0uaXRlbS5sbmddKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENlbnRlciBvbiBtYXBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImV4cGxvcmUtZGV0YWlsX19zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVQbGFuKHNlbGVjdGVkSXRlbS5pdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWlzTG9nZ2VkSW4gfHwgc2F2ZWRQbGFuSWRzLmhhcyhzZWxlY3RlZEl0ZW0uaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0xvZ2dlZEluXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ0xvZyBpbiB0byBzYXZlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNhdmVkUGxhbklkcy5oYXMoc2VsZWN0ZWRJdGVtLml0ZW0uaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdQbGFuIHNhdmVkJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnU2F2ZSBwbGFuJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2F2ZU1lc3NhZ2UgJiYgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWRldGFpbF9fbWVzc2FnZVwiPntzYXZlTWVzc2FnZX08L2Rpdj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxfX2NvbnRyb2xzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZXhwbG9yZS1wYW5lbF9fc2VhcmNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2VhcmNoPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3F1ZXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRRdWVyeShldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBuYW1lLCB0YWcsIG9yIGRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwbG9yZS1wYW5lbF9fc2VnbWVudGVkXCIgYXJpYS1sYWJlbD1cIlR5cGUgZmlsdGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhbJ2FsbCcsICdldmVudHMnLCAncGxhbnMnXSBhcyBjb25zdCkubWFwKCh2YWx1ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3R5cGVGaWx0ZXIgPT09IHZhbHVlID8gJ2V4cGxvcmUtcGFuZWxfX3NlZ21lbnQgZXhwbG9yZS1wYW5lbF9fc2VnbWVudC0tYWN0aXZlJyA6ICdleHBsb3JlLXBhbmVsX19zZWdtZW50J31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFR5cGVGaWx0ZXIodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWUgPT09ICdhbGwnID8gJ0FsbCcgOiB2YWx1ZSA9PT0gJ2V2ZW50cycgPyAnRXZlbnRzJyA6ICdQbGFucyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZXhwbG9yZS1wYW5lbF9fcmFkaXVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmFkaXVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9ezEwMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JhZGl1c0ttfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSYWRpdXNLbShOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB8fCAxMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5rbTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhZ3MubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxfX2FjdGl2ZS10YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VXNpbmcgZmlsdGVyczo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhZ3MubWFwKCh0YWcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBrZXk9e3RhZy5pZH0+I3t0YWcubmFtZX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLXBhbmVsX19zdW1tYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0cy5sZW5ndGh9IHJlc3VsdHtyZXN1bHRzLmxlbmd0aCA9PT0gMSA/ICcnIDogJ3MnfSB3aXRoaW4ge3JhZGl1c0ttfWttXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLXBhbmVsX19saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0cy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwbG9yZS1wYW5lbF9fZW1wdHlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gbWF0Y2hpbmcgZXZlbnRzIG9yIHBsYW5zIGZvdW5kIGluIHRoaXMgcmFkaXVzLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHRzLm1hcCgocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyB2aXNpYmxlVGFncywgaGlkZGVuQ291bnQgfSA9IGdldFZpc2libGVUYWdzKHJlc3VsdC5pdGVtLnRhZ3MpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFydGljbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YCR7cmVzdWx0LnR5cGV9LSR7cmVzdWx0Lml0ZW0uaWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX21haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2F2ZU1lc3NhZ2UoJycpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkSXRlbShyZXN1bHQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9fdG9wbGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BleHBsb3JlLWNhcmRfX2JhZGdlIGV4cGxvcmUtY2FyZF9fYmFkZ2UtLSR7cmVzdWx0LnR5cGV9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX2ljb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0Q2F0ZWdvcnlJY29uKHJlc3VsdC5pdGVtLnRhZ3MsIHJlc3VsdC50eXBlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQudHlwZSA9PT0gJ2V2ZW50JyA/ICdFdmVudCcgOiAnUGxhbid9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX19kaXN0YW5jZVwiPntyZXN1bHQuZGlzdGFuY2VLbS50b0ZpeGVkKDEpfWttIGF3YXk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPntyZXN1bHQuaXRlbS5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX21ldGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Zm9ybWF0QnVkZ2V0KHJlc3VsdC5pdGVtLmJ1ZGdldCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntmb3JtYXRWaXNpYmlsaXR5KHJlc3VsdC5pdGVtLnZpc2liaWxpdHkpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0LnR5cGUgPT09ICdldmVudCcgJiYgPHNwYW4+e2Zvcm1hdEV2ZW50VGltZShyZXN1bHQuaXRlbS5ldmVudF90aW1lKX08L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVUYWdzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9fdGFnc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVUYWdzLm1hcCgodGFnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0YWcuaWR9PiN7dGFnLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aGlkZGVuQ291bnQgPiAwICYmIDxzcGFuIGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9fdGFnLW1vcmVcIj4re2hpZGRlbkNvdW50fSBtb3JlPC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX2FjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQudHlwZSA9PT0gJ2V2ZW50JyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX2FjdGlvbiBleHBsb3JlLWNhcmRfX2FjdGlvbi0tZXZlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUb2dnbGVFdmVudFN1YnNjcmlwdGlvbihyZXN1bHQuaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNMb2dnZWRJbiB8fCB1cGRhdGluZ0V2ZW50SWQgPT09IHJlc3VsdC5pdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0xvZ2dlZEluXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdMb2cgaW4gdG8gc3Vic2NyaWJlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGluZ0V2ZW50SWQgPT09IHJlc3VsdC5pdGVtLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnVXBkYXRpbmcuLi4nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBqb2luZWRFdmVudElkcy5oYXMocmVzdWx0Lml0ZW0uaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1Vuc3Vic2NyaWJlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdTdWJzY3JpYmUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX2FjdGlvbiBleHBsb3JlLWNhcmRfX2FjdGlvbi0tcGxhblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVQbGFuKHJlc3VsdC5pdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc0xvZ2dlZEluIHx8IHNhdmVkUGxhbklkcy5oYXMocmVzdWx0Lml0ZW0uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0xvZ2dlZEluID8gJ0xvZyBpbiB0byBzYXZlJyA6IHNhdmVkUGxhbklkcy5oYXMocmVzdWx0Lml0ZW0uaWQpID8gJ1NhdmVkJyA6ICdTYXZlIHBsYW4nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbWFydGkvRG9jdW1lbnRzL0dpdEh1Yi9Tb2Z0d2FyZS1Qcm9qZWN0LUcxMC9Qcm9qZWN0L3NyYy9FeHBsb3JlUGFuZWwudHN4In0=