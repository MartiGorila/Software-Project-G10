import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SubscriptionPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { getCategoryIcon, getVisibleTags } from "/src/categoryIcons.ts";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useState = __vite__cjsImport4_react["useState"];
export default function SubscriptionPanel({
  subscribedEvents,
  friends,
  friendRequests,
  friendsLoading,
  friendsError,
  currentUser,
  onRemoveSubscription,
  onRemoveFriend,
  onAcceptFriendRequest,
  onRejectFriendRequest,
  onCancelFriendRequest,
  onViewUserProfile
}) {
  _s();
  const [removingFriendId, setRemovingFriendId] = useState(null);
  const [requestActionId, setRequestActionId] = useState(null);
  const [friendActionError, setFriendActionError] = useState("");
  const handleRemoveFriend = async (friendId) => {
    try {
      setRemovingFriendId(friendId);
      setFriendActionError("");
      await onRemoveFriend(friendId);
    } catch (error) {
      setFriendActionError(error instanceof Error ? error.message : "Failed to remove friend.");
    } finally {
      setRemovingFriendId(null);
    }
  };
  const handleRequestAction = async (requestId, action) => {
    try {
      setRequestActionId(requestId);
      setFriendActionError("");
      if (action === "accept") {
        await onAcceptFriendRequest(requestId);
      } else if (action === "reject") {
        await onRejectFriendRequest(requestId);
      } else {
        await onCancelFriendRequest(requestId);
      }
    } catch (error) {
      setFriendActionError(error instanceof Error ? error.message : "Failed to update request.");
    } finally {
      setRequestActionId(null);
    }
  };
  const formatEventTime = (iso) => new Date(iso).toLocaleString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit"
  });
  const getDescriptionPreview = (description) => {
    if (!description)
      return "";
    return description.length > 92 ? `${description.slice(0, 89)}...` : description;
  };
  return /* @__PURE__ */ jsxDEV("aside", { className: "sidebar", children: [
    currentUser && /* @__PURE__ */ jsxDEV("section", { className: "friends-section friends-section--top", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "friends-section__header", children: /* @__PURE__ */ jsxDEV("h3", { children: "Friends" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 105,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 104,
        columnNumber: 21
      }, this),
      friendsLoading && /* @__PURE__ */ jsxDEV("div", { className: "sidebar-empty", children: "Loading friends..." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 107,
        columnNumber: 40
      }, this),
      friendsError && /* @__PURE__ */ jsxDEV("div", { className: "sidebar-error", children: friendsError }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 108,
        columnNumber: 38
      }, this),
      friendActionError && /* @__PURE__ */ jsxDEV("div", { className: "sidebar-error", children: friendActionError }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 109,
        columnNumber: 43
      }, this),
      !friendsLoading && !friendsError && friends.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "sidebar-empty", children: "No friends yet." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      !friendsLoading && friends.length > 0 && /* @__PURE__ */ jsxDEV("ul", { className: "friends-list", children: friends.map(
        (friend) => /* @__PURE__ */ jsxDEV("li", { className: "friend-row", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "friend-row__profile",
              onClick: () => onViewUserProfile(friend.id),
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "friend-row__avatar", children: friend.avatar_url ? /* @__PURE__ */ jsxDEV("img", { src: friend.avatar_url, alt: friend.username }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                  lineNumber: 124,
                  columnNumber: 17
                }, this) : friend.username.slice(0, 2).toUpperCase() }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                  lineNumber: 122,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "friend-row__name", children: friend.username }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                  lineNumber: 129,
                  columnNumber: 41
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 117,
              columnNumber: 37
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "friend-row__remove",
              disabled: removingFriendId === friend.id,
              onClick: () => handleRemoveFriend(friend.id),
              children: removingFriendId === friend.id ? "..." : "Remove"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 131,
              columnNumber: 37
            },
            this
          )
        ] }, friend.id, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      !friendsLoading && friendRequests.incoming.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "friend-requests", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "friend-requests__label", children: "Incoming requests" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
          lineNumber: 145,
          columnNumber: 29
        }, this),
        friendRequests.incoming.map(
          (request) => /* @__PURE__ */ jsxDEV("div", { className: "friend-request-row", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "friend-row__profile",
                onClick: () => onViewUserProfile(request.requester_id),
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "friend-row__avatar", children: request.requester?.avatar_url ? /* @__PURE__ */ jsxDEV("img", { src: request.requester.avatar_url, alt: request.requester.username }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                    lineNumber: 155,
                    columnNumber: 17
                  }, this) : request.requester?.username.slice(0, 2).toUpperCase() ?? "??" }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                    lineNumber: 153,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "friend-row__name", children: request.requester?.username ?? "Unknown user" }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                    lineNumber: 160,
                    columnNumber: 41
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                lineNumber: 148,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "friend-request-row__actions", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "friend-request-row__accept",
                  disabled: requestActionId === request.id,
                  onClick: () => handleRequestAction(request.id, "accept"),
                  children: "Accept"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                  lineNumber: 163,
                  columnNumber: 41
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "friend-row__remove",
                  disabled: requestActionId === request.id,
                  onClick: () => handleRequestAction(request.id, "reject"),
                  children: "Reject"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                  lineNumber: 171,
                  columnNumber: 41
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 162,
              columnNumber: 37
            }, this)
          ] }, request.id, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
            lineNumber: 147,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 144,
        columnNumber: 9
      }, this),
      !friendsLoading && friendRequests.outgoing.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "friend-requests", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "friend-requests__label", children: "Sent requests" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
          lineNumber: 186,
          columnNumber: 29
        }, this),
        friendRequests.outgoing.map(
          (request) => /* @__PURE__ */ jsxDEV("div", { className: "friend-request-row", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "friend-row__profile",
                onClick: () => onViewUserProfile(request.recipient_id),
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "friend-row__avatar", children: request.recipient?.avatar_url ? /* @__PURE__ */ jsxDEV("img", { src: request.recipient.avatar_url, alt: request.recipient.username }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                    lineNumber: 196,
                    columnNumber: 17
                  }, this) : request.recipient?.username.slice(0, 2).toUpperCase() ?? "??" }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                    lineNumber: 194,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "friend-row__name", children: request.recipient?.username ?? "Unknown user" }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                    lineNumber: 201,
                    columnNumber: 41
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                lineNumber: 189,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "friend-row__remove",
                disabled: requestActionId === request.id,
                onClick: () => handleRequestAction(request.id, "cancel"),
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                lineNumber: 203,
                columnNumber: 37
              },
              this
            )
          ] }, request.id, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
            lineNumber: 188,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "subscriptions-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sidebar-header", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Subscribed events" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
          lineNumber: 220,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "sidebar-note", children: "Saved markers you subscribed to appear here." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
          lineNumber: 221,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 219,
        columnNumber: 17
      }, this),
      !currentUser && /* @__PURE__ */ jsxDEV("div", { className: "sidebar-empty", children: "Log in to see your subscriptions." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 223,
        columnNumber: 34
      }, this),
      currentUser && subscribedEvents.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "sidebar-empty", children: "You have no subscriptions yet." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 225,
        columnNumber: 9
      }, this),
      currentUser && subscribedEvents.length > 0 && /* @__PURE__ */ jsxDEV("ul", { className: "subscribed-event-list", children: subscribedEvents.map((event) => {
        const { visibleTags, hiddenCount } = getVisibleTags(event.tags, 3);
        const preview = getDescriptionPreview(event.description);
        return /* @__PURE__ */ jsxDEV("li", { className: "subscribed-event-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "subscribed-event-card__topline", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "explore-card__badge explore-card__badge--event", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "explore-card__icon", "aria-hidden": "true", children: getCategoryIcon(event.tags, "event") }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                lineNumber: 237,
                columnNumber: 41
              }, this),
              "Event"
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 236,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "subscribed-event-card__time", children: formatEventTime(event.event_time) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 242,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
            lineNumber: 235,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: event.name }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
            lineNumber: 244,
            columnNumber: 33
          }, this),
          preview && /* @__PURE__ */ jsxDEV("p", { children: preview }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
            lineNumber: 245,
            columnNumber: 45
          }, this),
          visibleTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "explore-card__tags", children: [
            visibleTags.map(
              (tag) => /* @__PURE__ */ jsxDEV("span", { children: [
                "#",
                tag.name
              ] }, tag.id, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
                lineNumber: 249,
                columnNumber: 19
              }, this)
            ),
            hiddenCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "explore-card__tag-more", children: [
              "+",
              hiddenCount,
              " more"
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 251,
              columnNumber: 61
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
            lineNumber: 247,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "subscribed-event-card__unsubscribe",
              onClick: () => onRemoveSubscription(event.id),
              children: "Unsubscribe"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
              lineNumber: 254,
              columnNumber: 33
            },
            this
          )
        ] }, event.id, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
          lineNumber: 234,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
        lineNumber: 228,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
      lineNumber: 218,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx",
    lineNumber: 101,
    columnNumber: 5
  }, this);
}
_s(SubscriptionPanel, "OH4/FGBetFzXX2Vp5YYXhSHcc50=");
_c = SubscriptionPanel;
var _c;
$RefreshReg$(_c, "SubscriptionPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SubscriptionPanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZ3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwRnhCLFNBQVNBLGlCQUFpQkMsc0JBQXNCO0FBQ2hELFNBQVNDLGdCQUFnQjtBQWlCekIsd0JBQXdCQyxrQkFBa0I7QUFBQSxFQUN0Q0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDb0IsR0FBRztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWhCLFNBQXdCLElBQUk7QUFDNUUsUUFBTSxDQUFDaUIsaUJBQWlCQyxrQkFBa0IsSUFBSWxCLFNBQXdCLElBQUk7QUFDMUUsUUFBTSxDQUFDbUIsbUJBQW1CQyxvQkFBb0IsSUFBSXBCLFNBQVMsRUFBRTtBQUU3RCxRQUFNcUIscUJBQXFCLE9BQU9DLGFBQXFCO0FBQ25ELFFBQUk7QUFDQU4sMEJBQW9CTSxRQUFRO0FBQzVCRiwyQkFBcUIsRUFBRTtBQUN2QixZQUFNWCxlQUFlYSxRQUFRO0FBQUEsSUFDakMsU0FBU0MsT0FBTztBQUNaSCwyQkFBcUJHLGlCQUFpQkMsUUFBUUQsTUFBTUUsVUFBVSwwQkFBMEI7QUFBQSxJQUM1RixVQUFDO0FBQ0dULDBCQUFvQixJQUFJO0FBQUEsSUFDNUI7QUFBQSxFQUNKO0FBRUEsUUFBTVUsc0JBQXNCLE9BQU9DLFdBQW1CQyxXQUEyQztBQUM3RixRQUFJO0FBQ0FWLHlCQUFtQlMsU0FBUztBQUM1QlAsMkJBQXFCLEVBQUU7QUFDdkIsVUFBSVEsV0FBVyxVQUFVO0FBQ3JCLGNBQU1sQixzQkFBc0JpQixTQUFTO0FBQUEsTUFDekMsV0FBV0MsV0FBVyxVQUFVO0FBQzVCLGNBQU1qQixzQkFBc0JnQixTQUFTO0FBQUEsTUFDekMsT0FBTztBQUNILGNBQU1mLHNCQUFzQmUsU0FBUztBQUFBLE1BQ3pDO0FBQUEsSUFDSixTQUFTSixPQUFPO0FBQ1pILDJCQUFxQkcsaUJBQWlCQyxRQUFRRCxNQUFNRSxVQUFVLDJCQUEyQjtBQUFBLElBQzdGLFVBQUM7QUFDR1AseUJBQW1CLElBQUk7QUFBQSxJQUMzQjtBQUFBLEVBQ0o7QUFFQSxRQUFNVyxrQkFBa0JBLENBQUNDLFFBQWdCLElBQUlDLEtBQUtELEdBQUcsRUFBRUUsZUFBZSxTQUFTO0FBQUEsSUFDM0VDLFNBQVM7QUFBQSxJQUNUQyxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsRUFDWixDQUFDO0FBRUQsUUFBTUMsd0JBQXdCQSxDQUFDQyxnQkFBK0I7QUFDMUQsUUFBSSxDQUFDQTtBQUFhLGFBQU87QUFDekIsV0FBT0EsWUFBWUMsU0FBUyxLQUFLLEdBQUdELFlBQVlFLE1BQU0sR0FBRyxFQUFFLENBQUMsUUFBUUY7QUFBQUEsRUFDeEU7QUFFQSxTQUNJLHVCQUFDLFdBQU0sV0FBVSxXQUNaaEM7QUFBQUEsbUJBQ0csdUJBQUMsYUFBUSxXQUFVLHdDQUNmO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNYLGlDQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ0Ysa0JBQWtCLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0Isa0NBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxNQUNuRUMsZ0JBQWdCLHVCQUFDLFNBQUksV0FBVSxpQkFBaUJBLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDO0FBQUEsTUFDN0RhLHFCQUFxQix1QkFBQyxTQUFJLFdBQVUsaUJBQWlCQSwrQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ3ZFLENBQUNkLGtCQUFrQixDQUFDQyxnQkFBZ0JILFFBQVFxQyxXQUFXLEtBQ3BELHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsK0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUVqRCxDQUFDbkMsa0JBQWtCRixRQUFRcUMsU0FBUyxLQUNqQyx1QkFBQyxRQUFHLFdBQVUsZ0JBQ1RyQyxrQkFBUXVDO0FBQUFBLFFBQUksQ0FBQ0MsV0FDVix1QkFBQyxRQUFtQixXQUFVLGNBQzFCO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTTlCLGtCQUFrQjhCLE9BQU9DLEVBQUU7QUFBQSxjQUUxQztBQUFBLHVDQUFDLFVBQUssV0FBVSxzQkFDWEQsaUJBQU9FLGFBQ0osdUJBQUMsU0FBSSxLQUFLRixPQUFPRSxZQUFZLEtBQUtGLE9BQU9HLFlBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtELElBRWxESCxPQUFPRyxTQUFTTCxNQUFNLEdBQUcsQ0FBQyxFQUFFTSxZQUFZLEtBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsb0JBQW9CSixpQkFBT0csWUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQTtBQUFBO0FBQUEsWUFaeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixVQUFVL0IscUJBQXFCNEIsT0FBT0M7QUFBQUEsY0FDdEMsU0FBUyxNQUFNdkIsbUJBQW1Cc0IsT0FBT0MsRUFBRTtBQUFBLGNBRTFDN0IsK0JBQXFCNEIsT0FBT0MsS0FBSyxRQUFRO0FBQUE7QUFBQSxZQU45QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBdEJLRCxPQUFPQyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsTUFDSCxLQTFCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFFSCxDQUFDdkMsa0JBQWtCRCxlQUFlNEMsU0FBU1IsU0FBUyxLQUNqRCx1QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsMEJBQXlCLGlDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDekRwQyxlQUFlNEMsU0FBU047QUFBQUEsVUFBSSxDQUFDTyxZQUMxQix1QkFBQyxTQUFxQixXQUFVLHNCQUM1QjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixTQUFTLE1BQU1wQyxrQkFBa0JvQyxRQUFRQyxZQUFZO0FBQUEsZ0JBRXJEO0FBQUEseUNBQUMsVUFBSyxXQUFVLHNCQUNYRCxrQkFBUUUsV0FBV04sYUFDaEIsdUJBQUMsU0FBSSxLQUFLSSxRQUFRRSxVQUFVTixZQUFZLEtBQUtJLFFBQVFFLFVBQVVMLFlBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdFLElBRXhFRyxRQUFRRSxXQUFXTCxTQUFTTCxNQUFNLEdBQUcsQ0FBQyxFQUFFTSxZQUFZLEtBQUssUUFKakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSxvQkFBb0JFLGtCQUFRRSxXQUFXTCxZQUFZLGtCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRjtBQUFBO0FBQUE7QUFBQSxjQVp0RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixVQUFVN0Isb0JBQW9CZ0MsUUFBUUw7QUFBQUEsa0JBQ3RDLFNBQVMsTUFBTWxCLG9CQUFvQnVCLFFBQVFMLElBQUksUUFBUTtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsVUFBVTNCLG9CQUFvQmdDLFFBQVFMO0FBQUFBLGtCQUN0QyxTQUFTLE1BQU1sQixvQkFBb0J1QixRQUFRTCxJQUFJLFFBQVE7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSjdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUFoQ01LLFFBQVFMLElBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsUUFDSDtBQUFBLFdBckNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxNQUVILENBQUN2QyxrQkFBa0JELGVBQWVnRCxTQUFTWixTQUFTLEtBQ2pELHVCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSwwQkFBeUIsNkJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUNyRHBDLGVBQWVnRCxTQUFTVjtBQUFBQSxVQUFJLENBQUNPLFlBQzFCLHVCQUFDLFNBQXFCLFdBQVUsc0JBQzVCO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVMsTUFBTXBDLGtCQUFrQm9DLFFBQVFJLFlBQVk7QUFBQSxnQkFFckQ7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsc0JBQ1hKLGtCQUFRSyxXQUFXVCxhQUNoQix1QkFBQyxTQUFJLEtBQUtJLFFBQVFLLFVBQVVULFlBQVksS0FBS0ksUUFBUUssVUFBVVIsWUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0UsSUFFeEVHLFFBQVFLLFdBQVdSLFNBQVNMLE1BQU0sR0FBRyxDQUFDLEVBQUVNLFlBQVksS0FBSyxRQUpqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLG9CQUFvQkUsa0JBQVFLLFdBQVdSLFlBQVksa0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtGO0FBQUE7QUFBQTtBQUFBLGNBWnRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsVUFBVTdCLG9CQUFvQmdDLFFBQVFMO0FBQUFBLGdCQUN0QyxTQUFTLE1BQU1sQixvQkFBb0J1QixRQUFRTCxJQUFJLFFBQVE7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQXRCTUssUUFBUUwsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxRQUNIO0FBQUEsV0EzQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLFNBOUdSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnSEE7QUFBQSxJQUdKLHVCQUFDLGFBQVEsV0FBVSx5QkFDZjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrQkFDWDtBQUFBLCtCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFFBQ3JCLHVCQUFDLE9BQUUsV0FBVSxnQkFBZSw0REFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFdBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0MsQ0FBQ3JDLGVBQWUsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQixpREFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRTtBQUFBLE1BQ2hGQSxlQUFlTCxpQkFBaUJzQyxXQUFXLEtBQ3hDLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsOENBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUVoRWpDLGVBQWVMLGlCQUFpQnNDLFNBQVMsS0FDdEMsdUJBQUMsUUFBRyxXQUFVLHlCQUNUdEMsMkJBQWlCd0MsSUFBSSxDQUFDYSxVQUFVO0FBQzdCLGNBQU0sRUFBRUMsYUFBYUMsWUFBWSxJQUFJMUQsZUFBZXdELE1BQU1HLE1BQU0sQ0FBQztBQUNqRSxjQUFNQyxVQUFVckIsc0JBQXNCaUIsTUFBTWhCLFdBQVc7QUFFdkQsZUFDQSx1QkFBQyxRQUFrQixXQUFVLHlCQUN6QjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrQ0FDWDtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSxzQkFBcUIsZUFBWSxRQUM1Q3pDLDBCQUFnQnlELE1BQU1HLE1BQU0sT0FBTyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FBTztBQUFBLGlCQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSwrQkFBK0I3QiwwQkFBZ0IwQixNQUFNSyxVQUFVLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsZUFQckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsWUFBUUwsZ0JBQU1NLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0I7QUFBQSxVQUNuQkYsV0FBVyx1QkFBQyxPQUFHQSxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFZO0FBQUEsVUFDdkJILFlBQVloQixTQUFTLEtBQ2xCLHVCQUFDLFNBQUksV0FBVSxzQkFDVmdCO0FBQUFBLHdCQUFZZDtBQUFBQSxjQUFJLENBQUNvQixRQUNkLHVCQUFDLFVBQWtCO0FBQUE7QUFBQSxnQkFBRUEsSUFBSUQ7QUFBQUEsbUJBQWRDLElBQUlsQixJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsWUFDakM7QUFBQSxZQUNBYSxjQUFjLEtBQUssdUJBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsY0FBRUE7QUFBQUEsY0FBWTtBQUFBLGlCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RDtBQUFBLGVBSnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU1qRCxxQkFBcUIrQyxNQUFNWCxFQUFFO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQTFCS1csTUFBTVgsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsTUFFSixDQUFDLEtBbkNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxTQTlDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0RBO0FBQUEsT0FyS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNLQTtBQUVSO0FBQUM5QixHQXRPdUJiLG1CQUFpQjtBQUFBLEtBQWpCQTtBQUFpQixJQUFBOEQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiZ2V0Q2F0ZWdvcnlJY29uIiwiZ2V0VmlzaWJsZVRhZ3MiLCJ1c2VTdGF0ZSIsIlN1YnNjcmlwdGlvblBhbmVsIiwic3Vic2NyaWJlZEV2ZW50cyIsImZyaWVuZHMiLCJmcmllbmRSZXF1ZXN0cyIsImZyaWVuZHNMb2FkaW5nIiwiZnJpZW5kc0Vycm9yIiwiY3VycmVudFVzZXIiLCJvblJlbW92ZVN1YnNjcmlwdGlvbiIsIm9uUmVtb3ZlRnJpZW5kIiwib25BY2NlcHRGcmllbmRSZXF1ZXN0Iiwib25SZWplY3RGcmllbmRSZXF1ZXN0Iiwib25DYW5jZWxGcmllbmRSZXF1ZXN0Iiwib25WaWV3VXNlclByb2ZpbGUiLCJfcyIsInJlbW92aW5nRnJpZW5kSWQiLCJzZXRSZW1vdmluZ0ZyaWVuZElkIiwicmVxdWVzdEFjdGlvbklkIiwic2V0UmVxdWVzdEFjdGlvbklkIiwiZnJpZW5kQWN0aW9uRXJyb3IiLCJzZXRGcmllbmRBY3Rpb25FcnJvciIsImhhbmRsZVJlbW92ZUZyaWVuZCIsImZyaWVuZElkIiwiZXJyb3IiLCJFcnJvciIsIm1lc3NhZ2UiLCJoYW5kbGVSZXF1ZXN0QWN0aW9uIiwicmVxdWVzdElkIiwiYWN0aW9uIiwiZm9ybWF0RXZlbnRUaW1lIiwiaXNvIiwiRGF0ZSIsInRvTG9jYWxlU3RyaW5nIiwid2Vla2RheSIsImRheSIsIm1vbnRoIiwiaG91ciIsIm1pbnV0ZSIsImdldERlc2NyaXB0aW9uUHJldmlldyIsImRlc2NyaXB0aW9uIiwibGVuZ3RoIiwic2xpY2UiLCJtYXAiLCJmcmllbmQiLCJpZCIsImF2YXRhcl91cmwiLCJ1c2VybmFtZSIsInRvVXBwZXJDYXNlIiwiaW5jb21pbmciLCJyZXF1ZXN0IiwicmVxdWVzdGVyX2lkIiwicmVxdWVzdGVyIiwib3V0Z29pbmciLCJyZWNpcGllbnRfaWQiLCJyZWNpcGllbnQiLCJldmVudCIsInZpc2libGVUYWdzIiwiaGlkZGVuQ291bnQiLCJ0YWdzIiwicHJldmlldyIsImV2ZW50X3RpbWUiLCJuYW1lIiwidGFnIiwiX2MiXSwic291cmNlcyI6WyJTdWJzY3JpcHRpb25QYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXV0aFVzZXIsIEFwaUV2ZW50LCBGcmllbmQsIEZyaWVuZFJlcXVlc3RzUmVzcG9uc2UgfSBmcm9tICcuL2FwaSdcclxuaW1wb3J0IHsgZ2V0Q2F0ZWdvcnlJY29uLCBnZXRWaXNpYmxlVGFncyB9IGZyb20gJy4vY2F0ZWdvcnlJY29ucydcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuXHJcbnR5cGUgU3Vic2NyaXB0aW9uUGFuZWxQcm9wcyA9IHtcclxuICAgIHN1YnNjcmliZWRFdmVudHM6IEFwaUV2ZW50W11cclxuICAgIGZyaWVuZHM6IEZyaWVuZFtdXHJcbiAgICBmcmllbmRSZXF1ZXN0czogRnJpZW5kUmVxdWVzdHNSZXNwb25zZVxyXG4gICAgZnJpZW5kc0xvYWRpbmc6IGJvb2xlYW5cclxuICAgIGZyaWVuZHNFcnJvcjogc3RyaW5nXHJcbiAgICBjdXJyZW50VXNlcjogQXV0aFVzZXIgfCBudWxsXHJcbiAgICBvblJlbW92ZVN1YnNjcmlwdGlvbjogKG1hcmtlcklkOiBzdHJpbmcpID0+IHZvaWRcclxuICAgIG9uUmVtb3ZlRnJpZW5kOiAoZnJpZW5kSWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxyXG4gICAgb25BY2NlcHRGcmllbmRSZXF1ZXN0OiAocmVxdWVzdElkOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD5cclxuICAgIG9uUmVqZWN0RnJpZW5kUmVxdWVzdDogKHJlcXVlc3RJZDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+XHJcbiAgICBvbkNhbmNlbEZyaWVuZFJlcXVlc3Q6IChyZXF1ZXN0SWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxyXG4gICAgb25WaWV3VXNlclByb2ZpbGU6ICh1c2VySWQ6IHN0cmluZykgPT4gdm9pZFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdWJzY3JpcHRpb25QYW5lbCh7XHJcbiAgICBzdWJzY3JpYmVkRXZlbnRzLFxyXG4gICAgZnJpZW5kcyxcclxuICAgIGZyaWVuZFJlcXVlc3RzLFxyXG4gICAgZnJpZW5kc0xvYWRpbmcsXHJcbiAgICBmcmllbmRzRXJyb3IsXHJcbiAgICBjdXJyZW50VXNlcixcclxuICAgIG9uUmVtb3ZlU3Vic2NyaXB0aW9uLFxyXG4gICAgb25SZW1vdmVGcmllbmQsXHJcbiAgICBvbkFjY2VwdEZyaWVuZFJlcXVlc3QsXHJcbiAgICBvblJlamVjdEZyaWVuZFJlcXVlc3QsXHJcbiAgICBvbkNhbmNlbEZyaWVuZFJlcXVlc3QsXHJcbiAgICBvblZpZXdVc2VyUHJvZmlsZSxcclxufTogU3Vic2NyaXB0aW9uUGFuZWxQcm9wcykge1xyXG4gICAgY29uc3QgW3JlbW92aW5nRnJpZW5kSWQsIHNldFJlbW92aW5nRnJpZW5kSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbClcclxuICAgIGNvbnN0IFtyZXF1ZXN0QWN0aW9uSWQsIHNldFJlcXVlc3RBY3Rpb25JZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxyXG4gICAgY29uc3QgW2ZyaWVuZEFjdGlvbkVycm9yLCBzZXRGcmllbmRBY3Rpb25FcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZW1vdmVGcmllbmQgPSBhc3luYyAoZnJpZW5kSWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldFJlbW92aW5nRnJpZW5kSWQoZnJpZW5kSWQpXHJcbiAgICAgICAgICAgIHNldEZyaWVuZEFjdGlvbkVycm9yKCcnKVxyXG4gICAgICAgICAgICBhd2FpdCBvblJlbW92ZUZyaWVuZChmcmllbmRJZClcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBzZXRGcmllbmRBY3Rpb25FcnJvcihlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdGYWlsZWQgdG8gcmVtb3ZlIGZyaWVuZC4nKVxyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldFJlbW92aW5nRnJpZW5kSWQobnVsbClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVxdWVzdEFjdGlvbiA9IGFzeW5jIChyZXF1ZXN0SWQ6IHN0cmluZywgYWN0aW9uOiAnYWNjZXB0JyB8ICdyZWplY3QnIHwgJ2NhbmNlbCcpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRSZXF1ZXN0QWN0aW9uSWQocmVxdWVzdElkKVxyXG4gICAgICAgICAgICBzZXRGcmllbmRBY3Rpb25FcnJvcignJylcclxuICAgICAgICAgICAgaWYgKGFjdGlvbiA9PT0gJ2FjY2VwdCcpIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IG9uQWNjZXB0RnJpZW5kUmVxdWVzdChyZXF1ZXN0SWQpXHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uID09PSAncmVqZWN0Jykge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgb25SZWplY3RGcmllbmRSZXF1ZXN0KHJlcXVlc3RJZClcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IG9uQ2FuY2VsRnJpZW5kUmVxdWVzdChyZXF1ZXN0SWQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBzZXRGcmllbmRBY3Rpb25FcnJvcihlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdGYWlsZWQgdG8gdXBkYXRlIHJlcXVlc3QuJylcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRSZXF1ZXN0QWN0aW9uSWQobnVsbClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZm9ybWF0RXZlbnRUaW1lID0gKGlzbzogc3RyaW5nKSA9PiBuZXcgRGF0ZShpc28pLnRvTG9jYWxlU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgICB3ZWVrZGF5OiAnc2hvcnQnLFxyXG4gICAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICAgIG1vbnRoOiAnc2hvcnQnLFxyXG4gICAgICAgIGhvdXI6ICcyLWRpZ2l0JyxcclxuICAgICAgICBtaW51dGU6ICcyLWRpZ2l0JyxcclxuICAgIH0pXHJcblxyXG4gICAgY29uc3QgZ2V0RGVzY3JpcHRpb25QcmV2aWV3ID0gKGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsKSA9PiB7XHJcbiAgICAgICAgaWYgKCFkZXNjcmlwdGlvbikgcmV0dXJuICcnXHJcbiAgICAgICAgcmV0dXJuIGRlc2NyaXB0aW9uLmxlbmd0aCA+IDkyID8gYCR7ZGVzY3JpcHRpb24uc2xpY2UoMCwgODkpfS4uLmAgOiBkZXNjcmlwdGlvblxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInNpZGViYXJcIj5cclxuICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZyaWVuZHMtc2VjdGlvbiBmcmllbmRzLXNlY3Rpb24tLXRvcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnJpZW5kcy1zZWN0aW9uX19oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzPkZyaWVuZHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtmcmllbmRzTG9hZGluZyAmJiA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItZW1wdHlcIj5Mb2FkaW5nIGZyaWVuZHMuLi48L2Rpdj59XHJcbiAgICAgICAgICAgICAgICAgICAge2ZyaWVuZHNFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItZXJyb3JcIj57ZnJpZW5kc0Vycm9yfTwvZGl2Pn1cclxuICAgICAgICAgICAgICAgICAgICB7ZnJpZW5kQWN0aW9uRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLWVycm9yXCI+e2ZyaWVuZEFjdGlvbkVycm9yfTwvZGl2Pn1cclxuICAgICAgICAgICAgICAgICAgICB7IWZyaWVuZHNMb2FkaW5nICYmICFmcmllbmRzRXJyb3IgJiYgZnJpZW5kcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItZW1wdHlcIj5ObyBmcmllbmRzIHlldC48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHshZnJpZW5kc0xvYWRpbmcgJiYgZnJpZW5kcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZyaWVuZHMtbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZyaWVuZHMubWFwKChmcmllbmQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtmcmllbmQuaWR9IGNsYXNzTmFtZT1cImZyaWVuZC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmcmllbmQtcm93X19wcm9maWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVmlld1VzZXJQcm9maWxlKGZyaWVuZC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZyaWVuZC1yb3dfX2F2YXRhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmcmllbmQuYXZhdGFyX3VybCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2ZyaWVuZC5hdmF0YXJfdXJsfSBhbHQ9e2ZyaWVuZC51c2VybmFtZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmcmllbmQudXNlcm5hbWUuc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmcmllbmQtcm93X19uYW1lXCI+e2ZyaWVuZC51c2VybmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZyaWVuZC1yb3dfX3JlbW92ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVtb3ZpbmdGcmllbmRJZCA9PT0gZnJpZW5kLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlRnJpZW5kKGZyaWVuZC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW1vdmluZ0ZyaWVuZElkID09PSBmcmllbmQuaWQgPyAnLi4uJyA6ICdSZW1vdmUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7IWZyaWVuZHNMb2FkaW5nICYmIGZyaWVuZFJlcXVlc3RzLmluY29taW5nLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZyaWVuZC1yZXF1ZXN0c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZnJpZW5kLXJlcXVlc3RzX19sYWJlbFwiPkluY29taW5nIHJlcXVlc3RzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZyaWVuZFJlcXVlc3RzLmluY29taW5nLm1hcCgocmVxdWVzdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtyZXF1ZXN0LmlkfSBjbGFzc05hbWU9XCJmcmllbmQtcmVxdWVzdC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmcmllbmQtcm93X19wcm9maWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVmlld1VzZXJQcm9maWxlKHJlcXVlc3QucmVxdWVzdGVyX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZnJpZW5kLXJvd19fYXZhdGFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlcXVlc3QucmVxdWVzdGVyPy5hdmF0YXJfdXJsID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cmVxdWVzdC5yZXF1ZXN0ZXIuYXZhdGFyX3VybH0gYWx0PXtyZXF1ZXN0LnJlcXVlc3Rlci51c2VybmFtZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1ZXN0LnJlcXVlc3Rlcj8udXNlcm5hbWUuc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKSA/PyAnPz8nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZyaWVuZC1yb3dfX25hbWVcIj57cmVxdWVzdC5yZXF1ZXN0ZXI/LnVzZXJuYW1lID8/ICdVbmtub3duIHVzZXInfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnJpZW5kLXJlcXVlc3Qtcm93X19hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZnJpZW5kLXJlcXVlc3Qtcm93X19hY2NlcHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZXF1ZXN0QWN0aW9uSWQgPT09IHJlcXVlc3QuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVxdWVzdEFjdGlvbihyZXF1ZXN0LmlkLCAnYWNjZXB0Jyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWNjZXB0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmcmllbmQtcm93X19yZW1vdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZXF1ZXN0QWN0aW9uSWQgPT09IHJlcXVlc3QuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVxdWVzdEFjdGlvbihyZXF1ZXN0LmlkLCAncmVqZWN0Jyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVqZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7IWZyaWVuZHNMb2FkaW5nICYmIGZyaWVuZFJlcXVlc3RzLm91dGdvaW5nLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZyaWVuZC1yZXF1ZXN0c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZnJpZW5kLXJlcXVlc3RzX19sYWJlbFwiPlNlbnQgcmVxdWVzdHM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZnJpZW5kUmVxdWVzdHMub3V0Z29pbmcubWFwKChyZXF1ZXN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3JlcXVlc3QuaWR9IGNsYXNzTmFtZT1cImZyaWVuZC1yZXF1ZXN0LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZyaWVuZC1yb3dfX3Byb2ZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25WaWV3VXNlclByb2ZpbGUocmVxdWVzdC5yZWNpcGllbnRfaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmcmllbmQtcm93X19hdmF0YXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVxdWVzdC5yZWNpcGllbnQ/LmF2YXRhcl91cmwgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtyZXF1ZXN0LnJlY2lwaWVudC5hdmF0YXJfdXJsfSBhbHQ9e3JlcXVlc3QucmVjaXBpZW50LnVzZXJuYW1lfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3QucmVjaXBpZW50Py51c2VybmFtZS5zbGljZSgwLCAyKS50b1VwcGVyQ2FzZSgpID8/ICc/PydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZnJpZW5kLXJvd19fbmFtZVwiPntyZXF1ZXN0LnJlY2lwaWVudD8udXNlcm5hbWUgPz8gJ1Vua25vd24gdXNlcid9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmcmllbmQtcm93X19yZW1vdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlcXVlc3RBY3Rpb25JZCA9PT0gcmVxdWVzdC5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlcXVlc3RBY3Rpb24ocmVxdWVzdC5pZCwgJ2NhbmNlbCcpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInN1YnNjcmlwdGlvbnMtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMj5TdWJzY3JpYmVkIGV2ZW50czwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic2lkZWJhci1ub3RlXCI+U2F2ZWQgbWFya2VycyB5b3Ugc3Vic2NyaWJlZCB0byBhcHBlYXIgaGVyZS48L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHshY3VycmVudFVzZXIgJiYgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLWVtcHR5XCI+TG9nIGluIHRvIHNlZSB5b3VyIHN1YnNjcmlwdGlvbnMuPC9kaXY+fVxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIHN1YnNjcmliZWRFdmVudHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItZW1wdHlcIj5Zb3UgaGF2ZSBubyBzdWJzY3JpcHRpb25zIHlldC48L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXIgJiYgc3Vic2NyaWJlZEV2ZW50cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3Vic2NyaWJlZC1ldmVudC1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJzY3JpYmVkRXZlbnRzLm1hcCgoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgdmlzaWJsZVRhZ3MsIGhpZGRlbkNvdW50IH0gPSBnZXRWaXNpYmxlVGFncyhldmVudC50YWdzLCAzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJldmlldyA9IGdldERlc2NyaXB0aW9uUHJldmlldyhldmVudC5kZXNjcmlwdGlvbilcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17ZXZlbnQuaWR9IGNsYXNzTmFtZT1cInN1YnNjcmliZWQtZXZlbnQtY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Vic2NyaWJlZC1ldmVudC1jYXJkX190b3BsaW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9fYmFkZ2UgZXhwbG9yZS1jYXJkX19iYWRnZS0tZXZlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4cGxvcmUtY2FyZF9faWNvblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRDYXRlZ29yeUljb24oZXZlbnQudGFncywgJ2V2ZW50Jyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFdmVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN1YnNjcmliZWQtZXZlbnQtY2FyZF9fdGltZVwiPntmb3JtYXRFdmVudFRpbWUoZXZlbnQuZXZlbnRfdGltZSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e2V2ZW50Lm5hbWV9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ByZXZpZXcgJiYgPHA+e3ByZXZpZXd9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVRhZ3MubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX190YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVRhZ3MubWFwKCh0YWcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e3RhZy5pZH0+I3t0YWcubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtoaWRkZW5Db3VudCA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX190YWctbW9yZVwiPit7aGlkZGVuQ291bnR9IG1vcmU8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN1YnNjcmliZWQtZXZlbnQtY2FyZF9fdW5zdWJzY3JpYmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblJlbW92ZVN1YnNjcmlwdGlvbihldmVudC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVbnN1YnNjcmliZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8L2FzaWRlPlxyXG4gICAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbWFydGkvRG9jdW1lbnRzL0dpdEh1Yi9Tb2Z0d2FyZS1Qcm9qZWN0LUcxMC9Qcm9qZWN0L3NyYy9TdWJzY3JpcHRpb25QYW5lbC50c3gifQ==