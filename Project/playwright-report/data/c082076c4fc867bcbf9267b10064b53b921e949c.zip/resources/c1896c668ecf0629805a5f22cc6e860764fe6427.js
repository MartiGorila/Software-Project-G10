import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ProfileModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { getCurrentUser, updateCurrentUser, uploadAvatar } from "/src/api.ts?t=1780399643427";
function Avatar({ url, username, size = 88 }) {
  _s();
  const [imgError, setImgError] = useState(false);
  const initials = username.slice(0, 2).toUpperCase();
  if (url && !imgError) {
    return /* @__PURE__ */ jsxDEV(
      "img",
      {
        src: url,
        alt: username,
        onError: () => setImgError(true),
        style: {
          width: size,
          height: size,
          borderRadius: "50%",
          objectFit: "cover",
          display: "block"
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
        lineNumber: 35,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-fallback", style: { width: size, height: size, fontSize: size * 0.33 }, children: initials }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
}
_s(Avatar, "0doYx/lFKmVVbvtO/eWR8SJrtgo=");
_c = Avatar;
export default function ProfileModal({ onClose, onProfileUpdated }) {
  _s2();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const fileInputRef = useRef(null);
  useEffect(() => {
    let cancelled = false;
    const loadProfile = async () => {
      try {
        setLoading(true);
        setError("");
        const data = await getCurrentUser();
        if (!cancelled) {
          setProfile(data);
          setUsername(data.username);
        }
      } catch (loadError) {
        if (!cancelled) {
          setError(loadError instanceof Error ? loadError.message : "Failed to load profile.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };
    loadProfile();
    return () => {
      cancelled = true;
    };
  }, []);
  const handleSaveUsername = async () => {
    const nextUsername = username.trim();
    if (!profile || !nextUsername || nextUsername === profile.username) {
      setEditing(false);
      setUsername(profile?.username ?? "");
      return;
    }
    try {
      setSaving(true);
      setSaveError("");
      const updated = await updateCurrentUser({ username: nextUsername });
      setProfile(updated);
      setUsername(updated.username);
      setEditing(false);
      onProfileUpdated(updated);
    } catch (saveErrorValue) {
      setSaveError(saveErrorValue instanceof Error ? saveErrorValue.message : "Failed to update profile.");
    } finally {
      setSaving(false);
    }
  };
  const handleAvatarChange = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file)
      return;
    try {
      setUploading(true);
      setUploadError("");
      const updated = await uploadAvatar(file);
      setProfile(updated);
      onProfileUpdated(updated);
    } catch (uploadErrorValue) {
      setUploadError(uploadErrorValue instanceof Error ? uploadErrorValue.message : "Failed to upload avatar.");
    } finally {
      setUploading(false);
    }
  };
  const memberSince = profile?.created_at ? new Date(profile.created_at).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric"
  }) : null;
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-backdrop", onClick: (event) => event.target === event.currentTarget && onClose(), children: /* @__PURE__ */ jsxDEV("div", { className: "profile-modal", children: [
    /* @__PURE__ */ jsxDEV("button", { className: "profile-close", type: "button", onClick: onClose, "aria-label": "Close profile", children: "x" }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
      lineNumber: 152,
      columnNumber: 17
    }, this),
    loading && /* @__PURE__ */ jsxDEV("div", { className: "profile-loading", children: "Loading profile..." }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
      lineNumber: 156,
      columnNumber: 29
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "profile-error", children: error }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
      lineNumber: 157,
      columnNumber: 27
    }, this),
    profile && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "profile-header-band" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
        lineNumber: 161,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-wrap", children: [
          /* @__PURE__ */ jsxDEV(Avatar, { url: profile.avatar_url, username: profile.username }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 165,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "profile-avatar-edit-btn",
              type: "button",
              onClick: () => fileInputRef.current?.click(),
              disabled: uploading,
              "aria-label": "Change avatar",
              children: uploading ? "..." : "Change"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
              lineNumber: 166,
              columnNumber: 33
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              accept: "image/png,image/jpeg,image/jpg,image/webp",
              className: "profile-avatar-input",
              onChange: handleAvatarChange
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
              lineNumber: 175,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
          lineNumber: 164,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "profile-identity", children: [
          editing ? /* @__PURE__ */ jsxDEV("div", { className: "profile-edit-row", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "profile-username-input",
                value: username,
                onChange: (event) => setUsername(event.target.value),
                autoFocus: true,
                onKeyDown: (event) => {
                  if (event.key === "Enter")
                    handleSaveUsername();
                  if (event.key === "Escape") {
                    setEditing(false);
                    setUsername(profile.username);
                    setSaveError("");
                  }
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
                lineNumber: 187,
                columnNumber: 41
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "profile-edit-actions", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "profile-save-btn",
                  type: "button",
                  onClick: handleSaveUsername,
                  disabled: saving,
                  children: saving ? "Saving..." : "Save"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
                  lineNumber: 202,
                  columnNumber: 45
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "profile-cancel-btn",
                  type: "button",
                  onClick: () => {
                    setEditing(false);
                    setUsername(profile.username);
                    setSaveError("");
                  },
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
                  lineNumber: 210,
                  columnNumber: 45
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
              lineNumber: 201,
              columnNumber: 41
            }, this),
            saveError && /* @__PURE__ */ jsxDEV("div", { className: "profile-save-error", children: saveError }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
              lineNumber: 222,
              columnNumber: 55
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 186,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "profile-username-row", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "profile-username", children: profile.username }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
              lineNumber: 226,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "profile-edit-icon-btn",
                type: "button",
                onClick: () => setEditing(true),
                children: "Edit"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
                lineNumber: 227,
                columnNumber: 41
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 225,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "profile-email", children: profile.email }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 236,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
          lineNumber: 184,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
        lineNumber: 163,
        columnNumber: 25
      }, this),
      uploadError && /* @__PURE__ */ jsxDEV("div", { className: "profile-upload-error", children: uploadError }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
        lineNumber: 240,
        columnNumber: 41
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "profile-meta-grid", children: [
        memberSince && /* @__PURE__ */ jsxDEV("div", { className: "profile-meta-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-label", children: "Member since" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 245,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-value", children: memberSince }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 246,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
          lineNumber: 244,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "profile-meta-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-label", children: "User ID" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 250,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-value profile-meta-id", children: [
            profile.id.slice(0, 8),
            "..."
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
            lineNumber: 251,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
          lineNumber: 249,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
        lineNumber: 242,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
      lineNumber: 160,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
    lineNumber: 151,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx",
    lineNumber: 150,
    columnNumber: 5
  }, this);
}
_s2(ProfileModal, "PdWb0wwym8ccfHNQseV7U2O0Ooc=");
_c2 = ProfileModal;
var _c, _c2;
$RefreshReg$(_c, "Avatar");
$RefreshReg$(_c2, "ProfileModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/ProfileModal.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVksU0E2SFEsVUE3SFI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZlosU0FBc0JBLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUN6RCxTQUFTQyxnQkFBZ0JDLG1CQUFtQkMsb0JBQW9CO0FBUWhFLFNBQVNDLE9BQU8sRUFBRUMsS0FBS0MsVUFBVUMsT0FBTyxHQUE0RCxHQUFHO0FBQUFDLEtBQUE7QUFDbkcsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlWLFNBQVMsS0FBSztBQUM5QyxRQUFNVyxXQUFXTCxTQUFTTSxNQUFNLEdBQUcsQ0FBQyxFQUFFQyxZQUFZO0FBRWxELE1BQUlSLE9BQU8sQ0FBQ0ksVUFBVTtBQUNsQixXQUNJO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxLQUFLSjtBQUFBQSxRQUNMLEtBQUtDO0FBQUFBLFFBQ0wsU0FBUyxNQUFNSSxZQUFZLElBQUk7QUFBQSxRQUMvQixPQUFPO0FBQUEsVUFDSEksT0FBT1A7QUFBQUEsVUFDUFEsUUFBUVI7QUFBQUEsVUFDUlMsY0FBYztBQUFBLFVBQ2RDLFdBQVc7QUFBQSxVQUNYQyxTQUFTO0FBQUEsUUFDYjtBQUFBO0FBQUEsTUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVTTtBQUFBLEVBR2Q7QUFFQSxTQUNJLHVCQUFDLFNBQUksV0FBVSwyQkFBMEIsT0FBTyxFQUFFSixPQUFPUCxNQUFNUSxRQUFRUixNQUFNWSxVQUFVWixPQUFPLEtBQUssR0FDOUZJLHNCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVSO0FBQUNILEdBMUJRSixRQUFNO0FBQUEsS0FBTkE7QUE0QlQsd0JBQXdCZ0IsYUFBYSxFQUFFQyxTQUFTQyxpQkFBb0MsR0FBRztBQUFBQyxNQUFBO0FBQ25GLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJekIsU0FBNEIsSUFBSTtBQUM5RCxRQUFNLENBQUMwQixTQUFTQyxVQUFVLElBQUkzQixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDNEIsT0FBT0MsUUFBUSxJQUFJN0IsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzhCLFNBQVNDLFVBQVUsSUFBSS9CLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNNLFVBQVUwQixXQUFXLElBQUloQyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUMsUUFBUUMsU0FBUyxJQUFJbEMsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ21DLFdBQVdDLFlBQVksSUFBSXBDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDdUMsYUFBYUMsY0FBYyxJQUFJeEMsU0FBUyxFQUFFO0FBQ2pELFFBQU15QyxlQUFlMUMsT0FBeUIsSUFBSTtBQUVsREQsWUFBVSxNQUFNO0FBQ1osUUFBSTRDLFlBQVk7QUFFaEIsVUFBTUMsY0FBYyxZQUFZO0FBQzVCLFVBQUk7QUFDQWhCLG1CQUFXLElBQUk7QUFDZkUsaUJBQVMsRUFBRTtBQUNYLGNBQU1lLE9BQU8sTUFBTTNDLGVBQWU7QUFDbEMsWUFBSSxDQUFDeUMsV0FBVztBQUNaakIscUJBQVdtQixJQUFJO0FBQ2ZaLHNCQUFZWSxLQUFLdEMsUUFBUTtBQUFBLFFBQzdCO0FBQUEsTUFDSixTQUFTdUMsV0FBVztBQUNoQixZQUFJLENBQUNILFdBQVc7QUFDWmIsbUJBQVNnQixxQkFBcUJDLFFBQVFELFVBQVVFLFVBQVUseUJBQXlCO0FBQUEsUUFDdkY7QUFBQSxNQUNKLFVBQUM7QUFDRyxZQUFJLENBQUNMLFdBQVc7QUFDWmYscUJBQVcsS0FBSztBQUFBLFFBQ3BCO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQWdCLGdCQUFZO0FBRVosV0FBTyxNQUFNO0FBQ1RELGtCQUFZO0FBQUEsSUFDaEI7QUFBQSxFQUNKLEdBQUcsRUFBRTtBQUVMLFFBQU1NLHFCQUFxQixZQUFZO0FBQ25DLFVBQU1DLGVBQWUzQyxTQUFTNEMsS0FBSztBQUNuQyxRQUFJLENBQUMxQixXQUFXLENBQUN5QixnQkFBZ0JBLGlCQUFpQnpCLFFBQVFsQixVQUFVO0FBQ2hFeUIsaUJBQVcsS0FBSztBQUNoQkMsa0JBQVlSLFNBQVNsQixZQUFZLEVBQUU7QUFDbkM7QUFBQSxJQUNKO0FBRUEsUUFBSTtBQUNBNEIsZ0JBQVUsSUFBSTtBQUNkRSxtQkFBYSxFQUFFO0FBQ2YsWUFBTWUsVUFBVSxNQUFNakQsa0JBQWtCLEVBQUVJLFVBQVUyQyxhQUFhLENBQUM7QUFDbEV4QixpQkFBVzBCLE9BQU87QUFDbEJuQixrQkFBWW1CLFFBQVE3QyxRQUFRO0FBQzVCeUIsaUJBQVcsS0FBSztBQUNoQlQsdUJBQWlCNkIsT0FBTztBQUFBLElBQzVCLFNBQVNDLGdCQUFnQjtBQUNyQmhCLG1CQUFhZ0IsMEJBQTBCTixRQUFRTSxlQUFlTCxVQUFVLDJCQUEyQjtBQUFBLElBQ3ZHLFVBQUM7QUFDR2IsZ0JBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDSjtBQUVBLFFBQU1tQixxQkFBcUIsT0FBT0MsVUFBeUM7QUFDdkUsVUFBTUMsT0FBT0QsTUFBTUUsT0FBT0MsUUFBUSxDQUFDO0FBQ25DSCxVQUFNRSxPQUFPRSxRQUFRO0FBRXJCLFFBQUksQ0FBQ0g7QUFBTTtBQUVYLFFBQUk7QUFDQWpCLG1CQUFhLElBQUk7QUFDakJFLHFCQUFlLEVBQUU7QUFDakIsWUFBTVcsVUFBVSxNQUFNaEQsYUFBYW9ELElBQUk7QUFDdkM5QixpQkFBVzBCLE9BQU87QUFDbEI3Qix1QkFBaUI2QixPQUFPO0FBQUEsSUFDNUIsU0FBU1Esa0JBQWtCO0FBQ3ZCbkIscUJBQWVtQiw0QkFBNEJiLFFBQVFhLGlCQUFpQlosVUFBVSwwQkFBMEI7QUFBQSxJQUM1RyxVQUFDO0FBQ0dULG1CQUFhLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFFQSxRQUFNc0IsY0FBY3BDLFNBQVNxQyxhQUN2QixJQUFJQyxLQUFLdEMsUUFBUXFDLFVBQVUsRUFBRUUsbUJBQW1CLFNBQVM7QUFBQSxJQUNyREMsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsRUFDVixDQUFDLElBQ0Q7QUFFTixTQUNJLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsU0FBUyxDQUFDWixVQUFVQSxNQUFNRSxXQUFXRixNQUFNYSxpQkFBaUI5QyxRQUFRLEdBQ2xHLGlDQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLDJCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsTUFBSyxVQUFTLFNBQVNBLFNBQVMsY0FBVyxpQkFBZ0IsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUNLLFdBQVcsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixrQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRDtBQUFBLElBQzlERSxTQUFTLHVCQUFDLFNBQUksV0FBVSxpQkFBaUJBLG1CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNDO0FBQUEsSUFFL0NKLFdBQ0csbUNBQ0k7QUFBQSw2QkFBQyxTQUFJLFdBQVUseUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BRXBDLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSx1QkFDWDtBQUFBLGlDQUFDLFVBQU8sS0FBS0EsUUFBUTRDLFlBQVksVUFBVTVDLFFBQVFsQixZQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzVEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1tQyxhQUFhNEIsU0FBU0MsTUFBTTtBQUFBLGNBQzNDLFVBQVVqQztBQUFBQSxjQUNWLGNBQVc7QUFBQSxjQUVWQSxzQkFBWSxRQUFRO0FBQUE7QUFBQSxZQVB6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLEtBQUtJO0FBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsUUFBTztBQUFBLGNBQ1AsV0FBVTtBQUFBLGNBQ1YsVUFBVVk7QUFBQUE7QUFBQUEsWUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLaUM7QUFBQSxhQWhCckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG9CQUNWdkI7QUFBQUEsb0JBQ0csdUJBQUMsU0FBSSxXQUFVLG9CQUNYO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFVO0FBQUEsZ0JBQ1YsT0FBT3hCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2dELFVBQVV0QixZQUFZc0IsTUFBTUUsT0FBT0UsS0FBSztBQUFBLGdCQUNuRDtBQUFBLGdCQUNBLFdBQVcsQ0FBQ0osVUFBVTtBQUNsQixzQkFBSUEsTUFBTWlCLFFBQVE7QUFBU3ZCLHVDQUFtQjtBQUM5QyxzQkFBSU0sTUFBTWlCLFFBQVEsVUFBVTtBQUN4QnhDLCtCQUFXLEtBQUs7QUFDaEJDLGdDQUFZUixRQUFRbEIsUUFBUTtBQUM1QjhCLGlDQUFhLEVBQUU7QUFBQSxrQkFDbkI7QUFBQSxnQkFDSjtBQUFBO0FBQUEsY0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZTTtBQUFBLFlBRU4sdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxTQUFTWTtBQUFBQSxrQkFDVCxVQUFVZjtBQUFBQSxrQkFFVEEsbUJBQVMsY0FBYztBQUFBO0FBQUEsZ0JBTjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUNYRiwrQkFBVyxLQUFLO0FBQ2hCQyxnQ0FBWVIsUUFBUWxCLFFBQVE7QUFDNUI4QixpQ0FBYSxFQUFFO0FBQUEsa0JBQ25CO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQ0QsYUFBYSx1QkFBQyxTQUFJLFdBQVUsc0JBQXNCQSx1QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0M7QUFBQSxlQXBDakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsb0JBQW9CWCxrQkFBUWxCLFlBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXlCLFdBQVcsSUFBSTtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUhwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUosdUJBQUMsVUFBSyxXQUFVLGlCQUFpQlAsa0JBQVFnRCxTQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLGFBcERuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcURBO0FBQUEsV0ExRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJFQTtBQUFBLE1BRUNqQyxlQUFlLHVCQUFDLFNBQUksV0FBVSx3QkFBd0JBLHlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFFbkUsdUJBQUMsU0FBSSxXQUFVLHFCQUNWcUI7QUFBQUEsdUJBQ0csdUJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHNCQUFxQiw0QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxVQUFLLFdBQVUsc0JBQXNCQSx5QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVKLHVCQUFDLFNBQUksV0FBVSxxQkFDWDtBQUFBLGlDQUFDLFVBQUssV0FBVSxzQkFBcUIsdUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsVUFDNUMsdUJBQUMsVUFBSyxXQUFVLHNDQUFzQ3BDO0FBQUFBLG9CQUFRaUQsR0FBRzdELE1BQU0sR0FBRyxDQUFDO0FBQUEsWUFBRTtBQUFBLGVBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsYUFGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQTdGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEZBO0FBQUEsT0F2R1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlHQSxLQTFHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkdBO0FBRVI7QUFBQ1csSUExTXVCSCxjQUFZO0FBQUEsTUFBWkE7QUFBWSxJQUFBc0QsSUFBQUM7QUFBQSxhQUFBRCxJQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiZ2V0Q3VycmVudFVzZXIiLCJ1cGRhdGVDdXJyZW50VXNlciIsInVwbG9hZEF2YXRhciIsIkF2YXRhciIsInVybCIsInVzZXJuYW1lIiwic2l6ZSIsIl9zIiwiaW1nRXJyb3IiLCJzZXRJbWdFcnJvciIsImluaXRpYWxzIiwic2xpY2UiLCJ0b1VwcGVyQ2FzZSIsIndpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwib2JqZWN0Rml0IiwiZGlzcGxheSIsImZvbnRTaXplIiwiUHJvZmlsZU1vZGFsIiwib25DbG9zZSIsIm9uUHJvZmlsZVVwZGF0ZWQiLCJfczIiLCJwcm9maWxlIiwic2V0UHJvZmlsZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImVkaXRpbmciLCJzZXRFZGl0aW5nIiwic2V0VXNlcm5hbWUiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJzYXZlRXJyb3IiLCJzZXRTYXZlRXJyb3IiLCJ1cGxvYWRpbmciLCJzZXRVcGxvYWRpbmciLCJ1cGxvYWRFcnJvciIsInNldFVwbG9hZEVycm9yIiwiZmlsZUlucHV0UmVmIiwiY2FuY2VsbGVkIiwibG9hZFByb2ZpbGUiLCJkYXRhIiwibG9hZEVycm9yIiwiRXJyb3IiLCJtZXNzYWdlIiwiaGFuZGxlU2F2ZVVzZXJuYW1lIiwibmV4dFVzZXJuYW1lIiwidHJpbSIsInVwZGF0ZWQiLCJzYXZlRXJyb3JWYWx1ZSIsImhhbmRsZUF2YXRhckNoYW5nZSIsImV2ZW50IiwiZmlsZSIsInRhcmdldCIsImZpbGVzIiwidmFsdWUiLCJ1cGxvYWRFcnJvclZhbHVlIiwibWVtYmVyU2luY2UiLCJjcmVhdGVkX2F0IiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwieWVhciIsImN1cnJlbnRUYXJnZXQiLCJhdmF0YXJfdXJsIiwiY3VycmVudCIsImNsaWNrIiwia2V5IiwiZW1haWwiLCJpZCIsIl9jIiwiX2MyIl0sInNvdXJjZXMiOlsiUHJvZmlsZU1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGFuZ2VFdmVudCwgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGdldEN1cnJlbnRVc2VyLCB1cGRhdGVDdXJyZW50VXNlciwgdXBsb2FkQXZhdGFyIH0gZnJvbSAnLi9hcGknXHJcbmltcG9ydCB7IE93blByb2ZpbGUgfSBmcm9tICcuL3R5cGVzJ1xyXG5cclxudHlwZSBQcm9maWxlTW9kYWxQcm9wcyA9IHtcclxuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWRcclxuICAgIG9uUHJvZmlsZVVwZGF0ZWQ6IChwcm9maWxlOiBPd25Qcm9maWxlKSA9PiB2b2lkXHJcbn1cclxuXHJcbmZ1bmN0aW9uIEF2YXRhcih7IHVybCwgdXNlcm5hbWUsIHNpemUgPSA4OCB9OiB7IHVybDogc3RyaW5nIHwgbnVsbDsgdXNlcm5hbWU6IHN0cmluZzsgc2l6ZT86IG51bWJlciB9KSB7XHJcbiAgICBjb25zdCBbaW1nRXJyb3IsIHNldEltZ0Vycm9yXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgaW5pdGlhbHMgPSB1c2VybmFtZS5zbGljZSgwLCAyKS50b1VwcGVyQ2FzZSgpXHJcblxyXG4gICAgaWYgKHVybCAmJiAhaW1nRXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICBzcmM9e3VybH1cclxuICAgICAgICAgICAgICAgIGFsdD17dXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICBvbkVycm9yPXsoKSA9PiBzZXRJbWdFcnJvcih0cnVlKX1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IHNpemUsXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBzaXplLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXHJcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0Rml0OiAnY292ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaycsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1hdmF0YXItZmFsbGJhY2tcIiBzdHlsZT17eyB3aWR0aDogc2l6ZSwgaGVpZ2h0OiBzaXplLCBmb250U2l6ZTogc2l6ZSAqIDAuMzMgfX0+XHJcbiAgICAgICAgICAgIHtpbml0aWFsc31cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZmlsZU1vZGFsKHsgb25DbG9zZSwgb25Qcm9maWxlVXBkYXRlZCB9OiBQcm9maWxlTW9kYWxQcm9wcykge1xyXG4gICAgY29uc3QgW3Byb2ZpbGUsIHNldFByb2ZpbGVdID0gdXNlU3RhdGU8T3duUHJvZmlsZSB8IG51bGw+KG51bGwpXHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxyXG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuICAgIGNvbnN0IFtlZGl0aW5nLCBzZXRFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICAgIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtzYXZlRXJyb3IsIHNldFNhdmVFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuICAgIGNvbnN0IFt1cGxvYWRpbmcsIHNldFVwbG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFt1cGxvYWRFcnJvciwgc2V0VXBsb2FkRXJyb3JdID0gdXNlU3RhdGUoJycpXHJcbiAgICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbClcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxyXG5cclxuICAgICAgICBjb25zdCBsb2FkUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSlcclxuICAgICAgICAgICAgICAgIHNldEVycm9yKCcnKVxyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldEN1cnJlbnRVc2VyKClcclxuICAgICAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJvZmlsZShkYXRhKVxyXG4gICAgICAgICAgICAgICAgICAgIHNldFVzZXJuYW1lKGRhdGEudXNlcm5hbWUpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGxvYWRFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihsb2FkRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGxvYWRFcnJvci5tZXNzYWdlIDogJ0ZhaWxlZCB0byBsb2FkIHByb2ZpbGUuJylcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbG9hZFByb2ZpbGUoKVxyXG5cclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgfSwgW10pXHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2F2ZVVzZXJuYW1lID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5leHRVc2VybmFtZSA9IHVzZXJuYW1lLnRyaW0oKVxyXG4gICAgICAgIGlmICghcHJvZmlsZSB8fCAhbmV4dFVzZXJuYW1lIHx8IG5leHRVc2VybmFtZSA9PT0gcHJvZmlsZS51c2VybmFtZSkge1xyXG4gICAgICAgICAgICBzZXRFZGl0aW5nKGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRVc2VybmFtZShwcm9maWxlPy51c2VybmFtZSA/PyAnJylcclxuICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRTYXZpbmcodHJ1ZSlcclxuICAgICAgICAgICAgc2V0U2F2ZUVycm9yKCcnKVxyXG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgdXBkYXRlQ3VycmVudFVzZXIoeyB1c2VybmFtZTogbmV4dFVzZXJuYW1lIH0pXHJcbiAgICAgICAgICAgIHNldFByb2ZpbGUodXBkYXRlZClcclxuICAgICAgICAgICAgc2V0VXNlcm5hbWUodXBkYXRlZC51c2VybmFtZSlcclxuICAgICAgICAgICAgc2V0RWRpdGluZyhmYWxzZSlcclxuICAgICAgICAgICAgb25Qcm9maWxlVXBkYXRlZCh1cGRhdGVkKVxyXG4gICAgICAgIH0gY2F0Y2ggKHNhdmVFcnJvclZhbHVlKSB7XHJcbiAgICAgICAgICAgIHNldFNhdmVFcnJvcihzYXZlRXJyb3JWYWx1ZSBpbnN0YW5jZW9mIEVycm9yID8gc2F2ZUVycm9yVmFsdWUubWVzc2FnZSA6ICdGYWlsZWQgdG8gdXBkYXRlIHByb2ZpbGUuJylcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRTYXZpbmcoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUF2YXRhckNoYW5nZSA9IGFzeW5jIChldmVudDogQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcclxuICAgICAgICBjb25zdCBmaWxlID0gZXZlbnQudGFyZ2V0LmZpbGVzPy5bMF1cclxuICAgICAgICBldmVudC50YXJnZXQudmFsdWUgPSAnJ1xyXG5cclxuICAgICAgICBpZiAoIWZpbGUpIHJldHVyblxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRVcGxvYWRpbmcodHJ1ZSlcclxuICAgICAgICAgICAgc2V0VXBsb2FkRXJyb3IoJycpXHJcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCB1cGxvYWRBdmF0YXIoZmlsZSlcclxuICAgICAgICAgICAgc2V0UHJvZmlsZSh1cGRhdGVkKVxyXG4gICAgICAgICAgICBvblByb2ZpbGVVcGRhdGVkKHVwZGF0ZWQpXHJcbiAgICAgICAgfSBjYXRjaCAodXBsb2FkRXJyb3JWYWx1ZSkge1xyXG4gICAgICAgICAgICBzZXRVcGxvYWRFcnJvcih1cGxvYWRFcnJvclZhbHVlIGluc3RhbmNlb2YgRXJyb3IgPyB1cGxvYWRFcnJvclZhbHVlLm1lc3NhZ2UgOiAnRmFpbGVkIHRvIHVwbG9hZCBhdmF0YXIuJylcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRVcGxvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG1lbWJlclNpbmNlID0gcHJvZmlsZT8uY3JlYXRlZF9hdFxyXG4gICAgICAgID8gbmV3IERhdGUocHJvZmlsZS5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgICAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICAgICAgICAgIG1vbnRoOiAnbG9uZycsXHJcbiAgICAgICAgICAgICAgeWVhcjogJ251bWVyaWMnLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICA6IG51bGxcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1iYWNrZHJvcFwiIG9uQ2xpY2s9eyhldmVudCkgPT4gZXZlbnQudGFyZ2V0ID09PSBldmVudC5jdXJyZW50VGFyZ2V0ICYmIG9uQ2xvc2UoKX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1tb2RhbFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcm9maWxlLWNsb3NlXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ2xvc2V9IGFyaWEtbGFiZWw9XCJDbG9zZSBwcm9maWxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgeFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAge2xvYWRpbmcgJiYgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWxvYWRpbmdcIj5Mb2FkaW5nIHByb2ZpbGUuLi48L2Rpdj59XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWVycm9yXCI+e2Vycm9yfTwvZGl2Pn1cclxuXHJcbiAgICAgICAgICAgICAgICB7cHJvZmlsZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWhlYWRlci1iYW5kXCIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1hdmF0YXItcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtYXZhdGFyLXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXZhdGFyIHVybD17cHJvZmlsZS5hdmF0YXJfdXJsfSB1c2VybmFtZT17cHJvZmlsZS51c2VybmFtZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtYXZhdGFyLWVkaXQtYnRuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXBsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2hhbmdlIGF2YXRhclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXBsb2FkaW5nID8gJy4uLicgOiAnQ2hhbmdlJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvcG5nLGltYWdlL2pwZWcsaW1hZ2UvanBnLGltYWdlL3dlYnBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWF2YXRhci1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVBdmF0YXJDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1pZGVudGl0eVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtZWRpdC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtdXNlcm5hbWUtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRVc2VybmFtZShldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFbnRlcicpIGhhbmRsZVNhdmVVc2VybmFtZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFc2NhcGUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXNlcm5hbWUocHJvZmlsZS51c2VybmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNhdmVFcnJvcignJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWVkaXQtYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHJvZmlsZS1zYXZlLWJ0blwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlVXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2F2aW5nID8gJ1NhdmluZy4uLicgOiAnU2F2ZSd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWNhbmNlbC1idG5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZyhmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVzZXJuYW1lKHByb2ZpbGUudXNlcm5hbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTYXZlRXJyb3IoJycpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NhdmVFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtc2F2ZS1lcnJvclwiPntzYXZlRXJyb3J9PC9kaXY+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtdXNlcm5hbWUtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLXVzZXJuYW1lXCI+e3Byb2ZpbGUudXNlcm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtZWRpdC1pY29uLWJ0blwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZyh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLWVtYWlsXCI+e3Byb2ZpbGUuZW1haWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VwbG9hZEVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS11cGxvYWQtZXJyb3JcIj57dXBsb2FkRXJyb3J9PC9kaXY+fVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLW1ldGEtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge21lbWJlclNpbmNlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtbWV0YS1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtbWV0YS1sYWJlbFwiPk1lbWJlciBzaW5jZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1tZXRhLXZhbHVlXCI+e21lbWJlclNpbmNlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtbWV0YS1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1tZXRhLWxhYmVsXCI+VXNlciBJRDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLW1ldGEtdmFsdWUgcHJvZmlsZS1tZXRhLWlkXCI+e3Byb2ZpbGUuaWQuc2xpY2UoMCwgOCl9Li4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXJ0aS9Eb2N1bWVudHMvR2l0SHViL1NvZnR3YXJlLVByb2plY3QtRzEwL1Byb2plY3Qvc3JjL1Byb2ZpbGVNb2RhbC50c3gifQ==