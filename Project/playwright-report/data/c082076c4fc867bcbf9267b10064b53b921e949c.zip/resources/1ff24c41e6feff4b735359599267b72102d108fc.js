import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SuggestionsPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useState = __vite__cjsImport3_react["useState"];
import { getSuggestions } from "/src/api.ts?t=1780399643427";
import { getCategoryIcon, getVisibleTags } from "/src/categoryIcons.ts";
function formatBudget(budget) {
  return budget === null ? "Budget unknown" : `€${budget.toFixed(2)}`;
}
function getFriendAttendance(suggestion, events, friendIds) {
  if (suggestion.type !== "event" || friendIds.size === 0)
    return 0;
  const event = events.find((candidate) => candidate.id === suggestion.id);
  return event?.event_participants?.filter((participant) => friendIds.has(participant.user_id)).length ?? 0;
}
function countTagMatches(suggestion, selectedTags) {
  if (selectedTags.size === 0)
    return 0;
  const suggestionTagIds = new Set(suggestion.tags.map((tag) => tag.id));
  return [...selectedTags].filter((tagId) => suggestionTagIds.has(tagId)).length;
}
function buildFriendlyReasons(suggestion, selectedTags, budgetMax, friendCount) {
  const reasons = [];
  if (suggestion.distance_km <= 1) {
    reasons.push("Very close to your map area");
  } else if (suggestion.distance_km <= 3) {
    reasons.push("Nearby and easy to reach");
  } else {
    reasons.push(`${suggestion.distance_km.toFixed(1)} km from your map center`);
  }
  const tagMatches = countTagMatches(suggestion, selectedTags);
  if (tagMatches > 0) {
    reasons.push(`Matches ${tagMatches} tag preference${tagMatches === 1 ? "" : "s"}`);
  }
  if (budgetMax !== void 0) {
    reasons.push(suggestion.budget === null ? "Budget unknown" : "Fits your budget");
  }
  if (friendCount > 0) {
    reasons.push(`${friendCount} friend${friendCount === 1 ? "" : "s"} attending`);
  }
  reasons.push(suggestion.type === "event" ? "Timed event recommendation" : "Flexible plan recommendation");
  return reasons.slice(0, 4);
}
function rankSuggestions(suggestions, selectedTags, budgetMax, events, friendIds) {
  return suggestions.map((suggestion, index) => {
    const friendCount = getFriendAttendance(suggestion, events, friendIds);
    const tagMatches = countTagMatches(suggestion, selectedTags);
    const budgetBoost = budgetMax !== void 0 && suggestion.budget !== null && suggestion.budget <= budgetMax ? 8 : 0;
    const personalizedScore = suggestion.score + friendCount * 14 + tagMatches * 8 + budgetBoost;
    return {
      suggestion,
      index,
      friendCount,
      personalizedScore,
      reasons: buildFriendlyReasons(suggestion, selectedTags, budgetMax, friendCount)
    };
  }).sort((a, b) => {
    if (b.personalizedScore !== a.personalizedScore)
      return b.personalizedScore - a.personalizedScore;
    if (a.suggestion.distance_km !== b.suggestion.distance_km)
      return a.suggestion.distance_km - b.suggestion.distance_km;
    return a.index - b.index;
  });
}
export default function SuggestionsPanel({
  mapCenter,
  selectedTagIds,
  filterType,
  tags,
  events,
  friendIds,
  onSelectSuggestion
}) {
  _s();
  const [radius, setRadius] = useState("10");
  const [budgetMax, setBudgetMax] = useState("");
  const [suggestionType, setSuggestionType] = useState(filterType);
  const [suggestionTagIds, setSuggestionTagIds] = useState(() => new Set(selectedTagIds));
  const [results, setResults] = useState([]);
  const [resultContext, setResultContext] = useState({
    selectedTags: new Set(selectedTagIds),
    type: filterType,
    budgetMax: void 0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [excludedByBudget, setExcludedByBudget] = useState(0);
  const selectedTagNames = [...suggestionTagIds].map((id) => tags.find((tag) => tag.id === id)?.name).filter(Boolean).join(", ");
  const rankedResults = rankSuggestions(results, resultContext.selectedTags, resultContext.budgetMax, events, friendIds);
  const topPick = rankedResults[0];
  const morePicks = rankedResults.slice(1);
  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    setHasSearched(true);
    setExcludedByBudget(0);
    const parsedRadius = Number(radius);
    const parsedBudget = budgetMax.trim() ? Number(budgetMax) : void 0;
    if (!Number.isFinite(parsedRadius) || parsedRadius <= 0) {
      setLoading(false);
      setError("Radius must be a positive number.");
      return;
    }
    if (parsedBudget !== void 0 && (!Number.isFinite(parsedBudget) || parsedBudget < 0)) {
      setLoading(false);
      setError("Budget must be a non-negative number.");
      return;
    }
    try {
      const data = await getSuggestions({
        lat: mapCenter[0],
        lng: mapCenter[1],
        radius: parsedRadius,
        budget_max: parsedBudget,
        tag_ids: [...suggestionTagIds],
        type: suggestionType
      });
      const filteredResults = parsedBudget === void 0 ? data.results : data.results.filter((suggestion) => suggestion.budget === null || suggestion.budget <= parsedBudget);
      setExcludedByBudget(data.results.length - filteredResults.length);
      setResultContext({
        selectedTags: new Set(suggestionTagIds),
        type: suggestionType,
        budgetMax: parsedBudget
      });
      setResults(filteredResults);
    } catch (suggestionError) {
      setError(suggestionError instanceof Error ? suggestionError.message : "Failed to load suggestions.");
      setResults([]);
      setExcludedByBudget(0);
    } finally {
      setLoading(false);
    }
  };
  const toggleSuggestionTag = (tagId) => {
    setSuggestionTagIds((previous) => {
      const next = new Set(previous);
      next.has(tagId) ? next.delete(tagId) : next.add(tagId);
      return next;
    });
  };
  const emptyMessage = excludedByBudget > 0 ? "No suggestions match your max budget. Unknown-budget options would still appear here if available." : `No matching ${resultContext.type === "all" ? "recommendations" : resultContext.type} found. Try widening the radius${resultContext.selectedTags.size > 0 ? ", clearing tag preferences" : ""}${resultContext.budgetMax !== void 0 ? ", or raising the max budget" : ""}.`;
  const renderSuggestionCard = (suggestion, reasons, friendCount, variant) => {
    const { visibleTags, hiddenCount } = getVisibleTags(suggestion.tags, variant === "top" ? 3 : 2);
    return /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: variant === "top" ? "suggestions-panel__top-pick" : "suggestions-panel__item-button",
        onClick: () => onSelectSuggestion(suggestion),
        children: [
          /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__topline", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `suggestions-panel__badge suggestions-panel__badge--${suggestion.type}`, children: [
              /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: getCategoryIcon(suggestion.tags, suggestion.type) }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
                lineNumber: 226,
                columnNumber: 25
              }, this),
              suggestion.type
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 225,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__score", children: [
              suggestion.score.toFixed(0),
              " match"
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 229,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 224,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__name", children: suggestion.name }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 231,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__meta", children: [
            suggestion.distance_km.toFixed(1),
            " km · ",
            formatBudget(suggestion.budget),
            friendCount > 0 && ` · ${friendCount} friend${friendCount === 1 ? "" : "s"} attending`
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 232,
            columnNumber: 17
          }, this),
          visibleTags.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__tags", children: [
            visibleTags.map(
              (tag) => /* @__PURE__ */ jsxDEV("span", { children: [
                "#",
                tag.name
              ] }, tag.id, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
                lineNumber: 239,
                columnNumber: 11
              }, this)
            ),
            hiddenCount > 0 && /* @__PURE__ */ jsxDEV("span", { children: [
              "+",
              hiddenCount,
              " more"
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 241,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 237,
            columnNumber: 9
          }, this),
          reasons.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__why", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Why suggested" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 246,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: reasons.map(
              (reason) => /* @__PURE__ */ jsxDEV("em", { children: reason }, reason, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
                lineNumber: 249,
                columnNumber: 13
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 247,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 245,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 219,
        columnNumber: 7
      },
      this
    );
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "suggestions-panel", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__header", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__eyebrow", children: "For you" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 261,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__title", children: "Recommended picks" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 262,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__subtitle", children: "Tune your mood, then get a ranked daily pick." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 263,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 260,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { className: "suggestions-panel__form", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__segmented", "aria-label": "Suggestion type", children: [
        ["all", "Both"],
        ["events", "Events"],
        ["plans", "Plans"]
      ].map(
        ([value, label]) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: suggestionType === value ? "suggestions-panel__segment suggestions-panel__segment--active" : "suggestions-panel__segment",
            onClick: () => setSuggestionType(value),
            children: label
          },
          value,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 272,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 266,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__row", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "suggestions-panel__field", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Radius km" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 284,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              min: "0.1",
              step: "0.1",
              value: radius,
              onChange: (event) => setRadius(event.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 285,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
          lineNumber: 283,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "suggestions-panel__field", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Max budget" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 294,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              min: "0",
              step: "0.01",
              value: budgetMax,
              onChange: (event) => setBudgetMax(event.target.value),
              placeholder: "Any"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
              lineNumber: 295,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
          lineNumber: 293,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 282,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__tag-preferences", "aria-label": "Suggestion tag preferences", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Preference tags" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
          lineNumber: 306,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          tags.length === 0 && /* @__PURE__ */ jsxDEV("em", { children: "No tags available." }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
            lineNumber: 308,
            columnNumber: 47
          }, this),
          tags.map(
            (tag) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: suggestionTagIds.has(tag.id) ? "suggestions-panel__tag suggestions-panel__tag--active" : "suggestions-panel__tag",
                onClick: () => toggleSuggestionTag(tag.id),
                children: [
                  "#",
                  tag.name
                ]
              },
              tag.id,
              true,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
                lineNumber: 310,
                columnNumber: 13
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
          lineNumber: 307,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 305,
        columnNumber: 17
      }, this),
      selectedTagNames && /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__hint", children: [
        "Prioritizing: ",
        selectedTagNames
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 322,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "suggestions-panel__submit", disabled: loading, children: loading ? "Finding..." : "Find suggestions" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 324,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 265,
      columnNumber: 13
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__error", children: error }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 328,
      columnNumber: 23
    }, this),
    !loading && !error && results.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__empty", children: hasSearched ? emptyMessage : "No suggestions loaded yet. Pick a type or mood, then find suggestions." }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 330,
      columnNumber: 7
    }, this),
    !loading && !error && excludedByBudget > 0 && results.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__hint", children: [
      "Hidden ",
      excludedByBudget,
      " over-budget result",
      excludedByBudget === 1 ? "" : "s",
      "."
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 335,
      columnNumber: 7
    }, this),
    topPick && /* @__PURE__ */ jsxDEV("div", { className: "suggestions-panel__daily", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "suggestions-panel__daily-label", children: "Top pick for you" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 341,
        columnNumber: 21
      }, this),
      renderSuggestionCard(topPick.suggestion, topPick.reasons, topPick.friendCount, "top")
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 340,
      columnNumber: 7
    }, this),
    morePicks.length > 0 && /* @__PURE__ */ jsxDEV("ul", { className: "suggestions-panel__list", children: morePicks.map(
      ({ suggestion, reasons, friendCount }) => /* @__PURE__ */ jsxDEV("li", { className: "suggestions-panel__item", children: renderSuggestionCard(suggestion, reasons, friendCount, "list") }, `${suggestion.type}-${suggestion.id}`, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
        lineNumber: 348,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
      lineNumber: 346,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx",
    lineNumber: 259,
    columnNumber: 5
  }, this);
}
_s(SuggestionsPanel, "4ZIrYL2v7Qu6tAY+vX1TvrXoEXI=");
_c = SuggestionsPanel;
var _c;
$RefreshReg$(_c, "SuggestionsPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/SuggestionsPanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOE13Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5TXhCLFNBQW9CQSxnQkFBZ0I7QUFDcEMsU0FBbUJDLHNCQUE2QztBQUNoRSxTQUFTQyxpQkFBaUJDLHNCQUFzQjtBQWNoRCxTQUFTQyxhQUFhQyxRQUF1QjtBQUN6QyxTQUFPQSxXQUFXLE9BQU8sbUJBQW1CLElBQUlBLE9BQU9DLFFBQVEsQ0FBQyxDQUFDO0FBQ3JFO0FBRUEsU0FBU0Msb0JBQW9CQyxZQUE4QkMsUUFBb0JDLFdBQXdCO0FBQ25HLE1BQUlGLFdBQVdHLFNBQVMsV0FBV0QsVUFBVUUsU0FBUztBQUFHLFdBQU87QUFDaEUsUUFBTUMsUUFBUUosT0FBT0ssS0FBSyxDQUFDQyxjQUFjQSxVQUFVQyxPQUFPUixXQUFXUSxFQUFFO0FBQ3ZFLFNBQU9ILE9BQU9JLG9CQUFvQkMsT0FBTyxDQUFDQyxnQkFBZ0JULFVBQVVVLElBQUlELFlBQVlFLE9BQU8sQ0FBQyxFQUFFQyxVQUFVO0FBQzVHO0FBRUEsU0FBU0MsZ0JBQWdCZixZQUE4QmdCLGNBQTJCO0FBQzlFLE1BQUlBLGFBQWFaLFNBQVM7QUFBRyxXQUFPO0FBQ3BDLFFBQU1hLG1CQUFtQixJQUFJQyxJQUFJbEIsV0FBV21CLEtBQUtDLElBQUksQ0FBQ0MsUUFBUUEsSUFBSWIsRUFBRSxDQUFDO0FBQ3JFLFNBQU8sQ0FBQyxHQUFHUSxZQUFZLEVBQUVOLE9BQU8sQ0FBQ1ksVUFBVUwsaUJBQWlCTCxJQUFJVSxLQUFLLENBQUMsRUFBRVI7QUFDNUU7QUFFQSxTQUFTUyxxQkFDTHZCLFlBQ0FnQixjQUNBUSxXQUNBQyxhQUNGO0FBQ0UsUUFBTUMsVUFBb0I7QUFFMUIsTUFBSTFCLFdBQVcyQixlQUFlLEdBQUc7QUFDN0JELFlBQVFFLEtBQUssNkJBQTZCO0FBQUEsRUFDOUMsV0FBVzVCLFdBQVcyQixlQUFlLEdBQUc7QUFDcENELFlBQVFFLEtBQUssMEJBQTBCO0FBQUEsRUFDM0MsT0FBTztBQUNIRixZQUFRRSxLQUFLLEdBQUc1QixXQUFXMkIsWUFBWTdCLFFBQVEsQ0FBQyxDQUFDLDBCQUEwQjtBQUFBLEVBQy9FO0FBRUEsUUFBTStCLGFBQWFkLGdCQUFnQmYsWUFBWWdCLFlBQVk7QUFDM0QsTUFBSWEsYUFBYSxHQUFHO0FBQ2hCSCxZQUFRRSxLQUFLLFdBQVdDLFVBQVUsa0JBQWtCQSxlQUFlLElBQUksS0FBSyxHQUFHLEVBQUU7QUFBQSxFQUNyRjtBQUVBLE1BQUlMLGNBQWNNLFFBQVc7QUFDekJKLFlBQVFFLEtBQUs1QixXQUFXSCxXQUFXLE9BQU8sbUJBQW1CLGtCQUFrQjtBQUFBLEVBQ25GO0FBRUEsTUFBSTRCLGNBQWMsR0FBRztBQUNqQkMsWUFBUUUsS0FBSyxHQUFHSCxXQUFXLFVBQVVBLGdCQUFnQixJQUFJLEtBQUssR0FBRyxZQUFZO0FBQUEsRUFDakY7QUFFQUMsVUFBUUUsS0FBSzVCLFdBQVdHLFNBQVMsVUFBVSwrQkFBK0IsOEJBQThCO0FBQ3hHLFNBQU91QixRQUFRSyxNQUFNLEdBQUcsQ0FBQztBQUM3QjtBQUVBLFNBQVNDLGdCQUNMQyxhQUNBakIsY0FDQVEsV0FDQXZCLFFBQ0FDLFdBQ0Y7QUFDRSxTQUFPK0IsWUFDRmIsSUFBSSxDQUFDcEIsWUFBWWtDLFVBQVU7QUFDeEIsVUFBTVQsY0FBYzFCLG9CQUFvQkMsWUFBWUMsUUFBUUMsU0FBUztBQUNyRSxVQUFNMkIsYUFBYWQsZ0JBQWdCZixZQUFZZ0IsWUFBWTtBQUMzRCxVQUFNbUIsY0FBY1gsY0FBY00sVUFBYTlCLFdBQVdILFdBQVcsUUFBUUcsV0FBV0gsVUFBVTJCLFlBQVksSUFBSTtBQUNsSCxVQUFNWSxvQkFBb0JwQyxXQUFXcUMsUUFBU1osY0FBYyxLQUFPSSxhQUFhLElBQUtNO0FBRXJGLFdBQU87QUFBQSxNQUNIbkM7QUFBQUEsTUFDQWtDO0FBQUFBLE1BQ0FUO0FBQUFBLE1BQ0FXO0FBQUFBLE1BQ0FWLFNBQVNILHFCQUFxQnZCLFlBQVlnQixjQUFjUSxXQUFXQyxXQUFXO0FBQUEsSUFDbEY7QUFBQSxFQUNKLENBQUMsRUFDQWEsS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQ1osUUFBSUEsRUFBRUosc0JBQXNCRyxFQUFFSDtBQUFtQixhQUFPSSxFQUFFSixvQkFBb0JHLEVBQUVIO0FBQ2hGLFFBQUlHLEVBQUV2QyxXQUFXMkIsZ0JBQWdCYSxFQUFFeEMsV0FBVzJCO0FBQWEsYUFBT1ksRUFBRXZDLFdBQVcyQixjQUFjYSxFQUFFeEMsV0FBVzJCO0FBQzFHLFdBQU9ZLEVBQUVMLFFBQVFNLEVBQUVOO0FBQUFBLEVBQ3ZCLENBQUM7QUFDVDtBQUVBLHdCQUF3Qk8saUJBQWlCO0FBQUEsRUFDckNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0F6QjtBQUFBQSxFQUNBbEI7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQTJDO0FBQ0csR0FBRztBQUFBQyxLQUFBO0FBQ04sUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl4RCxTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDZ0MsV0FBV3lCLFlBQVksSUFBSXpELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMwRCxnQkFBZ0JDLGlCQUFpQixJQUFJM0QsU0FBeUJvRCxVQUFVO0FBQy9FLFFBQU0sQ0FBQzNCLGtCQUFrQm1DLG1CQUFtQixJQUFJNUQsU0FBc0IsTUFBTSxJQUFJMEIsSUFBSXlCLGNBQWMsQ0FBQztBQUNuRyxRQUFNLENBQUNVLFNBQVNDLFVBQVUsSUFBSTlELFNBQTZCLEVBQUU7QUFDN0QsUUFBTSxDQUFDK0QsZUFBZUMsZ0JBQWdCLElBQUloRSxTQUl2QztBQUFBLElBQ0N3QixjQUFjLElBQUlFLElBQUl5QixjQUFjO0FBQUEsSUFDcEN4QyxNQUFNeUM7QUFBQUEsSUFDTnBCLFdBQVdNO0FBQUFBLEVBQ2YsQ0FBQztBQUNELFFBQU0sQ0FBQzJCLFNBQVNDLFVBQVUsSUFBSWxFLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNtRSxPQUFPQyxRQUFRLElBQUlwRSxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDcUUsYUFBYUMsY0FBYyxJQUFJdEUsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3VFLGtCQUFrQkMsbUJBQW1CLElBQUl4RSxTQUFTLENBQUM7QUFDMUQsUUFBTXlFLG1CQUFtQixDQUFDLEdBQUdoRCxnQkFBZ0IsRUFDeENHLElBQUksQ0FBQ1osT0FBT1csS0FBS2IsS0FBSyxDQUFDZSxRQUFRQSxJQUFJYixPQUFPQSxFQUFFLEdBQUcwRCxJQUFJLEVBQ25EeEQsT0FBT3lELE9BQU8sRUFDZEMsS0FBSyxJQUFJO0FBQ2QsUUFBTUMsZ0JBQWdCckMsZ0JBQWdCcUIsU0FBU0UsY0FBY3ZDLGNBQWN1QyxjQUFjL0IsV0FBV3ZCLFFBQVFDLFNBQVM7QUFDckgsUUFBTW9FLFVBQVVELGNBQWMsQ0FBQztBQUMvQixRQUFNRSxZQUFZRixjQUFjdEMsTUFBTSxDQUFDO0FBRXZDLFFBQU15QyxlQUFlLE9BQU9uRSxVQUFxQjtBQUM3Q0EsVUFBTW9FLGVBQWU7QUFDckJmLGVBQVcsSUFBSTtBQUNmRSxhQUFTLEVBQUU7QUFDWEUsbUJBQWUsSUFBSTtBQUNuQkUsd0JBQW9CLENBQUM7QUFFckIsVUFBTVUsZUFBZUMsT0FBTzVCLE1BQU07QUFDbEMsVUFBTTZCLGVBQWVwRCxVQUFVcUQsS0FBSyxJQUFJRixPQUFPbkQsU0FBUyxJQUFJTTtBQUU1RCxRQUFJLENBQUM2QyxPQUFPRyxTQUFTSixZQUFZLEtBQUtBLGdCQUFnQixHQUFHO0FBQ3JEaEIsaUJBQVcsS0FBSztBQUNoQkUsZUFBUyxtQ0FBbUM7QUFDNUM7QUFBQSxJQUNKO0FBQ0EsUUFBSWdCLGlCQUFpQjlDLFdBQWMsQ0FBQzZDLE9BQU9HLFNBQVNGLFlBQVksS0FBS0EsZUFBZSxJQUFJO0FBQ3BGbEIsaUJBQVcsS0FBSztBQUNoQkUsZUFBUyx1Q0FBdUM7QUFDaEQ7QUFBQSxJQUNKO0FBRUEsUUFBSTtBQUNBLFlBQU1tQixPQUFPLE1BQU10RixlQUFlO0FBQUEsUUFDOUJ1RixLQUFLdEMsVUFBVSxDQUFDO0FBQUEsUUFDaEJ1QyxLQUFLdkMsVUFBVSxDQUFDO0FBQUEsUUFDaEJLLFFBQVEyQjtBQUFBQSxRQUNSUSxZQUFZTjtBQUFBQSxRQUNaTyxTQUFTLENBQUMsR0FBR2xFLGdCQUFnQjtBQUFBLFFBQzdCZCxNQUFNK0M7QUFBQUEsTUFDVixDQUFDO0FBQ0QsWUFBTWtDLGtCQUFrQlIsaUJBQWlCOUMsU0FDbkNpRCxLQUFLMUIsVUFDTDBCLEtBQUsxQixRQUFRM0MsT0FBTyxDQUFDVixlQUFlQSxXQUFXSCxXQUFXLFFBQVFHLFdBQVdILFVBQVUrRSxZQUFZO0FBQ3pHWiwwQkFBb0JlLEtBQUsxQixRQUFRdkMsU0FBU3NFLGdCQUFnQnRFLE1BQU07QUFDaEUwQyx1QkFBaUI7QUFBQSxRQUNieEMsY0FBYyxJQUFJRSxJQUFJRCxnQkFBZ0I7QUFBQSxRQUN0Q2QsTUFBTStDO0FBQUFBLFFBQ04xQixXQUFXb0Q7QUFBQUEsTUFDZixDQUFDO0FBQ0R0QixpQkFBVzhCLGVBQWU7QUFBQSxJQUM5QixTQUFTQyxpQkFBaUI7QUFDdEJ6QixlQUFTeUIsMkJBQTJCQyxRQUFRRCxnQkFBZ0JFLFVBQVUsNkJBQTZCO0FBQ25HakMsaUJBQVcsRUFBRTtBQUNiVSwwQkFBb0IsQ0FBQztBQUFBLElBQ3pCLFVBQUM7QUFDR04saUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBLFFBQU04QixzQkFBc0JBLENBQUNsRSxVQUFrQjtBQUMzQzhCLHdCQUFvQixDQUFDcUMsYUFBYTtBQUM5QixZQUFNQyxPQUFPLElBQUl4RSxJQUFJdUUsUUFBUTtBQUM3QkMsV0FBSzlFLElBQUlVLEtBQUssSUFBSW9FLEtBQUtDLE9BQU9yRSxLQUFLLElBQUlvRSxLQUFLRSxJQUFJdEUsS0FBSztBQUNyRCxhQUFPb0U7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1HLGVBQWU5QixtQkFBbUIsSUFDbEMsdUdBQ0EsZUFBZVIsY0FBY3BELFNBQVMsUUFBUSxvQkFBb0JvRCxjQUFjcEQsSUFBSSxrQ0FBa0NvRCxjQUFjdkMsYUFBYVosT0FBTyxJQUFJLCtCQUErQixFQUFFLEdBQUdtRCxjQUFjL0IsY0FBY00sU0FBWSxnQ0FBZ0MsRUFBRTtBQUVoUixRQUFNZ0UsdUJBQXVCQSxDQUN6QjlGLFlBQ0EwQixTQUNBRCxhQUNBc0UsWUFDQztBQUNELFVBQU0sRUFBRUMsYUFBYUMsWUFBWSxJQUFJdEcsZUFBZUssV0FBV21CLE1BQU00RSxZQUFZLFFBQVEsSUFBSSxDQUFDO0FBRTlGLFdBQ0k7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQUs7QUFBQSxRQUNMLFdBQVdBLFlBQVksUUFBUSxnQ0FBZ0M7QUFBQSxRQUMvRCxTQUFTLE1BQU1sRCxtQkFBbUI3QyxVQUFVO0FBQUEsUUFFNUM7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsOEJBQ1o7QUFBQSxtQ0FBQyxVQUFLLFdBQVcsc0RBQXNEQSxXQUFXRyxJQUFJLElBQ2xGO0FBQUEscUNBQUMsVUFBSyxlQUFZLFFBQVFULDBCQUFnQk0sV0FBV21CLE1BQU1uQixXQUFXRyxJQUFJLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUEsY0FDM0VILFdBQVdHO0FBQUFBLGlCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsNEJBQTRCSDtBQUFBQSx5QkFBV3FDLE1BQU12QyxRQUFRLENBQUM7QUFBQSxjQUFFO0FBQUEsaUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsZUFMbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLDJCQUEyQkUscUJBQVdrRSxRQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLFVBQzNELHVCQUFDLFVBQUssV0FBVSwyQkFDWGxFO0FBQUFBLHVCQUFXMkIsWUFBWTdCLFFBQVEsQ0FBQztBQUFBLFlBQUU7QUFBQSxZQUFPRixhQUFhSSxXQUFXSCxNQUFNO0FBQUEsWUFDdkU0QixjQUFjLEtBQUssTUFBTUEsV0FBVyxVQUFVQSxnQkFBZ0IsSUFBSSxLQUFLLEdBQUc7QUFBQSxlQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQ3VFLFlBQVlsRixTQUFTLEtBQ2xCLHVCQUFDLFVBQUssV0FBVSwyQkFDWGtGO0FBQUFBLHdCQUFZNUU7QUFBQUEsY0FBSSxDQUFDQyxRQUNkLHVCQUFDLFVBQWtCO0FBQUE7QUFBQSxnQkFBRUEsSUFBSTZDO0FBQUFBLG1CQUFkN0MsSUFBSWIsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLFlBQ2pDO0FBQUEsWUFDQXlGLGNBQWMsS0FBSyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxjQUFFQTtBQUFBQSxjQUFZO0FBQUEsaUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUEsZUFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUh2RSxRQUFRWixTQUFTLEtBQ2QsdUJBQUMsVUFBSyxXQUFVLDBCQUNaO0FBQUEsbUNBQUMsWUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLFlBQ3JCLHVCQUFDLFVBQ0lZLGtCQUFRTjtBQUFBQSxjQUFJLENBQUM4RSxXQUNWLHVCQUFDLFFBQWlCQSxvQkFBVEEsUUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLFlBQzVCLEtBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBO0FBQUE7QUFBQSxNQWpDUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtQ0E7QUFBQSxFQUVSO0FBRUEsU0FDSSx1QkFBQyxhQUFRLFdBQVUscUJBQ2Y7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSw2QkFBQyxVQUFLLFdBQVUsOEJBQTZCLHVCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9EO0FBQUEsTUFDcEQsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQixpQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFVBQUssV0FBVSwrQkFBOEIsNkRBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkY7QUFBQSxTQUgvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFBMEIsVUFBVTFCLGNBQ2hEO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUErQixjQUFXLG1CQUNuRDtBQUFBLFFBQ0UsQ0FBQyxPQUFPLE1BQU07QUFBQSxRQUNkLENBQUMsVUFBVSxRQUFRO0FBQUEsUUFDbkIsQ0FBQyxTQUFTLE9BQU87QUFBQSxNQUFDLEVBQ1ZwRDtBQUFBQSxRQUFJLENBQUMsQ0FBQytFLE9BQU9DLEtBQUssTUFDMUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVHLE1BQUs7QUFBQSxZQUNMLFdBQVdsRCxtQkFBbUJpRCxRQUFRLGtFQUFrRTtBQUFBLFlBQ3hHLFNBQVMsTUFBTWhELGtCQUFrQmdELEtBQUs7QUFBQSxZQUVyQ0M7QUFBQUE7QUFBQUEsVUFMSUQ7QUFBQUEsVUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxNQUNILEtBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsNEJBQ2I7QUFBQSxpQ0FBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUNmO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxLQUFJO0FBQUEsY0FDSixNQUFLO0FBQUEsY0FDTCxPQUFPcEQ7QUFBQUEsY0FDUCxVQUFVLENBQUMxQyxVQUFVMkMsVUFBVTNDLE1BQU1nRyxPQUFPRixLQUFLO0FBQUE7QUFBQSxZQUxyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLdUQ7QUFBQSxhQVAzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSw0QkFDYjtBQUFBLGlDQUFDLFVBQUssMEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUNoQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsS0FBSTtBQUFBLGNBQ0osTUFBSztBQUFBLGNBQ0wsT0FBTzNFO0FBQUFBLGNBQ1AsVUFBVSxDQUFDbkIsVUFBVTRDLGFBQWE1QyxNQUFNZ0csT0FBT0YsS0FBSztBQUFBLGNBQ3BELGFBQVk7QUFBQTtBQUFBLFlBTmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1xQjtBQUFBLGFBUnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FBcUMsY0FBVyw4QkFDM0Q7QUFBQSwrQkFBQyxVQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUI7QUFBQSxRQUNyQix1QkFBQyxTQUNJaEY7QUFBQUEsZUFBS0wsV0FBVyxLQUFLLHVCQUFDLFFBQUcsa0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUMzQ0ssS0FBS0M7QUFBQUEsWUFBSSxDQUFDQyxRQUNQO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUcsTUFBSztBQUFBLGdCQUNMLFdBQVdKLGlCQUFpQkwsSUFBSVMsSUFBSWIsRUFBRSxJQUFJLDBEQUEwRDtBQUFBLGdCQUNwRyxTQUFTLE1BQU1nRixvQkFBb0JuRSxJQUFJYixFQUFFO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGtCQUV6Q2EsSUFBSTZDO0FBQUFBO0FBQUFBO0FBQUFBLGNBTEQ3QyxJQUFJYjtBQUFBQSxjQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLFVBQ0g7QUFBQSxhQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFDQ3lELG9CQUNHLHVCQUFDLFNBQUksV0FBVSwyQkFBMEI7QUFBQTtBQUFBLFFBQWVBO0FBQUFBLFdBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUU3RSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLDZCQUE0QixVQUFVUixTQUNqRUEsb0JBQVUsZUFBZSxzQkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0E3REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThEQTtBQUFBLElBQ0NFLFNBQVMsdUJBQUMsU0FBSSxXQUFVLDRCQUE0QkEsbUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxJQUMxRCxDQUFDRixXQUFXLENBQUNFLFNBQVNOLFFBQVF2QyxXQUFXLEtBQ3RDLHVCQUFDLFNBQUksV0FBVSw0QkFDVitDLHdCQUFjZ0MsZUFBZSw0RUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFSCxDQUFDcEMsV0FBVyxDQUFDRSxTQUFTSSxtQkFBbUIsS0FBS1YsUUFBUXZDLFNBQVMsS0FDNUQsdUJBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsTUFDN0JpRDtBQUFBQSxNQUFpQjtBQUFBLE1BQW9CQSxxQkFBcUIsSUFBSSxLQUFLO0FBQUEsTUFBSTtBQUFBLFNBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUhPLFdBQ0csdUJBQUMsU0FBSSxXQUFVLDRCQUNYO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGtDQUFpQyxnQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLE1BQ2hFd0IscUJBQXFCeEIsUUFBUXRFLFlBQVlzRSxRQUFRNUMsU0FBUzRDLFFBQVE3QyxhQUFhLEtBQUs7QUFBQSxTQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVIOEMsVUFBVXpELFNBQVMsS0FDaEIsdUJBQUMsUUFBRyxXQUFVLDJCQUNUeUQsb0JBQVVuRDtBQUFBQSxNQUFJLENBQUMsRUFBRXBCLFlBQVkwQixTQUFTRCxZQUFZLE1BQy9DLHVCQUFDLFFBQStDLFdBQVUsMkJBQ3JEcUUsK0JBQXFCOUYsWUFBWTBCLFNBQVNELGFBQWEsTUFBTSxLQUR6RCxHQUFHekIsV0FBV0csSUFBSSxJQUFJSCxXQUFXUSxFQUFFLElBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLElBQ0gsS0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQTdGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0ZBO0FBRVI7QUFBQ3NDLEdBbFB1Qkwsa0JBQWdCO0FBQUEsS0FBaEJBO0FBQWdCLElBQUE2RDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImdldFN1Z2dlc3Rpb25zIiwiZ2V0Q2F0ZWdvcnlJY29uIiwiZ2V0VmlzaWJsZVRhZ3MiLCJmb3JtYXRCdWRnZXQiLCJidWRnZXQiLCJ0b0ZpeGVkIiwiZ2V0RnJpZW5kQXR0ZW5kYW5jZSIsInN1Z2dlc3Rpb24iLCJldmVudHMiLCJmcmllbmRJZHMiLCJ0eXBlIiwic2l6ZSIsImV2ZW50IiwiZmluZCIsImNhbmRpZGF0ZSIsImlkIiwiZXZlbnRfcGFydGljaXBhbnRzIiwiZmlsdGVyIiwicGFydGljaXBhbnQiLCJoYXMiLCJ1c2VyX2lkIiwibGVuZ3RoIiwiY291bnRUYWdNYXRjaGVzIiwic2VsZWN0ZWRUYWdzIiwic3VnZ2VzdGlvblRhZ0lkcyIsIlNldCIsInRhZ3MiLCJtYXAiLCJ0YWciLCJ0YWdJZCIsImJ1aWxkRnJpZW5kbHlSZWFzb25zIiwiYnVkZ2V0TWF4IiwiZnJpZW5kQ291bnQiLCJyZWFzb25zIiwiZGlzdGFuY2Vfa20iLCJwdXNoIiwidGFnTWF0Y2hlcyIsInVuZGVmaW5lZCIsInNsaWNlIiwicmFua1N1Z2dlc3Rpb25zIiwic3VnZ2VzdGlvbnMiLCJpbmRleCIsImJ1ZGdldEJvb3N0IiwicGVyc29uYWxpemVkU2NvcmUiLCJzY29yZSIsInNvcnQiLCJhIiwiYiIsIlN1Z2dlc3Rpb25zUGFuZWwiLCJtYXBDZW50ZXIiLCJzZWxlY3RlZFRhZ0lkcyIsImZpbHRlclR5cGUiLCJvblNlbGVjdFN1Z2dlc3Rpb24iLCJfcyIsInJhZGl1cyIsInNldFJhZGl1cyIsInNldEJ1ZGdldE1heCIsInN1Z2dlc3Rpb25UeXBlIiwic2V0U3VnZ2VzdGlvblR5cGUiLCJzZXRTdWdnZXN0aW9uVGFnSWRzIiwicmVzdWx0cyIsInNldFJlc3VsdHMiLCJyZXN1bHRDb250ZXh0Iiwic2V0UmVzdWx0Q29udGV4dCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImhhc1NlYXJjaGVkIiwic2V0SGFzU2VhcmNoZWQiLCJleGNsdWRlZEJ5QnVkZ2V0Iiwic2V0RXhjbHVkZWRCeUJ1ZGdldCIsInNlbGVjdGVkVGFnTmFtZXMiLCJuYW1lIiwiQm9vbGVhbiIsImpvaW4iLCJyYW5rZWRSZXN1bHRzIiwidG9wUGljayIsIm1vcmVQaWNrcyIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwicGFyc2VkUmFkaXVzIiwiTnVtYmVyIiwicGFyc2VkQnVkZ2V0IiwidHJpbSIsImlzRmluaXRlIiwiZGF0YSIsImxhdCIsImxuZyIsImJ1ZGdldF9tYXgiLCJ0YWdfaWRzIiwiZmlsdGVyZWRSZXN1bHRzIiwic3VnZ2VzdGlvbkVycm9yIiwiRXJyb3IiLCJtZXNzYWdlIiwidG9nZ2xlU3VnZ2VzdGlvblRhZyIsInByZXZpb3VzIiwibmV4dCIsImRlbGV0ZSIsImFkZCIsImVtcHR5TWVzc2FnZSIsInJlbmRlclN1Z2dlc3Rpb25DYXJkIiwidmFyaWFudCIsInZpc2libGVUYWdzIiwiaGlkZGVuQ291bnQiLCJyZWFzb24iLCJ2YWx1ZSIsImxhYmVsIiwidGFyZ2V0IiwiX2MiXSwic291cmNlcyI6WyJTdWdnZXN0aW9uc1BhbmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGb3JtRXZlbnQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEFwaUV2ZW50LCBnZXRTdWdnZXN0aW9ucywgU3VnZ2VzdGlvblJlc3VsdCwgVGFnIH0gZnJvbSAnLi9hcGknXHJcbmltcG9ydCB7IGdldENhdGVnb3J5SWNvbiwgZ2V0VmlzaWJsZVRhZ3MgfSBmcm9tICcuL2NhdGVnb3J5SWNvbnMnXHJcblxyXG50eXBlIFN1Z2dlc3Rpb25UeXBlID0gJ2FsbCcgfCAnZXZlbnRzJyB8ICdwbGFucydcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgICBtYXBDZW50ZXI6IFtudW1iZXIsIG51bWJlcl1cclxuICAgIHNlbGVjdGVkVGFnSWRzOiBTZXQ8bnVtYmVyPlxyXG4gICAgZmlsdGVyVHlwZTogU3VnZ2VzdGlvblR5cGVcclxuICAgIHRhZ3M6IFRhZ1tdXHJcbiAgICBldmVudHM6IEFwaUV2ZW50W11cclxuICAgIGZyaWVuZElkczogU2V0PHN0cmluZz5cclxuICAgIG9uU2VsZWN0U3VnZ2VzdGlvbjogKHN1Z2dlc3Rpb246IFN1Z2dlc3Rpb25SZXN1bHQpID0+IHZvaWRcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0QnVkZ2V0KGJ1ZGdldDogbnVtYmVyIHwgbnVsbCkge1xyXG4gICAgcmV0dXJuIGJ1ZGdldCA9PT0gbnVsbCA/ICdCdWRnZXQgdW5rbm93bicgOiBg4oKsJHtidWRnZXQudG9GaXhlZCgyKX1gXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldEZyaWVuZEF0dGVuZGFuY2Uoc3VnZ2VzdGlvbjogU3VnZ2VzdGlvblJlc3VsdCwgZXZlbnRzOiBBcGlFdmVudFtdLCBmcmllbmRJZHM6IFNldDxzdHJpbmc+KSB7XHJcbiAgICBpZiAoc3VnZ2VzdGlvbi50eXBlICE9PSAnZXZlbnQnIHx8IGZyaWVuZElkcy5zaXplID09PSAwKSByZXR1cm4gMFxyXG4gICAgY29uc3QgZXZlbnQgPSBldmVudHMuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IHN1Z2dlc3Rpb24uaWQpXHJcbiAgICByZXR1cm4gZXZlbnQ/LmV2ZW50X3BhcnRpY2lwYW50cz8uZmlsdGVyKChwYXJ0aWNpcGFudCkgPT4gZnJpZW5kSWRzLmhhcyhwYXJ0aWNpcGFudC51c2VyX2lkKSkubGVuZ3RoID8/IDBcclxufVxyXG5cclxuZnVuY3Rpb24gY291bnRUYWdNYXRjaGVzKHN1Z2dlc3Rpb246IFN1Z2dlc3Rpb25SZXN1bHQsIHNlbGVjdGVkVGFnczogU2V0PG51bWJlcj4pIHtcclxuICAgIGlmIChzZWxlY3RlZFRhZ3Muc2l6ZSA9PT0gMCkgcmV0dXJuIDBcclxuICAgIGNvbnN0IHN1Z2dlc3Rpb25UYWdJZHMgPSBuZXcgU2V0KHN1Z2dlc3Rpb24udGFncy5tYXAoKHRhZykgPT4gdGFnLmlkKSlcclxuICAgIHJldHVybiBbLi4uc2VsZWN0ZWRUYWdzXS5maWx0ZXIoKHRhZ0lkKSA9PiBzdWdnZXN0aW9uVGFnSWRzLmhhcyh0YWdJZCkpLmxlbmd0aFxyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEZyaWVuZGx5UmVhc29ucyhcclxuICAgIHN1Z2dlc3Rpb246IFN1Z2dlc3Rpb25SZXN1bHQsXHJcbiAgICBzZWxlY3RlZFRhZ3M6IFNldDxudW1iZXI+LFxyXG4gICAgYnVkZ2V0TWF4OiBudW1iZXIgfCB1bmRlZmluZWQsXHJcbiAgICBmcmllbmRDb3VudDogbnVtYmVyLFxyXG4pIHtcclxuICAgIGNvbnN0IHJlYXNvbnM6IHN0cmluZ1tdID0gW11cclxuXHJcbiAgICBpZiAoc3VnZ2VzdGlvbi5kaXN0YW5jZV9rbSA8PSAxKSB7XHJcbiAgICAgICAgcmVhc29ucy5wdXNoKCdWZXJ5IGNsb3NlIHRvIHlvdXIgbWFwIGFyZWEnKVxyXG4gICAgfSBlbHNlIGlmIChzdWdnZXN0aW9uLmRpc3RhbmNlX2ttIDw9IDMpIHtcclxuICAgICAgICByZWFzb25zLnB1c2goJ05lYXJieSBhbmQgZWFzeSB0byByZWFjaCcpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlYXNvbnMucHVzaChgJHtzdWdnZXN0aW9uLmRpc3RhbmNlX2ttLnRvRml4ZWQoMSl9IGttIGZyb20geW91ciBtYXAgY2VudGVyYClcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0YWdNYXRjaGVzID0gY291bnRUYWdNYXRjaGVzKHN1Z2dlc3Rpb24sIHNlbGVjdGVkVGFncylcclxuICAgIGlmICh0YWdNYXRjaGVzID4gMCkge1xyXG4gICAgICAgIHJlYXNvbnMucHVzaChgTWF0Y2hlcyAke3RhZ01hdGNoZXN9IHRhZyBwcmVmZXJlbmNlJHt0YWdNYXRjaGVzID09PSAxID8gJycgOiAncyd9YClcclxuICAgIH1cclxuXHJcbiAgICBpZiAoYnVkZ2V0TWF4ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICByZWFzb25zLnB1c2goc3VnZ2VzdGlvbi5idWRnZXQgPT09IG51bGwgPyAnQnVkZ2V0IHVua25vd24nIDogJ0ZpdHMgeW91ciBidWRnZXQnKVxyXG4gICAgfVxyXG5cclxuICAgIGlmIChmcmllbmRDb3VudCA+IDApIHtcclxuICAgICAgICByZWFzb25zLnB1c2goYCR7ZnJpZW5kQ291bnR9IGZyaWVuZCR7ZnJpZW5kQ291bnQgPT09IDEgPyAnJyA6ICdzJ30gYXR0ZW5kaW5nYClcclxuICAgIH1cclxuXHJcbiAgICByZWFzb25zLnB1c2goc3VnZ2VzdGlvbi50eXBlID09PSAnZXZlbnQnID8gJ1RpbWVkIGV2ZW50IHJlY29tbWVuZGF0aW9uJyA6ICdGbGV4aWJsZSBwbGFuIHJlY29tbWVuZGF0aW9uJylcclxuICAgIHJldHVybiByZWFzb25zLnNsaWNlKDAsIDQpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJhbmtTdWdnZXN0aW9ucyhcclxuICAgIHN1Z2dlc3Rpb25zOiBTdWdnZXN0aW9uUmVzdWx0W10sXHJcbiAgICBzZWxlY3RlZFRhZ3M6IFNldDxudW1iZXI+LFxyXG4gICAgYnVkZ2V0TWF4OiBudW1iZXIgfCB1bmRlZmluZWQsXHJcbiAgICBldmVudHM6IEFwaUV2ZW50W10sXHJcbiAgICBmcmllbmRJZHM6IFNldDxzdHJpbmc+LFxyXG4pIHtcclxuICAgIHJldHVybiBzdWdnZXN0aW9uc1xyXG4gICAgICAgIC5tYXAoKHN1Z2dlc3Rpb24sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZyaWVuZENvdW50ID0gZ2V0RnJpZW5kQXR0ZW5kYW5jZShzdWdnZXN0aW9uLCBldmVudHMsIGZyaWVuZElkcylcclxuICAgICAgICAgICAgY29uc3QgdGFnTWF0Y2hlcyA9IGNvdW50VGFnTWF0Y2hlcyhzdWdnZXN0aW9uLCBzZWxlY3RlZFRhZ3MpXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1ZGdldEJvb3N0ID0gYnVkZ2V0TWF4ICE9PSB1bmRlZmluZWQgJiYgc3VnZ2VzdGlvbi5idWRnZXQgIT09IG51bGwgJiYgc3VnZ2VzdGlvbi5idWRnZXQgPD0gYnVkZ2V0TWF4ID8gOCA6IDBcclxuICAgICAgICAgICAgY29uc3QgcGVyc29uYWxpemVkU2NvcmUgPSBzdWdnZXN0aW9uLnNjb3JlICsgKGZyaWVuZENvdW50ICogMTQpICsgKHRhZ01hdGNoZXMgKiA4KSArIGJ1ZGdldEJvb3N0XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgc3VnZ2VzdGlvbixcclxuICAgICAgICAgICAgICAgIGluZGV4LFxyXG4gICAgICAgICAgICAgICAgZnJpZW5kQ291bnQsXHJcbiAgICAgICAgICAgICAgICBwZXJzb25hbGl6ZWRTY29yZSxcclxuICAgICAgICAgICAgICAgIHJlYXNvbnM6IGJ1aWxkRnJpZW5kbHlSZWFzb25zKHN1Z2dlc3Rpb24sIHNlbGVjdGVkVGFncywgYnVkZ2V0TWF4LCBmcmllbmRDb3VudCksXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChiLnBlcnNvbmFsaXplZFNjb3JlICE9PSBhLnBlcnNvbmFsaXplZFNjb3JlKSByZXR1cm4gYi5wZXJzb25hbGl6ZWRTY29yZSAtIGEucGVyc29uYWxpemVkU2NvcmVcclxuICAgICAgICAgICAgaWYgKGEuc3VnZ2VzdGlvbi5kaXN0YW5jZV9rbSAhPT0gYi5zdWdnZXN0aW9uLmRpc3RhbmNlX2ttKSByZXR1cm4gYS5zdWdnZXN0aW9uLmRpc3RhbmNlX2ttIC0gYi5zdWdnZXN0aW9uLmRpc3RhbmNlX2ttXHJcbiAgICAgICAgICAgIHJldHVybiBhLmluZGV4IC0gYi5pbmRleFxyXG4gICAgICAgIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFN1Z2dlc3Rpb25zUGFuZWwoe1xyXG4gICAgbWFwQ2VudGVyLFxyXG4gICAgc2VsZWN0ZWRUYWdJZHMsXHJcbiAgICBmaWx0ZXJUeXBlLFxyXG4gICAgdGFncyxcclxuICAgIGV2ZW50cyxcclxuICAgIGZyaWVuZElkcyxcclxuICAgIG9uU2VsZWN0U3VnZ2VzdGlvbixcclxufTogUHJvcHMpIHtcclxuICAgIGNvbnN0IFtyYWRpdXMsIHNldFJhZGl1c10gPSB1c2VTdGF0ZSgnMTAnKVxyXG4gICAgY29uc3QgW2J1ZGdldE1heCwgc2V0QnVkZ2V0TWF4XSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW3N1Z2dlc3Rpb25UeXBlLCBzZXRTdWdnZXN0aW9uVHlwZV0gPSB1c2VTdGF0ZTxTdWdnZXN0aW9uVHlwZT4oZmlsdGVyVHlwZSlcclxuICAgIGNvbnN0IFtzdWdnZXN0aW9uVGFnSWRzLCBzZXRTdWdnZXN0aW9uVGFnSWRzXSA9IHVzZVN0YXRlPFNldDxudW1iZXI+PigoKSA9PiBuZXcgU2V0KHNlbGVjdGVkVGFnSWRzKSlcclxuICAgIGNvbnN0IFtyZXN1bHRzLCBzZXRSZXN1bHRzXSA9IHVzZVN0YXRlPFN1Z2dlc3Rpb25SZXN1bHRbXT4oW10pXHJcbiAgICBjb25zdCBbcmVzdWx0Q29udGV4dCwgc2V0UmVzdWx0Q29udGV4dF0gPSB1c2VTdGF0ZTx7XHJcbiAgICAgICAgc2VsZWN0ZWRUYWdzOiBTZXQ8bnVtYmVyPlxyXG4gICAgICAgIHR5cGU6IFN1Z2dlc3Rpb25UeXBlXHJcbiAgICAgICAgYnVkZ2V0TWF4OiBudW1iZXIgfCB1bmRlZmluZWRcclxuICAgIH0+KHtcclxuICAgICAgICBzZWxlY3RlZFRhZ3M6IG5ldyBTZXQoc2VsZWN0ZWRUYWdJZHMpLFxyXG4gICAgICAgIHR5cGU6IGZpbHRlclR5cGUsXHJcbiAgICAgICAgYnVkZ2V0TWF4OiB1bmRlZmluZWQsXHJcbiAgICB9KVxyXG4gICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW2hhc1NlYXJjaGVkLCBzZXRIYXNTZWFyY2hlZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtleGNsdWRlZEJ5QnVkZ2V0LCBzZXRFeGNsdWRlZEJ5QnVkZ2V0XSA9IHVzZVN0YXRlKDApXHJcbiAgICBjb25zdCBzZWxlY3RlZFRhZ05hbWVzID0gWy4uLnN1Z2dlc3Rpb25UYWdJZHNdXHJcbiAgICAgICAgLm1hcCgoaWQpID0+IHRhZ3MuZmluZCgodGFnKSA9PiB0YWcuaWQgPT09IGlkKT8ubmFtZSlcclxuICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICAgLmpvaW4oJywgJylcclxuICAgIGNvbnN0IHJhbmtlZFJlc3VsdHMgPSByYW5rU3VnZ2VzdGlvbnMocmVzdWx0cywgcmVzdWx0Q29udGV4dC5zZWxlY3RlZFRhZ3MsIHJlc3VsdENvbnRleHQuYnVkZ2V0TWF4LCBldmVudHMsIGZyaWVuZElkcylcclxuICAgIGNvbnN0IHRvcFBpY2sgPSByYW5rZWRSZXN1bHRzWzBdXHJcbiAgICBjb25zdCBtb3JlUGlja3MgPSByYW5rZWRSZXN1bHRzLnNsaWNlKDEpXHJcblxyXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGV2ZW50OiBGb3JtRXZlbnQpID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgICAgIHNldEVycm9yKCcnKVxyXG4gICAgICAgIHNldEhhc1NlYXJjaGVkKHRydWUpXHJcbiAgICAgICAgc2V0RXhjbHVkZWRCeUJ1ZGdldCgwKVxyXG5cclxuICAgICAgICBjb25zdCBwYXJzZWRSYWRpdXMgPSBOdW1iZXIocmFkaXVzKVxyXG4gICAgICAgIGNvbnN0IHBhcnNlZEJ1ZGdldCA9IGJ1ZGdldE1heC50cmltKCkgPyBOdW1iZXIoYnVkZ2V0TWF4KSA6IHVuZGVmaW5lZFxyXG5cclxuICAgICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShwYXJzZWRSYWRpdXMpIHx8IHBhcnNlZFJhZGl1cyA8PSAwKSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgICAgIHNldEVycm9yKCdSYWRpdXMgbXVzdCBiZSBhIHBvc2l0aXZlIG51bWJlci4nKVxyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHBhcnNlZEJ1ZGdldCAhPT0gdW5kZWZpbmVkICYmICghTnVtYmVyLmlzRmluaXRlKHBhcnNlZEJ1ZGdldCkgfHwgcGFyc2VkQnVkZ2V0IDwgMCkpIHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgICAgICAgc2V0RXJyb3IoJ0J1ZGdldCBtdXN0IGJlIGEgbm9uLW5lZ2F0aXZlIG51bWJlci4nKVxyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRTdWdnZXN0aW9ucyh7XHJcbiAgICAgICAgICAgICAgICBsYXQ6IG1hcENlbnRlclswXSxcclxuICAgICAgICAgICAgICAgIGxuZzogbWFwQ2VudGVyWzFdLFxyXG4gICAgICAgICAgICAgICAgcmFkaXVzOiBwYXJzZWRSYWRpdXMsXHJcbiAgICAgICAgICAgICAgICBidWRnZXRfbWF4OiBwYXJzZWRCdWRnZXQsXHJcbiAgICAgICAgICAgICAgICB0YWdfaWRzOiBbLi4uc3VnZ2VzdGlvblRhZ0lkc10sXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBzdWdnZXN0aW9uVHlwZSxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgY29uc3QgZmlsdGVyZWRSZXN1bHRzID0gcGFyc2VkQnVkZ2V0ID09PSB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgID8gZGF0YS5yZXN1bHRzXHJcbiAgICAgICAgICAgICAgICA6IGRhdGEucmVzdWx0cy5maWx0ZXIoKHN1Z2dlc3Rpb24pID0+IHN1Z2dlc3Rpb24uYnVkZ2V0ID09PSBudWxsIHx8IHN1Z2dlc3Rpb24uYnVkZ2V0IDw9IHBhcnNlZEJ1ZGdldClcclxuICAgICAgICAgICAgc2V0RXhjbHVkZWRCeUJ1ZGdldChkYXRhLnJlc3VsdHMubGVuZ3RoIC0gZmlsdGVyZWRSZXN1bHRzLmxlbmd0aClcclxuICAgICAgICAgICAgc2V0UmVzdWx0Q29udGV4dCh7XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFRhZ3M6IG5ldyBTZXQoc3VnZ2VzdGlvblRhZ0lkcyksXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBzdWdnZXN0aW9uVHlwZSxcclxuICAgICAgICAgICAgICAgIGJ1ZGdldE1heDogcGFyc2VkQnVkZ2V0LFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICBzZXRSZXN1bHRzKGZpbHRlcmVkUmVzdWx0cylcclxuICAgICAgICB9IGNhdGNoIChzdWdnZXN0aW9uRXJyb3IpIHtcclxuICAgICAgICAgICAgc2V0RXJyb3Ioc3VnZ2VzdGlvbkVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBzdWdnZXN0aW9uRXJyb3IubWVzc2FnZSA6ICdGYWlsZWQgdG8gbG9hZCBzdWdnZXN0aW9ucy4nKVxyXG4gICAgICAgICAgICBzZXRSZXN1bHRzKFtdKVxyXG4gICAgICAgICAgICBzZXRFeGNsdWRlZEJ5QnVkZ2V0KDApXHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdG9nZ2xlU3VnZ2VzdGlvblRhZyA9ICh0YWdJZDogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgc2V0U3VnZ2VzdGlvblRhZ0lkcygocHJldmlvdXMpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBTZXQocHJldmlvdXMpXHJcbiAgICAgICAgICAgIG5leHQuaGFzKHRhZ0lkKSA/IG5leHQuZGVsZXRlKHRhZ0lkKSA6IG5leHQuYWRkKHRhZ0lkKVxyXG4gICAgICAgICAgICByZXR1cm4gbmV4dFxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZW1wdHlNZXNzYWdlID0gZXhjbHVkZWRCeUJ1ZGdldCA+IDBcclxuICAgICAgICA/ICdObyBzdWdnZXN0aW9ucyBtYXRjaCB5b3VyIG1heCBidWRnZXQuIFVua25vd24tYnVkZ2V0IG9wdGlvbnMgd291bGQgc3RpbGwgYXBwZWFyIGhlcmUgaWYgYXZhaWxhYmxlLidcclxuICAgICAgICA6IGBObyBtYXRjaGluZyAke3Jlc3VsdENvbnRleHQudHlwZSA9PT0gJ2FsbCcgPyAncmVjb21tZW5kYXRpb25zJyA6IHJlc3VsdENvbnRleHQudHlwZX0gZm91bmQuIFRyeSB3aWRlbmluZyB0aGUgcmFkaXVzJHtyZXN1bHRDb250ZXh0LnNlbGVjdGVkVGFncy5zaXplID4gMCA/ICcsIGNsZWFyaW5nIHRhZyBwcmVmZXJlbmNlcycgOiAnJ30ke3Jlc3VsdENvbnRleHQuYnVkZ2V0TWF4ICE9PSB1bmRlZmluZWQgPyAnLCBvciByYWlzaW5nIHRoZSBtYXggYnVkZ2V0JyA6ICcnfS5gXHJcblxyXG4gICAgY29uc3QgcmVuZGVyU3VnZ2VzdGlvbkNhcmQgPSAoXHJcbiAgICAgICAgc3VnZ2VzdGlvbjogU3VnZ2VzdGlvblJlc3VsdCxcclxuICAgICAgICByZWFzb25zOiBzdHJpbmdbXSxcclxuICAgICAgICBmcmllbmRDb3VudDogbnVtYmVyLFxyXG4gICAgICAgIHZhcmlhbnQ6ICd0b3AnIHwgJ2xpc3QnLFxyXG4gICAgKSA9PiB7XHJcbiAgICAgICAgY29uc3QgeyB2aXNpYmxlVGFncywgaGlkZGVuQ291bnQgfSA9IGdldFZpc2libGVUYWdzKHN1Z2dlc3Rpb24udGFncywgdmFyaWFudCA9PT0gJ3RvcCcgPyAzIDogMilcclxuXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3ZhcmlhbnQgPT09ICd0b3AnID8gJ3N1Z2dlc3Rpb25zLXBhbmVsX190b3AtcGljaycgOiAnc3VnZ2VzdGlvbnMtcGFuZWxfX2l0ZW0tYnV0dG9uJ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0U3VnZ2VzdGlvbihzdWdnZXN0aW9uKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX3RvcGxpbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BzdWdnZXN0aW9ucy1wYW5lbF9fYmFkZ2Ugc3VnZ2VzdGlvbnMtcGFuZWxfX2JhZGdlLS0ke3N1Z2dlc3Rpb24udHlwZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+e2dldENhdGVnb3J5SWNvbihzdWdnZXN0aW9uLnRhZ3MsIHN1Z2dlc3Rpb24udHlwZSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3VnZ2VzdGlvbi50eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fc2NvcmVcIj57c3VnZ2VzdGlvbi5zY29yZS50b0ZpeGVkKDApfSBtYXRjaDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN1Z2dlc3Rpb25zLXBhbmVsX19uYW1lXCI+e3N1Z2dlc3Rpb24ubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzdWdnZXN0aW9uLmRpc3RhbmNlX2ttLnRvRml4ZWQoMSl9IGttIMK3IHtmb3JtYXRCdWRnZXQoc3VnZ2VzdGlvbi5idWRnZXQpfVxyXG4gICAgICAgICAgICAgICAgICAgIHtmcmllbmRDb3VudCA+IDAgJiYgYCDCtyAke2ZyaWVuZENvdW50fSBmcmllbmQke2ZyaWVuZENvdW50ID09PSAxID8gJycgOiAncyd9IGF0dGVuZGluZ2B9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7dmlzaWJsZVRhZ3MubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX3RhZ3NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVUYWdzLm1hcCgodGFnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e3RhZy5pZH0+I3t0YWcubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGlkZGVuQ291bnQgPiAwICYmIDxzcGFuPit7aGlkZGVuQ291bnR9IG1vcmU8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7cmVhc29ucy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fd2h5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+V2h5IHN1Z2dlc3RlZDwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWFzb25zLm1hcCgocmVhc29uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGVtIGtleT17cmVhc29ufT57cmVhc29ufTwvZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInN1Z2dlc3Rpb25zLXBhbmVsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2hlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2V5ZWJyb3dcIj5Gb3IgeW91PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX3RpdGxlXCI+UmVjb21tZW5kZWQgcGlja3M8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fc3VidGl0bGVcIj5UdW5lIHlvdXIgbW9vZCwgdGhlbiBnZXQgYSByYW5rZWQgZGFpbHkgcGljay48L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fZm9ybVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fc2VnbWVudGVkXCIgYXJpYS1sYWJlbD1cIlN1Z2dlc3Rpb24gdHlwZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsoW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbJ2FsbCcsICdCb3RoJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFsnZXZlbnRzJywgJ0V2ZW50cyddLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbJ3BsYW5zJywgJ1BsYW5zJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgXSBhcyBjb25zdCkubWFwKChbdmFsdWUsIGxhYmVsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N1Z2dlc3Rpb25UeXBlID09PSB2YWx1ZSA/ICdzdWdnZXN0aW9ucy1wYW5lbF9fc2VnbWVudCBzdWdnZXN0aW9ucy1wYW5lbF9fc2VnbWVudC0tYWN0aXZlJyA6ICdzdWdnZXN0aW9ucy1wYW5lbF9fc2VnbWVudCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdWdnZXN0aW9uVHlwZSh2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmFkaXVzIGttPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMC4xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JhZGl1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJhZGl1cyhldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInN1Z2dlc3Rpb25zLXBhbmVsX19maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5NYXggYnVkZ2V0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVkZ2V0TWF4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QnVkZ2V0TWF4KGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFueVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fdGFnLXByZWZlcmVuY2VzXCIgYXJpYS1sYWJlbD1cIlN1Z2dlc3Rpb24gdGFnIHByZWZlcmVuY2VzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UHJlZmVyZW5jZSB0YWdzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YWdzLmxlbmd0aCA9PT0gMCAmJiA8ZW0+Tm8gdGFncyBhdmFpbGFibGUuPC9lbT59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YWdzLm1hcCgodGFnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0YWcuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdWdnZXN0aW9uVGFnSWRzLmhhcyh0YWcuaWQpID8gJ3N1Z2dlc3Rpb25zLXBhbmVsX190YWcgc3VnZ2VzdGlvbnMtcGFuZWxfX3RhZy0tYWN0aXZlJyA6ICdzdWdnZXN0aW9ucy1wYW5lbF9fdGFnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVTdWdnZXN0aW9uVGFnKHRhZy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgI3t0YWcubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVGFnTmFtZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2hpbnRcIj5Qcmlvcml0aXppbmc6IHtzZWxlY3RlZFRhZ05hbWVzfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInN1Z2dlc3Rpb25zLXBhbmVsX19zdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30+XHJcbiAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAnRmluZGluZy4uLicgOiAnRmluZCBzdWdnZXN0aW9ucyd9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9fZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxyXG4gICAgICAgICAgICB7IWxvYWRpbmcgJiYgIWVycm9yICYmIHJlc3VsdHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2VtcHR5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2hhc1NlYXJjaGVkID8gZW1wdHlNZXNzYWdlIDogJ05vIHN1Z2dlc3Rpb25zIGxvYWRlZCB5ZXQuIFBpY2sgYSB0eXBlIG9yIG1vb2QsIHRoZW4gZmluZCBzdWdnZXN0aW9ucy4nfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgZXhjbHVkZWRCeUJ1ZGdldCA+IDAgJiYgcmVzdWx0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2hpbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICBIaWRkZW4ge2V4Y2x1ZGVkQnlCdWRnZXR9IG92ZXItYnVkZ2V0IHJlc3VsdHtleGNsdWRlZEJ5QnVkZ2V0ID09PSAxID8gJycgOiAncyd9LlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHt0b3BQaWNrICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2RhaWx5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3VnZ2VzdGlvbnMtcGFuZWxfX2RhaWx5LWxhYmVsXCI+VG9wIHBpY2sgZm9yIHlvdTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7cmVuZGVyU3VnZ2VzdGlvbkNhcmQodG9wUGljay5zdWdnZXN0aW9uLCB0b3BQaWNrLnJlYXNvbnMsIHRvcFBpY2suZnJpZW5kQ291bnQsICd0b3AnKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7bW9yZVBpY2tzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInN1Z2dlc3Rpb25zLXBhbmVsX19saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge21vcmVQaWNrcy5tYXAoKHsgc3VnZ2VzdGlvbiwgcmVhc29ucywgZnJpZW5kQ291bnQgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtgJHtzdWdnZXN0aW9uLnR5cGV9LSR7c3VnZ2VzdGlvbi5pZH1gfSBjbGFzc05hbWU9XCJzdWdnZXN0aW9ucy1wYW5lbF9faXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlclN1Z2dlc3Rpb25DYXJkKHN1Z2dlc3Rpb24sIHJlYXNvbnMsIGZyaWVuZENvdW50LCAnbGlzdCcpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXJ0aS9Eb2N1bWVudHMvR2l0SHViL1NvZnR3YXJlLVByb2plY3QtRzEwL1Byb2plY3Qvc3JjL1N1Z2dlc3Rpb25zUGFuZWwudHN4In0=