import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/TopBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
function getInitials(username) {
  return username.slice(0, 2).toUpperCase();
}
export default function TopBar({
  currentUser,
  onOpenExplore,
  onOpenPlanner,
  onOpenProfile,
  onOpenSavedContent,
  onLoginClick,
  onLogout
}) {
  _s();
  const [accountOpen, setAccountOpen] = useState(false);
  const accountRef = useRef(null);
  useEffect(() => {
    if (!accountOpen)
      return;
    const handlePointerDown = (event) => {
      if (accountRef.current && !accountRef.current.contains(event.target)) {
        setAccountOpen(false);
      }
    };
    const handleKeyDown = (event) => {
      if (event.key === "Escape")
        setAccountOpen(false);
    };
    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [accountOpen]);
  const handleOpenProfile = () => {
    setAccountOpen(false);
    onOpenProfile();
  };
  const handleOpenSavedContent = () => {
    setAccountOpen(false);
    onOpenSavedContent();
  };
  const handleLogout = () => {
    setAccountOpen(false);
    onLogout();
  };
  return /* @__PURE__ */ jsxDEV("header", { className: "top-bar", "aria-label": "Application header", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "top-bar__brand", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "top-bar__mark", children: /* @__PURE__ */ jsxDEV("img", { src: "/rove-logo.png", alt: "" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 88,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 87,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "top-bar__copy", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "top-bar__name", children: "Rove" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
          lineNumber: 91,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("em", { className: "top-bar__tagline", children: "Wander. Explore. Connect." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
          lineNumber: 92,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 90,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
      lineNumber: 86,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "top-bar__nav", "aria-label": "Primary navigation", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onOpenExplore, children: "Explore" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 96,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onOpenPlanner, children: "Planner" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 97,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("a", { href: "#suggestions-panel", children: "Suggestions" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 98,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("a", { href: "#friends-panel", children: "Friends" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 99,
        columnNumber: 17
      }, this),
      currentUser ? /* @__PURE__ */ jsxDEV("div", { className: "top-bar__account", ref: accountRef, children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "top-bar__avatar-btn",
            onClick: () => setAccountOpen((open) => !open),
            "aria-label": "Open account menu",
            "aria-expanded": accountOpen,
            children: currentUser.avatar_url ? /* @__PURE__ */ jsxDEV("img", { src: currentUser.avatar_url, alt: currentUser.username }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 110,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV("span", { children: getInitials(currentUser.username) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 112,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
            lineNumber: 102,
            columnNumber: 25
          },
          this
        ),
        accountOpen && /* @__PURE__ */ jsxDEV("div", { className: "account-popover", role: "menu", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "account-popover__identity", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "account-popover__avatar", children: currentUser.avatar_url ? /* @__PURE__ */ jsxDEV("img", { src: currentUser.avatar_url, alt: currentUser.username }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 120,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("span", { children: getInitials(currentUser.username) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 122,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 118,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "account-popover__text", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: currentUser.username }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
                lineNumber: 126,
                columnNumber: 41
              }, this),
              currentUser.email && /* @__PURE__ */ jsxDEV("small", { children: currentUser.email }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
                lineNumber: 127,
                columnNumber: 63
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 125,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
            lineNumber: 117,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "account-popover__button", onClick: handleOpenProfile, children: "View & edit profile" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
            lineNumber: 130,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "account-popover__button", onClick: handleOpenSavedContent, children: "Saved content" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
            lineNumber: 133,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "account-popover__button account-popover__button--danger",
              onClick: handleLogout,
              children: "Logout"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
              lineNumber: 136,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 101,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onLoginClick, children: "Login / Register" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
        lineNumber: 147,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
      lineNumber: 95,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx",
    lineNumber: 85,
    columnNumber: 5
  }, this);
}
_s(TopBar, "3LhIMT1k6vEhDm8b5/BFrTtzW10=");
_c = TopBar;
var _c;
$RefreshReg$(_c, "TopBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/TopBar.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwRXBCLFNBQVNBLFdBQVdDLFFBQVFDLGdCQUFnQjtBQWE1QyxTQUFTQyxZQUFZQyxVQUEwQjtBQUMzQyxTQUFPQSxTQUFTQyxNQUFNLEdBQUcsQ0FBQyxFQUFFQyxZQUFZO0FBQzVDO0FBRUEsd0JBQXdCQyxPQUFPO0FBQUEsRUFDM0JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ1MsR0FBRztBQUFBQyxLQUFBO0FBQ1osUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlmLFNBQVMsS0FBSztBQUNwRCxRQUFNZ0IsYUFBYWpCLE9BQThCLElBQUk7QUFFckRELFlBQVUsTUFBTTtBQUNaLFFBQUksQ0FBQ2dCO0FBQWE7QUFFbEIsVUFBTUcsb0JBQW9CQSxDQUFDQyxVQUFzQjtBQUM3QyxVQUFJRixXQUFXRyxXQUFXLENBQUNILFdBQVdHLFFBQVFDLFNBQVNGLE1BQU1HLE1BQWMsR0FBRztBQUMxRU4sdUJBQWUsS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDSjtBQUNBLFVBQU1PLGdCQUFnQkEsQ0FBQ0osVUFBeUI7QUFDNUMsVUFBSUEsTUFBTUssUUFBUTtBQUFVUix1QkFBZSxLQUFLO0FBQUEsSUFDcEQ7QUFFQVMsYUFBU0MsaUJBQWlCLGFBQWFSLGlCQUFpQjtBQUN4RE8sYUFBU0MsaUJBQWlCLFdBQVdILGFBQWE7QUFDbEQsV0FBTyxNQUFNO0FBQ1RFLGVBQVNFLG9CQUFvQixhQUFhVCxpQkFBaUI7QUFDM0RPLGVBQVNFLG9CQUFvQixXQUFXSixhQUFhO0FBQUEsSUFDekQ7QUFBQSxFQUNKLEdBQUcsQ0FBQ1IsV0FBVyxDQUFDO0FBRWhCLFFBQU1hLG9CQUFvQkEsTUFBTTtBQUM1QlosbUJBQWUsS0FBSztBQUNwQk4sa0JBQWM7QUFBQSxFQUNsQjtBQUVBLFFBQU1tQix5QkFBeUJBLE1BQU07QUFDakNiLG1CQUFlLEtBQUs7QUFDcEJMLHVCQUFtQjtBQUFBLEVBQ3ZCO0FBRUEsUUFBTW1CLGVBQWVBLE1BQU07QUFDdkJkLG1CQUFlLEtBQUs7QUFDcEJILGFBQVM7QUFBQSxFQUNiO0FBRUEsU0FDSSx1QkFBQyxZQUFPLFdBQVUsV0FBVSxjQUFXLHNCQUNuQztBQUFBLDJCQUFDLFNBQUksV0FBVSxrQkFDWDtBQUFBLDZCQUFDLFVBQUssV0FBVSxpQkFDWixpQ0FBQyxTQUFJLEtBQUksa0JBQWlCLEtBQUksTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxpQkFBZ0Isb0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNwQyx1QkFBQyxRQUFHLFdBQVUsb0JBQW1CLHlDQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsV0FGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxjQUFXLHNCQUNyQztBQUFBLDZCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNMLGVBQWUsdUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxNQUNyRCx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTQyxlQUFlLHVCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFDckQsdUJBQUMsT0FBRSxNQUFLLHNCQUFxQiwyQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQ3hDLHVCQUFDLE9BQUUsTUFBSyxrQkFBaUIsdUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUMvQkYsY0FDRyx1QkFBQyxTQUFJLFdBQVUsb0JBQW1CLEtBQUtVLFlBQ25DO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTUQsZUFBZSxDQUFDZSxTQUFTLENBQUNBLElBQUk7QUFBQSxZQUM3QyxjQUFXO0FBQUEsWUFDWCxpQkFBZWhCO0FBQUFBLFlBRWRSLHNCQUFZeUIsYUFDVCx1QkFBQyxTQUFJLEtBQUt6QixZQUFZeUIsWUFBWSxLQUFLekIsWUFBWUosWUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQsSUFFNUQsdUJBQUMsVUFBTUQsc0JBQVlLLFlBQVlKLFFBQVEsS0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQTtBQUFBLFVBVmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBO0FBQUEsUUFDQ1ksZUFDRyx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLE1BQUssUUFDbEM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ1ZSLHNCQUFZeUIsYUFDVCx1QkFBQyxTQUFJLEtBQUt6QixZQUFZeUIsWUFBWSxLQUFLekIsWUFBWUosWUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQsSUFFNUQsdUJBQUMsVUFBTUQsc0JBQVlLLFlBQVlKLFFBQVEsS0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUMsS0FKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEscUNBQUMsWUFBUUksc0JBQVlKLFlBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FDN0JJLFlBQVkwQixTQUFTLHVCQUFDLFdBQU8xQixzQkFBWTBCLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsaUJBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsMkJBQTBCLFNBQVNMLG1CQUFtQixtQ0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSwyQkFBMEIsU0FBU0Msd0JBQXdCLDZCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBU0M7QUFBQUEsY0FBYTtBQUFBO0FBQUEsWUFIMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsV0ExQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQSxJQUVBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNsQixjQUFjLGdDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsU0FwRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzREE7QUFBQSxPQWhFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUVBO0FBRVI7QUFBQ0UsR0FuSHVCUixRQUFNO0FBQUEsS0FBTkE7QUFBTSxJQUFBNEI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJnZXRJbml0aWFscyIsInVzZXJuYW1lIiwic2xpY2UiLCJ0b1VwcGVyQ2FzZSIsIlRvcEJhciIsImN1cnJlbnRVc2VyIiwib25PcGVuRXhwbG9yZSIsIm9uT3BlblBsYW5uZXIiLCJvbk9wZW5Qcm9maWxlIiwib25PcGVuU2F2ZWRDb250ZW50Iiwib25Mb2dpbkNsaWNrIiwib25Mb2dvdXQiLCJfcyIsImFjY291bnRPcGVuIiwic2V0QWNjb3VudE9wZW4iLCJhY2NvdW50UmVmIiwiaGFuZGxlUG9pbnRlckRvd24iLCJldmVudCIsImN1cnJlbnQiLCJjb250YWlucyIsInRhcmdldCIsImhhbmRsZUtleURvd24iLCJrZXkiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiaGFuZGxlT3BlblByb2ZpbGUiLCJoYW5kbGVPcGVuU2F2ZWRDb250ZW50IiwiaGFuZGxlTG9nb3V0Iiwib3BlbiIsImF2YXRhcl91cmwiLCJlbWFpbCIsIl9jIl0sInNvdXJjZXMiOlsiVG9wQmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBBdXRoVXNlciB9IGZyb20gJy4vYXBpJ1xyXG5cclxudHlwZSBUb3BCYXJQcm9wcyA9IHtcclxuICAgIGN1cnJlbnRVc2VyOiBBdXRoVXNlciB8IG51bGxcclxuICAgIG9uT3BlbkV4cGxvcmU6ICgpID0+IHZvaWRcclxuICAgIG9uT3BlblBsYW5uZXI6ICgpID0+IHZvaWRcclxuICAgIG9uT3BlblByb2ZpbGU6ICgpID0+IHZvaWRcclxuICAgIG9uT3BlblNhdmVkQ29udGVudDogKCkgPT4gdm9pZFxyXG4gICAgb25Mb2dpbkNsaWNrOiAoKSA9PiB2b2lkXHJcbiAgICBvbkxvZ291dDogKCkgPT4gdm9pZFxyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRJbml0aWFscyh1c2VybmFtZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB1c2VybmFtZS5zbGljZSgwLCAyKS50b1VwcGVyQ2FzZSgpXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRvcEJhcih7XHJcbiAgICBjdXJyZW50VXNlcixcclxuICAgIG9uT3BlbkV4cGxvcmUsXHJcbiAgICBvbk9wZW5QbGFubmVyLFxyXG4gICAgb25PcGVuUHJvZmlsZSxcclxuICAgIG9uT3BlblNhdmVkQ29udGVudCxcclxuICAgIG9uTG9naW5DbGljayxcclxuICAgIG9uTG9nb3V0LFxyXG59OiBUb3BCYXJQcm9wcykge1xyXG4gICAgY29uc3QgW2FjY291bnRPcGVuLCBzZXRBY2NvdW50T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IGFjY291bnRSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQgfCBudWxsPihudWxsKVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFhY2NvdW50T3BlbikgcmV0dXJuXHJcblxyXG4gICAgICAgIGNvbnN0IGhhbmRsZVBvaW50ZXJEb3duID0gKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChhY2NvdW50UmVmLmN1cnJlbnQgJiYgIWFjY291bnRSZWYuY3VycmVudC5jb250YWlucyhldmVudC50YXJnZXQgYXMgTm9kZSkpIHtcclxuICAgICAgICAgICAgICAgIHNldEFjY291bnRPcGVuKGZhbHNlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHtcclxuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VzY2FwZScpIHNldEFjY291bnRPcGVuKGZhbHNlKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlUG9pbnRlckRvd24pXHJcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pXHJcbiAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlUG9pbnRlckRvd24pXHJcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKVxyXG4gICAgICAgIH1cclxuICAgIH0sIFthY2NvdW50T3Blbl0pXHJcblxyXG4gICAgY29uc3QgaGFuZGxlT3BlblByb2ZpbGUgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0QWNjb3VudE9wZW4oZmFsc2UpXHJcbiAgICAgICAgb25PcGVuUHJvZmlsZSgpXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlT3BlblNhdmVkQ29udGVudCA9ICgpID0+IHtcclxuICAgICAgICBzZXRBY2NvdW50T3BlbihmYWxzZSlcclxuICAgICAgICBvbk9wZW5TYXZlZENvbnRlbnQoKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcclxuICAgICAgICBzZXRBY2NvdW50T3BlbihmYWxzZSlcclxuICAgICAgICBvbkxvZ291dCgpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInRvcC1iYXJcIiBhcmlhLWxhYmVsPVwiQXBwbGljYXRpb24gaGVhZGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wLWJhcl9fYnJhbmRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRvcC1iYXJfX21hcmtcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9yb3ZlLWxvZ28ucG5nXCIgYWx0PVwiXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wLWJhcl9fY29weVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRvcC1iYXJfX25hbWVcIj5Sb3ZlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxlbSBjbGFzc05hbWU9XCJ0b3AtYmFyX190YWdsaW5lXCI+V2FuZGVyLiBFeHBsb3JlLiBDb25uZWN0LjwvZW0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwidG9wLWJhcl9fbmF2XCIgYXJpYS1sYWJlbD1cIlByaW1hcnkgbmF2aWdhdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25PcGVuRXhwbG9yZX0+RXhwbG9yZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25PcGVuUGxhbm5lcn0+UGxhbm5lcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNzdWdnZXN0aW9ucy1wYW5lbFwiPlN1Z2dlc3Rpb25zPC9hPlxyXG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNmcmllbmRzLXBhbmVsXCI+RnJpZW5kczwvYT5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlciA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC1iYXJfX2FjY291bnRcIiByZWY9e2FjY291bnRSZWZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRvcC1iYXJfX2F2YXRhci1idG5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWNjb3VudE9wZW4oKG9wZW4pID0+ICFvcGVuKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJPcGVuIGFjY291bnQgbWVudVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXthY2NvdW50T3Blbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRVc2VyLmF2YXRhcl91cmwgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2N1cnJlbnRVc2VyLmF2YXRhcl91cmx9IGFsdD17Y3VycmVudFVzZXIudXNlcm5hbWV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntnZXRJbml0aWFscyhjdXJyZW50VXNlci51c2VybmFtZSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthY2NvdW50T3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtcG9wb3ZlclwiIHJvbGU9XCJtZW51XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LXBvcG92ZXJfX2lkZW50aXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNjb3VudC1wb3BvdmVyX19hdmF0YXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5hdmF0YXJfdXJsID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtjdXJyZW50VXNlci5hdmF0YXJfdXJsfSBhbHQ9e2N1cnJlbnRVc2VyLnVzZXJuYW1lfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Z2V0SW5pdGlhbHMoY3VycmVudFVzZXIudXNlcm5hbWUpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtcG9wb3Zlcl9fdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57Y3VycmVudFVzZXIudXNlcm5hbWV9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXIuZW1haWwgJiYgPHNtYWxsPntjdXJyZW50VXNlci5lbWFpbH08L3NtYWxsPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYWNjb3VudC1wb3BvdmVyX19idXR0b25cIiBvbkNsaWNrPXtoYW5kbGVPcGVuUHJvZmlsZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgJmFtcDsgZWRpdCBwcm9maWxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYWNjb3VudC1wb3BvdmVyX19idXR0b25cIiBvbkNsaWNrPXtoYW5kbGVPcGVuU2F2ZWRDb250ZW50fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2F2ZWQgY29udGVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY291bnQtcG9wb3Zlcl9fYnV0dG9uIGFjY291bnQtcG9wb3Zlcl9fYnV0dG9uLS1kYW5nZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2dvdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvbkxvZ2luQ2xpY2t9PkxvZ2luIC8gUmVnaXN0ZXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG4gICAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvbWFydGkvRG9jdW1lbnRzL0dpdEh1Yi9Tb2Z0d2FyZS1Qcm9qZWN0LUcxMC9Qcm9qZWN0L3NyYy9Ub3BCYXIudHN4In0=