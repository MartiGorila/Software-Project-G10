import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/EventDetailsSidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/EventDetailsSidebar.css?t=1780399643212";
import { getCategoryIcon, getVisibleTags } from "/src/categoryIcons.ts";
export default function EventDetailsSidebar({
  event,
  onClose,
  isLoggedIn,
  currentUserId,
  joined,
  isFull,
  friendIds,
  onJoin,
  onLeave,
  onDeleteEvent,
  onViewUserProfile
}) {
  if (!event)
    return null;
  const isOwn = event.creator_id === currentUserId;
  const tags = event.tags ?? [];
  const { visibleTags, hiddenCount } = getVisibleTags(tags, 6);
  const participants = event.event_participants ?? [];
  const friendParticipants = participants.filter((participant) => friendIds.has(participant.user_id));
  const eventDate = new Date(event.event_time).toLocaleString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit"
  });
  const budgetLabel = event.budget != null ? `€${event.budget.toFixed(2)}` : "Budget unknown";
  const capacityLabel = event.capacity != null ? `${participants.length}/${event.capacity} going` : `${participants.length} going`;
  const visibilityLabel = event.visibility === "friends" ? "Friends" : event.visibility === "private" ? "Private" : "Public";
  return /* @__PURE__ */ jsxDEV("div", { className: "event-details-sidebar", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "event-details-header", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-header__topline", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "event-details-badge", children: [
          /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: getCategoryIcon(tags, "event") }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
            lineNumber: 77,
            columnNumber: 13
          }, this),
          "Event"
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 76,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "event-details-close", type: "button", onClick: onClose, "aria-label": "Close event details", children: "×" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 80,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: event.name }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this),
      visibleTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "event-details-tags", children: [
        visibleTags.map(
          (tag) => /* @__PURE__ */ jsxDEV("span", { className: "event-details-tag", children: [
            "#",
            tag.name
          ] }, tag.id, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
            lineNumber: 88,
            columnNumber: 11
          }, this)
        ),
        hiddenCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "event-details-tag event-details-tag--more", children: [
          "+",
          hiddenCount,
          " more"
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 90,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 74,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "event-details-metrics", "aria-label": "Event summary", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-metric", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Date" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 97,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: eventDate }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 96,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-metric", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Budget" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 101,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: budgetLabel }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 102,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 100,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-metric", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Capacity" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 105,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: capacityLabel }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 106,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-metric", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Visibility" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 109,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: visibilityLabel }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 110,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 108,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "event-details-card", children: [
      /* @__PURE__ */ jsxDEV("h3", { children: "Description" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 115,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: event.description || "No description provided." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "event-details-card event-details-creator", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Hosted by" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 121,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Organizer profile" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 122,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      event.creator_id && event.creator?.username ? /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "event-details-profile-pill",
          onClick: () => onViewUserProfile(event.creator_id),
          children: event.creator.username
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 125,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV("span", { className: "event-details-muted", children: "Unknown" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 133,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 119,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "event-details-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-section-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Friends attending" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: friendParticipants.length }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 140,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 138,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-people event-details-people--friends", children: friendParticipants.length > 0 ? friendParticipants.map(
        (participant) => /* @__PURE__ */ jsxDEV("div", { className: "event-details-person event-details-person--friend", children: participant.user?.username ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "event-details-profile-btn",
            onClick: () => onViewUserProfile(participant.user_id),
            children: participant.user.username
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
            lineNumber: 147,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("span", { children: participant.user_id }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 155,
          columnNumber: 13
        }, this) }, participant.user_id, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 145,
          columnNumber: 11
        }, this)
      ) : /* @__PURE__ */ jsxDEV("span", { className: "event-details-muted", children: "No friends are attending yet." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 160,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 137,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "event-details-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-section-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Subscribed users" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 167,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: participants.length }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 166,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "event-details-people", children: participants.length > 0 ? participants.map(
        (participant) => /* @__PURE__ */ jsxDEV("div", { className: "event-details-person", children: participant.user?.username ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "event-details-profile-btn",
            onClick: () => onViewUserProfile(participant.user_id),
            children: participant.user.username
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
            lineNumber: 175,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("span", { children: participant.user_id }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 183,
          columnNumber: 13
        }, this) }, participant.user_id, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 173,
          columnNumber: 11
        }, this)
      ) : /* @__PURE__ */ jsxDEV("span", { className: "event-details-muted", children: "No subscribers yet." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 188,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 170,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 165,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "event-details-actions", children: [
      isLoggedIn && !isOwn && /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: `event-details-action ${joined ? "event-details-action--secondary" : ""}`,
          disabled: !joined && isFull,
          onClick: () => joined ? onLeave(event.id) : onJoin(event.id),
          children: joined ? "Leave event" : isFull ? "Event full" : "Join event"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 195,
          columnNumber: 9
        },
        this
      ),
      !isLoggedIn && /* @__PURE__ */ jsxDEV("div", { className: "event-details-hint", children: "Log in to join this event." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
        lineNumber: 204,
        columnNumber: 9
      }, this),
      isOwn && /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "event-details-action event-details-action--danger",
          onClick: () => onDeleteEvent(event.id),
          children: "Delete"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
          lineNumber: 207,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
      lineNumber: 193,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx",
    lineNumber: 73,
    columnNumber: 5
  }, this);
}
_c = EventDetailsSidebar;
var _c;
$RefreshReg$(_c, "EventDetailsSidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/EventDetailsSidebar.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURZOzs7Ozs7Ozs7Ozs7Ozs7O0FBekRaLE9BQU87QUFFUCxTQUFTQSxpQkFBaUJDLHNCQUFzQjtBQUVoRCx3QkFBd0JDLG9CQUFvQjtBQUFBLEVBQzFDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQWFGLEdBQUc7QUFDRCxNQUFJLENBQUNWO0FBQU8sV0FBTztBQUNuQixRQUFNVyxRQUFRWCxNQUFNWSxlQUFlVDtBQUNuQyxRQUFNVSxPQUFPYixNQUFNYSxRQUFRO0FBQzNCLFFBQU0sRUFBRUMsYUFBYUMsWUFBWSxJQUFJakIsZUFBZWUsTUFBTSxDQUFDO0FBQzNELFFBQU1HLGVBQWVoQixNQUFNaUIsc0JBQXNCO0FBQ2pELFFBQU1DLHFCQUFxQkYsYUFBYUcsT0FBTyxDQUFDQyxnQkFBZ0JkLFVBQVVlLElBQUlELFlBQVlFLE9BQU8sQ0FBQztBQUNsRyxRQUFNQyxZQUFZLElBQUlDLEtBQUt4QixNQUFNeUIsVUFBVSxFQUFFQyxlQUFlLFNBQVM7QUFBQSxJQUNuRUMsU0FBUztBQUFBLElBQ1RDLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxRQUFNQyxjQUFjaEMsTUFBTWlDLFVBQVUsT0FBTyxJQUFJakMsTUFBTWlDLE9BQU9DLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDM0UsUUFBTUMsZ0JBQWdCbkMsTUFBTW9DLFlBQVksT0FDcEMsR0FBR3BCLGFBQWFxQixNQUFNLElBQUlyQyxNQUFNb0MsUUFBUSxXQUN4QyxHQUFHcEIsYUFBYXFCLE1BQU07QUFDMUIsUUFBTUMsa0JBQWtCdEMsTUFBTXVDLGVBQWUsWUFDekMsWUFDQXZDLE1BQU11QyxlQUFlLFlBQ25CLFlBQ0E7QUFFTixTQUNFLHVCQUFDLFNBQUksV0FBVSx5QkFBd0IsU0FBUyxDQUFDQyxNQUFNQSxFQUFFQyxnQkFBZ0IsR0FDdkU7QUFBQSwyQkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsdUJBQ2Q7QUFBQSxpQ0FBQyxVQUFLLGVBQVksUUFBUTVDLDBCQUFnQmdCLE1BQU0sT0FBTyxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQU87QUFBQSxhQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFlBQU8sV0FBVSx1QkFBc0IsTUFBSyxVQUFTLFNBQVNaLFNBQVMsY0FBVyx1QkFBc0IsaUJBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxRQUFJRCxnQkFBTTBDLFFBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBLE1BQ2Y1QixZQUFZdUIsU0FBUyxLQUNwQix1QkFBQyxTQUFJLFdBQVUsc0JBQ1p2QjtBQUFBQSxvQkFBWTZCO0FBQUFBLFVBQUksQ0FBQ0MsUUFDaEIsdUJBQUMsVUFBa0IsV0FBVSxxQkFBb0I7QUFBQTtBQUFBLFlBQUVBLElBQUlGO0FBQUFBLGVBQTVDRSxJQUFJQyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTREO0FBQUEsUUFDN0Q7QUFBQSxRQUNBOUIsY0FBYyxLQUFLLHVCQUFDLFVBQUssV0FBVSw2Q0FBNEM7QUFBQTtBQUFBLFVBQUVBO0FBQUFBLFVBQVk7QUFBQSxhQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsV0FKckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixjQUFXLGlCQUNoRDtBQUFBLDZCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLCtCQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFVO0FBQUEsUUFDVix1QkFBQyxZQUFRUSx1QkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CO0FBQUEsV0FGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSwrQkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQ1osdUJBQUMsWUFBUVMseUJBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFdBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsK0JBQUMsVUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUNkLHVCQUFDLFlBQVFHLDJCQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLCtCQUFDLFVBQUssMEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBLFFBQ2hCLHVCQUFDLFlBQVFHLDZCQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxXQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsc0JBQ2pCO0FBQUEsNkJBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmLHVCQUFDLE9BQUd0QyxnQkFBTThDLGVBQWUsOEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxTQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLGFBQVEsV0FBVSw0Q0FDakI7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyx5QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUNiLHVCQUFDLE9BQUUsaUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFdBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0M5QyxNQUFNWSxjQUFjWixNQUFNK0MsU0FBU0MsV0FDbEM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTXRDLGtCQUFrQlYsTUFBTVksVUFBVTtBQUFBLFVBRWhEWixnQkFBTStDLFFBQVFDO0FBQUFBO0FBQUFBLFFBTGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BLElBRUEsdUJBQUMsVUFBSyxXQUFVLHVCQUFzQix1QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QztBQUFBLFNBZGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUVBLHVCQUFDLGFBQVEsV0FBVSxzQkFDakI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxRQUFHLGlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUI7QUFBQSxRQUNyQix1QkFBQyxVQUFNOUIsNkJBQW1CbUIsVUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFdBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHNEQUNabkIsNkJBQW1CbUIsU0FBUyxJQUMzQm5CLG1CQUFtQnlCO0FBQUFBLFFBQUksQ0FBQ3ZCLGdCQUN0Qix1QkFBQyxTQUE4QixXQUFVLHFEQUN0Q0Esc0JBQVk2QixNQUFNRCxXQUNqQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNdEMsa0JBQWtCVSxZQUFZRSxPQUFPO0FBQUEsWUFFbkRGLHNCQUFZNkIsS0FBS0Q7QUFBQUE7QUFBQUEsVUFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsSUFFQSx1QkFBQyxVQUFNNUIsc0JBQVlFLFdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsS0FWckJGLFlBQVlFLFNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLE1BQ0QsSUFFRCx1QkFBQyxVQUFLLFdBQVUsdUJBQXNCLDZDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FLEtBbEJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLHNCQUNqQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFFBQUcsZ0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFFBQ3BCLHVCQUFDLFVBQU1OLHVCQUFhcUIsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFdBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNackIsdUJBQWFxQixTQUFTLElBQ3JCckIsYUFBYTJCO0FBQUFBLFFBQUksQ0FBQ3ZCLGdCQUNoQix1QkFBQyxTQUE4QixXQUFVLHdCQUN0Q0Esc0JBQVk2QixNQUFNRCxXQUNqQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNdEMsa0JBQWtCVSxZQUFZRSxPQUFPO0FBQUEsWUFFbkRGLHNCQUFZNkIsS0FBS0Q7QUFBQUE7QUFBQUEsVUFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsSUFFQSx1QkFBQyxVQUFNNUIsc0JBQVlFLFdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsS0FWckJGLFlBQVlFLFNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLE1BQ0QsSUFFRCx1QkFBQyxVQUFLLFdBQVUsdUJBQXNCLG1DQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlELEtBbEI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNacEI7QUFBQUEsb0JBQWMsQ0FBQ1MsU0FDZDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVyx3QkFBd0JQLFNBQVMsb0NBQW9DLEVBQUU7QUFBQSxVQUNsRixVQUFVLENBQUNBLFVBQVVDO0FBQUFBLFVBQ3JCLFNBQVMsTUFBTUQsU0FBU0ksUUFBUVIsTUFBTTZDLEVBQUUsSUFBSXRDLE9BQU9QLE1BQU02QyxFQUFFO0FBQUEsVUFFMUR6QyxtQkFBUyxnQkFBZ0JDLFNBQVMsZUFBZTtBQUFBO0FBQUEsUUFMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxNQUVELENBQUNILGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQiwwQ0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BRS9EUyxTQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixTQUFTLE1BQU1GLGNBQWNULE1BQU02QyxFQUFFO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsT0E3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThJQTtBQUVKO0FBQUNLLEtBak11Qm5EO0FBQW1CLElBQUFtRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJnZXRDYXRlZ29yeUljb24iLCJnZXRWaXNpYmxlVGFncyIsIkV2ZW50RGV0YWlsc1NpZGViYXIiLCJldmVudCIsIm9uQ2xvc2UiLCJpc0xvZ2dlZEluIiwiY3VycmVudFVzZXJJZCIsImpvaW5lZCIsImlzRnVsbCIsImZyaWVuZElkcyIsIm9uSm9pbiIsIm9uTGVhdmUiLCJvbkRlbGV0ZUV2ZW50Iiwib25WaWV3VXNlclByb2ZpbGUiLCJpc093biIsImNyZWF0b3JfaWQiLCJ0YWdzIiwidmlzaWJsZVRhZ3MiLCJoaWRkZW5Db3VudCIsInBhcnRpY2lwYW50cyIsImV2ZW50X3BhcnRpY2lwYW50cyIsImZyaWVuZFBhcnRpY2lwYW50cyIsImZpbHRlciIsInBhcnRpY2lwYW50IiwiaGFzIiwidXNlcl9pZCIsImV2ZW50RGF0ZSIsIkRhdGUiLCJldmVudF90aW1lIiwidG9Mb2NhbGVTdHJpbmciLCJ3ZWVrZGF5IiwiZGF5IiwibW9udGgiLCJob3VyIiwibWludXRlIiwiYnVkZ2V0TGFiZWwiLCJidWRnZXQiLCJ0b0ZpeGVkIiwiY2FwYWNpdHlMYWJlbCIsImNhcGFjaXR5IiwibGVuZ3RoIiwidmlzaWJpbGl0eUxhYmVsIiwidmlzaWJpbGl0eSIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJuYW1lIiwibWFwIiwidGFnIiwiaWQiLCJkZXNjcmlwdGlvbiIsImNyZWF0b3IiLCJ1c2VybmFtZSIsInVzZXIiLCJfYyJdLCJzb3VyY2VzIjpbIkV2ZW50RGV0YWlsc1NpZGViYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi9FdmVudERldGFpbHNTaWRlYmFyLmNzcydcclxuaW1wb3J0IHsgQXBpRXZlbnQgfSBmcm9tICcuL2FwaSdcclxuaW1wb3J0IHsgZ2V0Q2F0ZWdvcnlJY29uLCBnZXRWaXNpYmxlVGFncyB9IGZyb20gJy4vY2F0ZWdvcnlJY29ucydcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEV2ZW50RGV0YWlsc1NpZGViYXIoe1xyXG4gIGV2ZW50LFxyXG4gIG9uQ2xvc2UsXHJcbiAgaXNMb2dnZWRJbixcclxuICBjdXJyZW50VXNlcklkLFxyXG4gIGpvaW5lZCxcclxuICBpc0Z1bGwsXHJcbiAgZnJpZW5kSWRzLFxyXG4gIG9uSm9pbixcclxuICBvbkxlYXZlLFxyXG4gIG9uRGVsZXRlRXZlbnQsXHJcbiAgb25WaWV3VXNlclByb2ZpbGUsXHJcbn06IHtcclxuICBldmVudDogQXBpRXZlbnRcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkXHJcbiAgaXNMb2dnZWRJbjogYm9vbGVhblxyXG4gIGN1cnJlbnRVc2VySWQ6IHN0cmluZyB8IG51bGxcclxuICBqb2luZWQ6IGJvb2xlYW5cclxuICBpc0Z1bGw6IGJvb2xlYW5cclxuICBmcmllbmRJZHM6IFNldDxzdHJpbmc+XHJcbiAgb25Kb2luOiAoZXZlbnRJZDogc3RyaW5nKSA9PiB2b2lkXHJcbiAgb25MZWF2ZTogKGV2ZW50SWQ6IHN0cmluZykgPT4gdm9pZFxyXG4gIG9uRGVsZXRlRXZlbnQ6IChldmVudElkOiBzdHJpbmcpID0+IHZvaWRcclxuICBvblZpZXdVc2VyUHJvZmlsZTogKHVzZXJJZDogc3RyaW5nKSA9PiB2b2lkXHJcbn0pIHtcclxuICBpZiAoIWV2ZW50KSByZXR1cm4gbnVsbFxyXG4gIGNvbnN0IGlzT3duID0gZXZlbnQuY3JlYXRvcl9pZCA9PT0gY3VycmVudFVzZXJJZFxyXG4gIGNvbnN0IHRhZ3MgPSBldmVudC50YWdzID8/IFtdXHJcbiAgY29uc3QgeyB2aXNpYmxlVGFncywgaGlkZGVuQ291bnQgfSA9IGdldFZpc2libGVUYWdzKHRhZ3MsIDYpXHJcbiAgY29uc3QgcGFydGljaXBhbnRzID0gZXZlbnQuZXZlbnRfcGFydGljaXBhbnRzID8/IFtdXHJcbiAgY29uc3QgZnJpZW5kUGFydGljaXBhbnRzID0gcGFydGljaXBhbnRzLmZpbHRlcigocGFydGljaXBhbnQpID0+IGZyaWVuZElkcy5oYXMocGFydGljaXBhbnQudXNlcl9pZCkpXHJcbiAgY29uc3QgZXZlbnREYXRlID0gbmV3IERhdGUoZXZlbnQuZXZlbnRfdGltZSkudG9Mb2NhbGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgd2Vla2RheTogJ3Nob3J0JyxcclxuICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgbW9udGg6ICdzaG9ydCcsXHJcbiAgICBob3VyOiAnMi1kaWdpdCcsXHJcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcclxuICB9KVxyXG4gIGNvbnN0IGJ1ZGdldExhYmVsID0gZXZlbnQuYnVkZ2V0ICE9IG51bGwgPyBg4oKsJHtldmVudC5idWRnZXQudG9GaXhlZCgyKX1gIDogJ0J1ZGdldCB1bmtub3duJ1xyXG4gIGNvbnN0IGNhcGFjaXR5TGFiZWwgPSBldmVudC5jYXBhY2l0eSAhPSBudWxsXHJcbiAgICA/IGAke3BhcnRpY2lwYW50cy5sZW5ndGh9LyR7ZXZlbnQuY2FwYWNpdHl9IGdvaW5nYFxyXG4gICAgOiBgJHtwYXJ0aWNpcGFudHMubGVuZ3RofSBnb2luZ2BcclxuICBjb25zdCB2aXNpYmlsaXR5TGFiZWwgPSBldmVudC52aXNpYmlsaXR5ID09PSAnZnJpZW5kcydcclxuICAgID8gJ0ZyaWVuZHMnXHJcbiAgICA6IGV2ZW50LnZpc2liaWxpdHkgPT09ICdwcml2YXRlJ1xyXG4gICAgICA/ICdQcml2YXRlJ1xyXG4gICAgICA6ICdQdWJsaWMnXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtc2lkZWJhclwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLWhlYWRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy1oZWFkZXJfX3RvcGxpbmVcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtYmFkZ2VcIj5cclxuICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+e2dldENhdGVnb3J5SWNvbih0YWdzLCAnZXZlbnQnKX08L3NwYW4+XHJcbiAgICAgICAgICAgIEV2ZW50XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtY2xvc2VcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0gYXJpYS1sYWJlbD1cIkNsb3NlIGV2ZW50IGRldGFpbHNcIj5cclxuICAgICAgICAgICAgw5dcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxoMj57ZXZlbnQubmFtZX08L2gyPlxyXG4gICAgICAgIHt2aXNpYmxlVGFncy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy10YWdzXCI+XHJcbiAgICAgICAgICAgIHt2aXNpYmxlVGFncy5tYXAoKHRhZykgPT4gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGtleT17dGFnLmlkfSBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLXRhZ1wiPiN7dGFnLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAge2hpZGRlbkNvdW50ID4gMCAmJiA8c3BhbiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLXRhZyBldmVudC1kZXRhaWxzLXRhZy0tbW9yZVwiPit7aGlkZGVuQ291bnR9IG1vcmU8L3NwYW4+fVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtbWV0cmljc1wiIGFyaWEtbGFiZWw9XCJFdmVudCBzdW1tYXJ5XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLW1ldHJpY1wiPlxyXG4gICAgICAgICAgPHNwYW4+RGF0ZTwvc3Bhbj5cclxuICAgICAgICAgIDxzdHJvbmc+e2V2ZW50RGF0ZX08L3N0cm9uZz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtbWV0cmljXCI+XHJcbiAgICAgICAgICA8c3Bhbj5CdWRnZXQ8L3NwYW4+XHJcbiAgICAgICAgICA8c3Ryb25nPntidWRnZXRMYWJlbH08L3N0cm9uZz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtbWV0cmljXCI+XHJcbiAgICAgICAgICA8c3Bhbj5DYXBhY2l0eTwvc3Bhbj5cclxuICAgICAgICAgIDxzdHJvbmc+e2NhcGFjaXR5TGFiZWx9PC9zdHJvbmc+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLW1ldHJpY1wiPlxyXG4gICAgICAgICAgPHNwYW4+VmlzaWJpbGl0eTwvc3Bhbj5cclxuICAgICAgICAgIDxzdHJvbmc+e3Zpc2liaWxpdHlMYWJlbH08L3N0cm9uZz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLWNhcmRcIj5cclxuICAgICAgICA8aDM+RGVzY3JpcHRpb248L2gzPlxyXG4gICAgICAgIDxwPntldmVudC5kZXNjcmlwdGlvbiB8fCAnTm8gZGVzY3JpcHRpb24gcHJvdmlkZWQuJ308L3A+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtY2FyZCBldmVudC1kZXRhaWxzLWNyZWF0b3JcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgzPkhvc3RlZCBieTwvaDM+XHJcbiAgICAgICAgICA8cD5Pcmdhbml6ZXIgcHJvZmlsZTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7ZXZlbnQuY3JlYXRvcl9pZCAmJiBldmVudC5jcmVhdG9yPy51c2VybmFtZSA/IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtcHJvZmlsZS1waWxsXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25WaWV3VXNlclByb2ZpbGUoZXZlbnQuY3JlYXRvcl9pZCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtldmVudC5jcmVhdG9yLnVzZXJuYW1lfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtbXV0ZWRcIj5Vbmtub3duPC9zcGFuPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtY2FyZFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgPGgzPkZyaWVuZHMgYXR0ZW5kaW5nPC9oMz5cclxuICAgICAgICAgIDxzcGFuPntmcmllbmRQYXJ0aWNpcGFudHMubGVuZ3RofTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtcGVvcGxlIGV2ZW50LWRldGFpbHMtcGVvcGxlLS1mcmllbmRzXCI+XHJcbiAgICAgICAgICB7ZnJpZW5kUGFydGljaXBhbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgIGZyaWVuZFBhcnRpY2lwYW50cy5tYXAoKHBhcnRpY2lwYW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e3BhcnRpY2lwYW50LnVzZXJfaWR9IGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtcGVyc29uIGV2ZW50LWRldGFpbHMtcGVyc29uLS1mcmllbmRcIj5cclxuICAgICAgICAgICAgICAgIHtwYXJ0aWNpcGFudC51c2VyPy51c2VybmFtZSA/IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtcHJvZmlsZS1idG5cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVmlld1VzZXJQcm9maWxlKHBhcnRpY2lwYW50LnVzZXJfaWQpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3BhcnRpY2lwYW50LnVzZXIudXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4+e3BhcnRpY2lwYW50LnVzZXJfaWR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSlcclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtbXV0ZWRcIj5ObyBmcmllbmRzIGFyZSBhdHRlbmRpbmcgeWV0Ljwvc3Bhbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtY2FyZFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgPGgzPlN1YnNjcmliZWQgdXNlcnM8L2gzPlxyXG4gICAgICAgICAgPHNwYW4+e3BhcnRpY2lwYW50cy5sZW5ndGh9PC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy1wZW9wbGVcIj5cclxuICAgICAgICAgIHtwYXJ0aWNpcGFudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgcGFydGljaXBhbnRzLm1hcCgocGFydGljaXBhbnQpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2IGtleT17cGFydGljaXBhbnQudXNlcl9pZH0gY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy1wZXJzb25cIj5cclxuICAgICAgICAgICAgICAgIHtwYXJ0aWNpcGFudC51c2VyPy51c2VybmFtZSA/IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtcHJvZmlsZS1idG5cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVmlld1VzZXJQcm9maWxlKHBhcnRpY2lwYW50LnVzZXJfaWQpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3BhcnRpY2lwYW50LnVzZXIudXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4+e3BhcnRpY2lwYW50LnVzZXJfaWR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSlcclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtbXV0ZWRcIj5ObyBzdWJzY3JpYmVycyB5ZXQuPC9zcGFuPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLWFjdGlvbnNcIj5cclxuICAgICAgICB7aXNMb2dnZWRJbiAmJiAhaXNPd24gJiYgKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BldmVudC1kZXRhaWxzLWFjdGlvbiAke2pvaW5lZCA/ICdldmVudC1kZXRhaWxzLWFjdGlvbi0tc2Vjb25kYXJ5JyA6ICcnfWB9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXsham9pbmVkICYmIGlzRnVsbH1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gam9pbmVkID8gb25MZWF2ZShldmVudC5pZCkgOiBvbkpvaW4oZXZlbnQuaWQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7am9pbmVkID8gJ0xlYXZlIGV2ZW50JyA6IGlzRnVsbCA/ICdFdmVudCBmdWxsJyA6ICdKb2luIGV2ZW50J31cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgeyFpc0xvZ2dlZEluICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXZlbnQtZGV0YWlscy1oaW50XCI+TG9nIGluIHRvIGpvaW4gdGhpcyBldmVudC48L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICAgIHtpc093biAmJiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImV2ZW50LWRldGFpbHMtYWN0aW9uIGV2ZW50LWRldGFpbHMtYWN0aW9uLS1kYW5nZXJcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZUV2ZW50KGV2ZW50LmlkKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hcnRpL0RvY3VtZW50cy9HaXRIdWIvU29mdHdhcmUtUHJvamVjdC1HMTAvUHJvamVjdC9zcmMvRXZlbnREZXRhaWxzU2lkZWJhci50c3gifQ==