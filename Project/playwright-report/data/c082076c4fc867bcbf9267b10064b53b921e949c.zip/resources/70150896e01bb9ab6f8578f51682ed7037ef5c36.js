import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MapMarkers.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_leaflet from "/node_modules/.vite/deps/leaflet.js?v=fbd16829"; const L = __vite__cjsImport3_leaflet.__esModule ? __vite__cjsImport3_leaflet.default : __vite__cjsImport3_leaflet;
import { Marker, Popup, useMap, useMapEvents } from "/node_modules/.vite/deps/react-leaflet.js?v=523d6d0e";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useEffect = __vite__cjsImport5_react["useEffect"];
export const eventIcon = new L.DivIcon({
  className: "",
  html: `<div class="map-marker map-marker--event">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="18" rx="2" stroke="white" stroke-width="2"/>
            <path d="M3 9h18" stroke="white" stroke-width="2"/>
            <path d="M8 2v4M16 2v4" stroke="white" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <div class="map-marker__dot"></div>
    </div>`,
  iconSize: [36, 44],
  iconAnchor: [18, 44],
  popupAnchor: [0, -46]
});
export const planIcon = new L.DivIcon({
  className: "",
  html: `<div class="map-marker map-marker--plan">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" stroke="white" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <div class="map-marker__dot"></div>
    </div>`,
  iconSize: [36, 44],
  iconAnchor: [18, 44],
  popupAnchor: [0, -46]
});
export const ownEventIcon = new L.DivIcon({
  className: "",
  html: `<div class="map-marker map-marker--own">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="18" rx="2" stroke="white" stroke-width="2"/>
            <path d="M3 9h18" stroke="white" stroke-width="2"/>
            <path d="M8 2v4M16 2v4" stroke="white" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <div class="map-marker__dot"></div>
    </div>`,
  iconSize: [36, 44],
  iconAnchor: [18, 44],
  popupAnchor: [0, -46]
});
export const ownPlanIcon = new L.DivIcon({
  className: "",
  html: `<div class="map-marker map-marker--own">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" stroke="white" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <div class="map-marker__dot"></div>
    </div>`,
  iconSize: [36, 44],
  iconAnchor: [18, 44],
  popupAnchor: [0, -46]
});
function ClickHandler({ onClick }) {
  _s();
  useMapEvents({ click(e) {
    onClick([e.latlng.lat, e.latlng.lng]);
  } });
  return null;
}
_s(ClickHandler, "Ld/tk8Iz8AdZhC1l7acENaOEoCo=", false, function() {
  return [useMapEvents];
});
_c = ClickHandler;
function FocusMap({ position }) {
  _s2();
  const map = useMap();
  useEffect(() => {
    if (position) {
      map.panTo(position);
    }
  }, [map, position]);
  return null;
}
_s2(FocusMap, "IoceErwr5KVGS9kN4RQ1bOkYMAg=", false, function() {
  return [useMap];
});
_c2 = FocusMap;
function formatBudget(budget) {
  return budget != null ? `€${budget.toFixed(2)}` : null;
}
function formatVisibility(visibility) {
  if (visibility === "friends")
    return "Friends only";
  if (visibility === "private")
    return "Private";
  return "Public";
}
function userProfileButton(userId, username, onViewUserProfile) {
  if (!userId || !username)
    return null;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      className: "subscriber-name-btn",
      onClick: () => onViewUserProfile(userId),
      children: username
    },
    void 0,
    false,
    {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
      lineNumber: 127,
      columnNumber: 5
    },
    this
  );
}
export default function MapMarkers({
  events,
  plans,
  currentUserId,
  isLoggedIn,
  savedPlanIds,
  onDeletePlan,
  onSavePlan,
  onViewUserProfile,
  onMapClick,
  clickPosition,
  onCloseClick,
  onEventSelect,
  focusPosition
}) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(FocusMap, { position: focusPosition ?? null }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
      lineNumber: 170,
      columnNumber: 13
    }, this),
    events.map((event) => {
      const isOwn = event.creator_id === currentUserId;
      return /* @__PURE__ */ jsxDEV(
        Marker,
        {
          position: [event.lat, event.lng],
          icon: isOwn ? ownEventIcon : eventIcon,
          eventHandlers: onEventSelect ? { click: () => onEventSelect(event.id) } : void 0
        },
        `event-${event.id}`,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
          lineNumber: 178,
          columnNumber: 11
        },
        this
      );
    }),
    plans.map((plan) => {
      const isOwn = plan.creator_id === currentUserId;
      const tags = plan.tags ?? [];
      return /* @__PURE__ */ jsxDEV(
        Marker,
        {
          position: [plan.lat, plan.lng],
          icon: isOwn ? ownPlanIcon : planIcon,
          children: /* @__PURE__ */ jsxDEV(Popup, { children: /* @__PURE__ */ jsxDEV("div", { className: "marker-popup", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__badge marker-popup__badge--plan", children: "Plan" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
              lineNumber: 198,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__title", children: plan.name }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
              lineNumber: 199,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__meta", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "👤 by",
                " ",
                userProfileButton(plan.creator_id, plan.creator?.username, onViewUserProfile) ?? "Unknown"
              ] }, void 0, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
                lineNumber: 201,
                columnNumber: 37
              }, this),
              plan.budget != null && /* @__PURE__ */ jsxDEV("span", { children: [
                "💰 ",
                formatBudget(plan.budget)
              ] }, void 0, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
                lineNumber: 205,
                columnNumber: 61
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: formatVisibility(plan.visibility) }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
                lineNumber: 206,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
              lineNumber: 200,
              columnNumber: 33
            }, this),
            tags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__tags", children: tags.map(
              (tag) => /* @__PURE__ */ jsxDEV("span", { className: "marker-popup__tag", children: [
                "#",
                tag.name
              ] }, tag.id, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
                lineNumber: 211,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
              lineNumber: 209,
              columnNumber: 17
            }, this),
            plan.description && /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__desc", children: plan.description }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
              lineNumber: 216,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__actions", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "marker-popup__btn marker-popup__btn--save",
                  onClick: () => onSavePlan(plan),
                  disabled: !isLoggedIn || savedPlanIds.has(plan.id),
                  children: !isLoggedIn ? "Log in to save" : savedPlanIds.has(plan.id) ? "Saved" : "Save plan"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
                  lineNumber: 219,
                  columnNumber: 37
                },
                this
              ),
              isOwn && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  className: "marker-popup__btn marker-popup__btn--danger",
                  onClick: () => onDeletePlan(plan.id),
                  children: "Delete"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
                  lineNumber: 227,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
              lineNumber: 218,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
            lineNumber: 197,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
            lineNumber: 196,
            columnNumber: 25
          }, this)
        },
        `plan-${plan.id}`,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
          lineNumber: 191,
          columnNumber: 11
        },
        this
      );
    }),
    clickPosition && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Marker, { position: clickPosition }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
        lineNumber: 243,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(Popup, { position: clickPosition, eventHandlers: { remove: onCloseClick }, children: /* @__PURE__ */ jsxDEV("div", { className: "marker-popup", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__title", children: "New location" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
          lineNumber: 246,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "marker-popup__hint", children: isLoggedIn ? "Use the sidebar form to create an event or plan here." : "Log in to create events or plans." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
          lineNumber: 247,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
        lineNumber: 245,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
        lineNumber: 244,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
      lineNumber: 242,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ClickHandler, { onClick: onMapClick }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
      lineNumber: 257,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx",
    lineNumber: 169,
    columnNumber: 5
  }, this);
}
_c3 = MapMarkers;
var _c, _c2, _c3;
$RefreshReg$(_c, "ClickHandler");
$RefreshReg$(_c2, "FocusMap");
$RefreshReg$(_c3, "MapMarkers");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/MapMarkers.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkdRLFNBbUhRLFVBbkhSOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNHUixPQUFPQSxPQUFPO0FBQ2QsU0FBU0MsUUFBUUMsT0FBT0MsUUFBUUMsb0JBQW9CO0FBQ3BELFNBQVNDLGlCQUFpQjtBQUtuQixhQUFNQyxZQUFZLElBQUlOLEVBQUVPLFFBQVE7QUFBQSxFQUNuQ0MsV0FBVztBQUFBLEVBQ1hDLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUU5DLFVBQVUsQ0FBQyxJQUFJLEVBQUU7QUFBQSxFQUNqQkMsWUFBWSxDQUFDLElBQUksRUFBRTtBQUFBLEVBQ25CQyxhQUFhLENBQUMsR0FBRyxHQUFHO0FBQ3hCLENBQUM7QUFFTSxhQUFNQyxXQUFXLElBQUliLEVBQUVPLFFBQVE7QUFBQSxFQUNsQ0MsV0FBVztBQUFBLEVBQ1hDLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9OQyxVQUFVLENBQUMsSUFBSSxFQUFFO0FBQUEsRUFDakJDLFlBQVksQ0FBQyxJQUFJLEVBQUU7QUFBQSxFQUNuQkMsYUFBYSxDQUFDLEdBQUcsR0FBRztBQUN4QixDQUFDO0FBRU0sYUFBTUUsZUFBZSxJQUFJZCxFQUFFTyxRQUFRO0FBQUEsRUFDdENDLFdBQVc7QUFBQSxFQUNYQyxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFOQyxVQUFVLENBQUMsSUFBSSxFQUFFO0FBQUEsRUFDakJDLFlBQVksQ0FBQyxJQUFJLEVBQUU7QUFBQSxFQUNuQkMsYUFBYSxDQUFDLEdBQUcsR0FBRztBQUN4QixDQUFDO0FBRU0sYUFBTUcsY0FBYyxJQUFJZixFQUFFTyxRQUFRO0FBQUEsRUFDckNDLFdBQVc7QUFBQSxFQUNYQyxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPTkMsVUFBVSxDQUFDLElBQUksRUFBRTtBQUFBLEVBQ2pCQyxZQUFZLENBQUMsSUFBSSxFQUFFO0FBQUEsRUFDbkJDLGFBQWEsQ0FBQyxHQUFHLEdBQUc7QUFDeEIsQ0FBQztBQUVELFNBQVNJLGFBQWEsRUFBRUMsUUFBc0QsR0FBRztBQUFBQyxLQUFBO0FBQzdFZCxlQUFhLEVBQUVlLE1BQU1DLEdBQUc7QUFBRUgsWUFBUSxDQUFDRyxFQUFFQyxPQUFPQyxLQUFLRixFQUFFQyxPQUFPRSxHQUFHLENBQUM7QUFBQSxFQUFFLEVBQUUsQ0FBQztBQUNuRSxTQUFPO0FBQ1g7QUFBQ0wsR0FIUUYsY0FBWTtBQUFBLFVBQ2pCWixZQUFZO0FBQUE7QUFBQSxLQURQWTtBQUtULFNBQVNRLFNBQVMsRUFBRUMsU0FBZ0QsR0FBRztBQUFBQyxNQUFBO0FBQ25FLFFBQU1DLE1BQU14QixPQUFPO0FBRW5CRSxZQUFVLE1BQU07QUFDWixRQUFJb0IsVUFBVTtBQUNWRSxVQUFJQyxNQUFNSCxRQUFRO0FBQUEsSUFDdEI7QUFBQSxFQUNKLEdBQUcsQ0FBQ0UsS0FBS0YsUUFBUSxDQUFDO0FBRWxCLFNBQU87QUFDWDtBQU9BQyxJQWpCU0YsVUFBUTtBQUFBLFVBQ0RyQixNQUFNO0FBQUE7QUFBQSxNQURicUI7QUFtQlQsU0FBU0ssYUFBYUMsUUFBdUI7QUFDekMsU0FBT0EsVUFBVSxPQUFPLElBQUlBLE9BQU9DLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDdEQ7QUFFQSxTQUFTQyxpQkFBaUJDLFlBQW1DO0FBQ3pELE1BQUlBLGVBQWU7QUFBVyxXQUFPO0FBQ3JDLE1BQUlBLGVBQWU7QUFBVyxXQUFPO0FBQ3JDLFNBQU87QUFDWDtBQUVBLFNBQVNDLGtCQUNMQyxRQUNBQyxVQUNBQyxtQkFDRjtBQUNFLE1BQUksQ0FBQ0YsVUFBVSxDQUFDQztBQUFVLFdBQU87QUFFakMsU0FDSTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0csTUFBSztBQUFBLE1BQ0wsV0FBVTtBQUFBLE1BQ1YsU0FBUyxNQUFNQyxrQkFBa0JGLE1BQU07QUFBQSxNQUV0Q0M7QUFBQUE7QUFBQUEsSUFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQTtBQUVSO0FBa0JBLHdCQUF3QkUsV0FBVztBQUFBLEVBQy9CQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBUjtBQUFBQSxFQUNBUztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNHLEdBQUc7QUFDTixTQUNJLG1DQUNJO0FBQUEsMkJBQUMsWUFBUyxVQUFVQSxpQkFBaUIsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBQ3pDWCxPQUFPWixJQUFJLENBQUN3QixVQUFVO0FBQ25CLFlBQU1DLFFBQVFELE1BQU1FLGVBQWVaO0FBS25DLGFBQ0k7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVHLFVBQVUsQ0FBQ1UsTUFBTTdCLEtBQUs2QixNQUFNNUIsR0FBRztBQUFBLFVBQy9CLE1BQU02QixRQUFRdEMsZUFBZVI7QUFBQUEsVUFDN0IsZUFBZTJDLGdCQUFnQixFQUFFOUIsT0FBT0EsTUFBTThCLGNBQWNFLE1BQU1HLEVBQUUsRUFBRSxJQUFJQztBQUFBQTtBQUFBQSxRQUhyRSxTQUFTSixNQUFNRyxFQUFFO0FBQUEsUUFEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUl3RjtBQUFBLElBR2hHLENBQUM7QUFBQSxJQUVBZCxNQUFNYixJQUFJLENBQUM2QixTQUFTO0FBQ2pCLFlBQU1KLFFBQVFJLEtBQUtILGVBQWVaO0FBQ2xDLFlBQU1nQixPQUFPRCxLQUFLQyxRQUFRO0FBQzFCLGFBQ0k7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVHLFVBQVUsQ0FBQ0QsS0FBS2xDLEtBQUtrQyxLQUFLakMsR0FBRztBQUFBLFVBQzdCLE1BQU02QixRQUFRckMsY0FBY0Y7QUFBQUEsVUFFNUIsaUNBQUMsU0FDRyxpQ0FBQyxTQUFJLFdBQVUsZ0JBQ1g7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaURBQWdELG9CQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FLHVCQUFDLFNBQUksV0FBVSx1QkFBdUIyQyxlQUFLRSxRQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQ2hELHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLHFDQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUNJO0FBQUEsZ0JBQ0x4QixrQkFBa0JzQixLQUFLSCxZQUFZRyxLQUFLRyxTQUFTdkIsVUFBVUMsaUJBQWlCLEtBQUs7QUFBQSxtQkFGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0NtQixLQUFLMUIsVUFBVSxRQUFRLHVCQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUFJRCxhQUFhMkIsS0FBSzFCLE1BQU07QUFBQSxtQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxjQUM1RCx1QkFBQyxVQUFNRSwyQkFBaUJ3QixLQUFLdkIsVUFBVSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGlCQU43QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQ3dCLEtBQUtHLFNBQVMsS0FDWCx1QkFBQyxTQUFJLFdBQVUsc0JBQ1ZILGVBQUs5QjtBQUFBQSxjQUFJLENBQUNrQyxRQUNQLHVCQUFDLFVBQWtCLFdBQVUscUJBQW9CO0FBQUE7QUFBQSxnQkFBRUEsSUFBSUg7QUFBQUEsbUJBQTVDRyxJQUFJUCxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsWUFDL0QsS0FITDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFFSEUsS0FBS00sZUFDRix1QkFBQyxTQUFJLFdBQVUsc0JBQXNCTixlQUFLTSxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBRTFELHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU1qQixXQUFXVyxJQUFJO0FBQUEsa0JBQzlCLFVBQVUsQ0FBQ2QsY0FBY0MsYUFBYW9CLElBQUlQLEtBQUtGLEVBQUU7QUFBQSxrQkFFaEQsV0FBQ1osYUFBYSxtQkFBbUJDLGFBQWFvQixJQUFJUCxLQUFLRixFQUFFLElBQUksVUFBVTtBQUFBO0FBQUEsZ0JBTDVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQ0YsU0FDRztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNUixhQUFhWSxLQUFLRixFQUFFO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQWRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsZUFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQ0EsS0F2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQTtBQUFBLFFBNUNLLFFBQVFFLEtBQUtGLEVBQUU7QUFBQSxRQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BOENBO0FBQUEsSUFFUixDQUFDO0FBQUEsSUFFQVAsaUJBQ0csbUNBQ0k7QUFBQSw2QkFBQyxVQUFPLFVBQVVBLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsTUFDaEMsdUJBQUMsU0FBTSxVQUFVQSxlQUFlLGVBQWUsRUFBRWlCLFFBQVFoQixhQUFhLEdBQ2xFLGlDQUFDLFNBQUksV0FBVSxnQkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSx1QkFBc0IsNEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUNqRCx1QkFBQyxTQUFJLFdBQVUsc0JBQ1ZOLHVCQUNLLDBEQUNBLHVDQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUdKLHVCQUFDLGdCQUFhLFNBQVNJLGNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxPQXhGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlGQTtBQUVSO0FBQUNtQixNQTNHdUIzQjtBQUFVLElBQUE0QixJQUFBQyxLQUFBRjtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUYsS0FBQSIsIm5hbWVzIjpbIkwiLCJNYXJrZXIiLCJQb3B1cCIsInVzZU1hcCIsInVzZU1hcEV2ZW50cyIsInVzZUVmZmVjdCIsImV2ZW50SWNvbiIsIkRpdkljb24iLCJjbGFzc05hbWUiLCJodG1sIiwiaWNvblNpemUiLCJpY29uQW5jaG9yIiwicG9wdXBBbmNob3IiLCJwbGFuSWNvbiIsIm93bkV2ZW50SWNvbiIsIm93blBsYW5JY29uIiwiQ2xpY2tIYW5kbGVyIiwib25DbGljayIsIl9zIiwiY2xpY2siLCJlIiwibGF0bG5nIiwibGF0IiwibG5nIiwiRm9jdXNNYXAiLCJwb3NpdGlvbiIsIl9zMiIsIm1hcCIsInBhblRvIiwiZm9ybWF0QnVkZ2V0IiwiYnVkZ2V0IiwidG9GaXhlZCIsImZvcm1hdFZpc2liaWxpdHkiLCJ2aXNpYmlsaXR5IiwidXNlclByb2ZpbGVCdXR0b24iLCJ1c2VySWQiLCJ1c2VybmFtZSIsIm9uVmlld1VzZXJQcm9maWxlIiwiTWFwTWFya2VycyIsImV2ZW50cyIsInBsYW5zIiwiY3VycmVudFVzZXJJZCIsImlzTG9nZ2VkSW4iLCJzYXZlZFBsYW5JZHMiLCJvbkRlbGV0ZVBsYW4iLCJvblNhdmVQbGFuIiwib25NYXBDbGljayIsImNsaWNrUG9zaXRpb24iLCJvbkNsb3NlQ2xpY2siLCJvbkV2ZW50U2VsZWN0IiwiZm9jdXNQb3NpdGlvbiIsImV2ZW50IiwiaXNPd24iLCJjcmVhdG9yX2lkIiwiaWQiLCJ1bmRlZmluZWQiLCJwbGFuIiwidGFncyIsIm5hbWUiLCJjcmVhdG9yIiwibGVuZ3RoIiwidGFnIiwiZGVzY3JpcHRpb24iLCJoYXMiLCJyZW1vdmUiLCJfYzMiLCJfYyIsIl9jMiJdLCJzb3VyY2VzIjpbIk1hcE1hcmtlcnMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMIGZyb20gJ2xlYWZsZXQnXHJcbmltcG9ydCB7IE1hcmtlciwgUG9wdXAsIHVzZU1hcCwgdXNlTWFwRXZlbnRzIH0gZnJvbSAncmVhY3QtbGVhZmxldCdcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEFwaUV2ZW50LCBBcGlQbGFuIH0gZnJvbSAnLi9hcGknXHJcblxyXG4vLyDilIDilIAgQ3VzdG9tIGljb25zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG5cclxuZXhwb3J0IGNvbnN0IGV2ZW50SWNvbiA9IG5ldyBMLkRpdkljb24oe1xyXG4gICAgY2xhc3NOYW1lOiAnJyxcclxuICAgIGh0bWw6IGA8ZGl2IGNsYXNzPVwibWFwLW1hcmtlciBtYXAtbWFya2VyLS1ldmVudFwiPlxyXG4gICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxyXG4gICAgICAgICAgICA8cmVjdCB4PVwiM1wiIHk9XCI0XCIgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgcng9XCIyXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2Utd2lkdGg9XCIyXCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTMgOWgxOFwiIHN0cm9rZT1cIndoaXRlXCIgc3Ryb2tlLXdpZHRoPVwiMlwiLz5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk04IDJ2NE0xNiAydjRcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYXAtbWFya2VyX19kb3RcIj48L2Rpdj5cclxuICAgIDwvZGl2PmAsXHJcbiAgICBpY29uU2l6ZTogWzM2LCA0NF0sXHJcbiAgICBpY29uQW5jaG9yOiBbMTgsIDQ0XSxcclxuICAgIHBvcHVwQW5jaG9yOiBbMCwgLTQ2XSxcclxufSlcclxuXHJcbmV4cG9ydCBjb25zdCBwbGFuSWNvbiA9IG5ldyBMLkRpdkljb24oe1xyXG4gICAgY2xhc3NOYW1lOiAnJyxcclxuICAgIGh0bWw6IGA8ZGl2IGNsYXNzPVwibWFwLW1hcmtlciBtYXAtbWFya2VyLS1wbGFuXCI+XHJcbiAgICAgICAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNOSAxMWwzIDNMMjIgNFwiIHN0cm9rZT1cIndoaXRlXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiLz5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk0yMSAxMnY3YTIgMiAwIDAxLTIgMkg1YTIgMiAwIDAxLTItMlY1YTIgMiAwIDAxMi0yaDExXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiLz5cclxuICAgICAgICA8L3N2Zz5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwibWFwLW1hcmtlcl9fZG90XCI+PC9kaXY+XHJcbiAgICA8L2Rpdj5gLFxyXG4gICAgaWNvblNpemU6IFszNiwgNDRdLFxyXG4gICAgaWNvbkFuY2hvcjogWzE4LCA0NF0sXHJcbiAgICBwb3B1cEFuY2hvcjogWzAsIC00Nl0sXHJcbn0pXHJcblxyXG5leHBvcnQgY29uc3Qgb3duRXZlbnRJY29uID0gbmV3IEwuRGl2SWNvbih7XHJcbiAgICBjbGFzc05hbWU6ICcnLFxyXG4gICAgaHRtbDogYDxkaXYgY2xhc3M9XCJtYXAtbWFya2VyIG1hcC1tYXJrZXItLW93blwiPlxyXG4gICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxyXG4gICAgICAgICAgICA8cmVjdCB4PVwiM1wiIHk9XCI0XCIgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgcng9XCIyXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2Utd2lkdGg9XCIyXCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTMgOWgxOFwiIHN0cm9rZT1cIndoaXRlXCIgc3Ryb2tlLXdpZHRoPVwiMlwiLz5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk04IDJ2NE0xNiAydjRcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYXAtbWFya2VyX19kb3RcIj48L2Rpdj5cclxuICAgIDwvZGl2PmAsXHJcbiAgICBpY29uU2l6ZTogWzM2LCA0NF0sXHJcbiAgICBpY29uQW5jaG9yOiBbMTgsIDQ0XSxcclxuICAgIHBvcHVwQW5jaG9yOiBbMCwgLTQ2XSxcclxufSlcclxuXHJcbmV4cG9ydCBjb25zdCBvd25QbGFuSWNvbiA9IG5ldyBMLkRpdkljb24oe1xyXG4gICAgY2xhc3NOYW1lOiAnJyxcclxuICAgIGh0bWw6IGA8ZGl2IGNsYXNzPVwibWFwLW1hcmtlciBtYXAtbWFya2VyLS1vd25cIj5cclxuICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk05IDExbDMgM0wyMiA0XCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTIxIDEydjdhMiAyIDAgMDEtMiAySDVhMiAyIDAgMDEtMi0yVjVhMiAyIDAgMDEyLTJoMTFcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYXAtbWFya2VyX19kb3RcIj48L2Rpdj5cclxuICAgIDwvZGl2PmAsXHJcbiAgICBpY29uU2l6ZTogWzM2LCA0NF0sXHJcbiAgICBpY29uQW5jaG9yOiBbMTgsIDQ0XSxcclxuICAgIHBvcHVwQW5jaG9yOiBbMCwgLTQ2XSxcclxufSlcclxuXHJcbmZ1bmN0aW9uIENsaWNrSGFuZGxlcih7IG9uQ2xpY2sgfTogeyBvbkNsaWNrOiAocG9zOiBbbnVtYmVyLCBudW1iZXJdKSA9PiB2b2lkIH0pIHtcclxuICAgIHVzZU1hcEV2ZW50cyh7IGNsaWNrKGUpIHsgb25DbGljayhbZS5sYXRsbmcubGF0LCBlLmxhdGxuZy5sbmddKSB9IH0pXHJcbiAgICByZXR1cm4gbnVsbFxyXG59XHJcblxyXG5mdW5jdGlvbiBGb2N1c01hcCh7IHBvc2l0aW9uIH06IHsgcG9zaXRpb246IFtudW1iZXIsIG51bWJlcl0gfCBudWxsIH0pIHtcclxuICAgIGNvbnN0IG1hcCA9IHVzZU1hcCgpXHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAocG9zaXRpb24pIHtcclxuICAgICAgICAgICAgbWFwLnBhblRvKHBvc2l0aW9uKVxyXG4gICAgICAgIH1cclxuICAgIH0sIFttYXAsIHBvc2l0aW9uXSlcclxuXHJcbiAgICByZXR1cm4gbnVsbFxyXG59XHJcblxyXG4vLyBmdW5jdGlvbiBmb3JtYXRUaW1lKGlzbzogc3RyaW5nKSB7XHJcbi8vICAgICByZXR1cm4gbmV3IERhdGUoaXNvKS50b0xvY2FsZVN0cmluZygnZW4tR0InLCB7XHJcbi8vICAgICAgICAgd2Vla2RheTogJ3Nob3J0JywgZGF5OiAnbnVtZXJpYycsIG1vbnRoOiAnc2hvcnQnLFxyXG4vLyAgICAgICAgIGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcsXHJcbi8vICAgICB9KVxyXG4vLyB9XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRCdWRnZXQoYnVkZ2V0OiBudW1iZXIgfCBudWxsKSB7XHJcbiAgICByZXR1cm4gYnVkZ2V0ICE9IG51bGwgPyBg4oKsJHtidWRnZXQudG9GaXhlZCgyKX1gIDogbnVsbFxyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRWaXNpYmlsaXR5KHZpc2liaWxpdHk6IEFwaVBsYW5bJ3Zpc2liaWxpdHknXSkge1xyXG4gICAgaWYgKHZpc2liaWxpdHkgPT09ICdmcmllbmRzJykgcmV0dXJuICdGcmllbmRzIG9ubHknXHJcbiAgICBpZiAodmlzaWJpbGl0eSA9PT0gJ3ByaXZhdGUnKSByZXR1cm4gJ1ByaXZhdGUnXHJcbiAgICByZXR1cm4gJ1B1YmxpYydcclxufVxyXG5cclxuZnVuY3Rpb24gdXNlclByb2ZpbGVCdXR0b24oXHJcbiAgICB1c2VySWQ6IHN0cmluZyB8IHVuZGVmaW5lZCxcclxuICAgIHVzZXJuYW1lOiBzdHJpbmcgfCB1bmRlZmluZWQsXHJcbiAgICBvblZpZXdVc2VyUHJvZmlsZTogKHVzZXJJZDogc3RyaW5nKSA9PiB2b2lkLFxyXG4pIHtcclxuICAgIGlmICghdXNlcklkIHx8ICF1c2VybmFtZSkgcmV0dXJuIG51bGxcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInN1YnNjcmliZXItbmFtZS1idG5cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblZpZXdVc2VyUHJvZmlsZSh1c2VySWQpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgICAge3VzZXJuYW1lfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgKVxyXG59XHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gICAgZXZlbnRzOiBBcGlFdmVudFtdXHJcbiAgICBwbGFuczogQXBpUGxhbltdXHJcbiAgICBjdXJyZW50VXNlcklkOiBzdHJpbmcgfCBudWxsXHJcbiAgICBpc0xvZ2dlZEluOiBib29sZWFuXHJcbiAgICBzYXZlZFBsYW5JZHM6IFNldDxzdHJpbmc+XHJcbiAgICBvbkRlbGV0ZVBsYW46IChwbGFuSWQ6IHN0cmluZykgPT4gdm9pZFxyXG4gICAgb25TYXZlUGxhbjogKHBsYW46IEFwaVBsYW4pID0+IHsgc2F2ZWQ6IGJvb2xlYW47IG1lc3NhZ2U6IHN0cmluZyB9XHJcbiAgICBvblZpZXdVc2VyUHJvZmlsZTogKHVzZXJJZDogc3RyaW5nKSA9PiB2b2lkXHJcbiAgICBvbk1hcENsaWNrOiAocG9zOiBbbnVtYmVyLCBudW1iZXJdKSA9PiB2b2lkXHJcbiAgICBjbGlja1Bvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdIHwgbnVsbFxyXG4gICAgb25DbG9zZUNsaWNrOiAoKSA9PiB2b2lkXHJcbiAgICBvbkV2ZW50U2VsZWN0PzogKGV2ZW50SWQ6IHN0cmluZykgPT4gdm9pZFxyXG4gICAgZm9jdXNQb3NpdGlvbj86IFtudW1iZXIsIG51bWJlcl0gfCBudWxsXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1hcE1hcmtlcnMoe1xyXG4gICAgZXZlbnRzLFxyXG4gICAgcGxhbnMsXHJcbiAgICBjdXJyZW50VXNlcklkLFxyXG4gICAgaXNMb2dnZWRJbixcclxuICAgIHNhdmVkUGxhbklkcyxcclxuICAgIG9uRGVsZXRlUGxhbixcclxuICAgIG9uU2F2ZVBsYW4sXHJcbiAgICBvblZpZXdVc2VyUHJvZmlsZSxcclxuICAgIG9uTWFwQ2xpY2ssXHJcbiAgICBjbGlja1Bvc2l0aW9uLFxyXG4gICAgb25DbG9zZUNsaWNrLFxyXG4gICAgb25FdmVudFNlbGVjdCxcclxuICAgIGZvY3VzUG9zaXRpb24sXHJcbn06IFByb3BzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxGb2N1c01hcCBwb3NpdGlvbj17Zm9jdXNQb3NpdGlvbiA/PyBudWxsfSAvPlxyXG4gICAgICAgICAgICB7ZXZlbnRzLm1hcCgoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGlzT3duID0gZXZlbnQuY3JlYXRvcl9pZCA9PT0gY3VycmVudFVzZXJJZFxyXG5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPE1hcmtlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2BldmVudC0ke2V2ZW50LmlkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uPXtbZXZlbnQubGF0LCBldmVudC5sbmddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uPXtpc093biA/IG93bkV2ZW50SWNvbiA6IGV2ZW50SWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnRIYW5kbGVycz17b25FdmVudFNlbGVjdCA/IHsgY2xpY2s6ICgpID0+IG9uRXZlbnRTZWxlY3QoZXZlbnQuaWQpIH0gOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSl9XHJcblxyXG4gICAgICAgICAgICB7cGxhbnMubWFwKChwbGFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBpc093biA9IHBsYW4uY3JlYXRvcl9pZCA9PT0gY3VycmVudFVzZXJJZFxyXG4gICAgICAgICAgICAgICAgY29uc3QgdGFncyA9IHBsYW4udGFncyA/PyBbXVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8TWFya2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YHBsYW4tJHtwbGFuLmlkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uPXtbcGxhbi5sYXQsIHBsYW4ubG5nXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17aXNPd24gPyBvd25QbGFuSWNvbiA6IHBsYW5JY29ufVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBvcHVwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXJrZXItcG9wdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcmtlci1wb3B1cF9fYmFkZ2UgbWFya2VyLXBvcHVwX19iYWRnZS0tcGxhblwiPlBsYW48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcmtlci1wb3B1cF9fdGl0bGVcIj57cGxhbi5uYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFya2VyLXBvcHVwX19tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+RpCBieXsnICd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlclByb2ZpbGVCdXR0b24ocGxhbi5jcmVhdG9yX2lkLCBwbGFuLmNyZWF0b3I/LnVzZXJuYW1lLCBvblZpZXdVc2VyUHJvZmlsZSkgPz8gJ1Vua25vd24nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwbGFuLmJ1ZGdldCAhPSBudWxsICYmIDxzcGFuPvCfkrAge2Zvcm1hdEJ1ZGdldChwbGFuLmJ1ZGdldCl9PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdFZpc2liaWxpdHkocGxhbi52aXNpYmlsaXR5KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhZ3MubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFya2VyLXBvcHVwX190YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFncy5tYXAoKHRhZykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17dGFnLmlkfSBjbGFzc05hbWU9XCJtYXJrZXItcG9wdXBfX3RhZ1wiPiN7dGFnLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BsYW4uZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcmtlci1wb3B1cF9fZGVzY1wiPntwbGFuLmRlc2NyaXB0aW9ufTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXJrZXItcG9wdXBfX2FjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWFya2VyLXBvcHVwX19idG4gbWFya2VyLXBvcHVwX19idG4tLXNhdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TYXZlUGxhbihwbGFuKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNMb2dnZWRJbiB8fCBzYXZlZFBsYW5JZHMuaGFzKHBsYW4uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzTG9nZ2VkSW4gPyAnTG9nIGluIHRvIHNhdmUnIDogc2F2ZWRQbGFuSWRzLmhhcyhwbGFuLmlkKSA/ICdTYXZlZCcgOiAnU2F2ZSBwbGFuJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc093biAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWFya2VyLXBvcHVwX19idG4gbWFya2VyLXBvcHVwX19idG4tLWRhbmdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25EZWxldGVQbGFuKHBsYW4uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Qb3B1cD5cclxuICAgICAgICAgICAgICAgICAgICA8L01hcmtlcj5cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSl9XHJcblxyXG4gICAgICAgICAgICB7Y2xpY2tQb3NpdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYXJrZXIgcG9zaXRpb249e2NsaWNrUG9zaXRpb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBvcHVwIHBvc2l0aW9uPXtjbGlja1Bvc2l0aW9ufSBldmVudEhhbmRsZXJzPXt7IHJlbW92ZTogb25DbG9zZUNsaWNrIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcmtlci1wb3B1cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXJrZXItcG9wdXBfX3RpdGxlXCI+TmV3IGxvY2F0aW9uPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcmtlci1wb3B1cF9faGludFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvZ2dlZEluXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1VzZSB0aGUgc2lkZWJhciBmb3JtIHRvIGNyZWF0ZSBhbiBldmVudCBvciBwbGFuIGhlcmUuJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdMb2cgaW4gdG8gY3JlYXRlIGV2ZW50cyBvciBwbGFucy4nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUG9wdXA+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxDbGlja0hhbmRsZXIgb25DbGljaz17b25NYXBDbGlja30gLz5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hcnRpL0RvY3VtZW50cy9HaXRIdWIvU29mdHdhcmUtUHJvamVjdC1HMTAvUHJvamVjdC9zcmMvTWFwTWFya2Vycy50c3gifQ==