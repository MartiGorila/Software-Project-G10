import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PlannerPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { getCategoryIcon, getVisibleTags } from "/src/categoryIcons.ts";
const EARTH_RADIUS_KM = 6371;
const lengthToStops = {
  quick: 2,
  "half-day": 4,
  "full-day": 6
};
function toRadians(value) {
  return value * Math.PI / 180;
}
function distanceKm(from, to) {
  const dLat = toRadians(to[0] - from[0]);
  const dLng = toRadians(to[1] - from[1]);
  const lat1 = toRadians(from[0]);
  const lat2 = toRadians(to[0]);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function formatBudget(budget) {
  return budget == null ? "Budget unknown" : `€${budget.toFixed(2)}`;
}
function formatEventTime(iso) {
  return new Date(iso).toLocaleString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function formatEventClock(iso) {
  return new Date(iso).toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit"
  });
}
function formatRouteDate(dateKey) {
  const [year, month, day] = dateKey.split("-").map(Number);
  return new Date(year, month - 1, day).toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short"
  });
}
function getPreview(description) {
  if (!description)
    return "No description yet.";
  return description.length > 120 ? `${description.slice(0, 117)}...` : description;
}
function hasValidCoordinates(item) {
  return Number.isFinite(item.lat) && Number.isFinite(item.lng);
}
function scoreItem(item, radiusKm, selectedTagIds, budgetMax) {
  const reasons = [`${item.distanceFromCenter.toFixed(1)}km from the map center`];
  const distanceScore = Math.max(0, 30 * (1 - item.distanceFromCenter / radiusKm));
  let tagScore = 0;
  if (selectedTagIds.size > 0) {
    const tagIds = new Set(item.tags.map((tag) => tag.id));
    const matchedCount = [...selectedTagIds].filter((tagId) => tagIds.has(tagId)).length;
    tagScore = 50 * (matchedCount / selectedTagIds.size);
    reasons.push(`matches ${matchedCount} selected tag${matchedCount === 1 ? "" : "s"}`);
  } else if (item.tags.length > 0) {
    reasons.push("has tags for the selected mood");
  }
  let budgetScore = 0;
  if (budgetMax !== null) {
    if (item.budget === null) {
      budgetScore = 5;
      reasons.push("budget is unknown");
    } else if (item.budget <= budgetMax) {
      budgetScore = 20;
      reasons.push("within your max budget");
    } else {
      reasons.push("over your max budget");
    }
  }
  let timeScore = 0;
  if (item.type === "event" && item.eventTime) {
    const time = new Date(item.eventTime).getTime();
    if (Number.isFinite(time) && time >= Date.now()) {
      timeScore = 5;
      reasons.push("upcoming event");
    }
  }
  return {
    score: Math.round((distanceScore + tagScore + budgetScore + timeScore) * 100) / 100,
    reasons
  };
}
function eventTimeMs(item) {
  if (item.type !== "event" || !item.eventTime)
    return null;
  const time = new Date(item.eventTime).getTime();
  return Number.isFinite(time) ? time : null;
}
function eventDateKey(item) {
  if (item.type !== "event" || !item.eventTime)
    return null;
  const date = new Date(item.eventTime);
  if (!Number.isFinite(date.getTime()))
    return null;
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function withUniqueReason(item, reason) {
  return item.reasons.includes(reason) ? item : { ...item, reasons: [...item.reasons, reason] };
}
function selectRouteCandidates(candidates, mapCenter, targetStops, budgetMax) {
  const remaining = [...candidates].sort((a, b) => {
    if (b.score !== a.score)
      return b.score - a.score;
    if (a.distanceFromCenter !== b.distanceFromCenter)
      return a.distanceFromCenter - b.distanceFromCenter;
    if (a.type !== b.type)
      return a.type.localeCompare(b.type);
    return a.name.localeCompare(b.name);
  });
  const selected = [];
  let currentPosition = mapCenter;
  let knownBudget = 0;
  while (selected.length < targetStops && remaining.length > 0) {
    const ranked = remaining.map((item) => {
      const legDistance = distanceKm(currentPosition, [item.lat, item.lng]);
      const nextKnownBudget = knownBudget + (item.budget ?? 0);
      const budgetPenalty = budgetMax !== null && item.budget !== null && nextKnownBudget > budgetMax ? 80 : 0;
      const legScore = Math.max(0, 35 * (1 - legDistance / Math.max(1, item.distanceFromCenter + legDistance)));
      return {
        item,
        legDistance,
        routeScore: item.score + legScore - budgetPenalty
      };
    }).sort((a, b) => {
      if (b.routeScore !== a.routeScore)
        return b.routeScore - a.routeScore;
      if (a.legDistance !== b.legDistance)
        return a.legDistance - b.legDistance;
      if (a.item.type !== b.item.type)
        return a.item.type.localeCompare(b.item.type);
      return a.item.name.localeCompare(b.item.name);
    });
    const next = ranked[0];
    if (!next || next.routeScore < -20)
      break;
    selected.push(next.item);
    if (next.item.budget !== null)
      knownBudget += next.item.budget;
    currentPosition = [next.item.lat, next.item.lng];
    remaining.splice(remaining.findIndex((item) => item.type === next.item.type && item.id === next.item.id), 1);
  }
  return selected;
}
function nearestFirst(items, start) {
  const remaining = [...items];
  const ordered = [];
  let currentPosition = start;
  while (remaining.length > 0) {
    remaining.sort((a, b) => {
      const aDistance = distanceKm(currentPosition, [a.lat, a.lng]);
      const bDistance = distanceKm(currentPosition, [b.lat, b.lng]);
      if (aDistance !== bDistance)
        return aDistance - bDistance;
      if (b.score !== a.score)
        return b.score - a.score;
      return a.name.localeCompare(b.name);
    });
    const next = remaining.shift();
    if (!next)
      break;
    ordered.push(next);
    currentPosition = [next.lat, next.lng];
  }
  return ordered;
}
function addStopNumbers(items, mapCenter) {
  let currentPosition = mapCenter;
  return items.map((item, index) => {
    const legDistance = distanceKm(currentPosition, [item.lat, item.lng]);
    currentPosition = [item.lat, item.lng];
    return {
      ...item,
      stopNumber: index + 1,
      legDistance
    };
  });
}
function orderRouteCandidates(selected, mapCenter) {
  const timedEvents = selected.filter((item) => eventTimeMs(item) !== null).sort((a, b) => {
    const aTime = eventTimeMs(a) ?? 0;
    const bTime = eventTimeMs(b) ?? 0;
    if (aTime !== bTime)
      return aTime - bTime;
    return a.name.localeCompare(b.name);
  }).map((item) => withUniqueReason(item, `scheduled at ${formatEventClock(item.eventTime ?? "")}`));
  const untimedItems = selected.filter((item) => eventTimeMs(item) === null);
  if (timedEvents.length === 0) {
    return addStopNumbers(nearestFirst(untimedItems, mapCenter), mapCenter);
  }
  const slots = Array.from({ length: timedEvents.length + 1 }, () => []);
  untimedItems.forEach((item) => {
    const slotCosts = slots.map((_, slotIndex) => {
      if (slotIndex === 0) {
        return distanceKm(mapCenter, [item.lat, item.lng]) + distanceKm([item.lat, item.lng], [timedEvents[0].lat, timedEvents[0].lng]);
      }
      const previousTimed = timedEvents[slotIndex - 1];
      const previousPoint = [previousTimed.lat, previousTimed.lng];
      if (slotIndex === timedEvents.length) {
        return distanceKm(previousPoint, [item.lat, item.lng]);
      }
      const nextTimed = timedEvents[slotIndex];
      const nextPoint = [nextTimed.lat, nextTimed.lng];
      const directDistance = distanceKm(previousPoint, nextPoint);
      return distanceKm(previousPoint, [item.lat, item.lng]) + distanceKm([item.lat, item.lng], nextPoint) - directDistance;
    });
    const bestSlotIndex = slotCosts.reduce((bestIndex, cost, index) => cost < slotCosts[bestIndex] ? index : bestIndex, 0);
    const placementReason = bestSlotIndex === 0 ? "placed before the first timed stop" : bestSlotIndex === timedEvents.length ? "placed after timed stops" : "placed between timed stops";
    slots[bestSlotIndex].push(withUniqueReason(item, placementReason));
  });
  const ordered = [];
  let anchor = mapCenter;
  ordered.push(...nearestFirst(slots[0], anchor));
  if (ordered.length > 0) {
    const last = ordered[ordered.length - 1];
    anchor = [last.lat, last.lng];
  }
  timedEvents.forEach((event, index) => {
    ordered.push(event);
    anchor = [event.lat, event.lng];
    const slotItems = nearestFirst(slots[index + 1], anchor);
    ordered.push(...slotItems);
    if (slotItems.length > 0) {
      const last = slotItems[slotItems.length - 1];
      anchor = [last.lat, last.lng];
    }
  });
  return addStopNumbers(ordered, mapCenter);
}
function buildRoute(candidates, mapCenter, targetStops, budgetMax) {
  return orderRouteCandidates(
    selectRouteCandidates(candidates, mapCenter, targetStops, budgetMax),
    mapCenter
  );
}
function chooseBestEventDate(candidates) {
  const groups = /* @__PURE__ */ new Map();
  candidates.forEach((item) => {
    const dateKey = eventDateKey(item);
    if (!dateKey)
      return;
    groups.set(dateKey, [...groups.get(dateKey) ?? [], item]);
  });
  return [...groups.entries()].map(([dateKey, items]) => ({
    dateKey,
    items,
    totalScore: items.reduce((sum, item) => sum + item.score, 0)
  })).sort((a, b) => {
    if (b.totalScore !== a.totalScore)
      return b.totalScore - a.totalScore;
    if (b.items.length !== a.items.length)
      return b.items.length - a.items.length;
    return a.dateKey.localeCompare(b.dateKey);
  })[0] ?? null;
}
export default function PlannerPanel({
  events,
  plans,
  mapCenter,
  tags,
  onClose,
  onOpenEventDetails,
  onCenterOnMap,
  isLoggedIn,
  onSaveRoute
}) {
  _s();
  const [radiusKm, setRadiusKm] = useState("10");
  const [budgetMax, setBudgetMax] = useState("");
  const [typeMix, setTypeMix] = useState("both");
  const [planLength, setPlanLength] = useState("quick");
  const [selectedTagIds, setSelectedTagIds] = useState(/* @__PURE__ */ new Set());
  const [saveMessage, setSaveMessage] = useState("");
  const parsedRadius = Number(radiusKm);
  const safeRadius = Number.isFinite(parsedRadius) && parsedRadius > 0 ? parsedRadius : 10;
  const parsedBudget = budgetMax.trim() === "" ? null : Number(budgetMax);
  const safeBudgetMax = parsedBudget !== null && Number.isFinite(parsedBudget) && parsedBudget >= 0 ? parsedBudget : null;
  const routeResult = useMemo(() => {
    const selectedTags = selectedTagIds;
    const normalized = [
      ...typeMix === "plans" ? [] : events.filter(hasValidCoordinates).map((event) => {
        const base = {
          type: "event",
          id: event.id,
          name: event.name,
          description: event.description,
          lat: event.lat,
          lng: event.lng,
          budget: event.budget,
          tags: event.tags ?? [],
          eventTime: event.event_time,
          distanceFromCenter: distanceKm(mapCenter, [event.lat, event.lng])
        };
        return { ...base, ...scoreItem(base, safeRadius, selectedTags, safeBudgetMax) };
      }),
      ...typeMix === "events" ? [] : plans.filter(hasValidCoordinates).map((plan) => {
        const base = {
          type: "plan",
          id: plan.id,
          name: plan.name,
          description: plan.description,
          lat: plan.lat,
          lng: plan.lng,
          budget: plan.budget,
          tags: plan.tags ?? [],
          distanceFromCenter: distanceKm(mapCenter, [plan.lat, plan.lng])
        };
        return { ...base, ...scoreItem(base, safeRadius, selectedTags, safeBudgetMax) };
      })
    ];
    const candidates = normalized.filter((item) => item.distanceFromCenter <= safeRadius).filter((item) => {
      if (selectedTags.size === 0)
        return true;
      const itemTagIds = new Set(item.tags.map((tag) => tag.id));
      return [...selectedTags].every((tagId) => itemTagIds.has(tagId));
    });
    const bestEventDate = typeMix === "plans" ? null : chooseBestEventDate(candidates);
    const sameDayCandidates = bestEventDate ? candidates.filter((item) => item.type === "plan" || eventDateKey(item) === bestEventDate.dateKey) : candidates;
    return {
      route: buildRoute(sameDayCandidates, mapCenter, lengthToStops[planLength], safeBudgetMax),
      routeDateLabel: bestEventDate ? formatRouteDate(bestEventDate.dateKey) : ""
    };
  }, [events, mapCenter, planLength, plans, safeBudgetMax, safeRadius, selectedTagIds, typeMix]);
  const { route, routeDateLabel } = routeResult;
  const knownBudget = route.reduce((total, stop) => total + (stop.budget ?? 0), 0);
  const hasUnknownBudget = route.some((stop) => stop.budget === null);
  const totalDistance = route.reduce((total, stop) => total + stop.legDistance, 0);
  const toggleTag = (tagId) => {
    setSelectedTagIds((previous) => {
      const next = new Set(previous);
      next.has(tagId) ? next.delete(tagId) : next.add(tagId);
      return next;
    });
  };
  const handleSaveRoute = () => {
    if (route.length === 0)
      return;
    const result = onSaveRoute({
      title: routeDateLabel ? `Planner route for ${routeDateLabel}` : "Planner route",
      mapCenter,
      summary: {
        stops: route.length,
        knownBudget,
        hasUnknownBudget,
        totalDistance
      },
      stops: route.map((stop) => ({
        type: stop.type,
        id: stop.id,
        name: stop.name,
        description: stop.description,
        lat: stop.lat,
        lng: stop.lng,
        budget: stop.budget,
        tags: stop.tags,
        eventTime: stop.eventTime,
        reasons: stop.reasons,
        stopNumber: stop.stopNumber
      }))
    });
    setSaveMessage(result.message);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "planner-backdrop", onClick: onClose, children: /* @__PURE__ */ jsxDEV("section", { className: "planner-panel", "aria-label": "Route planner", onClick: (event) => event.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "planner-panel__header", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "planner-panel__eyebrow", children: "Random planner" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 492,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: "Build a nearby route" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 493,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Built from nearby plans/events matching your filters." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 494,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
        lineNumber: 491,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "explore-panel__close", onClick: onClose, "aria-label": "Close planner", children: "x" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
        lineNumber: 496,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
      lineNumber: 490,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "planner-panel__body", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "planner-toolbar", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "planner-controls", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "planner-field", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Radius" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 505,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "1",
                max: "100",
                value: radiusKm,
                onChange: (event) => setRadiusKm(event.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 506,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 504,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "planner-field", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Budget" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 515,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                step: "0.01",
                placeholder: "Any",
                value: budgetMax,
                onChange: (event) => setBudgetMax(event.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 516,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 514,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "planner-field", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Mix" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 526,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: typeMix, onChange: (event) => setTypeMix(event.target.value), children: [
              /* @__PURE__ */ jsxDEV("option", { value: "both", children: "Both" }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 528,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "events", children: "Events only" }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 529,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "plans", children: "Plans only" }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 530,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 527,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 525,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "planner-field", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Length" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 534,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: planLength, onChange: (event) => setPlanLength(event.target.value), children: [
              /* @__PURE__ */ jsxDEV("option", { value: "quick", children: "Quick · 2" }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 536,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "half-day", children: "Half-day · 4" }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 537,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "full-day", children: "Full-day · 6" }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 538,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 535,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 533,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 503,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "planner-tags", "aria-label": "Planner tag filters", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Tags" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 544,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "planner-tags__list", children: [
            tags.length === 0 && /* @__PURE__ */ jsxDEV("em", { children: "No tags available." }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 546,
              columnNumber: 55
            }, this),
            tags.map(
              (tag) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: selectedTagIds.has(tag.id) ? "planner-tag planner-tag--active" : "planner-tag",
                  onClick: () => toggleTag(tag.id),
                  children: [
                    "#",
                    tag.name
                  ]
                },
                tag.id,
                true,
                {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 548,
                  columnNumber: 17
                },
                this
              )
            )
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 545,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 543,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
        lineNumber: 502,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "planner-route-tools", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "planner-summary", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: route.length }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 564,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "stops" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 565,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 563,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: [
              "€",
              knownBudget.toFixed(2)
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 568,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: hasUnknownBudget ? "known budget, some unknown" : "known budget" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 569,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 567,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: [
              totalDistance.toFixed(1),
              "km"
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 572,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "route distance" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 573,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 571,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 562,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "planner-save-row", children: [
          routeDateLabel && /* @__PURE__ */ jsxDEV("span", { children: [
            "Built around ",
            routeDateLabel
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 578,
            columnNumber: 48
          }, this),
          route.length > 0 && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "planner-action planner-action--save",
              onClick: handleSaveRoute,
              disabled: !isLoggedIn,
              children: isLoggedIn ? "Save route" : "Log in to save"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 580,
              columnNumber: 15
            },
            this
          ),
          saveMessage && /* @__PURE__ */ jsxDEV("span", { className: "planner-save-row__message", children: saveMessage }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 589,
            columnNumber: 45
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 577,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
        lineNumber: 561,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "planner-route", children: [
        route.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "planner-empty", children: "No route could be generated with these filters. Try widening the radius or clearing tags." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
          lineNumber: 595,
          columnNumber: 13
        }, this),
        route.map((stop) => {
          const { visibleTags, hiddenCount } = getVisibleTags(stop.tags);
          return /* @__PURE__ */ jsxDEV("article", { className: "planner-stop", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "planner-stop__rail", children: /* @__PURE__ */ jsxDEV("div", { className: "planner-stop__number", children: stop.stopNumber }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 604,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 603,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "planner-stop__content", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "planner-stop__topline", children: [
                /* @__PURE__ */ jsxDEV("span", { className: `explore-card__badge explore-card__badge--${stop.type}`, children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "explore-card__icon", "aria-hidden": "true", children: getCategoryIcon(stop.tags, stop.type) }, void 0, false, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                    lineNumber: 609,
                    columnNumber: 49
                  }, this),
                  stop.type === "event" ? "Event" : "Plan"
                ] }, void 0, true, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 608,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "explore-card__distance", children: [
                  stop.legDistance.toFixed(1),
                  "km leg · ",
                  stop.distanceFromCenter.toFixed(1),
                  "km from center"
                ] }, void 0, true, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 614,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 607,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { children: stop.name }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 618,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: getPreview(stop.description) }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 619,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "explore-card__meta", children: [
                /* @__PURE__ */ jsxDEV("span", { children: formatBudget(stop.budget) }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 621,
                  columnNumber: 45
                }, this),
                stop.type === "event" && stop.eventTime && /* @__PURE__ */ jsxDEV("span", { children: formatEventTime(stop.eventTime) }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 622,
                  columnNumber: 89
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 620,
                columnNumber: 41
              }, this),
              visibleTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "explore-card__tags", children: [
                visibleTags.map(
                  (tag) => /* @__PURE__ */ jsxDEV("span", { children: [
                    "#",
                    tag.name
                  ] }, tag.id, true, {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                    lineNumber: 627,
                    columnNumber: 23
                  }, this)
                ),
                hiddenCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "explore-card__tag-more", children: [
                  "+",
                  hiddenCount,
                  " more"
                ] }, void 0, true, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 629,
                  columnNumber: 69
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 625,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "planner-stop__reasons", children: stop.reasons.map(
                (reason, reasonIndex) => /* @__PURE__ */ jsxDEV("span", { children: reason }, `${stop.type}-${stop.id}-${reasonIndex}`, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                  lineNumber: 634,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 632,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "planner-stop__actions", children: [
                stop.type === "event" && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "planner-action",
                    onClick: () => {
                      onOpenEventDetails(stop.id);
                      onClose();
                    },
                    children: "Open full event details"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                    lineNumber: 639,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "planner-action planner-action--secondary",
                    onClick: () => {
                      onCenterOnMap([stop.lat, stop.lng]);
                      onClose();
                    },
                    children: "Center on map"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                    lineNumber: 650,
                    columnNumber: 45
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
                lineNumber: 637,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
              lineNumber: 606,
              columnNumber: 37
            }, this)
          ] }, `${stop.type}-${stop.id}`, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
            lineNumber: 602,
            columnNumber: 17
          }, this);
        })
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
        lineNumber: 593,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
      lineNumber: 501,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
    lineNumber: 489,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx",
    lineNumber: 488,
    columnNumber: 5
  }, this);
}
_s(PlannerPanel, "Z8tYYA2sQPyJmAkAWMw+tFnAKIs=");
_c = PlannerPanel;
var _c;
$RefreshReg$(_c, "PlannerPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PlannerPanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd2R3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4ZHhCLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUVsQyxTQUFTQyxpQkFBaUJDLHNCQUFzQjtBQXNDaEQsTUFBTUMsa0JBQWtCO0FBQ3hCLE1BQU1DLGdCQUE0QztBQUFBLEVBQzlDQyxPQUFPO0FBQUEsRUFDUCxZQUFZO0FBQUEsRUFDWixZQUFZO0FBQ2hCO0FBRUEsU0FBU0MsVUFBVUMsT0FBZTtBQUM5QixTQUFPQSxRQUFRQyxLQUFLQyxLQUFLO0FBQzdCO0FBRUEsU0FBU0MsV0FBV0MsTUFBd0JDLElBQXNCO0FBQzlELFFBQU1DLE9BQU9QLFVBQVVNLEdBQUcsQ0FBQyxJQUFJRCxLQUFLLENBQUMsQ0FBQztBQUN0QyxRQUFNRyxPQUFPUixVQUFVTSxHQUFHLENBQUMsSUFBSUQsS0FBSyxDQUFDLENBQUM7QUFDdEMsUUFBTUksT0FBT1QsVUFBVUssS0FBSyxDQUFDLENBQUM7QUFDOUIsUUFBTUssT0FBT1YsVUFBVU0sR0FBRyxDQUFDLENBQUM7QUFDNUIsUUFBTUssSUFBSVQsS0FBS1UsSUFBSUwsT0FBTyxDQUFDLEtBQUssSUFDMUJMLEtBQUtXLElBQUlKLElBQUksSUFBSVAsS0FBS1csSUFBSUgsSUFBSSxJQUFJUixLQUFLVSxJQUFJSixPQUFPLENBQUMsS0FBSztBQUM5RCxTQUFPLElBQUlYLGtCQUFrQkssS0FBS1ksTUFBTVosS0FBS2EsS0FBS0osQ0FBQyxHQUFHVCxLQUFLYSxLQUFLLElBQUlKLENBQUMsQ0FBQztBQUMxRTtBQUVBLFNBQVNLLGFBQWFDLFFBQXVCO0FBQ3pDLFNBQU9BLFVBQVUsT0FBTyxtQkFBbUIsSUFBSUEsT0FBT0MsUUFBUSxDQUFDLENBQUM7QUFDcEU7QUFFQSxTQUFTQyxnQkFBZ0JDLEtBQWE7QUFDbEMsU0FBTyxJQUFJQyxLQUFLRCxHQUFHLEVBQUVFLGVBQWUsU0FBUztBQUFBLElBQ3pDQyxTQUFTO0FBQUEsSUFDVEMsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1osQ0FBQztBQUNMO0FBRUEsU0FBU0MsaUJBQWlCUixLQUFhO0FBQ25DLFNBQU8sSUFBSUMsS0FBS0QsR0FBRyxFQUFFUyxtQkFBbUIsU0FBUztBQUFBLElBQzdDSCxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1osQ0FBQztBQUNMO0FBRUEsU0FBU0csZ0JBQWdCQyxTQUFpQjtBQUN0QyxRQUFNLENBQUNDLE1BQU1QLE9BQU9ELEdBQUcsSUFBSU8sUUFBUUUsTUFBTSxHQUFHLEVBQUVDLElBQUlDLE1BQU07QUFDeEQsU0FBTyxJQUFJZCxLQUFLVyxNQUFNUCxRQUFRLEdBQUdELEdBQUcsRUFBRVksbUJBQW1CLFNBQVM7QUFBQSxJQUM5RGIsU0FBUztBQUFBLElBQ1RDLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsRUFDWCxDQUFDO0FBQ0w7QUFFQSxTQUFTWSxXQUFXQyxhQUE0QjtBQUM1QyxNQUFJLENBQUNBO0FBQWEsV0FBTztBQUN6QixTQUFPQSxZQUFZQyxTQUFTLE1BQU0sR0FBR0QsWUFBWUUsTUFBTSxHQUFHLEdBQUcsQ0FBQyxRQUFRRjtBQUMxRTtBQUVBLFNBQVNHLG9CQUFvQkMsTUFBb0M7QUFDN0QsU0FBT1AsT0FBT1EsU0FBU0QsS0FBS0UsR0FBRyxLQUFLVCxPQUFPUSxTQUFTRCxLQUFLRyxHQUFHO0FBQ2hFO0FBRUEsU0FBU0MsVUFDTEosTUFDQUssVUFDQUMsZ0JBQ0FDLFdBQ3NDO0FBQ3RDLFFBQU1DLFVBQVUsQ0FBQyxHQUFHUixLQUFLUyxtQkFBbUJqQyxRQUFRLENBQUMsQ0FBQyx3QkFBd0I7QUFDOUUsUUFBTWtDLGdCQUFnQmxELEtBQUttRCxJQUFJLEdBQUcsTUFBTSxJQUFJWCxLQUFLUyxxQkFBcUJKLFNBQVM7QUFFL0UsTUFBSU8sV0FBVztBQUNmLE1BQUlOLGVBQWVPLE9BQU8sR0FBRztBQUN6QixVQUFNQyxTQUFTLElBQUlDLElBQUlmLEtBQUtnQixLQUFLeEIsSUFBSSxDQUFDeUIsUUFBUUEsSUFBSUMsRUFBRSxDQUFDO0FBQ3JELFVBQU1DLGVBQWUsQ0FBQyxHQUFHYixjQUFjLEVBQUVjLE9BQU8sQ0FBQ0MsVUFBVVAsT0FBT1EsSUFBSUQsS0FBSyxDQUFDLEVBQUV4QjtBQUM5RWUsZUFBVyxNQUFNTyxlQUFlYixlQUFlTztBQUMvQ0wsWUFBUWUsS0FBSyxXQUFXSixZQUFZLGdCQUFnQkEsaUJBQWlCLElBQUksS0FBSyxHQUFHLEVBQUU7QUFBQSxFQUN2RixXQUFXbkIsS0FBS2dCLEtBQUtuQixTQUFTLEdBQUc7QUFDN0JXLFlBQVFlLEtBQUssZ0NBQWdDO0FBQUEsRUFDakQ7QUFFQSxNQUFJQyxjQUFjO0FBQ2xCLE1BQUlqQixjQUFjLE1BQU07QUFDcEIsUUFBSVAsS0FBS3pCLFdBQVcsTUFBTTtBQUN0QmlELG9CQUFjO0FBQ2RoQixjQUFRZSxLQUFLLG1CQUFtQjtBQUFBLElBQ3BDLFdBQVd2QixLQUFLekIsVUFBVWdDLFdBQVc7QUFDakNpQixvQkFBYztBQUNkaEIsY0FBUWUsS0FBSyx3QkFBd0I7QUFBQSxJQUN6QyxPQUFPO0FBQ0hmLGNBQVFlLEtBQUssc0JBQXNCO0FBQUEsSUFDdkM7QUFBQSxFQUNKO0FBRUEsTUFBSUUsWUFBWTtBQUNoQixNQUFJekIsS0FBSzBCLFNBQVMsV0FBVzFCLEtBQUsyQixXQUFXO0FBQ3pDLFVBQU1DLE9BQU8sSUFBSWpELEtBQUtxQixLQUFLMkIsU0FBUyxFQUFFRSxRQUFRO0FBQzlDLFFBQUlwQyxPQUFPUSxTQUFTMkIsSUFBSSxLQUFLQSxRQUFRakQsS0FBS21ELElBQUksR0FBRztBQUM3Q0wsa0JBQVk7QUFDWmpCLGNBQVFlLEtBQUssZ0JBQWdCO0FBQUEsSUFDakM7QUFBQSxFQUNKO0FBRUEsU0FBTztBQUFBLElBQ0hRLE9BQU92RSxLQUFLd0UsT0FBT3RCLGdCQUFnQkUsV0FBV1ksY0FBY0MsYUFBYSxHQUFHLElBQUk7QUFBQSxJQUNoRmpCO0FBQUFBLEVBQ0o7QUFDSjtBQUVBLFNBQVN5QixZQUFZakMsTUFBbUI7QUFDcEMsTUFBSUEsS0FBSzBCLFNBQVMsV0FBVyxDQUFDMUIsS0FBSzJCO0FBQVcsV0FBTztBQUNyRCxRQUFNQyxPQUFPLElBQUlqRCxLQUFLcUIsS0FBSzJCLFNBQVMsRUFBRUUsUUFBUTtBQUM5QyxTQUFPcEMsT0FBT1EsU0FBUzJCLElBQUksSUFBSUEsT0FBTztBQUMxQztBQUVBLFNBQVNNLGFBQWFsQyxNQUFtQjtBQUNyQyxNQUFJQSxLQUFLMEIsU0FBUyxXQUFXLENBQUMxQixLQUFLMkI7QUFBVyxXQUFPO0FBQ3JELFFBQU1RLE9BQU8sSUFBSXhELEtBQUtxQixLQUFLMkIsU0FBUztBQUNwQyxNQUFJLENBQUNsQyxPQUFPUSxTQUFTa0MsS0FBS04sUUFBUSxDQUFDO0FBQUcsV0FBTztBQUM3QyxRQUFNdkMsT0FBTzZDLEtBQUtDLFlBQVk7QUFDOUIsUUFBTXJELFFBQVFzRCxPQUFPRixLQUFLRyxTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUN6RCxRQUFNekQsTUFBTXVELE9BQU9GLEtBQUtLLFFBQVEsQ0FBQyxFQUFFRCxTQUFTLEdBQUcsR0FBRztBQUNsRCxTQUFPLEdBQUdqRCxJQUFJLElBQUlQLEtBQUssSUFBSUQsR0FBRztBQUNsQztBQUVBLFNBQVMyRCxpQkFBaUJ6QyxNQUFtQjBDLFFBQTZCO0FBQ3RFLFNBQU8xQyxLQUFLUSxRQUFRbUMsU0FBU0QsTUFBTSxJQUFJMUMsT0FBTyxFQUFFLEdBQUdBLE1BQU1RLFNBQVMsQ0FBQyxHQUFHUixLQUFLUSxTQUFTa0MsTUFBTSxFQUFFO0FBQ2hHO0FBRUEsU0FBU0Usc0JBQ0xDLFlBQ0FDLFdBQ0FDLGFBQ0F4QyxXQUNhO0FBQ2IsUUFBTXlDLFlBQVksQ0FBQyxHQUFHSCxVQUFVLEVBQUVJLEtBQUssQ0FBQ2hGLEdBQUdpRixNQUFNO0FBQzdDLFFBQUlBLEVBQUVuQixVQUFVOUQsRUFBRThEO0FBQU8sYUFBT21CLEVBQUVuQixRQUFROUQsRUFBRThEO0FBQzVDLFFBQUk5RCxFQUFFd0MsdUJBQXVCeUMsRUFBRXpDO0FBQW9CLGFBQU94QyxFQUFFd0MscUJBQXFCeUMsRUFBRXpDO0FBQ25GLFFBQUl4QyxFQUFFeUQsU0FBU3dCLEVBQUV4QjtBQUFNLGFBQU96RCxFQUFFeUQsS0FBS3lCLGNBQWNELEVBQUV4QixJQUFJO0FBQ3pELFdBQU96RCxFQUFFbUYsS0FBS0QsY0FBY0QsRUFBRUUsSUFBSTtBQUFBLEVBQ3RDLENBQUM7QUFDRCxRQUFNQyxXQUEwQjtBQUNoQyxNQUFJQyxrQkFBa0JSO0FBQ3RCLE1BQUlTLGNBQWM7QUFFbEIsU0FBT0YsU0FBU3hELFNBQVNrRCxlQUFlQyxVQUFVbkQsU0FBUyxHQUFHO0FBQzFELFVBQU0yRCxTQUFTUixVQUNWeEQsSUFBSSxDQUFDUSxTQUFTO0FBQ1gsWUFBTXlELGNBQWMvRixXQUFXNEYsaUJBQWlCLENBQUN0RCxLQUFLRSxLQUFLRixLQUFLRyxHQUFHLENBQUM7QUFDcEUsWUFBTXVELGtCQUFrQkgsZUFBZXZELEtBQUt6QixVQUFVO0FBQ3RELFlBQU1vRixnQkFBZ0JwRCxjQUFjLFFBQVFQLEtBQUt6QixXQUFXLFFBQVFtRixrQkFBa0JuRCxZQUFZLEtBQUs7QUFDdkcsWUFBTXFELFdBQVdwRyxLQUFLbUQsSUFBSSxHQUFHLE1BQU0sSUFBSThDLGNBQWNqRyxLQUFLbUQsSUFBSSxHQUFHWCxLQUFLUyxxQkFBcUJnRCxXQUFXLEVBQUU7QUFDeEcsYUFBTztBQUFBLFFBQ0h6RDtBQUFBQSxRQUNBeUQ7QUFBQUEsUUFDQUksWUFBWTdELEtBQUsrQixRQUFRNkIsV0FBV0Q7QUFBQUEsTUFDeEM7QUFBQSxJQUNKLENBQUMsRUFDQVYsS0FBSyxDQUFDaEYsR0FBR2lGLE1BQU07QUFDWixVQUFJQSxFQUFFVyxlQUFlNUYsRUFBRTRGO0FBQVksZUFBT1gsRUFBRVcsYUFBYTVGLEVBQUU0RjtBQUMzRCxVQUFJNUYsRUFBRXdGLGdCQUFnQlAsRUFBRU87QUFBYSxlQUFPeEYsRUFBRXdGLGNBQWNQLEVBQUVPO0FBQzlELFVBQUl4RixFQUFFK0IsS0FBSzBCLFNBQVN3QixFQUFFbEQsS0FBSzBCO0FBQU0sZUFBT3pELEVBQUUrQixLQUFLMEIsS0FBS3lCLGNBQWNELEVBQUVsRCxLQUFLMEIsSUFBSTtBQUM3RSxhQUFPekQsRUFBRStCLEtBQUtvRCxLQUFLRCxjQUFjRCxFQUFFbEQsS0FBS29ELElBQUk7QUFBQSxJQUNoRCxDQUFDO0FBRUwsVUFBTVUsT0FBT04sT0FBTyxDQUFDO0FBQ3JCLFFBQUksQ0FBQ00sUUFBUUEsS0FBS0QsYUFBYTtBQUFLO0FBRXBDUixhQUFTOUIsS0FBS3VDLEtBQUs5RCxJQUFJO0FBQ3ZCLFFBQUk4RCxLQUFLOUQsS0FBS3pCLFdBQVc7QUFBTWdGLHFCQUFlTyxLQUFLOUQsS0FBS3pCO0FBQ3hEK0Usc0JBQWtCLENBQUNRLEtBQUs5RCxLQUFLRSxLQUFLNEQsS0FBSzlELEtBQUtHLEdBQUc7QUFDL0M2QyxjQUFVZSxPQUFPZixVQUFVZ0IsVUFBVSxDQUFDaEUsU0FBU0EsS0FBSzBCLFNBQVNvQyxLQUFLOUQsS0FBSzBCLFFBQVExQixLQUFLa0IsT0FBTzRDLEtBQUs5RCxLQUFLa0IsRUFBRSxHQUFHLENBQUM7QUFBQSxFQUMvRztBQUVBLFNBQU9tQztBQUNYO0FBRUEsU0FBU1ksYUFBYUMsT0FBc0JDLE9BQXlCO0FBQ2pFLFFBQU1uQixZQUFZLENBQUMsR0FBR2tCLEtBQUs7QUFDM0IsUUFBTUUsVUFBeUI7QUFDL0IsTUFBSWQsa0JBQWtCYTtBQUV0QixTQUFPbkIsVUFBVW5ELFNBQVMsR0FBRztBQUN6Qm1ELGNBQVVDLEtBQUssQ0FBQ2hGLEdBQUdpRixNQUFNO0FBQ3JCLFlBQU1tQixZQUFZM0csV0FBVzRGLGlCQUFpQixDQUFDckYsRUFBRWlDLEtBQUtqQyxFQUFFa0MsR0FBRyxDQUFDO0FBQzVELFlBQU1tRSxZQUFZNUcsV0FBVzRGLGlCQUFpQixDQUFDSixFQUFFaEQsS0FBS2dELEVBQUUvQyxHQUFHLENBQUM7QUFDNUQsVUFBSWtFLGNBQWNDO0FBQVcsZUFBT0QsWUFBWUM7QUFDaEQsVUFBSXBCLEVBQUVuQixVQUFVOUQsRUFBRThEO0FBQU8sZUFBT21CLEVBQUVuQixRQUFROUQsRUFBRThEO0FBQzVDLGFBQU85RCxFQUFFbUYsS0FBS0QsY0FBY0QsRUFBRUUsSUFBSTtBQUFBLElBQ3RDLENBQUM7QUFDRCxVQUFNVSxPQUFPZCxVQUFVdUIsTUFBTTtBQUM3QixRQUFJLENBQUNUO0FBQU07QUFDWE0sWUFBUTdDLEtBQUt1QyxJQUFJO0FBQ2pCUixzQkFBa0IsQ0FBQ1EsS0FBSzVELEtBQUs0RCxLQUFLM0QsR0FBRztBQUFBLEVBQ3pDO0FBRUEsU0FBT2lFO0FBQ1g7QUFFQSxTQUFTSSxlQUFlTixPQUFzQnBCLFdBQTBDO0FBQ3BGLE1BQUlRLGtCQUFrQlI7QUFDdEIsU0FBT29CLE1BQU0xRSxJQUFJLENBQUNRLE1BQU15RSxVQUFVO0FBQzlCLFVBQU1oQixjQUFjL0YsV0FBVzRGLGlCQUFpQixDQUFDdEQsS0FBS0UsS0FBS0YsS0FBS0csR0FBRyxDQUFDO0FBQ3BFbUQsc0JBQWtCLENBQUN0RCxLQUFLRSxLQUFLRixLQUFLRyxHQUFHO0FBQ3JDLFdBQU87QUFBQSxNQUNILEdBQUdIO0FBQUFBLE1BQ0gwRSxZQUFZRCxRQUFRO0FBQUEsTUFDcEJoQjtBQUFBQSxJQUNKO0FBQUEsRUFDSixDQUFDO0FBQ0w7QUFFQSxTQUFTa0IscUJBQXFCdEIsVUFBeUJQLFdBQTBDO0FBQzdGLFFBQU04QixjQUFjdkIsU0FDZmpDLE9BQU8sQ0FBQ3BCLFNBQVNpQyxZQUFZakMsSUFBSSxNQUFNLElBQUksRUFDM0NpRCxLQUFLLENBQUNoRixHQUFHaUYsTUFBTTtBQUNaLFVBQU0yQixRQUFRNUMsWUFBWWhFLENBQUMsS0FBSztBQUNoQyxVQUFNNkcsUUFBUTdDLFlBQVlpQixDQUFDLEtBQUs7QUFDaEMsUUFBSTJCLFVBQVVDO0FBQU8sYUFBT0QsUUFBUUM7QUFDcEMsV0FBTzdHLEVBQUVtRixLQUFLRCxjQUFjRCxFQUFFRSxJQUFJO0FBQUEsRUFDdEMsQ0FBQyxFQUNBNUQsSUFBSSxDQUFDUSxTQUFTeUMsaUJBQWlCekMsTUFBTSxnQkFBZ0JkLGlCQUFpQmMsS0FBSzJCLGFBQWEsRUFBRSxDQUFDLEVBQUUsQ0FBQztBQUNuRyxRQUFNb0QsZUFBZTFCLFNBQVNqQyxPQUFPLENBQUNwQixTQUFTaUMsWUFBWWpDLElBQUksTUFBTSxJQUFJO0FBRXpFLE1BQUk0RSxZQUFZL0UsV0FBVyxHQUFHO0FBQzFCLFdBQU8yRSxlQUFlUCxhQUFhYyxjQUFjakMsU0FBUyxHQUFHQSxTQUFTO0FBQUEsRUFDMUU7QUFFQSxRQUFNa0MsUUFBeUJDLE1BQU10SCxLQUFLLEVBQUVrQyxRQUFRK0UsWUFBWS9FLFNBQVMsRUFBRSxHQUFHLE1BQU0sRUFBRTtBQUV0RmtGLGVBQWFHLFFBQVEsQ0FBQ2xGLFNBQVM7QUFDM0IsVUFBTW1GLFlBQVlILE1BQU14RixJQUFJLENBQUM0RixHQUFHQyxjQUFjO0FBQzFDLFVBQUlBLGNBQWMsR0FBRztBQUNqQixlQUFPM0gsV0FBV29GLFdBQVcsQ0FBQzlDLEtBQUtFLEtBQUtGLEtBQUtHLEdBQUcsQ0FBQyxJQUFJekMsV0FBVyxDQUFDc0MsS0FBS0UsS0FBS0YsS0FBS0csR0FBRyxHQUFHLENBQUN5RSxZQUFZLENBQUMsRUFBRTFFLEtBQUswRSxZQUFZLENBQUMsRUFBRXpFLEdBQUcsQ0FBQztBQUFBLE1BQ2xJO0FBRUEsWUFBTW1GLGdCQUFnQlYsWUFBWVMsWUFBWSxDQUFDO0FBQy9DLFlBQU1FLGdCQUFrQyxDQUFDRCxjQUFjcEYsS0FBS29GLGNBQWNuRixHQUFHO0FBRTdFLFVBQUlrRixjQUFjVCxZQUFZL0UsUUFBUTtBQUNsQyxlQUFPbkMsV0FBVzZILGVBQWUsQ0FBQ3ZGLEtBQUtFLEtBQUtGLEtBQUtHLEdBQUcsQ0FBQztBQUFBLE1BQ3pEO0FBRUEsWUFBTXFGLFlBQVlaLFlBQVlTLFNBQVM7QUFDdkMsWUFBTUksWUFBOEIsQ0FBQ0QsVUFBVXRGLEtBQUtzRixVQUFVckYsR0FBRztBQUNqRSxZQUFNdUYsaUJBQWlCaEksV0FBVzZILGVBQWVFLFNBQVM7QUFDMUQsYUFBTy9ILFdBQVc2SCxlQUFlLENBQUN2RixLQUFLRSxLQUFLRixLQUFLRyxHQUFHLENBQUMsSUFBSXpDLFdBQVcsQ0FBQ3NDLEtBQUtFLEtBQUtGLEtBQUtHLEdBQUcsR0FBR3NGLFNBQVMsSUFBSUM7QUFBQUEsSUFDM0csQ0FBQztBQUNELFVBQU1DLGdCQUFnQlIsVUFBVVMsT0FBTyxDQUFDQyxXQUFXQyxNQUFNckIsVUFBVXFCLE9BQU9YLFVBQVVVLFNBQVMsSUFBSXBCLFFBQVFvQixXQUFXLENBQUM7QUFDckgsVUFBTUUsa0JBQWtCSixrQkFBa0IsSUFDcEMsdUNBQ0FBLGtCQUFrQmYsWUFBWS9FLFNBQzFCLDZCQUNBO0FBQ1ZtRixVQUFNVyxhQUFhLEVBQUVwRSxLQUFLa0IsaUJBQWlCekMsTUFBTStGLGVBQWUsQ0FBQztBQUFBLEVBQ3JFLENBQUM7QUFFRCxRQUFNM0IsVUFBeUI7QUFDL0IsTUFBSTRCLFNBQVNsRDtBQUNic0IsVUFBUTdDLEtBQUssR0FBRzBDLGFBQWFlLE1BQU0sQ0FBQyxHQUFHZ0IsTUFBTSxDQUFDO0FBQzlDLE1BQUk1QixRQUFRdkUsU0FBUyxHQUFHO0FBQ3BCLFVBQU1vRyxPQUFPN0IsUUFBUUEsUUFBUXZFLFNBQVMsQ0FBQztBQUN2Q21HLGFBQVMsQ0FBQ0MsS0FBSy9GLEtBQUsrRixLQUFLOUYsR0FBRztBQUFBLEVBQ2hDO0FBRUF5RSxjQUFZTSxRQUFRLENBQUNnQixPQUFPekIsVUFBVTtBQUNsQ0wsWUFBUTdDLEtBQUsyRSxLQUFLO0FBQ2xCRixhQUFTLENBQUNFLE1BQU1oRyxLQUFLZ0csTUFBTS9GLEdBQUc7QUFDOUIsVUFBTWdHLFlBQVlsQyxhQUFhZSxNQUFNUCxRQUFRLENBQUMsR0FBR3VCLE1BQU07QUFDdkQ1QixZQUFRN0MsS0FBSyxHQUFHNEUsU0FBUztBQUN6QixRQUFJQSxVQUFVdEcsU0FBUyxHQUFHO0FBQ3RCLFlBQU1vRyxPQUFPRSxVQUFVQSxVQUFVdEcsU0FBUyxDQUFDO0FBQzNDbUcsZUFBUyxDQUFDQyxLQUFLL0YsS0FBSytGLEtBQUs5RixHQUFHO0FBQUEsSUFDaEM7QUFBQSxFQUNKLENBQUM7QUFFRCxTQUFPcUUsZUFBZUosU0FBU3RCLFNBQVM7QUFDNUM7QUFFQSxTQUFTc0QsV0FDTHZELFlBQ0FDLFdBQ0FDLGFBQ0F4QyxXQUNXO0FBQ1gsU0FBT29FO0FBQUFBLElBQ0gvQixzQkFBc0JDLFlBQVlDLFdBQVdDLGFBQWF4QyxTQUFTO0FBQUEsSUFDbkV1QztBQUFBQSxFQUNKO0FBQ0o7QUFFQSxTQUFTdUQsb0JBQW9CeEQsWUFBMkI7QUFDcEQsUUFBTXlELFNBQVMsb0JBQUlDLElBQTJCO0FBQzlDMUQsYUFBV3FDLFFBQVEsQ0FBQ2xGLFNBQVM7QUFDekIsVUFBTVgsVUFBVTZDLGFBQWFsQyxJQUFJO0FBQ2pDLFFBQUksQ0FBQ1g7QUFBUztBQUNkaUgsV0FBT0UsSUFBSW5ILFNBQVMsQ0FBQyxHQUFJaUgsT0FBT0csSUFBSXBILE9BQU8sS0FBSyxJQUFLVyxJQUFJLENBQUM7QUFBQSxFQUM5RCxDQUFDO0FBRUQsU0FBTyxDQUFDLEdBQUdzRyxPQUFPSSxRQUFRLENBQUMsRUFDdEJsSCxJQUFJLENBQUMsQ0FBQ0gsU0FBUzZFLEtBQUssT0FBTztBQUFBLElBQ3hCN0U7QUFBQUEsSUFDQTZFO0FBQUFBLElBQ0F5QyxZQUFZekMsTUFBTTBCLE9BQU8sQ0FBQ2dCLEtBQUs1RyxTQUFTNEcsTUFBTTVHLEtBQUsrQixPQUFPLENBQUM7QUFBQSxFQUMvRCxFQUFFLEVBQ0RrQixLQUFLLENBQUNoRixHQUFHaUYsTUFBTTtBQUNaLFFBQUlBLEVBQUV5RCxlQUFlMUksRUFBRTBJO0FBQVksYUFBT3pELEVBQUV5RCxhQUFhMUksRUFBRTBJO0FBQzNELFFBQUl6RCxFQUFFZ0IsTUFBTXJFLFdBQVc1QixFQUFFaUcsTUFBTXJFO0FBQVEsYUFBT3FELEVBQUVnQixNQUFNckUsU0FBUzVCLEVBQUVpRyxNQUFNckU7QUFDdkUsV0FBTzVCLEVBQUVvQixRQUFROEQsY0FBY0QsRUFBRTdELE9BQU87QUFBQSxFQUM1QyxDQUFDLEVBQUUsQ0FBQyxLQUFLO0FBQ2pCO0FBRUEsd0JBQXdCd0gsYUFBYTtBQUFBLEVBQ2pDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBakU7QUFBQUEsRUFDQTlCO0FBQUFBLEVBQ0FnRztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNlLEdBQUc7QUFBQUMsS0FBQTtBQUNsQixRQUFNLENBQUNoSCxVQUFVaUgsV0FBVyxJQUFJdEssU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ3VELFdBQVdnSCxZQUFZLElBQUl2SyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDd0ssU0FBU0MsVUFBVSxJQUFJekssU0FBc0IsTUFBTTtBQUMxRCxRQUFNLENBQUMwSyxZQUFZQyxhQUFhLElBQUkzSyxTQUFxQixPQUFPO0FBQ2hFLFFBQU0sQ0FBQ3NELGdCQUFnQnNILGlCQUFpQixJQUFJNUssU0FBc0Isb0JBQUkrRCxJQUFJLENBQUM7QUFDM0UsUUFBTSxDQUFDOEcsYUFBYUMsY0FBYyxJQUFJOUssU0FBUyxFQUFFO0FBRWpELFFBQU0rSyxlQUFldEksT0FBT1ksUUFBUTtBQUNwQyxRQUFNMkgsYUFBYXZJLE9BQU9RLFNBQVM4SCxZQUFZLEtBQUtBLGVBQWUsSUFBSUEsZUFBZTtBQUN0RixRQUFNRSxlQUFlMUgsVUFBVTJILEtBQUssTUFBTSxLQUFLLE9BQU96SSxPQUFPYyxTQUFTO0FBQ3RFLFFBQU00SCxnQkFBZ0JGLGlCQUFpQixRQUFReEksT0FBT1EsU0FBU2dJLFlBQVksS0FBS0EsZ0JBQWdCLElBQUlBLGVBQWU7QUFFbkgsUUFBTUcsY0FBY3JMLFFBQVEsTUFBTTtBQUM5QixVQUFNc0wsZUFBZS9IO0FBQ3JCLFVBQU1nSSxhQUE0QjtBQUFBLE1BQzlCLEdBQUlkLFlBQVksVUFBVSxLQUFLVixPQUFPMUYsT0FBT3JCLG1CQUFtQixFQUFFUCxJQUFJLENBQUMwRyxVQUFVO0FBQzdFLGNBQU1xQyxPQUFPO0FBQUEsVUFDVDdHLE1BQU07QUFBQSxVQUNOUixJQUFJZ0YsTUFBTWhGO0FBQUFBLFVBQ1ZrQyxNQUFNOEMsTUFBTTlDO0FBQUFBLFVBQ1p4RCxhQUFhc0csTUFBTXRHO0FBQUFBLFVBQ25CTSxLQUFLZ0csTUFBTWhHO0FBQUFBLFVBQ1hDLEtBQUsrRixNQUFNL0Y7QUFBQUEsVUFDWDVCLFFBQVEySCxNQUFNM0g7QUFBQUEsVUFDZHlDLE1BQU1rRixNQUFNbEYsUUFBUTtBQUFBLFVBQ3BCVyxXQUFXdUUsTUFBTXNDO0FBQUFBLFVBQ2pCL0gsb0JBQW9CL0MsV0FBV29GLFdBQVcsQ0FBQ29ELE1BQU1oRyxLQUFLZ0csTUFBTS9GLEdBQUcsQ0FBQztBQUFBLFFBQ3BFO0FBQ0EsZUFBTyxFQUFFLEdBQUdvSSxNQUFNLEdBQUduSSxVQUFVbUksTUFBTVAsWUFBWUssY0FBY0YsYUFBYSxFQUFFO0FBQUEsTUFDbEYsQ0FBQztBQUFBLE1BQ0QsR0FBSVgsWUFBWSxXQUFXLEtBQUtULE1BQU0zRixPQUFPckIsbUJBQW1CLEVBQUVQLElBQUksQ0FBQ2lKLFNBQVM7QUFDNUUsY0FBTUYsT0FBTztBQUFBLFVBQ1Q3RyxNQUFNO0FBQUEsVUFDTlIsSUFBSXVILEtBQUt2SDtBQUFBQSxVQUNUa0MsTUFBTXFGLEtBQUtyRjtBQUFBQSxVQUNYeEQsYUFBYTZJLEtBQUs3STtBQUFBQSxVQUNsQk0sS0FBS3VJLEtBQUt2STtBQUFBQSxVQUNWQyxLQUFLc0ksS0FBS3RJO0FBQUFBLFVBQ1Y1QixRQUFRa0ssS0FBS2xLO0FBQUFBLFVBQ2J5QyxNQUFNeUgsS0FBS3pILFFBQVE7QUFBQSxVQUNuQlAsb0JBQW9CL0MsV0FBV29GLFdBQVcsQ0FBQzJGLEtBQUt2SSxLQUFLdUksS0FBS3RJLEdBQUcsQ0FBQztBQUFBLFFBQ2xFO0FBQ0EsZUFBTyxFQUFFLEdBQUdvSSxNQUFNLEdBQUduSSxVQUFVbUksTUFBTVAsWUFBWUssY0FBY0YsYUFBYSxFQUFFO0FBQUEsTUFDbEYsQ0FBQztBQUFBLElBQUU7QUFHUCxVQUFNdEYsYUFBYXlGLFdBQ2RsSCxPQUFPLENBQUNwQixTQUFTQSxLQUFLUyxzQkFBc0J1SCxVQUFVLEVBQ3RENUcsT0FBTyxDQUFDcEIsU0FBUztBQUNkLFVBQUlxSSxhQUFheEgsU0FBUztBQUFHLGVBQU87QUFDcEMsWUFBTTZILGFBQWEsSUFBSTNILElBQUlmLEtBQUtnQixLQUFLeEIsSUFBSSxDQUFDeUIsUUFBUUEsSUFBSUMsRUFBRSxDQUFDO0FBQ3pELGFBQU8sQ0FBQyxHQUFHbUgsWUFBWSxFQUFFTSxNQUFNLENBQUN0SCxVQUFVcUgsV0FBV3BILElBQUlELEtBQUssQ0FBQztBQUFBLElBQ25FLENBQUM7QUFFTCxVQUFNdUgsZ0JBQWdCcEIsWUFBWSxVQUFVLE9BQU9uQixvQkFBb0J4RCxVQUFVO0FBQ2pGLFVBQU1nRyxvQkFBb0JELGdCQUNwQi9GLFdBQVd6QixPQUFPLENBQUNwQixTQUFTQSxLQUFLMEIsU0FBUyxVQUFVUSxhQUFhbEMsSUFBSSxNQUFNNEksY0FBY3ZKLE9BQU8sSUFDaEd3RDtBQUVOLFdBQU87QUFBQSxNQUNIaUcsT0FBTzFDLFdBQVd5QyxtQkFBbUIvRixXQUFXMUYsY0FBY3NLLFVBQVUsR0FBR1MsYUFBYTtBQUFBLE1BQ3hGWSxnQkFBZ0JILGdCQUFnQnhKLGdCQUFnQndKLGNBQWN2SixPQUFPLElBQUk7QUFBQSxJQUM3RTtBQUFBLEVBQ0osR0FBRyxDQUFDeUgsUUFBUWhFLFdBQVc0RSxZQUFZWCxPQUFPb0IsZUFBZUgsWUFBWTFILGdCQUFnQmtILE9BQU8sQ0FBQztBQUU3RixRQUFNLEVBQUVzQixPQUFPQyxlQUFlLElBQUlYO0FBQ2xDLFFBQU03RSxjQUFjdUYsTUFBTWxELE9BQU8sQ0FBQ29ELE9BQU9DLFNBQVNELFNBQVNDLEtBQUsxSyxVQUFVLElBQUksQ0FBQztBQUMvRSxRQUFNMkssbUJBQW1CSixNQUFNSyxLQUFLLENBQUNGLFNBQVNBLEtBQUsxSyxXQUFXLElBQUk7QUFDbEUsUUFBTTZLLGdCQUFnQk4sTUFBTWxELE9BQU8sQ0FBQ29ELE9BQU9DLFNBQVNELFFBQVFDLEtBQUt4RixhQUFhLENBQUM7QUFFL0UsUUFBTTRGLFlBQVlBLENBQUNoSSxVQUFrQjtBQUNqQ3VHLHNCQUFrQixDQUFDMEIsYUFBYTtBQUM1QixZQUFNeEYsT0FBTyxJQUFJL0MsSUFBSXVJLFFBQVE7QUFDN0J4RixXQUFLeEMsSUFBSUQsS0FBSyxJQUFJeUMsS0FBS3lGLE9BQU9sSSxLQUFLLElBQUl5QyxLQUFLMEYsSUFBSW5JLEtBQUs7QUFDckQsYUFBT3lDO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNMkYsa0JBQWtCQSxNQUFNO0FBQzFCLFFBQUlYLE1BQU1qSixXQUFXO0FBQUc7QUFDeEIsVUFBTTZKLFNBQVN0QyxZQUFZO0FBQUEsTUFDdkJ1QyxPQUFPWixpQkFBaUIscUJBQXFCQSxjQUFjLEtBQUs7QUFBQSxNQUNoRWpHO0FBQUFBLE1BQ0E4RyxTQUFTO0FBQUEsUUFDTEMsT0FBT2YsTUFBTWpKO0FBQUFBLFFBQ2IwRDtBQUFBQSxRQUNBMkY7QUFBQUEsUUFDQUU7QUFBQUEsTUFDSjtBQUFBLE1BQ0FTLE9BQU9mLE1BQU10SixJQUFJLENBQUN5SixVQUFVO0FBQUEsUUFDeEJ2SCxNQUFNdUgsS0FBS3ZIO0FBQUFBLFFBQ1hSLElBQUkrSCxLQUFLL0g7QUFBQUEsUUFDVGtDLE1BQU02RixLQUFLN0Y7QUFBQUEsUUFDWHhELGFBQWFxSixLQUFLcko7QUFBQUEsUUFDbEJNLEtBQUsrSSxLQUFLL0k7QUFBQUEsUUFDVkMsS0FBSzhJLEtBQUs5STtBQUFBQSxRQUNWNUIsUUFBUTBLLEtBQUsxSztBQUFBQSxRQUNieUMsTUFBTWlJLEtBQUtqSTtBQUFBQSxRQUNYVyxXQUFXc0gsS0FBS3RIO0FBQUFBLFFBQ2hCbkIsU0FBU3lJLEtBQUt6STtBQUFBQSxRQUNka0UsWUFBWXVFLEtBQUt2RTtBQUFBQSxNQUNyQixFQUFFO0FBQUEsSUFDTixDQUFDO0FBQ0RvRCxtQkFBZTRCLE9BQU9JLE9BQU87QUFBQSxFQUNqQztBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLG9CQUFtQixTQUFTOUMsU0FDdkMsaUNBQUMsYUFBUSxXQUFVLGlCQUFnQixjQUFXLGlCQUFnQixTQUFTLENBQUNkLFVBQVVBLE1BQU02RCxnQkFBZ0IsR0FDcEc7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUJBQ1g7QUFBQSw2QkFBQyxTQUNHO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDBCQUF5Qiw4QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLFFBQUcsb0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQ3hCLHVCQUFDLE9BQUUscUVBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFdBSDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSx3QkFBdUIsU0FBUy9DLFNBQVMsY0FBVyxpQkFBZ0IsaUJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUNaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLEtBQUk7QUFBQSxnQkFDSixLQUFJO0FBQUEsZ0JBQ0osT0FBTzNHO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQzZGLFVBQVVvQixZQUFZcEIsTUFBTThELE9BQU96TSxLQUFLO0FBQUE7QUFBQSxjQUx2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLeUQ7QUFBQSxlQVA3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUNaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLEtBQUk7QUFBQSxnQkFDSixNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU9nRDtBQUFBQSxnQkFDUCxVQUFVLENBQUMyRixVQUFVcUIsYUFBYXJCLE1BQU04RCxPQUFPek0sS0FBSztBQUFBO0FBQUEsY0FOeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTTBEO0FBQUEsZUFSOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsVUFBSyxtQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFTO0FBQUEsWUFDVCx1QkFBQyxZQUFPLE9BQU9pSyxTQUFTLFVBQVUsQ0FBQ3RCLFVBQVV1QixXQUFXdkIsTUFBTThELE9BQU96TSxLQUFvQixHQUNyRjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQ3pCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGNBQ2xDLHVCQUFDLFlBQU8sT0FBTSxTQUFRLDBCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUhwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUNaLHVCQUFDLFlBQU8sT0FBT21LLFlBQVksVUFBVSxDQUFDeEIsVUFBVXlCLGNBQWN6QixNQUFNOEQsT0FBT3pNLEtBQW1CLEdBQzFGO0FBQUEscUNBQUMsWUFBTyxPQUFNLFNBQVEseUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FDL0IsdUJBQUMsWUFBTyxPQUFNLFlBQVcsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FDckMsdUJBQUMsWUFBTyxPQUFNLFlBQVcsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsaUJBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0NBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsY0FBVyx1QkFDckM7QUFBQSxpQ0FBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQSxVQUNWLHVCQUFDLFNBQUksV0FBVSxzQkFDVnlEO0FBQUFBLGlCQUFLbkIsV0FBVyxLQUFLLHVCQUFDLFFBQUcsa0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUMzQ21CLEtBQUt4QjtBQUFBQSxjQUFJLENBQUN5QixRQUNQO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVHLE1BQUs7QUFBQSxrQkFDTCxXQUFXWCxlQUFlZ0IsSUFBSUwsSUFBSUMsRUFBRSxJQUFJLG9DQUFvQztBQUFBLGtCQUM1RSxTQUFTLE1BQU1tSSxVQUFVcEksSUFBSUMsRUFBRTtBQUFBLGtCQUFFO0FBQUE7QUFBQSxvQkFFL0JELElBQUltQztBQUFBQTtBQUFBQTtBQUFBQSxnQkFMRG5DLElBQUlDO0FBQUFBLGdCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLFlBQ0g7QUFBQSxlQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBeERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5REE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLGlDQUFDLFNBQ0c7QUFBQSxtQ0FBQyxZQUFRNEgsZ0JBQU1qSixVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUEsWUFDdEIsdUJBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsZUFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsWUFBTztBQUFBO0FBQUEsY0FBRTBELFlBQVkvRSxRQUFRLENBQUM7QUFBQSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxVQUFNMEssNkJBQW1CLCtCQUErQixrQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxlQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsWUFBUUU7QUFBQUEsNEJBQWM1SyxRQUFRLENBQUM7QUFBQSxjQUFFO0FBQUEsaUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsWUFDcEMsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQjtBQUFBLGVBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG9CQUNWdUs7QUFBQUEsNEJBQWtCLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQWNBO0FBQUFBLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQUEsVUFDckRELE1BQU1qSixTQUFTLEtBQ1o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFNBQVM0SjtBQUFBQSxjQUNULFVBQVUsQ0FBQ3RDO0FBQUFBLGNBRVZBLHVCQUFhLGVBQWU7QUFBQTtBQUFBLFlBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFFSFUsZUFBZSx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCQSx5QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxhQVo3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1ZpQjtBQUFBQSxjQUFNakosV0FBVyxLQUNkLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IseUdBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUhpSixNQUFNdEosSUFBSSxDQUFDeUosU0FBUztBQUNqQixnQkFBTSxFQUFFZ0IsYUFBYUMsWUFBWSxJQUFJaE4sZUFBZStMLEtBQUtqSSxJQUFJO0FBQzdELGlCQUNJLHVCQUFDLGFBQXdDLFdBQVUsZ0JBQy9DO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNCQUNYLGlDQUFDLFNBQUksV0FBVSx3QkFBd0JpSSxlQUFLdkUsY0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEscUNBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsdUNBQUMsVUFBSyxXQUFXLDRDQUE0Q3VFLEtBQUt2SCxJQUFJLElBQ2xFO0FBQUEseUNBQUMsVUFBSyxXQUFVLHNCQUFxQixlQUFZLFFBQzVDekUsMEJBQWdCZ00sS0FBS2pJLE1BQU1pSSxLQUFLdkgsSUFBSSxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0N1SCxLQUFLdkgsU0FBUyxVQUFVLFVBQVU7QUFBQSxxQkFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSwwQkFDWHVIO0FBQUFBLHVCQUFLeEYsWUFBWWpGLFFBQVEsQ0FBQztBQUFBLGtCQUFFO0FBQUEsa0JBQVV5SyxLQUFLeEksbUJBQW1CakMsUUFBUSxDQUFDO0FBQUEsa0JBQUU7QUFBQSxxQkFEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLFFBQUl5SyxlQUFLN0YsUUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsY0FDZix1QkFBQyxPQUFHekQscUJBQVdzSixLQUFLckosV0FBVyxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQ2pDLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLHVDQUFDLFVBQU10Qix1QkFBYTJLLEtBQUsxSyxNQUFNLEtBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2hDMEssS0FBS3ZILFNBQVMsV0FBV3VILEtBQUt0SCxhQUFhLHVCQUFDLFVBQU1sRCwwQkFBZ0J3SyxLQUFLdEgsU0FBUyxLQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLG1CQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQ3NJLFlBQVlwSyxTQUFTLEtBQ2xCLHVCQUFDLFNBQUksV0FBVSxzQkFDVm9LO0FBQUFBLDRCQUFZeks7QUFBQUEsa0JBQUksQ0FBQ3lCLFFBQ2QsdUJBQUMsVUFBa0I7QUFBQTtBQUFBLG9CQUFFQSxJQUFJbUM7QUFBQUEsdUJBQWRuQyxJQUFJQyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsZ0JBQ2pDO0FBQUEsZ0JBQ0FnSixjQUFjLEtBQUssdUJBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsa0JBQUVBO0FBQUFBLGtCQUFZO0FBQUEscUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTREO0FBQUEsbUJBSnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUVKLHVCQUFDLFNBQUksV0FBVSx5QkFDVmpCLGVBQUt6SSxRQUFRaEI7QUFBQUEsZ0JBQUksQ0FBQ2tELFFBQVF5SCxnQkFDdkIsdUJBQUMsVUFBcUR6SCxvQkFBM0MsR0FBR3VHLEtBQUt2SCxJQUFJLElBQUl1SCxLQUFLL0gsRUFBRSxJQUFJaUosV0FBVyxJQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RDtBQUFBLGNBQ2hFLEtBSEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNWbEI7QUFBQUEscUJBQUt2SCxTQUFTLFdBQ1g7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU07QUFDWHVGLHlDQUFtQmdDLEtBQUsvSCxFQUFFO0FBQzFCOEYsOEJBQVE7QUFBQSxvQkFDWjtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxnQkFFSjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLFNBQVMsTUFBTTtBQUNYRSxvQ0FBYyxDQUFDK0IsS0FBSy9JLEtBQUsrSSxLQUFLOUksR0FBRyxDQUFDO0FBQ2xDNkcsOEJBQVE7QUFBQSxvQkFDWjtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkF0REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1REE7QUFBQSxlQTNEVSxHQUFHaUMsS0FBS3ZILElBQUksSUFBSXVILEtBQUsvSCxFQUFFLElBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNERBO0FBQUEsUUFFUixDQUFDO0FBQUEsV0F2RUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdFQTtBQUFBLFNBcEtKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxS0E7QUFBQSxPQWpMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0xBLEtBbkxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvTEE7QUFFUjtBQUFDbUcsR0E1U3VCUixjQUFZO0FBQUEsS0FBWkE7QUFBWSxJQUFBdUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiZ2V0Q2F0ZWdvcnlJY29uIiwiZ2V0VmlzaWJsZVRhZ3MiLCJFQVJUSF9SQURJVVNfS00iLCJsZW5ndGhUb1N0b3BzIiwicXVpY2siLCJ0b1JhZGlhbnMiLCJ2YWx1ZSIsIk1hdGgiLCJQSSIsImRpc3RhbmNlS20iLCJmcm9tIiwidG8iLCJkTGF0IiwiZExuZyIsImxhdDEiLCJsYXQyIiwiYSIsInNpbiIsImNvcyIsImF0YW4yIiwic3FydCIsImZvcm1hdEJ1ZGdldCIsImJ1ZGdldCIsInRvRml4ZWQiLCJmb3JtYXRFdmVudFRpbWUiLCJpc28iLCJEYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJ3ZWVrZGF5IiwiZGF5IiwibW9udGgiLCJob3VyIiwibWludXRlIiwiZm9ybWF0RXZlbnRDbG9jayIsInRvTG9jYWxlVGltZVN0cmluZyIsImZvcm1hdFJvdXRlRGF0ZSIsImRhdGVLZXkiLCJ5ZWFyIiwic3BsaXQiLCJtYXAiLCJOdW1iZXIiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJnZXRQcmV2aWV3IiwiZGVzY3JpcHRpb24iLCJsZW5ndGgiLCJzbGljZSIsImhhc1ZhbGlkQ29vcmRpbmF0ZXMiLCJpdGVtIiwiaXNGaW5pdGUiLCJsYXQiLCJsbmciLCJzY29yZUl0ZW0iLCJyYWRpdXNLbSIsInNlbGVjdGVkVGFnSWRzIiwiYnVkZ2V0TWF4IiwicmVhc29ucyIsImRpc3RhbmNlRnJvbUNlbnRlciIsImRpc3RhbmNlU2NvcmUiLCJtYXgiLCJ0YWdTY29yZSIsInNpemUiLCJ0YWdJZHMiLCJTZXQiLCJ0YWdzIiwidGFnIiwiaWQiLCJtYXRjaGVkQ291bnQiLCJmaWx0ZXIiLCJ0YWdJZCIsImhhcyIsInB1c2giLCJidWRnZXRTY29yZSIsInRpbWVTY29yZSIsInR5cGUiLCJldmVudFRpbWUiLCJ0aW1lIiwiZ2V0VGltZSIsIm5vdyIsInNjb3JlIiwicm91bmQiLCJldmVudFRpbWVNcyIsImV2ZW50RGF0ZUtleSIsImRhdGUiLCJnZXRGdWxsWWVhciIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJnZXREYXRlIiwid2l0aFVuaXF1ZVJlYXNvbiIsInJlYXNvbiIsImluY2x1ZGVzIiwic2VsZWN0Um91dGVDYW5kaWRhdGVzIiwiY2FuZGlkYXRlcyIsIm1hcENlbnRlciIsInRhcmdldFN0b3BzIiwicmVtYWluaW5nIiwic29ydCIsImIiLCJsb2NhbGVDb21wYXJlIiwibmFtZSIsInNlbGVjdGVkIiwiY3VycmVudFBvc2l0aW9uIiwia25vd25CdWRnZXQiLCJyYW5rZWQiLCJsZWdEaXN0YW5jZSIsIm5leHRLbm93bkJ1ZGdldCIsImJ1ZGdldFBlbmFsdHkiLCJsZWdTY29yZSIsInJvdXRlU2NvcmUiLCJuZXh0Iiwic3BsaWNlIiwiZmluZEluZGV4IiwibmVhcmVzdEZpcnN0IiwiaXRlbXMiLCJzdGFydCIsIm9yZGVyZWQiLCJhRGlzdGFuY2UiLCJiRGlzdGFuY2UiLCJzaGlmdCIsImFkZFN0b3BOdW1iZXJzIiwiaW5kZXgiLCJzdG9wTnVtYmVyIiwib3JkZXJSb3V0ZUNhbmRpZGF0ZXMiLCJ0aW1lZEV2ZW50cyIsImFUaW1lIiwiYlRpbWUiLCJ1bnRpbWVkSXRlbXMiLCJzbG90cyIsIkFycmF5IiwiZm9yRWFjaCIsInNsb3RDb3N0cyIsIl8iLCJzbG90SW5kZXgiLCJwcmV2aW91c1RpbWVkIiwicHJldmlvdXNQb2ludCIsIm5leHRUaW1lZCIsIm5leHRQb2ludCIsImRpcmVjdERpc3RhbmNlIiwiYmVzdFNsb3RJbmRleCIsInJlZHVjZSIsImJlc3RJbmRleCIsImNvc3QiLCJwbGFjZW1lbnRSZWFzb24iLCJhbmNob3IiLCJsYXN0IiwiZXZlbnQiLCJzbG90SXRlbXMiLCJidWlsZFJvdXRlIiwiY2hvb3NlQmVzdEV2ZW50RGF0ZSIsImdyb3VwcyIsIk1hcCIsInNldCIsImdldCIsImVudHJpZXMiLCJ0b3RhbFNjb3JlIiwic3VtIiwiUGxhbm5lclBhbmVsIiwiZXZlbnRzIiwicGxhbnMiLCJvbkNsb3NlIiwib25PcGVuRXZlbnREZXRhaWxzIiwib25DZW50ZXJPbk1hcCIsImlzTG9nZ2VkSW4iLCJvblNhdmVSb3V0ZSIsIl9zIiwic2V0UmFkaXVzS20iLCJzZXRCdWRnZXRNYXgiLCJ0eXBlTWl4Iiwic2V0VHlwZU1peCIsInBsYW5MZW5ndGgiLCJzZXRQbGFuTGVuZ3RoIiwic2V0U2VsZWN0ZWRUYWdJZHMiLCJzYXZlTWVzc2FnZSIsInNldFNhdmVNZXNzYWdlIiwicGFyc2VkUmFkaXVzIiwic2FmZVJhZGl1cyIsInBhcnNlZEJ1ZGdldCIsInRyaW0iLCJzYWZlQnVkZ2V0TWF4Iiwicm91dGVSZXN1bHQiLCJzZWxlY3RlZFRhZ3MiLCJub3JtYWxpemVkIiwiYmFzZSIsImV2ZW50X3RpbWUiLCJwbGFuIiwiaXRlbVRhZ0lkcyIsImV2ZXJ5IiwiYmVzdEV2ZW50RGF0ZSIsInNhbWVEYXlDYW5kaWRhdGVzIiwicm91dGUiLCJyb3V0ZURhdGVMYWJlbCIsInRvdGFsIiwic3RvcCIsImhhc1Vua25vd25CdWRnZXQiLCJzb21lIiwidG90YWxEaXN0YW5jZSIsInRvZ2dsZVRhZyIsInByZXZpb3VzIiwiZGVsZXRlIiwiYWRkIiwiaGFuZGxlU2F2ZVJvdXRlIiwicmVzdWx0IiwidGl0bGUiLCJzdW1tYXJ5Iiwic3RvcHMiLCJtZXNzYWdlIiwic3RvcFByb3BhZ2F0aW9uIiwidGFyZ2V0IiwidmlzaWJsZVRhZ3MiLCJoaWRkZW5Db3VudCIsInJlYXNvbkluZGV4IiwiX2MiXSwic291cmNlcyI6WyJQbGFubmVyUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB0eXBlIHsgQXBpRXZlbnQsIEFwaVBsYW4sIFRhZyB9IGZyb20gJy4vYXBpJ1xyXG5pbXBvcnQgeyBnZXRDYXRlZ29yeUljb24sIGdldFZpc2libGVUYWdzIH0gZnJvbSAnLi9jYXRlZ29yeUljb25zJ1xyXG5pbXBvcnQgdHlwZSB7IFNhdmVkUm91dGVEcmFmdCB9IGZyb20gJy4vc2F2ZWRDb250ZW50J1xyXG5cclxudHlwZSBQbGFubmVyVHlwZSA9ICdib3RoJyB8ICdldmVudHMnIHwgJ3BsYW5zJ1xyXG50eXBlIFBsYW5MZW5ndGggPSAncXVpY2snIHwgJ2hhbGYtZGF5JyB8ICdmdWxsLWRheSdcclxuXHJcbnR5cGUgUGxhbm5lckl0ZW0gPSB7XHJcbiAgICB0eXBlOiAnZXZlbnQnIHwgJ3BsYW4nXHJcbiAgICBpZDogc3RyaW5nXHJcbiAgICBuYW1lOiBzdHJpbmdcclxuICAgIGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsXHJcbiAgICBsYXQ6IG51bWJlclxyXG4gICAgbG5nOiBudW1iZXJcclxuICAgIGJ1ZGdldDogbnVtYmVyIHwgbnVsbFxyXG4gICAgdGFnczogVGFnW11cclxuICAgIGV2ZW50VGltZT86IHN0cmluZ1xyXG4gICAgZGlzdGFuY2VGcm9tQ2VudGVyOiBudW1iZXJcclxuICAgIHNjb3JlOiBudW1iZXJcclxuICAgIHJlYXNvbnM6IHN0cmluZ1tdXHJcbn1cclxuXHJcbnR5cGUgUm91dGVTdG9wID0gUGxhbm5lckl0ZW0gJiB7XHJcbiAgICBzdG9wTnVtYmVyOiBudW1iZXJcclxuICAgIGxlZ0Rpc3RhbmNlOiBudW1iZXJcclxufVxyXG5cclxudHlwZSBQbGFubmVyUGFuZWxQcm9wcyA9IHtcclxuICAgIGV2ZW50czogQXBpRXZlbnRbXVxyXG4gICAgcGxhbnM6IEFwaVBsYW5bXVxyXG4gICAgbWFwQ2VudGVyOiBbbnVtYmVyLCBudW1iZXJdXHJcbiAgICB0YWdzOiBUYWdbXVxyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZFxyXG4gICAgb25PcGVuRXZlbnREZXRhaWxzOiAoZXZlbnRJZDogc3RyaW5nKSA9PiB2b2lkXHJcbiAgICBvbkNlbnRlck9uTWFwOiAocG9zaXRpb246IFtudW1iZXIsIG51bWJlcl0pID0+IHZvaWRcclxuICAgIGlzTG9nZ2VkSW46IGJvb2xlYW5cclxuICAgIG9uU2F2ZVJvdXRlOiAocm91dGU6IFNhdmVkUm91dGVEcmFmdCkgPT4geyBzYXZlZDogYm9vbGVhbjsgbWVzc2FnZTogc3RyaW5nIH1cclxufVxyXG5cclxuY29uc3QgRUFSVEhfUkFESVVTX0tNID0gNjM3MVxyXG5jb25zdCBsZW5ndGhUb1N0b3BzOiBSZWNvcmQ8UGxhbkxlbmd0aCwgbnVtYmVyPiA9IHtcclxuICAgIHF1aWNrOiAyLFxyXG4gICAgJ2hhbGYtZGF5JzogNCxcclxuICAgICdmdWxsLWRheSc6IDYsXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRvUmFkaWFucyh2YWx1ZTogbnVtYmVyKSB7XHJcbiAgICByZXR1cm4gdmFsdWUgKiBNYXRoLlBJIC8gMTgwXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRpc3RhbmNlS20oZnJvbTogW251bWJlciwgbnVtYmVyXSwgdG86IFtudW1iZXIsIG51bWJlcl0pIHtcclxuICAgIGNvbnN0IGRMYXQgPSB0b1JhZGlhbnModG9bMF0gLSBmcm9tWzBdKVxyXG4gICAgY29uc3QgZExuZyA9IHRvUmFkaWFucyh0b1sxXSAtIGZyb21bMV0pXHJcbiAgICBjb25zdCBsYXQxID0gdG9SYWRpYW5zKGZyb21bMF0pXHJcbiAgICBjb25zdCBsYXQyID0gdG9SYWRpYW5zKHRvWzBdKVxyXG4gICAgY29uc3QgYSA9IE1hdGguc2luKGRMYXQgLyAyKSAqKiAyXHJcbiAgICAgICAgKyBNYXRoLmNvcyhsYXQxKSAqIE1hdGguY29zKGxhdDIpICogTWF0aC5zaW4oZExuZyAvIDIpICoqIDJcclxuICAgIHJldHVybiAyICogRUFSVEhfUkFESVVTX0tNICogTWF0aC5hdGFuMihNYXRoLnNxcnQoYSksIE1hdGguc3FydCgxIC0gYSkpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdEJ1ZGdldChidWRnZXQ6IG51bWJlciB8IG51bGwpIHtcclxuICAgIHJldHVybiBidWRnZXQgPT0gbnVsbCA/ICdCdWRnZXQgdW5rbm93bicgOiBg4oKsJHtidWRnZXQudG9GaXhlZCgyKX1gXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdEV2ZW50VGltZShpc286IHN0cmluZykge1xyXG4gICAgcmV0dXJuIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgIHdlZWtkYXk6ICdzaG9ydCcsXHJcbiAgICAgICAgZGF5OiAnbnVtZXJpYycsXHJcbiAgICAgICAgbW9udGg6ICdzaG9ydCcsXHJcbiAgICAgICAgaG91cjogJzItZGlnaXQnLFxyXG4gICAgICAgIG1pbnV0ZTogJzItZGlnaXQnLFxyXG4gICAgfSlcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0RXZlbnRDbG9jayhpc286IHN0cmluZykge1xyXG4gICAgcmV0dXJuIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgICBob3VyOiAnMi1kaWdpdCcsXHJcbiAgICAgICAgbWludXRlOiAnMi1kaWdpdCcsXHJcbiAgICB9KVxyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRSb3V0ZURhdGUoZGF0ZUtleTogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBbeWVhciwgbW9udGgsIGRheV0gPSBkYXRlS2V5LnNwbGl0KCctJykubWFwKE51bWJlcilcclxuICAgIHJldHVybiBuZXcgRGF0ZSh5ZWFyLCBtb250aCAtIDEsIGRheSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgICB3ZWVrZGF5OiAnc2hvcnQnLFxyXG4gICAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICAgIG1vbnRoOiAnc2hvcnQnLFxyXG4gICAgfSlcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0UHJldmlldyhkZXNjcmlwdGlvbjogc3RyaW5nIHwgbnVsbCkge1xyXG4gICAgaWYgKCFkZXNjcmlwdGlvbikgcmV0dXJuICdObyBkZXNjcmlwdGlvbiB5ZXQuJ1xyXG4gICAgcmV0dXJuIGRlc2NyaXB0aW9uLmxlbmd0aCA+IDEyMCA/IGAke2Rlc2NyaXB0aW9uLnNsaWNlKDAsIDExNyl9Li4uYCA6IGRlc2NyaXB0aW9uXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhhc1ZhbGlkQ29vcmRpbmF0ZXMoaXRlbTogeyBsYXQ6IG51bWJlcjsgbG5nOiBudW1iZXIgfSkge1xyXG4gICAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZShpdGVtLmxhdCkgJiYgTnVtYmVyLmlzRmluaXRlKGl0ZW0ubG5nKVxyXG59XHJcblxyXG5mdW5jdGlvbiBzY29yZUl0ZW0oXHJcbiAgICBpdGVtOiBPbWl0PFBsYW5uZXJJdGVtLCAnc2NvcmUnIHwgJ3JlYXNvbnMnPixcclxuICAgIHJhZGl1c0ttOiBudW1iZXIsXHJcbiAgICBzZWxlY3RlZFRhZ0lkczogU2V0PG51bWJlcj4sXHJcbiAgICBidWRnZXRNYXg6IG51bWJlciB8IG51bGwsXHJcbik6IFBpY2s8UGxhbm5lckl0ZW0sICdzY29yZScgfCAncmVhc29ucyc+IHtcclxuICAgIGNvbnN0IHJlYXNvbnMgPSBbYCR7aXRlbS5kaXN0YW5jZUZyb21DZW50ZXIudG9GaXhlZCgxKX1rbSBmcm9tIHRoZSBtYXAgY2VudGVyYF1cclxuICAgIGNvbnN0IGRpc3RhbmNlU2NvcmUgPSBNYXRoLm1heCgwLCAzMCAqICgxIC0gaXRlbS5kaXN0YW5jZUZyb21DZW50ZXIgLyByYWRpdXNLbSkpXHJcblxyXG4gICAgbGV0IHRhZ1Njb3JlID0gMFxyXG4gICAgaWYgKHNlbGVjdGVkVGFnSWRzLnNpemUgPiAwKSB7XHJcbiAgICAgICAgY29uc3QgdGFnSWRzID0gbmV3IFNldChpdGVtLnRhZ3MubWFwKCh0YWcpID0+IHRhZy5pZCkpXHJcbiAgICAgICAgY29uc3QgbWF0Y2hlZENvdW50ID0gWy4uLnNlbGVjdGVkVGFnSWRzXS5maWx0ZXIoKHRhZ0lkKSA9PiB0YWdJZHMuaGFzKHRhZ0lkKSkubGVuZ3RoXHJcbiAgICAgICAgdGFnU2NvcmUgPSA1MCAqIChtYXRjaGVkQ291bnQgLyBzZWxlY3RlZFRhZ0lkcy5zaXplKVxyXG4gICAgICAgIHJlYXNvbnMucHVzaChgbWF0Y2hlcyAke21hdGNoZWRDb3VudH0gc2VsZWN0ZWQgdGFnJHttYXRjaGVkQ291bnQgPT09IDEgPyAnJyA6ICdzJ31gKVxyXG4gICAgfSBlbHNlIGlmIChpdGVtLnRhZ3MubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHJlYXNvbnMucHVzaCgnaGFzIHRhZ3MgZm9yIHRoZSBzZWxlY3RlZCBtb29kJylcclxuICAgIH1cclxuXHJcbiAgICBsZXQgYnVkZ2V0U2NvcmUgPSAwXHJcbiAgICBpZiAoYnVkZ2V0TWF4ICE9PSBudWxsKSB7XHJcbiAgICAgICAgaWYgKGl0ZW0uYnVkZ2V0ID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGJ1ZGdldFNjb3JlID0gNVxyXG4gICAgICAgICAgICByZWFzb25zLnB1c2goJ2J1ZGdldCBpcyB1bmtub3duJylcclxuICAgICAgICB9IGVsc2UgaWYgKGl0ZW0uYnVkZ2V0IDw9IGJ1ZGdldE1heCkge1xyXG4gICAgICAgICAgICBidWRnZXRTY29yZSA9IDIwXHJcbiAgICAgICAgICAgIHJlYXNvbnMucHVzaCgnd2l0aGluIHlvdXIgbWF4IGJ1ZGdldCcpXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVhc29ucy5wdXNoKCdvdmVyIHlvdXIgbWF4IGJ1ZGdldCcpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGxldCB0aW1lU2NvcmUgPSAwXHJcbiAgICBpZiAoaXRlbS50eXBlID09PSAnZXZlbnQnICYmIGl0ZW0uZXZlbnRUaW1lKSB7XHJcbiAgICAgICAgY29uc3QgdGltZSA9IG5ldyBEYXRlKGl0ZW0uZXZlbnRUaW1lKS5nZXRUaW1lKClcclxuICAgICAgICBpZiAoTnVtYmVyLmlzRmluaXRlKHRpbWUpICYmIHRpbWUgPj0gRGF0ZS5ub3coKSkge1xyXG4gICAgICAgICAgICB0aW1lU2NvcmUgPSA1XHJcbiAgICAgICAgICAgIHJlYXNvbnMucHVzaCgndXBjb21pbmcgZXZlbnQnKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHNjb3JlOiBNYXRoLnJvdW5kKChkaXN0YW5jZVNjb3JlICsgdGFnU2NvcmUgKyBidWRnZXRTY29yZSArIHRpbWVTY29yZSkgKiAxMDApIC8gMTAwLFxyXG4gICAgICAgIHJlYXNvbnMsXHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV2ZW50VGltZU1zKGl0ZW06IFBsYW5uZXJJdGVtKSB7XHJcbiAgICBpZiAoaXRlbS50eXBlICE9PSAnZXZlbnQnIHx8ICFpdGVtLmV2ZW50VGltZSkgcmV0dXJuIG51bGxcclxuICAgIGNvbnN0IHRpbWUgPSBuZXcgRGF0ZShpdGVtLmV2ZW50VGltZSkuZ2V0VGltZSgpXHJcbiAgICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHRpbWUpID8gdGltZSA6IG51bGxcclxufVxyXG5cclxuZnVuY3Rpb24gZXZlbnREYXRlS2V5KGl0ZW06IFBsYW5uZXJJdGVtKSB7XHJcbiAgICBpZiAoaXRlbS50eXBlICE9PSAnZXZlbnQnIHx8ICFpdGVtLmV2ZW50VGltZSkgcmV0dXJuIG51bGxcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShpdGVtLmV2ZW50VGltZSlcclxuICAgIGlmICghTnVtYmVyLmlzRmluaXRlKGRhdGUuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGxcclxuICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKClcclxuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJylcclxuICAgIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKVxyXG4gICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWBcclxufVxyXG5cclxuZnVuY3Rpb24gd2l0aFVuaXF1ZVJlYXNvbihpdGVtOiBQbGFubmVySXRlbSwgcmVhc29uOiBzdHJpbmcpOiBQbGFubmVySXRlbSB7XHJcbiAgICByZXR1cm4gaXRlbS5yZWFzb25zLmluY2x1ZGVzKHJlYXNvbikgPyBpdGVtIDogeyAuLi5pdGVtLCByZWFzb25zOiBbLi4uaXRlbS5yZWFzb25zLCByZWFzb25dIH1cclxufVxyXG5cclxuZnVuY3Rpb24gc2VsZWN0Um91dGVDYW5kaWRhdGVzKFxyXG4gICAgY2FuZGlkYXRlczogUGxhbm5lckl0ZW1bXSxcclxuICAgIG1hcENlbnRlcjogW251bWJlciwgbnVtYmVyXSxcclxuICAgIHRhcmdldFN0b3BzOiBudW1iZXIsXHJcbiAgICBidWRnZXRNYXg6IG51bWJlciB8IG51bGwsXHJcbik6IFBsYW5uZXJJdGVtW10ge1xyXG4gICAgY29uc3QgcmVtYWluaW5nID0gWy4uLmNhbmRpZGF0ZXNdLnNvcnQoKGEsIGIpID0+IHtcclxuICAgICAgICBpZiAoYi5zY29yZSAhPT0gYS5zY29yZSkgcmV0dXJuIGIuc2NvcmUgLSBhLnNjb3JlXHJcbiAgICAgICAgaWYgKGEuZGlzdGFuY2VGcm9tQ2VudGVyICE9PSBiLmRpc3RhbmNlRnJvbUNlbnRlcikgcmV0dXJuIGEuZGlzdGFuY2VGcm9tQ2VudGVyIC0gYi5kaXN0YW5jZUZyb21DZW50ZXJcclxuICAgICAgICBpZiAoYS50eXBlICE9PSBiLnR5cGUpIHJldHVybiBhLnR5cGUubG9jYWxlQ29tcGFyZShiLnR5cGUpXHJcbiAgICAgICAgcmV0dXJuIGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSlcclxuICAgIH0pXHJcbiAgICBjb25zdCBzZWxlY3RlZDogUGxhbm5lckl0ZW1bXSA9IFtdXHJcbiAgICBsZXQgY3VycmVudFBvc2l0aW9uID0gbWFwQ2VudGVyXHJcbiAgICBsZXQga25vd25CdWRnZXQgPSAwXHJcblxyXG4gICAgd2hpbGUgKHNlbGVjdGVkLmxlbmd0aCA8IHRhcmdldFN0b3BzICYmIHJlbWFpbmluZy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY29uc3QgcmFua2VkID0gcmVtYWluaW5nXHJcbiAgICAgICAgICAgIC5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGxlZ0Rpc3RhbmNlID0gZGlzdGFuY2VLbShjdXJyZW50UG9zaXRpb24sIFtpdGVtLmxhdCwgaXRlbS5sbmddKVxyXG4gICAgICAgICAgICAgICAgY29uc3QgbmV4dEtub3duQnVkZ2V0ID0ga25vd25CdWRnZXQgKyAoaXRlbS5idWRnZXQgPz8gMClcclxuICAgICAgICAgICAgICAgIGNvbnN0IGJ1ZGdldFBlbmFsdHkgPSBidWRnZXRNYXggIT09IG51bGwgJiYgaXRlbS5idWRnZXQgIT09IG51bGwgJiYgbmV4dEtub3duQnVkZ2V0ID4gYnVkZ2V0TWF4ID8gODAgOiAwXHJcbiAgICAgICAgICAgICAgICBjb25zdCBsZWdTY29yZSA9IE1hdGgubWF4KDAsIDM1ICogKDEgLSBsZWdEaXN0YW5jZSAvIE1hdGgubWF4KDEsIGl0ZW0uZGlzdGFuY2VGcm9tQ2VudGVyICsgbGVnRGlzdGFuY2UpKSlcclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbSxcclxuICAgICAgICAgICAgICAgICAgICBsZWdEaXN0YW5jZSxcclxuICAgICAgICAgICAgICAgICAgICByb3V0ZVNjb3JlOiBpdGVtLnNjb3JlICsgbGVnU2NvcmUgLSBidWRnZXRQZW5hbHR5LFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKGIucm91dGVTY29yZSAhPT0gYS5yb3V0ZVNjb3JlKSByZXR1cm4gYi5yb3V0ZVNjb3JlIC0gYS5yb3V0ZVNjb3JlXHJcbiAgICAgICAgICAgICAgICBpZiAoYS5sZWdEaXN0YW5jZSAhPT0gYi5sZWdEaXN0YW5jZSkgcmV0dXJuIGEubGVnRGlzdGFuY2UgLSBiLmxlZ0Rpc3RhbmNlXHJcbiAgICAgICAgICAgICAgICBpZiAoYS5pdGVtLnR5cGUgIT09IGIuaXRlbS50eXBlKSByZXR1cm4gYS5pdGVtLnR5cGUubG9jYWxlQ29tcGFyZShiLml0ZW0udHlwZSlcclxuICAgICAgICAgICAgICAgIHJldHVybiBhLml0ZW0ubmFtZS5sb2NhbGVDb21wYXJlKGIuaXRlbS5uYW1lKVxyXG4gICAgICAgICAgICB9KVxyXG5cclxuICAgICAgICBjb25zdCBuZXh0ID0gcmFua2VkWzBdXHJcbiAgICAgICAgaWYgKCFuZXh0IHx8IG5leHQucm91dGVTY29yZSA8IC0yMCkgYnJlYWtcclxuXHJcbiAgICAgICAgc2VsZWN0ZWQucHVzaChuZXh0Lml0ZW0pXHJcbiAgICAgICAgaWYgKG5leHQuaXRlbS5idWRnZXQgIT09IG51bGwpIGtub3duQnVkZ2V0ICs9IG5leHQuaXRlbS5idWRnZXRcclxuICAgICAgICBjdXJyZW50UG9zaXRpb24gPSBbbmV4dC5pdGVtLmxhdCwgbmV4dC5pdGVtLmxuZ11cclxuICAgICAgICByZW1haW5pbmcuc3BsaWNlKHJlbWFpbmluZy5maW5kSW5kZXgoKGl0ZW0pID0+IGl0ZW0udHlwZSA9PT0gbmV4dC5pdGVtLnR5cGUgJiYgaXRlbS5pZCA9PT0gbmV4dC5pdGVtLmlkKSwgMSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gc2VsZWN0ZWRcclxufVxyXG5cclxuZnVuY3Rpb24gbmVhcmVzdEZpcnN0KGl0ZW1zOiBQbGFubmVySXRlbVtdLCBzdGFydDogW251bWJlciwgbnVtYmVyXSkge1xyXG4gICAgY29uc3QgcmVtYWluaW5nID0gWy4uLml0ZW1zXVxyXG4gICAgY29uc3Qgb3JkZXJlZDogUGxhbm5lckl0ZW1bXSA9IFtdXHJcbiAgICBsZXQgY3VycmVudFBvc2l0aW9uID0gc3RhcnRcclxuXHJcbiAgICB3aGlsZSAocmVtYWluaW5nLmxlbmd0aCA+IDApIHtcclxuICAgICAgICByZW1haW5pbmcuc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBhRGlzdGFuY2UgPSBkaXN0YW5jZUttKGN1cnJlbnRQb3NpdGlvbiwgW2EubGF0LCBhLmxuZ10pXHJcbiAgICAgICAgICAgIGNvbnN0IGJEaXN0YW5jZSA9IGRpc3RhbmNlS20oY3VycmVudFBvc2l0aW9uLCBbYi5sYXQsIGIubG5nXSlcclxuICAgICAgICAgICAgaWYgKGFEaXN0YW5jZSAhPT0gYkRpc3RhbmNlKSByZXR1cm4gYURpc3RhbmNlIC0gYkRpc3RhbmNlXHJcbiAgICAgICAgICAgIGlmIChiLnNjb3JlICE9PSBhLnNjb3JlKSByZXR1cm4gYi5zY29yZSAtIGEuc2NvcmVcclxuICAgICAgICAgICAgcmV0dXJuIGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSlcclxuICAgICAgICB9KVxyXG4gICAgICAgIGNvbnN0IG5leHQgPSByZW1haW5pbmcuc2hpZnQoKVxyXG4gICAgICAgIGlmICghbmV4dCkgYnJlYWtcclxuICAgICAgICBvcmRlcmVkLnB1c2gobmV4dClcclxuICAgICAgICBjdXJyZW50UG9zaXRpb24gPSBbbmV4dC5sYXQsIG5leHQubG5nXVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBvcmRlcmVkXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFkZFN0b3BOdW1iZXJzKGl0ZW1zOiBQbGFubmVySXRlbVtdLCBtYXBDZW50ZXI6IFtudW1iZXIsIG51bWJlcl0pOiBSb3V0ZVN0b3BbXSB7XHJcbiAgICBsZXQgY3VycmVudFBvc2l0aW9uID0gbWFwQ2VudGVyXHJcbiAgICByZXR1cm4gaXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGxlZ0Rpc3RhbmNlID0gZGlzdGFuY2VLbShjdXJyZW50UG9zaXRpb24sIFtpdGVtLmxhdCwgaXRlbS5sbmddKVxyXG4gICAgICAgIGN1cnJlbnRQb3NpdGlvbiA9IFtpdGVtLmxhdCwgaXRlbS5sbmddXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgLi4uaXRlbSxcclxuICAgICAgICAgICAgc3RvcE51bWJlcjogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBsZWdEaXN0YW5jZSxcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG59XHJcblxyXG5mdW5jdGlvbiBvcmRlclJvdXRlQ2FuZGlkYXRlcyhzZWxlY3RlZDogUGxhbm5lckl0ZW1bXSwgbWFwQ2VudGVyOiBbbnVtYmVyLCBudW1iZXJdKTogUm91dGVTdG9wW10ge1xyXG4gICAgY29uc3QgdGltZWRFdmVudHMgPSBzZWxlY3RlZFxyXG4gICAgICAgIC5maWx0ZXIoKGl0ZW0pID0+IGV2ZW50VGltZU1zKGl0ZW0pICE9PSBudWxsKVxyXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGFUaW1lID0gZXZlbnRUaW1lTXMoYSkgPz8gMFxyXG4gICAgICAgICAgICBjb25zdCBiVGltZSA9IGV2ZW50VGltZU1zKGIpID8/IDBcclxuICAgICAgICAgICAgaWYgKGFUaW1lICE9PSBiVGltZSkgcmV0dXJuIGFUaW1lIC0gYlRpbWVcclxuICAgICAgICAgICAgcmV0dXJuIGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSlcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5tYXAoKGl0ZW0pID0+IHdpdGhVbmlxdWVSZWFzb24oaXRlbSwgYHNjaGVkdWxlZCBhdCAke2Zvcm1hdEV2ZW50Q2xvY2soaXRlbS5ldmVudFRpbWUgPz8gJycpfWApKVxyXG4gICAgY29uc3QgdW50aW1lZEl0ZW1zID0gc2VsZWN0ZWQuZmlsdGVyKChpdGVtKSA9PiBldmVudFRpbWVNcyhpdGVtKSA9PT0gbnVsbClcclxuXHJcbiAgICBpZiAodGltZWRFdmVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgcmV0dXJuIGFkZFN0b3BOdW1iZXJzKG5lYXJlc3RGaXJzdCh1bnRpbWVkSXRlbXMsIG1hcENlbnRlciksIG1hcENlbnRlcilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzbG90czogUGxhbm5lckl0ZW1bXVtdID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogdGltZWRFdmVudHMubGVuZ3RoICsgMSB9LCAoKSA9PiBbXSlcclxuXHJcbiAgICB1bnRpbWVkSXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHNsb3RDb3N0cyA9IHNsb3RzLm1hcCgoXywgc2xvdEluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChzbG90SW5kZXggPT09IDApIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBkaXN0YW5jZUttKG1hcENlbnRlciwgW2l0ZW0ubGF0LCBpdGVtLmxuZ10pICsgZGlzdGFuY2VLbShbaXRlbS5sYXQsIGl0ZW0ubG5nXSwgW3RpbWVkRXZlbnRzWzBdLmxhdCwgdGltZWRFdmVudHNbMF0ubG5nXSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY29uc3QgcHJldmlvdXNUaW1lZCA9IHRpbWVkRXZlbnRzW3Nsb3RJbmRleCAtIDFdXHJcbiAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzUG9pbnQ6IFtudW1iZXIsIG51bWJlcl0gPSBbcHJldmlvdXNUaW1lZC5sYXQsIHByZXZpb3VzVGltZWQubG5nXVxyXG5cclxuICAgICAgICAgICAgaWYgKHNsb3RJbmRleCA9PT0gdGltZWRFdmVudHMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZGlzdGFuY2VLbShwcmV2aW91c1BvaW50LCBbaXRlbS5sYXQsIGl0ZW0ubG5nXSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY29uc3QgbmV4dFRpbWVkID0gdGltZWRFdmVudHNbc2xvdEluZGV4XVxyXG4gICAgICAgICAgICBjb25zdCBuZXh0UG9pbnQ6IFtudW1iZXIsIG51bWJlcl0gPSBbbmV4dFRpbWVkLmxhdCwgbmV4dFRpbWVkLmxuZ11cclxuICAgICAgICAgICAgY29uc3QgZGlyZWN0RGlzdGFuY2UgPSBkaXN0YW5jZUttKHByZXZpb3VzUG9pbnQsIG5leHRQb2ludClcclxuICAgICAgICAgICAgcmV0dXJuIGRpc3RhbmNlS20ocHJldmlvdXNQb2ludCwgW2l0ZW0ubGF0LCBpdGVtLmxuZ10pICsgZGlzdGFuY2VLbShbaXRlbS5sYXQsIGl0ZW0ubG5nXSwgbmV4dFBvaW50KSAtIGRpcmVjdERpc3RhbmNlXHJcbiAgICAgICAgfSlcclxuICAgICAgICBjb25zdCBiZXN0U2xvdEluZGV4ID0gc2xvdENvc3RzLnJlZHVjZSgoYmVzdEluZGV4LCBjb3N0LCBpbmRleCkgPT4gY29zdCA8IHNsb3RDb3N0c1tiZXN0SW5kZXhdID8gaW5kZXggOiBiZXN0SW5kZXgsIDApXHJcbiAgICAgICAgY29uc3QgcGxhY2VtZW50UmVhc29uID0gYmVzdFNsb3RJbmRleCA9PT0gMFxyXG4gICAgICAgICAgICA/ICdwbGFjZWQgYmVmb3JlIHRoZSBmaXJzdCB0aW1lZCBzdG9wJ1xyXG4gICAgICAgICAgICA6IGJlc3RTbG90SW5kZXggPT09IHRpbWVkRXZlbnRzLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgPyAncGxhY2VkIGFmdGVyIHRpbWVkIHN0b3BzJ1xyXG4gICAgICAgICAgICAgICAgOiAncGxhY2VkIGJldHdlZW4gdGltZWQgc3RvcHMnXHJcbiAgICAgICAgc2xvdHNbYmVzdFNsb3RJbmRleF0ucHVzaCh3aXRoVW5pcXVlUmVhc29uKGl0ZW0sIHBsYWNlbWVudFJlYXNvbikpXHJcbiAgICB9KVxyXG5cclxuICAgIGNvbnN0IG9yZGVyZWQ6IFBsYW5uZXJJdGVtW10gPSBbXVxyXG4gICAgbGV0IGFuY2hvciA9IG1hcENlbnRlclxyXG4gICAgb3JkZXJlZC5wdXNoKC4uLm5lYXJlc3RGaXJzdChzbG90c1swXSwgYW5jaG9yKSlcclxuICAgIGlmIChvcmRlcmVkLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCBsYXN0ID0gb3JkZXJlZFtvcmRlcmVkLmxlbmd0aCAtIDFdXHJcbiAgICAgICAgYW5jaG9yID0gW2xhc3QubGF0LCBsYXN0LmxuZ11cclxuICAgIH1cclxuXHJcbiAgICB0aW1lZEV2ZW50cy5mb3JFYWNoKChldmVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICBvcmRlcmVkLnB1c2goZXZlbnQpXHJcbiAgICAgICAgYW5jaG9yID0gW2V2ZW50LmxhdCwgZXZlbnQubG5nXVxyXG4gICAgICAgIGNvbnN0IHNsb3RJdGVtcyA9IG5lYXJlc3RGaXJzdChzbG90c1tpbmRleCArIDFdLCBhbmNob3IpXHJcbiAgICAgICAgb3JkZXJlZC5wdXNoKC4uLnNsb3RJdGVtcylcclxuICAgICAgICBpZiAoc2xvdEl0ZW1zLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgY29uc3QgbGFzdCA9IHNsb3RJdGVtc1tzbG90SXRlbXMubGVuZ3RoIC0gMV1cclxuICAgICAgICAgICAgYW5jaG9yID0gW2xhc3QubGF0LCBsYXN0LmxuZ11cclxuICAgICAgICB9XHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiBhZGRTdG9wTnVtYmVycyhvcmRlcmVkLCBtYXBDZW50ZXIpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkUm91dGUoXHJcbiAgICBjYW5kaWRhdGVzOiBQbGFubmVySXRlbVtdLFxyXG4gICAgbWFwQ2VudGVyOiBbbnVtYmVyLCBudW1iZXJdLFxyXG4gICAgdGFyZ2V0U3RvcHM6IG51bWJlcixcclxuICAgIGJ1ZGdldE1heDogbnVtYmVyIHwgbnVsbCxcclxuKTogUm91dGVTdG9wW10ge1xyXG4gICAgcmV0dXJuIG9yZGVyUm91dGVDYW5kaWRhdGVzKFxyXG4gICAgICAgIHNlbGVjdFJvdXRlQ2FuZGlkYXRlcyhjYW5kaWRhdGVzLCBtYXBDZW50ZXIsIHRhcmdldFN0b3BzLCBidWRnZXRNYXgpLFxyXG4gICAgICAgIG1hcENlbnRlcixcclxuICAgIClcclxufVxyXG5cclxuZnVuY3Rpb24gY2hvb3NlQmVzdEV2ZW50RGF0ZShjYW5kaWRhdGVzOiBQbGFubmVySXRlbVtdKSB7XHJcbiAgICBjb25zdCBncm91cHMgPSBuZXcgTWFwPHN0cmluZywgUGxhbm5lckl0ZW1bXT4oKVxyXG4gICAgY2FuZGlkYXRlcy5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZGF0ZUtleSA9IGV2ZW50RGF0ZUtleShpdGVtKVxyXG4gICAgICAgIGlmICghZGF0ZUtleSkgcmV0dXJuXHJcbiAgICAgICAgZ3JvdXBzLnNldChkYXRlS2V5LCBbLi4uKGdyb3Vwcy5nZXQoZGF0ZUtleSkgPz8gW10pLCBpdGVtXSlcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIFsuLi5ncm91cHMuZW50cmllcygpXVxyXG4gICAgICAgIC5tYXAoKFtkYXRlS2V5LCBpdGVtc10pID0+ICh7XHJcbiAgICAgICAgICAgIGRhdGVLZXksXHJcbiAgICAgICAgICAgIGl0ZW1zLFxyXG4gICAgICAgICAgICB0b3RhbFNjb3JlOiBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgaXRlbS5zY29yZSwgMCksXHJcbiAgICAgICAgfSkpXHJcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IHtcclxuICAgICAgICAgICAgaWYgKGIudG90YWxTY29yZSAhPT0gYS50b3RhbFNjb3JlKSByZXR1cm4gYi50b3RhbFNjb3JlIC0gYS50b3RhbFNjb3JlXHJcbiAgICAgICAgICAgIGlmIChiLml0ZW1zLmxlbmd0aCAhPT0gYS5pdGVtcy5sZW5ndGgpIHJldHVybiBiLml0ZW1zLmxlbmd0aCAtIGEuaXRlbXMubGVuZ3RoXHJcbiAgICAgICAgICAgIHJldHVybiBhLmRhdGVLZXkubG9jYWxlQ29tcGFyZShiLmRhdGVLZXkpXHJcbiAgICAgICAgfSlbMF0gPz8gbnVsbFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQbGFubmVyUGFuZWwoe1xyXG4gICAgZXZlbnRzLFxyXG4gICAgcGxhbnMsXHJcbiAgICBtYXBDZW50ZXIsXHJcbiAgICB0YWdzLFxyXG4gICAgb25DbG9zZSxcclxuICAgIG9uT3BlbkV2ZW50RGV0YWlscyxcclxuICAgIG9uQ2VudGVyT25NYXAsXHJcbiAgICBpc0xvZ2dlZEluLFxyXG4gICAgb25TYXZlUm91dGUsXHJcbn06IFBsYW5uZXJQYW5lbFByb3BzKSB7XHJcbiAgICBjb25zdCBbcmFkaXVzS20sIHNldFJhZGl1c0ttXSA9IHVzZVN0YXRlKCcxMCcpXHJcbiAgICBjb25zdCBbYnVkZ2V0TWF4LCBzZXRCdWRnZXRNYXhdID0gdXNlU3RhdGUoJycpXHJcbiAgICBjb25zdCBbdHlwZU1peCwgc2V0VHlwZU1peF0gPSB1c2VTdGF0ZTxQbGFubmVyVHlwZT4oJ2JvdGgnKVxyXG4gICAgY29uc3QgW3BsYW5MZW5ndGgsIHNldFBsYW5MZW5ndGhdID0gdXNlU3RhdGU8UGxhbkxlbmd0aD4oJ3F1aWNrJylcclxuICAgIGNvbnN0IFtzZWxlY3RlZFRhZ0lkcywgc2V0U2VsZWN0ZWRUYWdJZHNdID0gdXNlU3RhdGU8U2V0PG51bWJlcj4+KG5ldyBTZXQoKSlcclxuICAgIGNvbnN0IFtzYXZlTWVzc2FnZSwgc2V0U2F2ZU1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gICAgY29uc3QgcGFyc2VkUmFkaXVzID0gTnVtYmVyKHJhZGl1c0ttKVxyXG4gICAgY29uc3Qgc2FmZVJhZGl1cyA9IE51bWJlci5pc0Zpbml0ZShwYXJzZWRSYWRpdXMpICYmIHBhcnNlZFJhZGl1cyA+IDAgPyBwYXJzZWRSYWRpdXMgOiAxMFxyXG4gICAgY29uc3QgcGFyc2VkQnVkZ2V0ID0gYnVkZ2V0TWF4LnRyaW0oKSA9PT0gJycgPyBudWxsIDogTnVtYmVyKGJ1ZGdldE1heClcclxuICAgIGNvbnN0IHNhZmVCdWRnZXRNYXggPSBwYXJzZWRCdWRnZXQgIT09IG51bGwgJiYgTnVtYmVyLmlzRmluaXRlKHBhcnNlZEJ1ZGdldCkgJiYgcGFyc2VkQnVkZ2V0ID49IDAgPyBwYXJzZWRCdWRnZXQgOiBudWxsXHJcblxyXG4gICAgY29uc3Qgcm91dGVSZXN1bHQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICBjb25zdCBzZWxlY3RlZFRhZ3MgPSBzZWxlY3RlZFRhZ0lkc1xyXG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWQ6IFBsYW5uZXJJdGVtW10gPSBbXHJcbiAgICAgICAgICAgIC4uLih0eXBlTWl4ID09PSAncGxhbnMnID8gW10gOiBldmVudHMuZmlsdGVyKGhhc1ZhbGlkQ29vcmRpbmF0ZXMpLm1hcCgoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGJhc2UgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2V2ZW50JyBhcyBjb25zdCxcclxuICAgICAgICAgICAgICAgICAgICBpZDogZXZlbnQuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogZXZlbnQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZXZlbnQuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgbGF0OiBldmVudC5sYXQsXHJcbiAgICAgICAgICAgICAgICAgICAgbG5nOiBldmVudC5sbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgYnVkZ2V0OiBldmVudC5idWRnZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgdGFnczogZXZlbnQudGFncyA/PyBbXSxcclxuICAgICAgICAgICAgICAgICAgICBldmVudFRpbWU6IGV2ZW50LmV2ZW50X3RpbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzdGFuY2VGcm9tQ2VudGVyOiBkaXN0YW5jZUttKG1hcENlbnRlciwgW2V2ZW50LmxhdCwgZXZlbnQubG5nXSksXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5iYXNlLCAuLi5zY29yZUl0ZW0oYmFzZSwgc2FmZVJhZGl1cywgc2VsZWN0ZWRUYWdzLCBzYWZlQnVkZ2V0TWF4KSB9XHJcbiAgICAgICAgICAgIH0pKSxcclxuICAgICAgICAgICAgLi4uKHR5cGVNaXggPT09ICdldmVudHMnID8gW10gOiBwbGFucy5maWx0ZXIoaGFzVmFsaWRDb29yZGluYXRlcykubWFwKChwbGFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBiYXNlID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdwbGFuJyBhcyBjb25zdCxcclxuICAgICAgICAgICAgICAgICAgICBpZDogcGxhbi5pZCxcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiBwbGFuLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHBsYW4uZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgbGF0OiBwbGFuLmxhdCxcclxuICAgICAgICAgICAgICAgICAgICBsbmc6IHBsYW4ubG5nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1ZGdldDogcGxhbi5idWRnZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgdGFnczogcGxhbi50YWdzID8/IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3RhbmNlRnJvbUNlbnRlcjogZGlzdGFuY2VLbShtYXBDZW50ZXIsIFtwbGFuLmxhdCwgcGxhbi5sbmddKSxcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLmJhc2UsIC4uLnNjb3JlSXRlbShiYXNlLCBzYWZlUmFkaXVzLCBzZWxlY3RlZFRhZ3MsIHNhZmVCdWRnZXRNYXgpIH1cclxuICAgICAgICAgICAgfSkpLFxyXG4gICAgICAgIF1cclxuXHJcbiAgICAgICAgY29uc3QgY2FuZGlkYXRlcyA9IG5vcm1hbGl6ZWRcclxuICAgICAgICAgICAgLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5kaXN0YW5jZUZyb21DZW50ZXIgPD0gc2FmZVJhZGl1cylcclxuICAgICAgICAgICAgLmZpbHRlcigoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkVGFncy5zaXplID09PSAwKSByZXR1cm4gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgY29uc3QgaXRlbVRhZ0lkcyA9IG5ldyBTZXQoaXRlbS50YWdzLm1hcCgodGFnKSA9PiB0YWcuaWQpKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFsuLi5zZWxlY3RlZFRhZ3NdLmV2ZXJ5KCh0YWdJZCkgPT4gaXRlbVRhZ0lkcy5oYXModGFnSWQpKVxyXG4gICAgICAgICAgICB9KVxyXG5cclxuICAgICAgICBjb25zdCBiZXN0RXZlbnREYXRlID0gdHlwZU1peCA9PT0gJ3BsYW5zJyA/IG51bGwgOiBjaG9vc2VCZXN0RXZlbnREYXRlKGNhbmRpZGF0ZXMpXHJcbiAgICAgICAgY29uc3Qgc2FtZURheUNhbmRpZGF0ZXMgPSBiZXN0RXZlbnREYXRlXHJcbiAgICAgICAgICAgID8gY2FuZGlkYXRlcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0udHlwZSA9PT0gJ3BsYW4nIHx8IGV2ZW50RGF0ZUtleShpdGVtKSA9PT0gYmVzdEV2ZW50RGF0ZS5kYXRlS2V5KVxyXG4gICAgICAgICAgICA6IGNhbmRpZGF0ZXNcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcm91dGU6IGJ1aWxkUm91dGUoc2FtZURheUNhbmRpZGF0ZXMsIG1hcENlbnRlciwgbGVuZ3RoVG9TdG9wc1twbGFuTGVuZ3RoXSwgc2FmZUJ1ZGdldE1heCksXHJcbiAgICAgICAgICAgIHJvdXRlRGF0ZUxhYmVsOiBiZXN0RXZlbnREYXRlID8gZm9ybWF0Um91dGVEYXRlKGJlc3RFdmVudERhdGUuZGF0ZUtleSkgOiAnJyxcclxuICAgICAgICB9XHJcbiAgICB9LCBbZXZlbnRzLCBtYXBDZW50ZXIsIHBsYW5MZW5ndGgsIHBsYW5zLCBzYWZlQnVkZ2V0TWF4LCBzYWZlUmFkaXVzLCBzZWxlY3RlZFRhZ0lkcywgdHlwZU1peF0pXHJcblxyXG4gICAgY29uc3QgeyByb3V0ZSwgcm91dGVEYXRlTGFiZWwgfSA9IHJvdXRlUmVzdWx0XHJcbiAgICBjb25zdCBrbm93bkJ1ZGdldCA9IHJvdXRlLnJlZHVjZSgodG90YWwsIHN0b3ApID0+IHRvdGFsICsgKHN0b3AuYnVkZ2V0ID8/IDApLCAwKVxyXG4gICAgY29uc3QgaGFzVW5rbm93bkJ1ZGdldCA9IHJvdXRlLnNvbWUoKHN0b3ApID0+IHN0b3AuYnVkZ2V0ID09PSBudWxsKVxyXG4gICAgY29uc3QgdG90YWxEaXN0YW5jZSA9IHJvdXRlLnJlZHVjZSgodG90YWwsIHN0b3ApID0+IHRvdGFsICsgc3RvcC5sZWdEaXN0YW5jZSwgMClcclxuXHJcbiAgICBjb25zdCB0b2dnbGVUYWcgPSAodGFnSWQ6IG51bWJlcikgPT4ge1xyXG4gICAgICAgIHNldFNlbGVjdGVkVGFnSWRzKChwcmV2aW91cykgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2aW91cylcclxuICAgICAgICAgICAgbmV4dC5oYXModGFnSWQpID8gbmV4dC5kZWxldGUodGFnSWQpIDogbmV4dC5hZGQodGFnSWQpXHJcbiAgICAgICAgICAgIHJldHVybiBuZXh0XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBoYW5kbGVTYXZlUm91dGUgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKHJvdXRlLmxlbmd0aCA9PT0gMCkgcmV0dXJuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gb25TYXZlUm91dGUoe1xyXG4gICAgICAgICAgICB0aXRsZTogcm91dGVEYXRlTGFiZWwgPyBgUGxhbm5lciByb3V0ZSBmb3IgJHtyb3V0ZURhdGVMYWJlbH1gIDogJ1BsYW5uZXIgcm91dGUnLFxyXG4gICAgICAgICAgICBtYXBDZW50ZXIsXHJcbiAgICAgICAgICAgIHN1bW1hcnk6IHtcclxuICAgICAgICAgICAgICAgIHN0b3BzOiByb3V0ZS5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICBrbm93bkJ1ZGdldCxcclxuICAgICAgICAgICAgICAgIGhhc1Vua25vd25CdWRnZXQsXHJcbiAgICAgICAgICAgICAgICB0b3RhbERpc3RhbmNlLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdG9wczogcm91dGUubWFwKChzdG9wKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgdHlwZTogc3RvcC50eXBlLFxyXG4gICAgICAgICAgICAgICAgaWQ6IHN0b3AuaWQsXHJcbiAgICAgICAgICAgICAgICBuYW1lOiBzdG9wLm5hbWUsXHJcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogc3RvcC5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICAgIGxhdDogc3RvcC5sYXQsXHJcbiAgICAgICAgICAgICAgICBsbmc6IHN0b3AubG5nLFxyXG4gICAgICAgICAgICAgICAgYnVkZ2V0OiBzdG9wLmJ1ZGdldCxcclxuICAgICAgICAgICAgICAgIHRhZ3M6IHN0b3AudGFncyxcclxuICAgICAgICAgICAgICAgIGV2ZW50VGltZTogc3RvcC5ldmVudFRpbWUsXHJcbiAgICAgICAgICAgICAgICByZWFzb25zOiBzdG9wLnJlYXNvbnMsXHJcbiAgICAgICAgICAgICAgICBzdG9wTnVtYmVyOiBzdG9wLnN0b3BOdW1iZXIsXHJcbiAgICAgICAgICAgIH0pKSxcclxuICAgICAgICB9KVxyXG4gICAgICAgIHNldFNhdmVNZXNzYWdlKHJlc3VsdC5tZXNzYWdlKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLWJhY2tkcm9wXCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBsYW5uZXItcGFuZWxcIiBhcmlhLWxhYmVsPVwiUm91dGUgcGxhbm5lclwiIG9uQ2xpY2s9eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXBhbmVsX19oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwbGFubmVyLXBhbmVsX19leWVicm93XCI+UmFuZG9tIHBsYW5uZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMj5CdWlsZCBhIG5lYXJieSByb3V0ZTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPkJ1aWx0IGZyb20gbmVhcmJ5IHBsYW5zL2V2ZW50cyBtYXRjaGluZyB5b3VyIGZpbHRlcnMuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImV4cGxvcmUtcGFuZWxfX2Nsb3NlXCIgb25DbGljaz17b25DbG9zZX0gYXJpYS1sYWJlbD1cIkNsb3NlIHBsYW5uZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXBhbmVsX19ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXRvb2xiYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLWNvbnRyb2xzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicGxhbm5lci1maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJhZGl1czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmFkaXVzS219XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJhZGl1c0ttKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicGxhbm5lci1maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJ1ZGdldDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQW55XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2J1ZGdldE1heH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QnVkZ2V0TWF4KGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicGxhbm5lci1maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1peDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXt0eXBlTWl4fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRUeXBlTWl4KGV2ZW50LnRhcmdldC52YWx1ZSBhcyBQbGFubmVyVHlwZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYm90aFwiPkJvdGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImV2ZW50c1wiPkV2ZW50cyBvbmx5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwbGFuc1wiPlBsYW5zIG9ubHk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicGxhbm5lci1maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkxlbmd0aDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtwbGFuTGVuZ3RofSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRQbGFuTGVuZ3RoKGV2ZW50LnRhcmdldC52YWx1ZSBhcyBQbGFuTGVuZ3RoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJxdWlja1wiPlF1aWNrIMK3IDI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImhhbGYtZGF5XCI+SGFsZi1kYXkgwrcgNDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZnVsbC1kYXlcIj5GdWxsLWRheSDCtyA2PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxhbm5lci10YWdzXCIgYXJpYS1sYWJlbD1cIlBsYW5uZXIgdGFnIGZpbHRlcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlRhZ3M8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYW5uZXItdGFnc19fbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWdzLmxlbmd0aCA9PT0gMCAmJiA8ZW0+Tm8gdGFncyBhdmFpbGFibGUuPC9lbT59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhZ3MubWFwKCh0YWcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0YWcuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17c2VsZWN0ZWRUYWdJZHMuaGFzKHRhZy5pZCkgPyAncGxhbm5lci10YWcgcGxhbm5lci10YWctLWFjdGl2ZScgOiAncGxhbm5lci10YWcnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlVGFnKHRhZy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICN7dGFnLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYW5uZXItcm91dGUtdG9vbHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXN1bW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57cm91dGUubGVuZ3RofTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnN0b3BzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+4oKse2tub3duQnVkZ2V0LnRvRml4ZWQoMil9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2hhc1Vua25vd25CdWRnZXQgPyAna25vd24gYnVkZ2V0LCBzb21lIHVua25vd24nIDogJ2tub3duIGJ1ZGdldCd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3RvdGFsRGlzdGFuY2UudG9GaXhlZCgxKX1rbTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnJvdXRlIGRpc3RhbmNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXNhdmUtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cm91dGVEYXRlTGFiZWwgJiYgPHNwYW4+QnVpbHQgYXJvdW5kIHtyb3V0ZURhdGVMYWJlbH08L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JvdXRlLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBsYW5uZXItYWN0aW9uIHBsYW5uZXItYWN0aW9uLS1zYXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZVJvdXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWlzTG9nZ2VkSW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNMb2dnZWRJbiA/ICdTYXZlIHJvdXRlJyA6ICdMb2cgaW4gdG8gc2F2ZSd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NhdmVNZXNzYWdlICYmIDxzcGFuIGNsYXNzTmFtZT1cInBsYW5uZXItc2F2ZS1yb3dfX21lc3NhZ2VcIj57c2F2ZU1lc3NhZ2V9PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxhbm5lci1yb3V0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cm91dGUubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxhbm5lci1lbXB0eVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIHJvdXRlIGNvdWxkIGJlIGdlbmVyYXRlZCB3aXRoIHRoZXNlIGZpbHRlcnMuIFRyeSB3aWRlbmluZyB0aGUgcmFkaXVzIG9yIGNsZWFyaW5nIHRhZ3MuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JvdXRlLm1hcCgoc3RvcCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyB2aXNpYmxlVGFncywgaGlkZGVuQ291bnQgfSA9IGdldFZpc2libGVUYWdzKHN0b3AudGFncylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFydGljbGUga2V5PXtgJHtzdG9wLnR5cGV9LSR7c3RvcC5pZH1gfSBjbGFzc05hbWU9XCJwbGFubmVyLXN0b3BcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXN0b3BfX3JhaWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxhbm5lci1zdG9wX19udW1iZXJcIj57c3RvcC5zdG9wTnVtYmVyfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXN0b3BfX2NvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxhbm5lci1zdG9wX190b3BsaW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZXhwbG9yZS1jYXJkX19iYWRnZSBleHBsb3JlLWNhcmRfX2JhZGdlLS0ke3N0b3AudHlwZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX19pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0Q2F0ZWdvcnlJY29uKHN0b3AudGFncywgc3RvcC50eXBlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RvcC50eXBlID09PSAnZXZlbnQnID8gJ0V2ZW50JyA6ICdQbGFuJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX19kaXN0YW5jZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RvcC5sZWdEaXN0YW5jZS50b0ZpeGVkKDEpfWttIGxlZyDCtyB7c3RvcC5kaXN0YW5jZUZyb21DZW50ZXIudG9GaXhlZCgxKX1rbSBmcm9tIGNlbnRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPntzdG9wLm5hbWV9PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPntnZXRQcmV2aWV3KHN0b3AuZGVzY3JpcHRpb24pfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX19tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdEJ1ZGdldChzdG9wLmJ1ZGdldCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdG9wLnR5cGUgPT09ICdldmVudCcgJiYgc3RvcC5ldmVudFRpbWUgJiYgPHNwYW4+e2Zvcm1hdEV2ZW50VGltZShzdG9wLmV2ZW50VGltZSl9PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVUYWdzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhwbG9yZS1jYXJkX190YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlVGFncy5tYXAoKHRhZykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0YWcuaWR9PiN7dGFnLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2hpZGRlbkNvdW50ID4gMCAmJiA8c3BhbiBjbGFzc05hbWU9XCJleHBsb3JlLWNhcmRfX3RhZy1tb3JlXCI+K3toaWRkZW5Db3VudH0gbW9yZTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGFubmVyLXN0b3BfX3JlYXNvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RvcC5yZWFzb25zLm1hcCgocmVhc29uLCByZWFzb25JbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2Ake3N0b3AudHlwZX0tJHtzdG9wLmlkfS0ke3JlYXNvbkluZGV4fWB9PntyZWFzb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYW5uZXItc3RvcF9fYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdG9wLnR5cGUgPT09ICdldmVudCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBsYW5uZXItYWN0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbk9wZW5FdmVudERldGFpbHMoc3RvcC5pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9wZW4gZnVsbCBldmVudCBkZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGxhbm5lci1hY3Rpb24gcGxhbm5lci1hY3Rpb24tLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2VudGVyT25NYXAoW3N0b3AubGF0LCBzdG9wLmxuZ10pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENlbnRlciBvbiBtYXBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hcnRpL0RvY3VtZW50cy9HaXRIdWIvU29mdHdhcmUtUHJvamVjdC1HMTAvUHJvamVjdC9zcmMvUGxhbm5lclBhbmVsLnRzeCJ9