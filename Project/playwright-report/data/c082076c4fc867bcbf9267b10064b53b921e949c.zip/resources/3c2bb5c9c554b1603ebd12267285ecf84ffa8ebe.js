import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CreatePanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useState = __vite__cjsImport3_react["useState"];
import { createEvent, createPlan } from "/src/api.ts?t=1780399643427";
export default function CreatePanel({
  position,
  availableTags,
  onEventCreated,
  onPlanCreated,
  onCancel
}) {
  _s();
  const [type, setType] = useState("event");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [eventTime, setEventTime] = useState("");
  const [capacity, setCapacity] = useState("");
  const [budget, setBudget] = useState("");
  const [visibility, setVisibility] = useState("public");
  const [selectedTagIds, setSelectedTagIds] = useState(/* @__PURE__ */ new Set());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  if (!position)
    return null;
  const toggleTag = (tagId) => {
    setSelectedTagIds((prev) => {
      const next = new Set(prev);
      next.has(tagId) ? next.delete(tagId) : next.add(tagId);
      return next;
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim())
      return;
    setSaving(true);
    setError("");
    try {
      const tag_ids = [...selectedTagIds];
      const normalizedBudget = budget.trim() === "" ? 0 : parseFloat(budget);
      if (!Number.isFinite(normalizedBudget) || normalizedBudget < 0) {
        throw new Error("Budget must be a non-negative number");
      }
      if (type === "event") {
        if (!eventTime)
          throw new Error("Event time is required");
        const event = await createEvent({
          name: name.trim(),
          description: description.trim() || void 0,
          lat: position[0],
          lng: position[1],
          event_time: new Date(eventTime).toISOString(),
          capacity: capacity ? parseInt(capacity) : void 0,
          budget: normalizedBudget,
          visibility,
          tag_ids
        });
        onEventCreated(event);
      } else {
        const plan = await createPlan({
          name: name.trim(),
          description: description.trim() || void 0,
          lat: position[0],
          lng: position[1],
          budget: normalizedBudget,
          visibility,
          tag_ids
        });
        onPlanCreated(plan);
      }
      setName("");
      setDescription("");
      setEventTime("");
      setCapacity("");
      setBudget("");
      setVisibility("public");
      setSelectedTagIds(/* @__PURE__ */ new Set());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "create-panel", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "create-panel__header", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "create-panel__title", children: "New marker" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 114,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "create-panel__close", onClick: onCancel, children: "✕" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 115,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
      lineNumber: 113,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "create-panel__type-toggle", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: `create-panel__type-btn ${type === "event" ? "create-panel__type-btn--active-event" : ""}`,
          onClick: () => setType("event"),
          children: "🗓 Event"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 119,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: `create-panel__type-btn ${type === "plan" ? "create-panel__type-btn--active-plan" : ""}`,
          onClick: () => setType("plan"),
          children: "📋 Plan"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 126,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
      lineNumber: 118,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("form", { className: "create-panel__form", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Name *" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 137,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            className: "create-panel__input",
            value: name,
            onChange: (e) => setName(e.target.value),
            placeholder: type === "event" ? "Morning run" : "Weekend trip",
            required: true
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
            lineNumber: 138,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 136,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Description" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 148,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            className: "create-panel__input create-panel__textarea",
            rows: 2,
            value: description,
            onChange: (e) => setDescription(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
            lineNumber: 149,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 147,
        columnNumber: 17
      }, this),
      type === "event" && /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Date & Time *" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 159,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            className: "create-panel__input",
            type: "datetime-local",
            value: eventTime,
            onChange: (e) => setEventTime(e.target.value),
            required: true
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
            lineNumber: 160,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 158,
        columnNumber: 9
      }, this),
      type === "event" && /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Capacity" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 172,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            className: "create-panel__input",
            type: "number",
            min: "1",
            value: capacity,
            onChange: (e) => setCapacity(e.target.value),
            placeholder: "Unlimited"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
            lineNumber: 173,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 171,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Budget (€) *" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 185,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            className: "create-panel__input",
            type: "number",
            min: "0",
            step: "0.01",
            value: budget,
            onChange: (e) => setBudget(e.target.value),
            placeholder: "0 for free"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
            lineNumber: 186,
            columnNumber: 21
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "create-panel__hint", children: "Leave blank to mark it as free." }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 195,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 184,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Visibility" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 199,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "create-panel__visibility", children: [
          ["public", "Public", "Everyone can discover it"],
          ["friends", "Friends", "Only accepted friends can discover it"],
          ["private", "Private", "Only you can see it"]
        ].map(
          ([value, label, hint]) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: `create-panel__visibility-btn ${visibility === value ? "create-panel__visibility-btn--active" : ""}`,
              onClick: () => setVisibility(value),
              children: [
                /* @__PURE__ */ jsxDEV("strong", { children: label }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
                  lineNumber: 212,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: hint }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
                  lineNumber: 213,
                  columnNumber: 33
                }, this)
              ]
            },
            value,
            true,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
              lineNumber: 206,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 200,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 198,
        columnNumber: 17
      }, this),
      availableTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "create-panel__field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "create-panel__label", children: "Tags" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 221,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "create-panel__tags", children: availableTags.map(
          (tag) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: `create-panel__tag-btn ${selectedTagIds.has(tag.id) ? "create-panel__tag-btn--active" : ""}`,
              onClick: () => toggleTag(tag.id),
              children: [
                "#",
                tag.name
              ]
            },
            tag.id,
            true,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
              lineNumber: 224,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 222,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 220,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "create-panel__error", children: error }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
        lineNumber: 237,
        columnNumber: 27
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: `create-panel__submit create-panel__submit--${type}`,
          disabled: saving,
          children: saving ? "Creating…" : `Create ${type}`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
          lineNumber: 239,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
      lineNumber: 135,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx",
    lineNumber: 112,
    columnNumber: 5
  }, this);
}
_s(CreatePanel, "dFVmCSoDV50FjleOwZ+2jxgttUo=");
_c = CreatePanel;
var _c;
$RefreshReg$(_c, "CreatePanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/CreatePanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEZnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5RmhCLFNBQW9CQSxnQkFBZ0I7QUFDcEMsU0FBU0MsYUFBYUMsa0JBQXNEO0FBVTVFLHdCQUF3QkMsWUFBWTtBQUFBLEVBQ2hDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNHLEdBQUc7QUFBQUMsS0FBQTtBQUNOLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJWCxTQUEyQixPQUFPO0FBQzFELFFBQU0sQ0FBQ1ksTUFBTUMsT0FBTyxJQUFJYixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDYyxhQUFhQyxjQUFjLElBQUlmLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNnQixXQUFXQyxZQUFZLElBQUlqQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDa0IsVUFBVUMsV0FBVyxJQUFJbkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ29CLFFBQVFDLFNBQVMsSUFBSXJCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNzQixZQUFZQyxhQUFhLElBQUl2QixTQUFxQixRQUFRO0FBQ2pFLFFBQU0sQ0FBQ3dCLGdCQUFnQkMsaUJBQWlCLElBQUl6QixTQUFzQixvQkFBSTBCLElBQUksQ0FBQztBQUMzRSxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTVCLFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUM2QixPQUFPQyxRQUFRLElBQUk5QixTQUFTLEVBQUU7QUFFckMsTUFBSSxDQUFDSTtBQUFVLFdBQU87QUFFdEIsUUFBTTJCLFlBQVlBLENBQUNDLFVBQWtCO0FBQ2pDUCxzQkFBa0IsQ0FBQ1EsU0FBUztBQUN4QixZQUFNQyxPQUFPLElBQUlSLElBQUlPLElBQUk7QUFDekJDLFdBQUtDLElBQUlILEtBQUssSUFBSUUsS0FBS0UsT0FBT0osS0FBSyxJQUFJRSxLQUFLRyxJQUFJTCxLQUFLO0FBQ3JELGFBQU9FO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNSSxlQUFlLE9BQU9DLE1BQWlCO0FBQ3pDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQzVCLEtBQUs2QixLQUFLO0FBQUc7QUFDbEJiLGNBQVUsSUFBSTtBQUNkRSxhQUFTLEVBQUU7QUFDWCxRQUFJO0FBQ0EsWUFBTVksVUFBVSxDQUFDLEdBQUdsQixjQUFjO0FBQ2xDLFlBQU1tQixtQkFBbUJ2QixPQUFPcUIsS0FBSyxNQUFNLEtBQUssSUFBSUcsV0FBV3hCLE1BQU07QUFDckUsVUFBSSxDQUFDeUIsT0FBT0MsU0FBU0gsZ0JBQWdCLEtBQUtBLG1CQUFtQixHQUFHO0FBQzVELGNBQU0sSUFBSUksTUFBTSxzQ0FBc0M7QUFBQSxNQUMxRDtBQUVBLFVBQUlyQyxTQUFTLFNBQVM7QUFDbEIsWUFBSSxDQUFDTTtBQUFXLGdCQUFNLElBQUkrQixNQUFNLHdCQUF3QjtBQUN4RCxjQUFNQyxRQUFRLE1BQU0vQyxZQUFZO0FBQUEsVUFDNUJXLE1BQU1BLEtBQUs2QixLQUFLO0FBQUEsVUFDaEIzQixhQUFhQSxZQUFZMkIsS0FBSyxLQUFLUTtBQUFBQSxVQUNuQ0MsS0FBSzlDLFNBQVMsQ0FBQztBQUFBLFVBQ2YrQyxLQUFLL0MsU0FBUyxDQUFDO0FBQUEsVUFDZmdELFlBQVksSUFBSUMsS0FBS3JDLFNBQVMsRUFBRXNDLFlBQVk7QUFBQSxVQUM1Q3BDLFVBQVVBLFdBQVdxQyxTQUFTckMsUUFBUSxJQUFJK0I7QUFBQUEsVUFDMUM3QixRQUFRdUI7QUFBQUEsVUFDUnJCO0FBQUFBLFVBQ0FvQjtBQUFBQSxRQUNKLENBQUM7QUFDRHBDLHVCQUFlMEMsS0FBSztBQUFBLE1BQ3hCLE9BQU87QUFDSCxjQUFNUSxPQUFPLE1BQU10RCxXQUFXO0FBQUEsVUFDMUJVLE1BQU1BLEtBQUs2QixLQUFLO0FBQUEsVUFDaEIzQixhQUFhQSxZQUFZMkIsS0FBSyxLQUFLUTtBQUFBQSxVQUNuQ0MsS0FBSzlDLFNBQVMsQ0FBQztBQUFBLFVBQ2YrQyxLQUFLL0MsU0FBUyxDQUFDO0FBQUEsVUFDZmdCLFFBQVF1QjtBQUFBQSxVQUNSckI7QUFBQUEsVUFDQW9CO0FBQUFBLFFBQ0osQ0FBQztBQUNEbkMsc0JBQWNpRCxJQUFJO0FBQUEsTUFDdEI7QUFDQTNDLGNBQVEsRUFBRTtBQUNWRSxxQkFBZSxFQUFFO0FBQ2pCRSxtQkFBYSxFQUFFO0FBQ2ZFLGtCQUFZLEVBQUU7QUFDZEUsZ0JBQVUsRUFBRTtBQUNaRSxvQkFBYyxRQUFRO0FBQ3RCRSx3QkFBa0Isb0JBQUlDLElBQUksQ0FBQztBQUFBLElBQy9CLFNBQVMrQixLQUFjO0FBQ25CM0IsZUFBUzJCLGVBQWVWLFFBQVFVLElBQUlDLFVBQVUsc0JBQXNCO0FBQUEsSUFDeEUsVUFBQztBQUNHOUIsZ0JBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDSjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGdCQUNYO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHVCQUFzQiwwQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQ2hELHVCQUFDLFlBQU8sV0FBVSx1QkFBc0IsU0FBU3BCLFVBQVUsaUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxTQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxXQUFXLDBCQUEwQkUsU0FBUyxVQUFVLHlDQUF5QyxFQUFFO0FBQUEsVUFDbkcsU0FBUyxNQUFNQyxRQUFRLE9BQU87QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUhwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFdBQVcsMEJBQTBCRCxTQUFTLFNBQVMsd0NBQXdDLEVBQUU7QUFBQSxVQUNqRyxTQUFTLE1BQU1DLFFBQVEsTUFBTTtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBSG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxzQkFBcUIsVUFBVTJCLGNBQzNDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHVCQUFzQixzQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQzdDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFVO0FBQUEsWUFDVixPQUFPMUI7QUFBQUEsWUFDUCxVQUFVLENBQUMyQixNQUFNMUIsUUFBUTBCLEVBQUVvQixPQUFPQyxLQUFLO0FBQUEsWUFDdkMsYUFBYWxELFNBQVMsVUFBVSxnQkFBZ0I7QUFBQSxZQUNoRCxVQUFRO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtZO0FBQUEsV0FQaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLDJCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLE1BQU07QUFBQSxZQUNOLE9BQU9JO0FBQUFBLFlBQ1AsVUFBVSxDQUFDeUIsTUFBTXhCLGVBQWV3QixFQUFFb0IsT0FBT0MsS0FBSztBQUFBO0FBQUEsVUFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSW9EO0FBQUEsV0FOeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQ2xELFNBQVMsV0FDTix1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLDZCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFDcEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLE9BQU9NO0FBQUFBLFlBQ1AsVUFBVSxDQUFDdUIsTUFBTXRCLGFBQWFzQixFQUFFb0IsT0FBT0MsS0FBSztBQUFBLFlBQzVDLFVBQVE7QUFBQTtBQUFBLFVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS1k7QUFBQSxXQVBoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUdIbEQsU0FBUyxXQUNOLHVCQUFDLFNBQUksV0FBVSx1QkFDWDtBQUFBLCtCQUFDLFdBQU0sV0FBVSx1QkFBc0Isd0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUMvQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBVTtBQUFBLFlBQ1YsTUFBSztBQUFBLFlBQ0wsS0FBSTtBQUFBLFlBQ0osT0FBT1E7QUFBQUEsWUFDUCxVQUFVLENBQUNxQixNQUFNcEIsWUFBWW9CLEVBQUVvQixPQUFPQyxLQUFLO0FBQUEsWUFDM0MsYUFBWTtBQUFBO0FBQUEsVUFOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTTJCO0FBQUEsV0FSL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHSix1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLDRCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1EO0FBQUEsUUFDbkQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLEtBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLE9BQU94QztBQUFBQSxZQUNQLFVBQVUsQ0FBQ21CLE1BQU1sQixVQUFVa0IsRUFBRW9CLE9BQU9DLEtBQUs7QUFBQSxZQUN6QyxhQUFZO0FBQUE7QUFBQSxVQVBoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPNEI7QUFBQSxRQUU1Qix1QkFBQyxVQUFLLFdBQVUsc0JBQXFCLCtDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsV0FYeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLDBCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFDakQsdUJBQUMsU0FBSSxXQUFVLDRCQUNUO0FBQUEsVUFDRSxDQUFDLFVBQVUsVUFBVSwwQkFBMEI7QUFBQSxVQUMvQyxDQUFDLFdBQVcsV0FBVyx1Q0FBdUM7QUFBQSxVQUM5RCxDQUFDLFdBQVcsV0FBVyxxQkFBcUI7QUFBQSxRQUFDLEVBQ3JDQztBQUFBQSxVQUFJLENBQUMsQ0FBQ0QsT0FBT0UsT0FBT0MsSUFBSSxNQUNoQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsTUFBSztBQUFBLGNBQ0wsV0FBVyxnQ0FBZ0N6QyxlQUFlc0MsUUFBUSx5Q0FBeUMsRUFBRTtBQUFBLGNBQzdHLFNBQVMsTUFBTXJDLGNBQWNxQyxLQUFLO0FBQUEsY0FFbEM7QUFBQSx1Q0FBQyxZQUFRRSxtQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUEsZ0JBQ2YsdUJBQUMsVUFBTUMsa0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBO0FBQUE7QUFBQSxZQU5QSDtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFFBQ0gsS0FmTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BRUN2RCxjQUFjMkQsU0FBUyxLQUNwQix1QkFBQyxTQUFJLFdBQVUsdUJBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLG9CQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDO0FBQUEsUUFDM0MsdUJBQUMsU0FBSSxXQUFVLHNCQUNWM0Qsd0JBQWN3RDtBQUFBQSxVQUFJLENBQUNJLFFBQ2hCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFRyxNQUFLO0FBQUEsY0FDTCxXQUFXLHlCQUF5QnpDLGVBQWVXLElBQUk4QixJQUFJQyxFQUFFLElBQUksa0NBQWtDLEVBQUU7QUFBQSxjQUNyRyxTQUFTLE1BQU1uQyxVQUFVa0MsSUFBSUMsRUFBRTtBQUFBLGNBQUU7QUFBQTtBQUFBLGdCQUUvQkQsSUFBSXJEO0FBQUFBO0FBQUFBO0FBQUFBLFlBTERxRCxJQUFJQztBQUFBQSxZQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFFBQ0gsS0FWTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxXQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BR0hyQyxTQUFTLHVCQUFDLFNBQUksV0FBVSx1QkFBdUJBLG1CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRDO0FBQUEsTUFFdEQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQUs7QUFBQSxVQUNMLFdBQVcsOENBQThDbkIsSUFBSTtBQUFBLFVBQzdELFVBQVVpQjtBQUFBQSxVQUVUQSxtQkFBUyxjQUFjLFVBQVVqQixJQUFJO0FBQUE7QUFBQSxRQUwxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBOUdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErR0E7QUFBQSxPQXRJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUlBO0FBRVI7QUFBQ0QsR0ExTnVCTixhQUFXO0FBQUEsS0FBWEE7QUFBVyxJQUFBZ0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJjcmVhdGVFdmVudCIsImNyZWF0ZVBsYW4iLCJDcmVhdGVQYW5lbCIsInBvc2l0aW9uIiwiYXZhaWxhYmxlVGFncyIsIm9uRXZlbnRDcmVhdGVkIiwib25QbGFuQ3JlYXRlZCIsIm9uQ2FuY2VsIiwiX3MiLCJ0eXBlIiwic2V0VHlwZSIsIm5hbWUiLCJzZXROYW1lIiwiZGVzY3JpcHRpb24iLCJzZXREZXNjcmlwdGlvbiIsImV2ZW50VGltZSIsInNldEV2ZW50VGltZSIsImNhcGFjaXR5Iiwic2V0Q2FwYWNpdHkiLCJidWRnZXQiLCJzZXRCdWRnZXQiLCJ2aXNpYmlsaXR5Iiwic2V0VmlzaWJpbGl0eSIsInNlbGVjdGVkVGFnSWRzIiwic2V0U2VsZWN0ZWRUYWdJZHMiLCJTZXQiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJlcnJvciIsInNldEVycm9yIiwidG9nZ2xlVGFnIiwidGFnSWQiLCJwcmV2IiwibmV4dCIsImhhcyIsImRlbGV0ZSIsImFkZCIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJ0YWdfaWRzIiwibm9ybWFsaXplZEJ1ZGdldCIsInBhcnNlRmxvYXQiLCJOdW1iZXIiLCJpc0Zpbml0ZSIsIkVycm9yIiwiZXZlbnQiLCJ1bmRlZmluZWQiLCJsYXQiLCJsbmciLCJldmVudF90aW1lIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicGFyc2VJbnQiLCJwbGFuIiwiZXJyIiwibWVzc2FnZSIsInRhcmdldCIsInZhbHVlIiwibWFwIiwibGFiZWwiLCJoaW50IiwibGVuZ3RoIiwidGFnIiwiaWQiLCJfYyJdLCJzb3VyY2VzIjpbIkNyZWF0ZVBhbmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGb3JtRXZlbnQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGNyZWF0ZUV2ZW50LCBjcmVhdGVQbGFuLCBBcGlFdmVudCwgQXBpUGxhbiwgVGFnLCBWaXNpYmlsaXR5IH0gZnJvbSAnLi9hcGknXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gICAgcG9zaXRpb246IFtudW1iZXIsIG51bWJlcl0gfCBudWxsXHJcbiAgICBhdmFpbGFibGVUYWdzOiBUYWdbXVxyXG4gICAgb25FdmVudENyZWF0ZWQ6IChldmVudDogQXBpRXZlbnQpID0+IHZvaWRcclxuICAgIG9uUGxhbkNyZWF0ZWQ6IChwbGFuOiBBcGlQbGFuKSA9PiB2b2lkXHJcbiAgICBvbkNhbmNlbDogKCkgPT4gdm9pZFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDcmVhdGVQYW5lbCh7XHJcbiAgICBwb3NpdGlvbixcclxuICAgIGF2YWlsYWJsZVRhZ3MsXHJcbiAgICBvbkV2ZW50Q3JlYXRlZCxcclxuICAgIG9uUGxhbkNyZWF0ZWQsXHJcbiAgICBvbkNhbmNlbCxcclxufTogUHJvcHMpIHtcclxuICAgIGNvbnN0IFt0eXBlLCBzZXRUeXBlXSA9IHVzZVN0YXRlPCdldmVudCcgfCAncGxhbic+KCdldmVudCcpXHJcbiAgICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICAgIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoJycpXHJcbiAgICBjb25zdCBbZXZlbnRUaW1lLCBzZXRFdmVudFRpbWVdID0gdXNlU3RhdGUoJycpXHJcbiAgICBjb25zdCBbY2FwYWNpdHksIHNldENhcGFjaXR5XSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW2J1ZGdldCwgc2V0QnVkZ2V0XSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW3Zpc2liaWxpdHksIHNldFZpc2liaWxpdHldID0gdXNlU3RhdGU8VmlzaWJpbGl0eT4oJ3B1YmxpYycpXHJcbiAgICBjb25zdCBbc2VsZWN0ZWRUYWdJZHMsIHNldFNlbGVjdGVkVGFnSWRzXSA9IHVzZVN0YXRlPFNldDxudW1iZXI+PihuZXcgU2V0KCkpXHJcbiAgICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICAgIGlmICghcG9zaXRpb24pIHJldHVybiBudWxsXHJcblxyXG4gICAgY29uc3QgdG9nZ2xlVGFnID0gKHRhZ0lkOiBudW1iZXIpID0+IHtcclxuICAgICAgICBzZXRTZWxlY3RlZFRhZ0lkcygocHJldikgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KVxyXG4gICAgICAgICAgICBuZXh0Lmhhcyh0YWdJZCkgPyBuZXh0LmRlbGV0ZSh0YWdJZCkgOiBuZXh0LmFkZCh0YWdJZClcclxuICAgICAgICAgICAgcmV0dXJuIG5leHRcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBGb3JtRXZlbnQpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBpZiAoIW5hbWUudHJpbSgpKSByZXR1cm5cclxuICAgICAgICBzZXRTYXZpbmcodHJ1ZSlcclxuICAgICAgICBzZXRFcnJvcignJylcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB0YWdfaWRzID0gWy4uLnNlbGVjdGVkVGFnSWRzXVxyXG4gICAgICAgICAgICBjb25zdCBub3JtYWxpemVkQnVkZ2V0ID0gYnVkZ2V0LnRyaW0oKSA9PT0gJycgPyAwIDogcGFyc2VGbG9hdChidWRnZXQpXHJcbiAgICAgICAgICAgIGlmICghTnVtYmVyLmlzRmluaXRlKG5vcm1hbGl6ZWRCdWRnZXQpIHx8IG5vcm1hbGl6ZWRCdWRnZXQgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0J1ZGdldCBtdXN0IGJlIGEgbm9uLW5lZ2F0aXZlIG51bWJlcicpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlID09PSAnZXZlbnQnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWV2ZW50VGltZSkgdGhyb3cgbmV3IEVycm9yKCdFdmVudCB0aW1lIGlzIHJlcXVpcmVkJylcclxuICAgICAgICAgICAgICAgIGNvbnN0IGV2ZW50ID0gYXdhaXQgY3JlYXRlRXZlbnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IG5hbWUudHJpbSgpLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbi50cmltKCkgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhdDogcG9zaXRpb25bMF0sXHJcbiAgICAgICAgICAgICAgICAgICAgbG5nOiBwb3NpdGlvblsxXSxcclxuICAgICAgICAgICAgICAgICAgICBldmVudF90aW1lOiBuZXcgRGF0ZShldmVudFRpbWUpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICAgICAgY2FwYWNpdHk6IGNhcGFjaXR5ID8gcGFyc2VJbnQoY2FwYWNpdHkpIDogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1ZGdldDogbm9ybWFsaXplZEJ1ZGdldCxcclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5LFxyXG4gICAgICAgICAgICAgICAgICAgIHRhZ19pZHMsXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgb25FdmVudENyZWF0ZWQoZXZlbnQpXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwbGFuID0gYXdhaXQgY3JlYXRlUGxhbih7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZS50cmltKCksXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLnRyaW0oKSB8fCB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbGF0OiBwb3NpdGlvblswXSxcclxuICAgICAgICAgICAgICAgICAgICBsbmc6IHBvc2l0aW9uWzFdLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1ZGdldDogbm9ybWFsaXplZEJ1ZGdldCxcclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5LFxyXG4gICAgICAgICAgICAgICAgICAgIHRhZ19pZHMsXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgb25QbGFuQ3JlYXRlZChwbGFuKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHNldE5hbWUoJycpXHJcbiAgICAgICAgICAgIHNldERlc2NyaXB0aW9uKCcnKVxyXG4gICAgICAgICAgICBzZXRFdmVudFRpbWUoJycpXHJcbiAgICAgICAgICAgIHNldENhcGFjaXR5KCcnKVxyXG4gICAgICAgICAgICBzZXRCdWRnZXQoJycpXHJcbiAgICAgICAgICAgIHNldFZpc2liaWxpdHkoJ3B1YmxpYycpXHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVGFnSWRzKG5ldyBTZXQoKSlcclxuICAgICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcclxuICAgICAgICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdTb21ldGhpbmcgd2VudCB3cm9uZycpXHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0U2F2aW5nKGZhbHNlKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fdGl0bGVcIj5OZXcgbWFya2VyPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2Nsb3NlXCIgb25DbGljaz17b25DYW5jZWx9PuKclTwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX190eXBlLXRvZ2dsZVwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGNyZWF0ZS1wYW5lbF9fdHlwZS1idG4gJHt0eXBlID09PSAnZXZlbnQnID8gJ2NyZWF0ZS1wYW5lbF9fdHlwZS1idG4tLWFjdGl2ZS1ldmVudCcgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFR5cGUoJ2V2ZW50Jyl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAg8J+XkyBFdmVudFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3JlYXRlLXBhbmVsX190eXBlLWJ0biAke3R5cGUgPT09ICdwbGFuJyA/ICdjcmVhdGUtcGFuZWxfX3R5cGUtYnRuLS1hY3RpdmUtcGxhbicgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFR5cGUoJ3BsYW4nKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICDwn5OLIFBsYW5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fZm9ybVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2ZpZWxkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fbGFiZWxcIj5OYW1lICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2lucHV0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0eXBlID09PSAnZXZlbnQnID8gJ01vcm5pbmcgcnVuJyA6ICdXZWVrZW5kIHRyaXAnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19sYWJlbFwiPkRlc2NyaXB0aW9uPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19pbnB1dCBjcmVhdGUtcGFuZWxfX3RleHRhcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge3R5cGUgPT09ICdldmVudCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19sYWJlbFwiPkRhdGUgJiBUaW1lICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9faW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtldmVudFRpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEV2ZW50VGltZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7dHlwZSA9PT0gJ2V2ZW50JyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2ZpZWxkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2xhYmVsXCI+Q2FwYWNpdHk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9faW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYXBhY2l0eX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2FwYWNpdHkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJVbmxpbWl0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19sYWJlbFwiPkJ1ZGdldCAo4oKsKSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnVkZ2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJ1ZGdldChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMCBmb3IgZnJlZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2hpbnRcIj5MZWF2ZSBibGFuayB0byBtYXJrIGl0IGFzIGZyZWUuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2ZpZWxkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fbGFiZWxcIj5WaXNpYmlsaXR5PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fdmlzaWJpbGl0eVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFsncHVibGljJywgJ1B1YmxpYycsICdFdmVyeW9uZSBjYW4gZGlzY292ZXIgaXQnXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFsnZnJpZW5kcycsICdGcmllbmRzJywgJ09ubHkgYWNjZXB0ZWQgZnJpZW5kcyBjYW4gZGlzY292ZXIgaXQnXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFsncHJpdmF0ZScsICdQcml2YXRlJywgJ09ubHkgeW91IGNhbiBzZWUgaXQnXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXSBhcyBjb25zdCkubWFwKChbdmFsdWUsIGxhYmVsLCBoaW50XSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3JlYXRlLXBhbmVsX192aXNpYmlsaXR5LWJ0biAke3Zpc2liaWxpdHkgPT09IHZhbHVlID8gJ2NyZWF0ZS1wYW5lbF9fdmlzaWJpbGl0eS1idG4tLWFjdGl2ZScgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpc2liaWxpdHkodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e2xhYmVsfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntoaW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHthdmFpbGFibGVUYWdzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsX19sYWJlbFwiPlRhZ3M8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNyZWF0ZS1wYW5lbF9fdGFnc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVRhZ3MubWFwKCh0YWcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGFnLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3JlYXRlLXBhbmVsX190YWctYnRuICR7c2VsZWN0ZWRUYWdJZHMuaGFzKHRhZy5pZCkgPyAnY3JlYXRlLXBhbmVsX190YWctYnRuLS1hY3RpdmUnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlVGFnKHRhZy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAje3RhZy5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJjcmVhdGUtcGFuZWxfX2Vycm9yXCI+e2Vycm9yfTwvZGl2Pn1cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3JlYXRlLXBhbmVsX19zdWJtaXQgY3JlYXRlLXBhbmVsX19zdWJtaXQtLSR7dHlwZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3NhdmluZyA/ICdDcmVhdGluZ+KApicgOiBgQ3JlYXRlICR7dHlwZX1gfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL21hcnRpL0RvY3VtZW50cy9HaXRIdWIvU29mdHdhcmUtUHJvamVjdC1HMTAvUHJvamVjdC9zcmMvQ3JlYXRlUGFuZWwudHN4In0=