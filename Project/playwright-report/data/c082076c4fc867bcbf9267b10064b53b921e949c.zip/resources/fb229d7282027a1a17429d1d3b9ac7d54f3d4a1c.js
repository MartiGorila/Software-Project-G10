import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from "/node_modules/.vite/deps/react-leaflet.js?v=523d6d0e";
import "/node_modules/leaflet/dist/leaflet.css";
import "/src/App.css?t=1780399642173";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useMemo = __vite__cjsImport6_react["useMemo"]; const useState = __vite__cjsImport6_react["useState"];
import MapMarkers from "/src/MapMarkers.tsx?t=1780399642886";
import EventDetailsSidebar from "/src/EventDetailsSidebar.tsx?t=1780399642351";
import CreatePanel from "/src/CreatePanel.tsx?t=1780399643427";
import FilterPanel from "/src/FilterPanel.tsx?t=1780399643483";
import SuggestionsPanel from "/src/SuggestionsPanel.tsx?t=1780399643517";
import ExplorePanel from "/src/ExplorePanel.tsx?t=1780399643237";
import PlannerPanel from "/src/PlannerPanel.tsx?t=1780399642934";
import TopBar from "/src/TopBar.tsx?t=1780399643365";
import ProfileModal from "/src/ProfileModal.tsx?t=1780399643427";
import PublicProfileModal from "/src/PublicProfileModal.tsx?t=1780399643427";
import SubscriptionPanel from "/src/SubscriptionPanel.tsx?t=1780399643312";
import SavedContentPanel from "/src/SavedContentPanel.tsx";
import {
  addSavedPlan,
  addSavedRoute,
  emptySavedContent,
  loadSavedContent,
  persistSavedContent,
  removeSavedPlan,
  removeSavedRoute
} from "/src/savedContent.ts";
import {
  getAuthToken,
  getCurrentUser,
  getEvents,
  getFriends,
  getFriendRequests,
  getPlans,
  getTags,
  acceptFriendRequest,
  cancelFriendRequest,
  joinEvent,
  leaveEvent,
  deleteEvent,
  deletePlan,
  rejectFriendRequest,
  removeFriend,
  sendFriendRequest,
  login,
  logout as apiLogout,
  register
} from "/src/api.ts?t=1780399643427";
import { sortTagsForDisplay } from "/src/categoryIcons.ts";
const barcelonaCenter = [41.3851, 2.1734];
function matchesTags(itemTags, selectedIds) {
  if (selectedIds.size === 0)
    return true;
  const ids = (itemTags ?? []).map((t) => t.id);
  return [...selectedIds].every((id) => ids.includes(id));
}
function MapCenterTracker({ onCenterChange }) {
  _s();
  useMapEvents({
    moveend(event) {
      const center = event.target.getCenter();
      onCenterChange([center.lat, center.lng]);
    }
  });
  return null;
}
_s(MapCenterTracker, "Ld/tk8Iz8AdZhC1l7acENaOEoCo=", false, function() {
  return [useMapEvents];
});
_c = MapCenterTracker;
function App() {
  _s2();
  const [events, setEvents] = useState([]);
  const [plans, setPlans] = useState([]);
  const [allTags, setAllTags] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [friends, setFriends] = useState([]);
  const [friendRequests, setFriendRequests] = useState({ incoming: [], outgoing: [] });
  const [friendsLoading, setFriendsLoading] = useState(false);
  const [friendsError, setFriendsError] = useState("");
  const [friendNotice, setFriendNotice] = useState("");
  const [friendNoticeExiting, setFriendNoticeExiting] = useState(false);
  const [incomingNoticeExiting, setIncomingNoticeExiting] = useState(false);
  const [dismissedIncomingCount, setDismissedIncomingCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showSplash, setShowSplash] = useState(true);
  const [splashExiting, setSplashExiting] = useState(false);
  const [joinedEventIds, setJoinedEventIds] = useState(/* @__PURE__ */ new Set());
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [mapCenter, setMapCenter] = useState(barcelonaCenter);
  const [suggestionFocus, setSuggestionFocus] = useState(null);
  const [selectedTagIds, setSelectedTagIds] = useState(/* @__PURE__ */ new Set());
  const [filterType, setFilterType] = useState("all");
  const [relevanceFilter, setRelevanceFilter] = useState("all");
  const [clickPosition, setClickPosition] = useState(null);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [authMode, setAuthMode] = useState("login");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ username: "", email: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [showOwnProfile, setShowOwnProfile] = useState(false);
  const [viewingUserId, setViewingUserId] = useState(null);
  const [showExplore, setShowExplore] = useState(false);
  const [showPlanner, setShowPlanner] = useState(false);
  const [showSavedContent, setShowSavedContent] = useState(false);
  const [savedContent, setSavedContent] = useState(emptySavedContent);
  const friendIds = useMemo(() => new Set(friends.map((friend) => friend.id)), [friends]);
  const incomingRequestByUserId = useMemo(
    () => new Map(friendRequests.incoming.map((request) => [request.requester_id, request])),
    [friendRequests.incoming]
  );
  const outgoingRequestByUserId = useMemo(
    () => new Map(friendRequests.outgoing.map((request) => [request.recipient_id, request])),
    [friendRequests.outgoing]
  );
  const savedPlanIds = useMemo(
    () => new Set(savedContent.plans.map((plan) => plan.id)),
    [savedContent.plans]
  );
  const incomingRequestCount = friendRequests.incoming.length;
  const showIncomingRequestNotice = Boolean(currentUser && incomingRequestCount > 0 && incomingRequestCount !== dismissedIncomingCount);
  const refreshData = async (user) => {
    const resolvedUser = user !== void 0 ? user : currentUser;
    const [eventsData, plansData] = await Promise.all([getEvents(), getPlans()]);
    setEvents(eventsData);
    setPlans(plansData);
    if (resolvedUser) {
      const joined = new Set(
        eventsData.filter((e) => e.event_participants?.some((p) => p.user_id === resolvedUser.id)).map((e) => e.id)
      );
      setJoinedEventIds(joined);
    }
  };
  const refreshFriends = async () => {
    if (!getAuthToken()) {
      setFriends([]);
      setFriendsError("");
      return;
    }
    try {
      setFriendsLoading(true);
      setFriendsError("");
      const data = await getFriends();
      setFriends(data);
    } catch (err) {
      setFriends([]);
      setFriendsError(err instanceof Error ? err.message : "Failed to load friends.");
    } finally {
      setFriendsLoading(false);
    }
  };
  const refreshFriendRequests = async () => {
    if (!getAuthToken()) {
      setFriendRequests({ incoming: [], outgoing: [] });
      return;
    }
    try {
      const data = await getFriendRequests();
      setFriendRequests(data);
    } catch {
      setFriendRequests({ incoming: [], outgoing: [] });
    }
  };
  useEffect(() => {
    const fadeTimer = window.setTimeout(() => setSplashExiting(true), 2850);
    const removeTimer = window.setTimeout(() => setShowSplash(false), 3200);
    return () => {
      window.clearTimeout(fadeTimer);
      window.clearTimeout(removeTimer);
    };
  }, []);
  useEffect(() => {
    const init = async () => {
      setIsLoading(true);
      try {
        const [eventsData, plansData, tagsData] = await Promise.all(
          [
            getEvents(),
            getPlans(),
            getTags()
          ]
        );
        setEvents(eventsData);
        setPlans(plansData);
        setAllTags(tagsData);
        if (getAuthToken()) {
          try {
            const user = await getCurrentUser();
            setCurrentUser(user);
            setSavedContent(loadSavedContent(user.id));
            await Promise.all([refreshFriends(), refreshFriendRequests()]);
            const joined = new Set(
              eventsData.filter((e) => e.event_participants?.some((p) => p.user_id === user.id)).map((e) => e.id)
            );
            setJoinedEventIds(joined);
          } catch {
            apiLogout();
            setCurrentUser(null);
          }
        }
      } catch (err) {
        setLoginError(err instanceof Error ? err.message : "Failed to load data");
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);
  const matchesRelevance = (item, type) => {
    if (relevanceFilter === "all")
      return true;
    if (!currentUser)
      return false;
    if (relevanceFilter === "mine") {
      return item.creator_id === currentUser.id || type === "event" && joinedEventIds.has(item.id);
    }
    if (friendIds.has(item.creator_id))
      return true;
    return type === "event" ? (item.event_participants ?? []).some((participant) => friendIds.has(participant.user_id)) : false;
  };
  const filteredEvents = (filterType === "plans" ? [] : events).filter(
    (e) => matchesTags(e.tags, selectedTagIds) && matchesRelevance(e, "event")
  );
  const filteredPlans = (filterType === "events" ? [] : plans).filter(
    (p) => matchesTags(p.tags, selectedTagIds) && matchesRelevance(p, "plan")
  );
  const visibleTags = useMemo(
    () => sortTagsForDisplay(allTags.filter((tag) => !tag.name.toLowerCase().startsWith("ci-"))),
    [allTags]
  );
  const subscribedEvents = events.filter((event) => joinedEventIds.has(event.id));
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError("");
    try {
      const data = await login(loginForm.email.trim(), loginForm.password);
      setCurrentUser(data.user);
      setSavedContent(loadSavedContent(data.user.id));
      setShowLoginForm(false);
      setLoginForm({ email: "", password: "" });
      await refreshData(data.user);
      await refreshSocialState();
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : "Login failed.");
    }
  };
  const handleRegister = async (e) => {
    e.preventDefault();
    setLoginError("");
    try {
      const data = await register(
        registerForm.username.trim(),
        registerForm.email.trim(),
        registerForm.password
      );
      setCurrentUser(data.user);
      setSavedContent(loadSavedContent(data.user.id));
      setShowLoginForm(false);
      setRegisterForm({ username: "", email: "", password: "" });
      setAuthMode("login");
      await refreshData(data.user);
      await refreshSocialState();
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : "Registration failed.");
    }
  };
  const handleLogout = () => {
    apiLogout();
    setCurrentUser(null);
    setFriends([]);
    setFriendRequests({ incoming: [], outgoing: [] });
    setFriendNotice("");
    setDismissedIncomingCount(0);
    setFriendsError("");
    setJoinedEventIds(/* @__PURE__ */ new Set());
    setShowLoginForm(false);
    setLoginError("");
    setShowOwnProfile(false);
    setShowSavedContent(false);
    setViewingUserId(null);
    setSavedContent(emptySavedContent);
    setRelevanceFilter("all");
  };
  const handleJoin = async (eventId) => {
    try {
      await joinEvent(eventId);
      setJoinedEventIds((prev) => /* @__PURE__ */ new Set([...prev, eventId]));
      const updated = await getEvents();
      setEvents(updated);
    } catch (err) {
      console.error("Join failed:", err);
    }
  };
  const handleLeave = async (eventId) => {
    try {
      await leaveEvent(eventId);
      setJoinedEventIds((prev) => {
        const s = new Set(prev);
        s.delete(eventId);
        return s;
      });
      const updated = await getEvents();
      setEvents(updated);
    } catch (err) {
      console.error("Leave failed:", err);
    }
  };
  const handleDeleteEvent = async (eventId) => {
    try {
      await deleteEvent(eventId);
      setEvents((prev) => prev.filter((e) => e.id !== eventId));
    } catch (err) {
      console.error("Delete event failed:", err);
    }
  };
  const handleDeletePlan = async (planId) => {
    try {
      await deletePlan(planId);
      setPlans((prev) => prev.filter((p) => p.id !== planId));
    } catch (err) {
      console.error("Delete plan failed:", err);
    }
  };
  const handleEventCreated = async (_event) => {
    setClickPosition(null);
    const [updatedEvents, tags] = await Promise.all([getEvents(), getTags()]);
    setEvents(updatedEvents);
    setAllTags(tags);
  };
  const handlePlanCreated = async (_plan) => {
    setClickPosition(null);
    const [updatedPlans, tags] = await Promise.all([getPlans(), getTags()]);
    setPlans(updatedPlans);
    setAllTags(tags);
  };
  const selectedEvent = selectedEventId ? events.find((event) => event.id === selectedEventId) ?? null : null;
  const handleSelectEvent = (eventId) => {
    setSelectedEventId(eventId);
  };
  const handleCloseEventDetails = () => {
    setSelectedEventId(null);
  };
  const handleSelectSuggestion = (suggestion) => {
    setSuggestionFocus([suggestion.lat, suggestion.lng]);
    if (suggestion.type === "event") {
      setSelectedEventId(suggestion.id);
    }
  };
  const handleSelectExplorePlan = (position) => {
    setSuggestionFocus(position);
  };
  const handleCenterOnMap = (position) => {
    setSuggestionFocus(position);
  };
  const setAndPersistSavedContent = (next) => {
    if (!currentUser)
      return;
    setSavedContent(next);
    persistSavedContent(currentUser.id, next);
  };
  const handleSavePlan = (plan) => {
    if (!currentUser)
      return { saved: false, message: "Log in to save plans." };
    const result = addSavedPlan(savedContent, plan);
    setAndPersistSavedContent(result.state);
    return {
      saved: !result.duplicate,
      message: result.duplicate ? "Plan already saved." : "Plan saved."
    };
  };
  const handleSaveRoute = (route) => {
    if (!currentUser)
      return { saved: false, message: "Log in to save routes." };
    setAndPersistSavedContent(addSavedRoute(savedContent, route));
    return { saved: true, message: "Route saved." };
  };
  const handleRemoveSavedPlan = (planId) => {
    setAndPersistSavedContent(removeSavedPlan(savedContent, planId));
  };
  const handleRemoveSavedRoute = (routeId) => {
    setAndPersistSavedContent(removeSavedRoute(savedContent, routeId));
  };
  const handleToggleTag = (tagId) => {
    setSelectedTagIds((prev) => {
      const next = new Set(prev);
      next.has(tagId) ? next.delete(tagId) : next.add(tagId);
      return next;
    });
  };
  const handleClearFilters = () => {
    setSelectedTagIds(/* @__PURE__ */ new Set());
    setFilterType("all");
    setRelevanceFilter("all");
  };
  const handleProfileUpdated = () => {
    getCurrentUser().then(setCurrentUser).catch(console.error);
  };
  const refreshSocialState = async () => {
    await Promise.all([refreshFriends(), refreshFriendRequests()]);
  };
  const showFriendNotice = (message) => {
    setFriendNotice(message);
    setFriendNoticeExiting(false);
    window.setTimeout(() => {
      setFriendNoticeExiting(true);
      window.setTimeout(() => {
        setFriendNotice((current) => current === message ? "" : current);
        setFriendNoticeExiting(false);
      }, 320);
    }, 3e3);
  };
  const dismissIncomingNotice = () => {
    if (!showIncomingRequestNotice || incomingNoticeExiting)
      return;
    setIncomingNoticeExiting(true);
    window.setTimeout(() => {
      setDismissedIncomingCount(incomingRequestCount);
      setIncomingNoticeExiting(false);
    }, 320);
  };
  const dismissFriendNotices = () => {
    if (friendNotice && !friendNoticeExiting) {
      setFriendNoticeExiting(true);
      window.setTimeout(() => {
        setFriendNotice("");
        setFriendNoticeExiting(false);
      }, 320);
    }
    dismissIncomingNotice();
  };
  useEffect(() => {
    if (!showIncomingRequestNotice)
      return;
    const timer = window.setTimeout(() => {
      dismissIncomingNotice();
    }, 7e3);
    return () => window.clearTimeout(timer);
  }, [incomingRequestCount, showIncomingRequestNotice, incomingNoticeExiting]);
  const handleSendFriendRequest = async (userId) => {
    await sendFriendRequest(userId);
    await refreshSocialState();
    showFriendNotice("Friend request sent.");
  };
  const handleAcceptFriendRequest = async (requestId) => {
    await acceptFriendRequest(requestId);
    await refreshSocialState();
    showFriendNotice("Friend request accepted.");
  };
  const handleRejectFriendRequest = async (requestId) => {
    await rejectFriendRequest(requestId);
    await refreshSocialState();
    showFriendNotice("Friend request rejected.");
  };
  const handleCancelFriendRequest = async (requestId) => {
    await cancelFriendRequest(requestId);
    await refreshSocialState();
    showFriendNotice("Friend request cancelled.");
  };
  const handleRemoveFriend = async (userId) => {
    await removeFriend(userId);
    await refreshSocialState();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "map-shell", onPointerDown: dismissFriendNotices, children: [
    showSplash && /* @__PURE__ */ jsxDEV("div", { className: `rove-splash ${splashExiting ? "rove-splash--exit" : ""}`, "aria-label": "Loading Rove", children: /* @__PURE__ */ jsxDEV("div", { className: "rove-splash__content", children: [
      /* @__PURE__ */ jsxDEV("img", { src: "/rove-mark-white.png", alt: "Rove", className: "rove-splash__logo" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 558,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rove-splash__progress", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 560,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 559,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 557,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 556,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      TopBar,
      {
        currentUser,
        onOpenExplore: () => setShowExplore(true),
        onOpenPlanner: () => setShowPlanner(true),
        onOpenProfile: () => setShowOwnProfile(true),
        onOpenSavedContent: () => setShowSavedContent(true),
        onLoginClick: () => {
          setShowLoginForm((v) => !v);
          setLoginError("");
        },
        onLogout: handleLogout
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 565,
        columnNumber: 13
      },
      this
    ),
    (showIncomingRequestNotice || friendNotice) && /* @__PURE__ */ jsxDEV("div", { className: "friend-notice-stack", "aria-live": "polite", onPointerDown: (event) => event.stopPropagation(), children: [
      showIncomingRequestNotice && /* @__PURE__ */ jsxDEV(
        "a",
        {
          className: `friend-notice friend-notice--request ${incomingNoticeExiting ? "friend-notice--exit" : ""}`,
          href: "#friends-panel",
          onClick: dismissIncomingNotice,
          children: incomingRequestCount === 1 ? "You have 1 new friend request" : `You have ${incomingRequestCount} new friend requests`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 581,
          columnNumber: 9
        },
        this
      ),
      friendNotice && /* @__PURE__ */ jsxDEV("div", { className: `friend-notice friend-notice--success ${friendNoticeExiting ? "friend-notice--exit" : ""}`, children: friendNotice }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 592,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 579,
      columnNumber: 7
    }, this),
    showExplore && /* @__PURE__ */ jsxDEV(
      ExplorePanel,
      {
        events,
        plans,
        mapCenter,
        selectedTagIds,
        tags: visibleTags,
        onClose: () => setShowExplore(false),
        onSelectEvent: handleSelectEvent,
        onSelectPlan: handleSelectExplorePlan,
        isLoggedIn: !!currentUser,
        savedPlanIds,
        joinedEventIds,
        onSavePlan: handleSavePlan,
        onSubscribeEvent: handleJoin,
        onUnsubscribeEvent: handleLeave
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 600,
        columnNumber: 7
      },
      this
    ),
    showPlanner && /* @__PURE__ */ jsxDEV(
      PlannerPanel,
      {
        events,
        plans,
        mapCenter,
        tags: visibleTags,
        onClose: () => setShowPlanner(false),
        onOpenEventDetails: handleSelectEvent,
        onCenterOnMap: handleCenterOnMap,
        isLoggedIn: !!currentUser,
        onSaveRoute: handleSaveRoute
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 619,
        columnNumber: 7
      },
      this
    ),
    !currentUser && showLoginForm && /* @__PURE__ */ jsxDEV("div", { className: "top-auth-popover", children: /* @__PURE__ */ jsxDEV("div", { className: "top-auth-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-mode-row", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "popup-button",
            onClick: () => {
              setAuthMode("login");
              setLoginError("");
            },
            disabled: authMode === "login",
            children: "Login"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 636,
            columnNumber: 29
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "popup-button",
            onClick: () => {
              setAuthMode("register");
              setLoginError("");
            },
            disabled: authMode === "register",
            children: "Register"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 639,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 635,
        columnNumber: 25
      }, this),
      authMode === "login" ? /* @__PURE__ */ jsxDEV("form", { className: "login-form", onSubmit: handleLogin, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "login-field", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "login-email", children: "Email" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 646,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "login-email",
              className: "popup-input",
              type: "email",
              value: loginForm.email,
              onChange: (e) => setLoginForm({ ...loginForm, email: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 647,
              columnNumber: 37
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 645,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "login-field", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "login-password", children: "Password" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 652,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "login-password",
              className: "popup-input",
              type: "password",
              value: loginForm.password,
              onChange: (e) => setLoginForm({ ...loginForm, password: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 653,
              columnNumber: 37
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 651,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "popup-submit", children: "Sign in" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 657,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 644,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("form", { className: "login-form", onSubmit: handleRegister, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "login-field", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "register-username", children: "Username" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 662,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "register-username",
              className: "popup-input",
              value: registerForm.username,
              onChange: (e) => setRegisterForm({ ...registerForm, username: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 663,
              columnNumber: 37
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 661,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "login-field", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "register-email", children: "Email" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 668,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "register-email",
              className: "popup-input",
              type: "email",
              value: registerForm.email,
              onChange: (e) => setRegisterForm({ ...registerForm, email: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 669,
              columnNumber: 37
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 667,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "login-field", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "register-password", children: "Password" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 674,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "register-password",
              className: "popup-input",
              type: "password",
              value: registerForm.password,
              onChange: (e) => setRegisterForm({ ...registerForm, password: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 675,
              columnNumber: 37
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 673,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "popup-submit", children: "Register" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 679,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 660,
        columnNumber: 11
      }, this),
      isLoading && /* @__PURE__ */ jsxDEV("div", { className: "login-info", children: "Loading map data..." }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 682,
        columnNumber: 39
      }, this),
      loginError && /* @__PURE__ */ jsxDEV("div", { className: "login-error", children: loginError }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 683,
        columnNumber: 40
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 634,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 633,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "app-main", children: [
      /* @__PURE__ */ jsxDEV("section", { className: "map-card", "aria-label": "Explore map", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "map-card__header", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "map-card__eyebrow", children: "Barcelona live map" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 692,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("h1", { children: "Explore events and plans nearby" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 693,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 691,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Click the map to create something new, or select an event marker to see details." }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 695,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 690,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "map-card__body", children: [
          /* @__PURE__ */ jsxDEV(
            MapContainer,
            {
              className: "leaflet-container",
              center: barcelonaCenter,
              zoom: 14,
              style: { height: "100%" },
              children: [
                /* @__PURE__ */ jsxDEV(
                  TileLayer,
                  {
                    url: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
                    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors © <a href="https://carto.com/attributions">CARTO</a>'
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
                    lineNumber: 705,
                    columnNumber: 29
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Marker, { position: barcelonaCenter, children: /* @__PURE__ */ jsxDEV(Popup, { children: "Barcelona center: Plaça de Catalunya." }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
                  lineNumber: 711,
                  columnNumber: 33
                }, this) }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
                  lineNumber: 710,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(MapCenterTracker, { onCenterChange: setMapCenter }, void 0, false, {
                  fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
                  lineNumber: 714,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  MapMarkers,
                  {
                    events: filteredEvents,
                    plans: filteredPlans,
                    currentUserId: currentUser?.id ?? null,
                    isLoggedIn: !!currentUser,
                    savedPlanIds,
                    onDeletePlan: handleDeletePlan,
                    onSavePlan: handleSavePlan,
                    onViewUserProfile: setViewingUserId,
                    onMapClick: setClickPosition,
                    clickPosition,
                    onCloseClick: () => setClickPosition(null),
                    onEventSelect: handleSelectEvent,
                    focusPosition: suggestionFocus
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
                    lineNumber: 716,
                    columnNumber: 29
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 699,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "map-scrim", "aria-hidden": "true" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 732,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 698,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "map-legend", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "map-legend__item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "map-legend__dot map-legend__dot--event" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 737,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Event" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 738,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 736,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "map-legend__item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "map-legend__dot map-legend__dot--plan" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 741,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Plan" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 742,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 740,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "map-legend__item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "map-legend__dot map-legend__dot--own" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 745,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Yours" }, void 0, false, {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 746,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 744,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 735,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 689,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("aside", { className: "sidebar-overlay", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "control-section", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "control-section__label", id: "explore-panel", children: "Explore filters" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 753,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            FilterPanel,
            {
              tags: visibleTags,
              selectedTagIds,
              onToggleTag: handleToggleTag,
              onClear: handleClearFilters,
              filterType,
              onFilterType: setFilterType,
              relevanceFilter,
              onRelevanceFilter: setRelevanceFilter,
              isLoggedIn: !!currentUser
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 754,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 752,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "control-section", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "control-section__label", id: "suggestions-panel", children: "Suggestions" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 768,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            SuggestionsPanel,
            {
              mapCenter,
              selectedTagIds,
              filterType,
              tags: visibleTags,
              events,
              friendIds,
              onSelectSuggestion: handleSelectSuggestion
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 769,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 767,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "control-section", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "control-section__label", id: "friends-panel", children: "Friends & subscribed events" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
            lineNumber: 781,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(
            SubscriptionPanel,
            {
              subscribedEvents,
              friends,
              friendRequests,
              friendsLoading,
              friendsError,
              onRemoveSubscription: handleLeave,
              onRemoveFriend: handleRemoveFriend,
              onAcceptFriendRequest: handleAcceptFriendRequest,
              onRejectFriendRequest: handleRejectFriendRequest,
              onCancelFriendRequest: handleCancelFriendRequest,
              onViewUserProfile: setViewingUserId,
              currentUser
            },
            void 0,
            false,
            {
              fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
              lineNumber: 782,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
          lineNumber: 780,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 751,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 688,
      columnNumber: 13
    }, this),
    selectedEvent && /* @__PURE__ */ jsxDEV("div", { className: "event-details-overlay", onClick: handleCloseEventDetails, children: /* @__PURE__ */ jsxDEV(
      EventDetailsSidebar,
      {
        event: selectedEvent,
        onClose: handleCloseEventDetails,
        isLoggedIn: !!currentUser,
        currentUserId: currentUser?.id ?? null,
        joined: joinedEventIds.has(selectedEvent.id),
        isFull: selectedEvent.capacity !== null && selectedEvent.capacity <= (selectedEvent.event_participants?.length ?? 0),
        onJoin: handleJoin,
        onLeave: handleLeave,
        onDeleteEvent: handleDeleteEvent,
        onViewUserProfile: setViewingUserId,
        friendIds
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 802,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 801,
      columnNumber: 7
    }, this),
    clickPosition && currentUser && /* @__PURE__ */ jsxDEV("div", { className: "create-panel-overlay", children: /* @__PURE__ */ jsxDEV(
      CreatePanel,
      {
        position: clickPosition,
        availableTags: visibleTags,
        onEventCreated: handleEventCreated,
        onPlanCreated: handlePlanCreated,
        onCancel: () => setClickPosition(null)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 819,
        columnNumber: 21
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
      lineNumber: 818,
      columnNumber: 7
    }, this),
    showOwnProfile && currentUser && /* @__PURE__ */ jsxDEV(
      ProfileModal,
      {
        onClose: () => setShowOwnProfile(false),
        onProfileUpdated: handleProfileUpdated
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 830,
        columnNumber: 7
      },
      this
    ),
    showSavedContent && currentUser && /* @__PURE__ */ jsxDEV(
      SavedContentPanel,
      {
        savedContent,
        events,
        onClose: () => setShowSavedContent(false),
        onOpenEventDetails: (eventId) => {
          setSelectedEventId(eventId);
          setShowSavedContent(false);
        },
        onCenterOnMap: (position) => {
          handleCenterOnMap(position);
          setShowSavedContent(false);
        },
        onRemovePlan: handleRemoveSavedPlan,
        onRemoveRoute: handleRemoveSavedRoute
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 836,
        columnNumber: 7
      },
      this
    ),
    viewingUserId && /* @__PURE__ */ jsxDEV(
      PublicProfileModal,
      {
        userId: viewingUserId,
        currentUserId: currentUser?.id ?? null,
        friendIds,
        incomingRequest: incomingRequestByUserId.get(viewingUserId) ?? null,
        outgoingRequest: outgoingRequestByUserId.get(viewingUserId) ?? null,
        onSendFriendRequest: handleSendFriendRequest,
        onAcceptFriendRequest: handleAcceptFriendRequest,
        onRemoveFriend: handleRemoveFriend,
        onClose: () => setViewingUserId(null)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
        lineNumber: 853,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx",
    lineNumber: 554,
    columnNumber: 5
  }, this);
}
_s2(App, "mnSZCtLM4dHWJaElCzykBTT+dho=");
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "MapCenterTracker");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMGhCd0I7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBMWhCeEIsU0FBU0EsY0FBY0MsV0FBV0MsUUFBUUMsT0FBT0Msb0JBQW9CO0FBQ3JFLE9BQU87QUFDUCxPQUFPO0FBQ1AsU0FBb0JDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUN4RCxPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MseUJBQXlCO0FBQ2hDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxpQkFBc0M7QUFDN0MsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msd0JBQXdCO0FBQy9CLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyx1QkFBdUI7QUFDOUI7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUdHO0FBQ1A7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxVQUFVQztBQUFBQSxFQUNWQztBQUFBQSxPQVFHO0FBQ1AsU0FBU0MsMEJBQTBCO0FBRW5DLE1BQU1DLGtCQUFvQyxDQUFDLFNBQVMsTUFBTTtBQUkxRCxTQUFTQyxZQUFZQyxVQUE2QkMsYUFBbUM7QUFDakYsTUFBSUEsWUFBWUMsU0FBUztBQUFHLFdBQU87QUFDbkMsUUFBTUMsT0FBT0gsWUFBWSxJQUFJSSxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLEVBQUU7QUFDNUMsU0FBTyxDQUFDLEdBQUdMLFdBQVcsRUFBRU0sTUFBTSxDQUFDRCxPQUFPSCxJQUFJSyxTQUFTRixFQUFFLENBQUM7QUFDMUQ7QUFFQSxTQUFTRyxpQkFBaUIsRUFBRUMsZUFBdUUsR0FBRztBQUFBQyxLQUFBO0FBQ2xHekQsZUFBYTtBQUFBLElBQ1QwRCxRQUFRQyxPQUFPO0FBQ1gsWUFBTUMsU0FBU0QsTUFBTUUsT0FBT0MsVUFBVTtBQUN0Q04scUJBQWUsQ0FBQ0ksT0FBT0csS0FBS0gsT0FBT0ksR0FBRyxDQUFDO0FBQUEsSUFDM0M7QUFBQSxFQUNKLENBQUM7QUFDRCxTQUFPO0FBQ1g7QUFBQ1AsR0FSUUYsa0JBQWdCO0FBQUEsVUFDckJ2RCxZQUFZO0FBQUE7QUFBQSxLQURQdUQ7QUFVVCxTQUFTVSxNQUFNO0FBQUFDLE1BQUE7QUFDWCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWpFLFNBQXFCLEVBQUU7QUFDbkQsUUFBTSxDQUFDa0UsT0FBT0MsUUFBUSxJQUFJbkUsU0FBb0IsRUFBRTtBQUNoRCxRQUFNLENBQUNvRSxTQUFTQyxVQUFVLElBQUlyRSxTQUFnQixFQUFFO0FBQ2hELFFBQU0sQ0FBQ3NFLGFBQWFDLGNBQWMsSUFBSXZFLFNBQTBCLElBQUk7QUFDcEUsUUFBTSxDQUFDd0UsU0FBU0MsVUFBVSxJQUFJekUsU0FBbUIsRUFBRTtBQUNuRCxRQUFNLENBQUMwRSxnQkFBZ0JDLGlCQUFpQixJQUFJM0UsU0FBaUMsRUFBRTRFLFVBQVUsSUFBSUMsVUFBVSxHQUFHLENBQUM7QUFDM0csUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJL0UsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ2dGLGNBQWNDLGVBQWUsSUFBSWpGLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNrRixjQUFjQyxlQUFlLElBQUluRixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDb0YscUJBQXFCQyxzQkFBc0IsSUFBSXJGLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUNzRix1QkFBdUJDLHdCQUF3QixJQUFJdkYsU0FBUyxLQUFLO0FBQ3hFLFFBQU0sQ0FBQ3dGLHdCQUF3QkMseUJBQXlCLElBQUl6RixTQUFTLENBQUM7QUFDdEUsUUFBTSxDQUFDMEYsV0FBV0MsWUFBWSxJQUFJM0YsU0FBUyxJQUFJO0FBQy9DLFFBQU0sQ0FBQzRGLFlBQVlDLGFBQWEsSUFBSTdGLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUM4RixlQUFlQyxnQkFBZ0IsSUFBSS9GLFNBQVMsS0FBSztBQUV4RCxRQUFNLENBQUNnRyxnQkFBZ0JDLGlCQUFpQixJQUFJakcsU0FBc0Isb0JBQUlrRyxJQUFJLENBQUM7QUFDM0UsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJcEcsU0FBd0IsSUFBSTtBQUMxRSxRQUFNLENBQUNxRyxXQUFXQyxZQUFZLElBQUl0RyxTQUEyQnlDLGVBQWU7QUFDNUUsUUFBTSxDQUFDOEQsaUJBQWlCQyxrQkFBa0IsSUFBSXhHLFNBQWtDLElBQUk7QUFHcEYsUUFBTSxDQUFDeUcsZ0JBQWdCQyxpQkFBaUIsSUFBSTFHLFNBQXNCLG9CQUFJa0csSUFBSSxDQUFDO0FBQzNFLFFBQU0sQ0FBQ1MsWUFBWUMsYUFBYSxJQUFJNUcsU0FBcUMsS0FBSztBQUM5RSxRQUFNLENBQUM2RyxpQkFBaUJDLGtCQUFrQixJQUFJOUcsU0FBMEIsS0FBSztBQUU3RSxRQUFNLENBQUMrRyxlQUFlQyxnQkFBZ0IsSUFBSWhILFNBQWtDLElBQUk7QUFFaEYsUUFBTSxDQUFDaUgsZUFBZUMsZ0JBQWdCLElBQUlsSCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDbUgsVUFBVUMsV0FBVyxJQUFJcEgsU0FBK0IsT0FBTztBQUN0RSxRQUFNLENBQUNxSCxXQUFXQyxZQUFZLElBQUl0SCxTQUFTLEVBQUV1SCxPQUFPLElBQUlDLFVBQVUsR0FBRyxDQUFDO0FBQ3RFLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJMUgsU0FBUyxFQUFFMkgsVUFBVSxJQUFJSixPQUFPLElBQUlDLFVBQVUsR0FBRyxDQUFDO0FBQzFGLFFBQU0sQ0FBQ0ksWUFBWUMsYUFBYSxJQUFJN0gsU0FBUyxFQUFFO0FBRS9DLFFBQU0sQ0FBQzhILGdCQUFnQkMsaUJBQWlCLElBQUkvSCxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDZ0ksZUFBZUMsZ0JBQWdCLElBQUlqSSxTQUF3QixJQUFJO0FBQ3RFLFFBQU0sQ0FBQ2tJLGFBQWFDLGNBQWMsSUFBSW5JLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNvSSxhQUFhQyxjQUFjLElBQUlySSxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDc0ksa0JBQWtCQyxtQkFBbUIsSUFBSXZJLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUN3SSxjQUFjQyxlQUFlLElBQUl6SSxTQUE0QmUsaUJBQWlCO0FBQ3JGLFFBQU0ySCxZQUFZM0ksUUFBUSxNQUFNLElBQUltRyxJQUFJMUIsUUFBUXpCLElBQUksQ0FBQzRGLFdBQVdBLE9BQU8xRixFQUFFLENBQUMsR0FBRyxDQUFDdUIsT0FBTyxDQUFDO0FBQ3RGLFFBQU1vRSwwQkFBMEI3STtBQUFBQSxJQUM1QixNQUFNLElBQUk4SSxJQUFJbkUsZUFBZUUsU0FBUzdCLElBQUksQ0FBQytGLFlBQVksQ0FBQ0EsUUFBUUMsY0FBY0QsT0FBTyxDQUFDLENBQUM7QUFBQSxJQUN2RixDQUFDcEUsZUFBZUUsUUFBUTtBQUFBLEVBQzVCO0FBQ0EsUUFBTW9FLDBCQUEwQmpKO0FBQUFBLElBQzVCLE1BQU0sSUFBSThJLElBQUluRSxlQUFlRyxTQUFTOUIsSUFBSSxDQUFDK0YsWUFBWSxDQUFDQSxRQUFRRyxjQUFjSCxPQUFPLENBQUMsQ0FBQztBQUFBLElBQ3ZGLENBQUNwRSxlQUFlRyxRQUFRO0FBQUEsRUFDNUI7QUFDQSxRQUFNcUUsZUFBZW5KO0FBQUFBLElBQ2pCLE1BQU0sSUFBSW1HLElBQUlzQyxhQUFhdEUsTUFBTW5CLElBQUksQ0FBQ29HLFNBQVNBLEtBQUtsRyxFQUFFLENBQUM7QUFBQSxJQUN2RCxDQUFDdUYsYUFBYXRFLEtBQUs7QUFBQSxFQUN2QjtBQUNBLFFBQU1rRix1QkFBdUIxRSxlQUFlRSxTQUFTeUU7QUFDckQsUUFBTUMsNEJBQTRCQyxRQUFRakYsZUFBZThFLHVCQUF1QixLQUFLQSx5QkFBeUI1RCxzQkFBc0I7QUFJcEksUUFBTWdFLGNBQWMsT0FBT0MsU0FBMkI7QUFDbEQsVUFBTUMsZUFBZUQsU0FBU0UsU0FBWUYsT0FBT25GO0FBQ2pELFVBQU0sQ0FBQ3NGLFlBQVlDLFNBQVMsSUFBSSxNQUFNQyxRQUFRQyxJQUFJLENBQUN6SSxVQUFVLEdBQUdHLFNBQVMsQ0FBQyxDQUFDO0FBQzNFd0MsY0FBVTJGLFVBQVU7QUFDcEJ6RixhQUFTMEYsU0FBUztBQUVsQixRQUFJSCxjQUFjO0FBQ2QsWUFBTU0sU0FBUyxJQUFJOUQ7QUFBQUEsUUFDZjBELFdBQ0tLLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsb0JBQW9CQyxLQUFLLENBQUNDLE1BQU1BLEVBQUVDLFlBQVlaLGFBQWF6RyxFQUFFLENBQUMsRUFDOUVGLElBQUksQ0FBQ21ILE1BQU1BLEVBQUVqSCxFQUFFO0FBQUEsTUFDeEI7QUFDQWdELHdCQUFrQitELE1BQU07QUFBQSxJQUM1QjtBQUFBLEVBQ0o7QUFFQSxRQUFNTyxpQkFBaUIsWUFBWTtBQUMvQixRQUFJLENBQUNuSixhQUFhLEdBQUc7QUFDakJxRCxpQkFBVyxFQUFFO0FBQ2JRLHNCQUFnQixFQUFFO0FBQ2xCO0FBQUEsSUFDSjtBQUVBLFFBQUk7QUFDQUYsd0JBQWtCLElBQUk7QUFDdEJFLHNCQUFnQixFQUFFO0FBQ2xCLFlBQU11RixPQUFPLE1BQU1qSixXQUFXO0FBQzlCa0QsaUJBQVcrRixJQUFJO0FBQUEsSUFDbkIsU0FBU0MsS0FBSztBQUNWaEcsaUJBQVcsRUFBRTtBQUNiUSxzQkFBZ0J3RixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHlCQUF5QjtBQUFBLElBQ2xGLFVBQUM7QUFDRzVGLHdCQUFrQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNKO0FBRUEsUUFBTTZGLHdCQUF3QixZQUFZO0FBQ3RDLFFBQUksQ0FBQ3hKLGFBQWEsR0FBRztBQUNqQnVELHdCQUFrQixFQUFFQyxVQUFVLElBQUlDLFVBQVUsR0FBRyxDQUFDO0FBQ2hEO0FBQUEsSUFDSjtBQUVBLFFBQUk7QUFDQSxZQUFNMkYsT0FBTyxNQUFNaEosa0JBQWtCO0FBQ3JDbUQsd0JBQWtCNkYsSUFBSTtBQUFBLElBQzFCLFFBQVE7QUFDSjdGLHdCQUFrQixFQUFFQyxVQUFVLElBQUlDLFVBQVUsR0FBRyxDQUFDO0FBQUEsSUFDcEQ7QUFBQSxFQUNKO0FBRUEvRSxZQUFVLE1BQU07QUFDWixVQUFNK0ssWUFBWUMsT0FBT0MsV0FBVyxNQUFNaEYsaUJBQWlCLElBQUksR0FBRyxJQUFJO0FBQ3RFLFVBQU1pRixjQUFjRixPQUFPQyxXQUFXLE1BQU1sRixjQUFjLEtBQUssR0FBRyxJQUFJO0FBRXRFLFdBQU8sTUFBTTtBQUNUaUYsYUFBT0csYUFBYUosU0FBUztBQUM3QkMsYUFBT0csYUFBYUQsV0FBVztBQUFBLElBQ25DO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFFTGxMLFlBQVUsTUFBTTtBQUNaLFVBQU1vTCxPQUFPLFlBQVk7QUFDckJ2RixtQkFBYSxJQUFJO0FBQ2pCLFVBQUk7QUFDQSxjQUFNLENBQUNpRSxZQUFZQyxXQUFXc0IsUUFBUSxJQUFJLE1BQU1yQixRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDeER6SSxVQUFVO0FBQUEsWUFDVkcsU0FBUztBQUFBLFlBQ1RDLFFBQVE7QUFBQSxVQUFDO0FBQUEsUUFDWjtBQUNEdUMsa0JBQVUyRixVQUFVO0FBQ3BCekYsaUJBQVMwRixTQUFTO0FBQ2xCeEYsbUJBQVc4RyxRQUFRO0FBRW5CLFlBQUkvSixhQUFhLEdBQUc7QUFDaEIsY0FBSTtBQUNBLGtCQUFNcUksT0FBTyxNQUFNcEksZUFBZTtBQUNsQ2tELDJCQUFla0YsSUFBSTtBQUNuQmhCLDRCQUFnQnpILGlCQUFpQnlJLEtBQUt4RyxFQUFFLENBQUM7QUFDekMsa0JBQU02RyxRQUFRQyxJQUFJLENBQUNRLGVBQWUsR0FBR0ssc0JBQXNCLENBQUMsQ0FBQztBQUM3RCxrQkFBTVosU0FBUyxJQUFJOUQ7QUFBQUEsY0FDZjBELFdBQ0tLLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsb0JBQW9CQyxLQUFLLENBQUNDLE1BQU1BLEVBQUVDLFlBQVliLEtBQUt4RyxFQUFFLENBQUMsRUFDdEVGLElBQUksQ0FBQ21ILE1BQU1BLEVBQUVqSCxFQUFFO0FBQUEsWUFDeEI7QUFDQWdELDhCQUFrQitELE1BQU07QUFBQSxVQUM1QixRQUFRO0FBQ0oxSCxzQkFBVTtBQUNWaUMsMkJBQWUsSUFBSTtBQUFBLFVBQ3ZCO0FBQUEsUUFDSjtBQUFBLE1BQ0osU0FBU2tHLEtBQUs7QUFDVjVDLHNCQUFjNEMsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxxQkFBcUI7QUFBQSxNQUM1RSxVQUFDO0FBQ0doRixxQkFBYSxLQUFLO0FBQUEsTUFDdEI7QUFBQSxJQUNKO0FBQ0F1RixTQUFLO0FBQUEsRUFDVCxHQUFHLEVBQUU7QUFJTCxRQUFNRSxtQkFBbUJBLENBQUNDLE1BQTBCQyxTQUEyQjtBQUMzRSxRQUFJekUsb0JBQW9CO0FBQU8sYUFBTztBQUN0QyxRQUFJLENBQUN2QztBQUFhLGFBQU87QUFFekIsUUFBSXVDLG9CQUFvQixRQUFRO0FBQzVCLGFBQU93RSxLQUFLRSxlQUFlakgsWUFBWXJCLE1BQU9xSSxTQUFTLFdBQVd0RixlQUFld0YsSUFBSUgsS0FBS3BJLEVBQUU7QUFBQSxJQUNoRztBQUVBLFFBQUl5RixVQUFVOEMsSUFBSUgsS0FBS0UsVUFBVTtBQUFHLGFBQU87QUFDM0MsV0FBT0QsU0FBUyxXQUNSRCxLQUFrQmxCLHNCQUFzQixJQUFJQyxLQUFLLENBQUNxQixnQkFBZ0IvQyxVQUFVOEMsSUFBSUMsWUFBWW5CLE9BQU8sQ0FBQyxJQUN0RztBQUFBLEVBQ1Y7QUFFQSxRQUFNb0Isa0JBQWtCL0UsZUFBZSxVQUFVLEtBQUszQyxRQUFRaUc7QUFBQUEsSUFBTyxDQUFDQyxNQUNsRXhILFlBQVl3SCxFQUFFeUIsTUFBTWxGLGNBQWMsS0FBSzJFLGlCQUFpQmxCLEdBQUcsT0FBTztBQUFBLEVBQ3RFO0FBQ0EsUUFBTTBCLGlCQUFpQmpGLGVBQWUsV0FBVyxLQUFLekMsT0FBTytGO0FBQUFBLElBQU8sQ0FBQ0ksTUFDakUzSCxZQUFZMkgsRUFBRXNCLE1BQU1sRixjQUFjLEtBQUsyRSxpQkFBaUJmLEdBQUcsTUFBTTtBQUFBLEVBQ3JFO0FBQ0EsUUFBTXdCLGNBQWM5TDtBQUFBQSxJQUNoQixNQUFNeUMsbUJBQW1CNEIsUUFBUTZGLE9BQU8sQ0FBQzZCLFFBQVEsQ0FBQ0EsSUFBSUMsS0FBS0MsWUFBWSxFQUFFQyxXQUFXLEtBQUssQ0FBQyxDQUFDO0FBQUEsSUFDM0YsQ0FBQzdILE9BQU87QUFBQSxFQUNaO0FBQ0EsUUFBTThILG1CQUFtQmxJLE9BQ3BCaUcsT0FBTyxDQUFDekcsVUFBVXdDLGVBQWV3RixJQUFJaEksTUFBTVAsRUFBRSxDQUFDO0FBSW5ELFFBQU1rSixjQUFjLE9BQU9qQyxNQUFrQztBQUN6REEsTUFBRWtDLGVBQWU7QUFDakJ2RSxrQkFBYyxFQUFFO0FBQ2hCLFFBQUk7QUFDQSxZQUFNMkMsT0FBTyxNQUFNcEksTUFBTWlGLFVBQVVFLE1BQU04RSxLQUFLLEdBQUdoRixVQUFVRyxRQUFRO0FBQ25FakQscUJBQWVpRyxLQUFLZixJQUFJO0FBQ3hCaEIsc0JBQWdCekgsaUJBQWlCd0osS0FBS2YsS0FBS3hHLEVBQUUsQ0FBQztBQUM5Q2lFLHVCQUFpQixLQUFLO0FBQ3RCSSxtQkFBYSxFQUFFQyxPQUFPLElBQUlDLFVBQVUsR0FBRyxDQUFDO0FBQ3hDLFlBQU1nQyxZQUFZZ0IsS0FBS2YsSUFBSTtBQUMzQixZQUFNNkMsbUJBQW1CO0FBQUEsSUFDN0IsU0FBUzdCLEtBQUs7QUFDVjVDLG9CQUFjNEMsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxlQUFlO0FBQUEsSUFDdEU7QUFBQSxFQUNKO0FBRUEsUUFBTTRCLGlCQUFpQixPQUFPckMsTUFBa0M7QUFDNURBLE1BQUVrQyxlQUFlO0FBQ2pCdkUsa0JBQWMsRUFBRTtBQUNoQixRQUFJO0FBQ0EsWUFBTTJDLE9BQU8sTUFBTWpJO0FBQUFBLFFBQ2ZrRixhQUFhRSxTQUFTMEUsS0FBSztBQUFBLFFBQzNCNUUsYUFBYUYsTUFBTThFLEtBQUs7QUFBQSxRQUN4QjVFLGFBQWFEO0FBQUFBLE1BQ2pCO0FBQ0FqRCxxQkFBZWlHLEtBQUtmLElBQUk7QUFDeEJoQixzQkFBZ0J6SCxpQkFBaUJ3SixLQUFLZixLQUFLeEcsRUFBRSxDQUFDO0FBQzlDaUUsdUJBQWlCLEtBQUs7QUFDdEJRLHNCQUFnQixFQUFFQyxVQUFVLElBQUlKLE9BQU8sSUFBSUMsVUFBVSxHQUFHLENBQUM7QUFDekRKLGtCQUFZLE9BQU87QUFDbkIsWUFBTW9DLFlBQVlnQixLQUFLZixJQUFJO0FBQzNCLFlBQU02QyxtQkFBbUI7QUFBQSxJQUM3QixTQUFTN0IsS0FBSztBQUNWNUMsb0JBQWM0QyxlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHNCQUFzQjtBQUFBLElBQzdFO0FBQUEsRUFDSjtBQUVBLFFBQU02QixlQUFlQSxNQUFNO0FBQ3ZCbEssY0FBVTtBQUNWaUMsbUJBQWUsSUFBSTtBQUNuQkUsZUFBVyxFQUFFO0FBQ2JFLHNCQUFrQixFQUFFQyxVQUFVLElBQUlDLFVBQVUsR0FBRyxDQUFDO0FBQ2hETSxvQkFBZ0IsRUFBRTtBQUNsQk0sOEJBQTBCLENBQUM7QUFDM0JSLG9CQUFnQixFQUFFO0FBQ2xCZ0Isc0JBQWtCLG9CQUFJQyxJQUFJLENBQUM7QUFDM0JnQixxQkFBaUIsS0FBSztBQUN0Qlcsa0JBQWMsRUFBRTtBQUNoQkUsc0JBQWtCLEtBQUs7QUFDdkJRLHdCQUFvQixLQUFLO0FBQ3pCTixxQkFBaUIsSUFBSTtBQUNyQlEsb0JBQWdCMUgsaUJBQWlCO0FBQ2pDK0YsdUJBQW1CLEtBQUs7QUFBQSxFQUM1QjtBQUlBLFFBQU0yRixhQUFhLE9BQU9DLFlBQW9CO0FBQzFDLFFBQUk7QUFDQSxZQUFNN0ssVUFBVTZLLE9BQU87QUFDdkJ6Ryx3QkFBa0IsQ0FBQzBHLFNBQVMsb0JBQUl6RyxJQUFJLENBQUMsR0FBR3lHLE1BQU1ELE9BQU8sQ0FBQyxDQUFDO0FBQ3ZELFlBQU1FLFVBQVUsTUFBTXRMLFVBQVU7QUFDaEMyQyxnQkFBVTJJLE9BQU87QUFBQSxJQUNyQixTQUFTbkMsS0FBSztBQUNWb0MsY0FBUUMsTUFBTSxnQkFBZ0JyQyxHQUFHO0FBQUEsSUFDckM7QUFBQSxFQUNKO0FBRUEsUUFBTXNDLGNBQWMsT0FBT0wsWUFBb0I7QUFDM0MsUUFBSTtBQUNBLFlBQU01SyxXQUFXNEssT0FBTztBQUN4QnpHLHdCQUFrQixDQUFDMEcsU0FBUztBQUFFLGNBQU1LLElBQUksSUFBSTlHLElBQUl5RyxJQUFJO0FBQUdLLFVBQUVDLE9BQU9QLE9BQU87QUFBRyxlQUFPTTtBQUFBQSxNQUFFLENBQUM7QUFDcEYsWUFBTUosVUFBVSxNQUFNdEwsVUFBVTtBQUNoQzJDLGdCQUFVMkksT0FBTztBQUFBLElBQ3JCLFNBQVNuQyxLQUFLO0FBQ1ZvQyxjQUFRQyxNQUFNLGlCQUFpQnJDLEdBQUc7QUFBQSxJQUN0QztBQUFBLEVBQ0o7QUFJQSxRQUFNeUMsb0JBQW9CLE9BQU9SLFlBQW9CO0FBQ2pELFFBQUk7QUFDQSxZQUFNM0ssWUFBWTJLLE9BQU87QUFDekJ6SSxnQkFBVSxDQUFDMEksU0FBU0EsS0FBSzFDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWpILE9BQU95SixPQUFPLENBQUM7QUFBQSxJQUM1RCxTQUFTakMsS0FBSztBQUNWb0MsY0FBUUMsTUFBTSx3QkFBd0JyQyxHQUFHO0FBQUEsSUFDN0M7QUFBQSxFQUNKO0FBRUEsUUFBTTBDLG1CQUFtQixPQUFPQyxXQUFtQjtBQUMvQyxRQUFJO0FBQ0EsWUFBTXBMLFdBQVdvTCxNQUFNO0FBQ3ZCakosZUFBUyxDQUFDd0ksU0FBU0EsS0FBSzFDLE9BQU8sQ0FBQ0ksTUFBTUEsRUFBRXBILE9BQU9tSyxNQUFNLENBQUM7QUFBQSxJQUMxRCxTQUFTM0MsS0FBSztBQUNWb0MsY0FBUUMsTUFBTSx1QkFBdUJyQyxHQUFHO0FBQUEsSUFDNUM7QUFBQSxFQUNKO0FBSUEsUUFBTTRDLHFCQUFxQixPQUFPQyxXQUFxQjtBQUNuRHRHLHFCQUFpQixJQUFJO0FBQ3JCLFVBQU0sQ0FBQ3VHLGVBQWU1QixJQUFJLElBQUksTUFBTTdCLFFBQVFDLElBQUksQ0FBQ3pJLFVBQVUsR0FBR0ksUUFBUSxDQUFDLENBQUM7QUFDeEV1QyxjQUFVc0osYUFBYTtBQUN2QmxKLGVBQVdzSCxJQUFJO0FBQUEsRUFDbkI7QUFFQSxRQUFNNkIsb0JBQW9CLE9BQU9DLFVBQW1CO0FBQ2hEekcscUJBQWlCLElBQUk7QUFDckIsVUFBTSxDQUFDMEcsY0FBYy9CLElBQUksSUFBSSxNQUFNN0IsUUFBUUMsSUFBSSxDQUFDdEksU0FBUyxHQUFHQyxRQUFRLENBQUMsQ0FBQztBQUN0RXlDLGFBQVN1SixZQUFZO0FBQ3JCckosZUFBV3NILElBQUk7QUFBQSxFQUNuQjtBQUNBLFFBQU1nQyxnQkFBZ0J4SCxrQkFBa0JuQyxPQUFPNEosS0FBSyxDQUFDcEssVUFBVUEsTUFBTVAsT0FBT2tELGVBQWUsS0FBSyxPQUFPO0FBQ3ZHLFFBQU0wSCxvQkFBb0JBLENBQUNuQixZQUFvQjtBQUMzQ3RHLHVCQUFtQnNHLE9BQU87QUFBQSxFQUM5QjtBQUNBLFFBQU1vQiwwQkFBMEJBLE1BQU07QUFDbEMxSCx1QkFBbUIsSUFBSTtBQUFBLEVBQzNCO0FBRUEsUUFBTTJILHlCQUF5QkEsQ0FBQ0MsZUFBaUM7QUFDN0R4SCx1QkFBbUIsQ0FBQ3dILFdBQVdwSyxLQUFLb0ssV0FBV25LLEdBQUcsQ0FBQztBQUNuRCxRQUFJbUssV0FBVzFDLFNBQVMsU0FBUztBQUM3QmxGLHlCQUFtQjRILFdBQVcvSyxFQUFFO0FBQUEsSUFDcEM7QUFBQSxFQUNKO0FBRUEsUUFBTWdMLDBCQUEwQkEsQ0FBQ0MsYUFBK0I7QUFDNUQxSCx1QkFBbUIwSCxRQUFRO0FBQUEsRUFDL0I7QUFFQSxRQUFNQyxvQkFBb0JBLENBQUNELGFBQStCO0FBQ3REMUgsdUJBQW1CMEgsUUFBUTtBQUFBLEVBQy9CO0FBSUEsUUFBTUUsNEJBQTRCQSxDQUFDQyxTQUE0QjtBQUMzRCxRQUFJLENBQUMvSjtBQUFhO0FBQ2xCbUUsb0JBQWdCNEYsSUFBSTtBQUNwQnBOLHdCQUFvQnFELFlBQVlyQixJQUFJb0wsSUFBSTtBQUFBLEVBQzVDO0FBRUEsUUFBTUMsaUJBQWlCQSxDQUFDbkYsU0FBa0I7QUFDdEMsUUFBSSxDQUFDN0U7QUFBYSxhQUFPLEVBQUVpSyxPQUFPLE9BQU81RCxTQUFTLHdCQUF3QjtBQUUxRSxVQUFNNkQsU0FBUzNOLGFBQWEySCxjQUFjVyxJQUFJO0FBQzlDaUYsOEJBQTBCSSxPQUFPQyxLQUFLO0FBRXRDLFdBQU87QUFBQSxNQUNIRixPQUFPLENBQUNDLE9BQU9FO0FBQUFBLE1BQ2YvRCxTQUFTNkQsT0FBT0UsWUFBWSx3QkFBd0I7QUFBQSxJQUN4RDtBQUFBLEVBQ0o7QUFFQSxRQUFNQyxrQkFBa0JBLENBQUNDLFVBQTJCO0FBQ2hELFFBQUksQ0FBQ3RLO0FBQWEsYUFBTyxFQUFFaUssT0FBTyxPQUFPNUQsU0FBUyx5QkFBeUI7QUFDM0V5RCw4QkFBMEJ0TixjQUFjMEgsY0FBY29HLEtBQUssQ0FBQztBQUM1RCxXQUFPLEVBQUVMLE9BQU8sTUFBTTVELFNBQVMsZUFBZTtBQUFBLEVBQ2xEO0FBRUEsUUFBTWtFLHdCQUF3QkEsQ0FBQ3pCLFdBQW1CO0FBQzlDZ0IsOEJBQTBCbE4sZ0JBQWdCc0gsY0FBYzRFLE1BQU0sQ0FBQztBQUFBLEVBQ25FO0FBRUEsUUFBTTBCLHlCQUF5QkEsQ0FBQ0MsWUFBb0I7QUFDaERYLDhCQUEwQmpOLGlCQUFpQnFILGNBQWN1RyxPQUFPLENBQUM7QUFBQSxFQUNyRTtBQUdBLFFBQU1DLGtCQUFrQkEsQ0FBQ0MsVUFBa0I7QUFDdkN2SSxzQkFBa0IsQ0FBQ2lHLFNBQVM7QUFDeEIsWUFBTTBCLE9BQU8sSUFBSW5JLElBQUl5RyxJQUFJO0FBQ3pCMEIsV0FBSzdDLElBQUl5RCxLQUFLLElBQUlaLEtBQUtwQixPQUFPZ0MsS0FBSyxJQUFJWixLQUFLYSxJQUFJRCxLQUFLO0FBQ3JELGFBQU9aO0FBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNYyxxQkFBcUJBLE1BQU07QUFDN0J6SSxzQkFBa0Isb0JBQUlSLElBQUksQ0FBQztBQUMzQlUsa0JBQWMsS0FBSztBQUNuQkUsdUJBQW1CLEtBQUs7QUFBQSxFQUM1QjtBQUlBLFFBQU1zSSx1QkFBdUJBLE1BQU07QUFDL0IvTixtQkFBZSxFQUFFZ08sS0FBSzlLLGNBQWMsRUFBRStLLE1BQU16QyxRQUFRQyxLQUFLO0FBQUEsRUFDN0Q7QUFFQSxRQUFNUixxQkFBcUIsWUFBWTtBQUNuQyxVQUFNeEMsUUFBUUMsSUFBSSxDQUFDUSxlQUFlLEdBQUdLLHNCQUFzQixDQUFDLENBQUM7QUFBQSxFQUNqRTtBQUVBLFFBQU0yRSxtQkFBbUJBLENBQUM1RSxZQUFvQjtBQUMxQ3hGLG9CQUFnQndGLE9BQU87QUFDdkJ0RiwyQkFBdUIsS0FBSztBQUM1QnlGLFdBQU9DLFdBQVcsTUFBTTtBQUNwQjFGLDZCQUF1QixJQUFJO0FBQzNCeUYsYUFBT0MsV0FBVyxNQUFNO0FBQ3BCNUYsd0JBQWdCLENBQUNxSyxZQUFZQSxZQUFZN0UsVUFBVSxLQUFLNkUsT0FBTztBQUMvRG5LLCtCQUF1QixLQUFLO0FBQUEsTUFDaEMsR0FBRyxHQUFHO0FBQUEsSUFDVixHQUFHLEdBQUk7QUFBQSxFQUNYO0FBRUEsUUFBTW9LLHdCQUF3QkEsTUFBTTtBQUNoQyxRQUFJLENBQUNuRyw2QkFBNkJoRTtBQUF1QjtBQUN6REMsNkJBQXlCLElBQUk7QUFDN0J1RixXQUFPQyxXQUFXLE1BQU07QUFDcEJ0RixnQ0FBMEIyRCxvQkFBb0I7QUFDOUM3RCwrQkFBeUIsS0FBSztBQUFBLElBQ2xDLEdBQUcsR0FBRztBQUFBLEVBQ1Y7QUFFQSxRQUFNbUssdUJBQXVCQSxNQUFNO0FBQy9CLFFBQUl4SyxnQkFBZ0IsQ0FBQ0UscUJBQXFCO0FBQ3RDQyw2QkFBdUIsSUFBSTtBQUMzQnlGLGFBQU9DLFdBQVcsTUFBTTtBQUNwQjVGLHdCQUFnQixFQUFFO0FBQ2xCRSwrQkFBdUIsS0FBSztBQUFBLE1BQ2hDLEdBQUcsR0FBRztBQUFBLElBQ1Y7QUFDQW9LLDBCQUFzQjtBQUFBLEVBQzFCO0FBRUEzUCxZQUFVLE1BQU07QUFDWixRQUFJLENBQUN3SjtBQUEyQjtBQUVoQyxVQUFNcUcsUUFBUTdFLE9BQU9DLFdBQVcsTUFBTTtBQUNsQzBFLDRCQUFzQjtBQUFBLElBQzFCLEdBQUcsR0FBSTtBQUVQLFdBQU8sTUFBTTNFLE9BQU9HLGFBQWEwRSxLQUFLO0FBQUEsRUFDMUMsR0FBRyxDQUFDdkcsc0JBQXNCRSwyQkFBMkJoRSxxQkFBcUIsQ0FBQztBQUUzRSxRQUFNc0ssMEJBQTBCLE9BQU9DLFdBQW1CO0FBQ3RELFVBQU0xTixrQkFBa0IwTixNQUFNO0FBQzlCLFVBQU12RCxtQkFBbUI7QUFDekJpRCxxQkFBaUIsc0JBQXNCO0FBQUEsRUFDM0M7QUFFQSxRQUFNTyw0QkFBNEIsT0FBT0MsY0FBc0I7QUFDM0QsVUFBTXBPLG9CQUFvQm9PLFNBQVM7QUFDbkMsVUFBTXpELG1CQUFtQjtBQUN6QmlELHFCQUFpQiwwQkFBMEI7QUFBQSxFQUMvQztBQUVBLFFBQU1TLDRCQUE0QixPQUFPRCxjQUFzQjtBQUMzRCxVQUFNOU4sb0JBQW9COE4sU0FBUztBQUNuQyxVQUFNekQsbUJBQW1CO0FBQ3pCaUQscUJBQWlCLDBCQUEwQjtBQUFBLEVBQy9DO0FBRUEsUUFBTVUsNEJBQTRCLE9BQU9GLGNBQXNCO0FBQzNELFVBQU1uTyxvQkFBb0JtTyxTQUFTO0FBQ25DLFVBQU16RCxtQkFBbUI7QUFDekJpRCxxQkFBaUIsMkJBQTJCO0FBQUEsRUFDaEQ7QUFFQSxRQUFNVyxxQkFBcUIsT0FBT0wsV0FBbUI7QUFDakQsVUFBTTNOLGFBQWEyTixNQUFNO0FBQ3pCLFVBQU12RCxtQkFBbUI7QUFBQSxFQUM3QjtBQUVBLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGFBQVksZUFBZW9ELHNCQUNyQzlKO0FBQUFBLGtCQUNHLHVCQUFDLFNBQUksV0FBVyxlQUFlRSxnQkFBZ0Isc0JBQXNCLEVBQUUsSUFBSSxjQUFXLGdCQUNsRixpQ0FBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSw2QkFBQyxTQUFJLEtBQUksd0JBQXVCLEtBQUksUUFBTyxXQUFVLHVCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFDeEUsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixlQUFZLFFBQy9DLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFLLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVKO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRztBQUFBLFFBQ0EsZUFBZSxNQUFNcUMsZUFBZSxJQUFJO0FBQUEsUUFDeEMsZUFBZSxNQUFNRSxlQUFlLElBQUk7QUFBQSxRQUN4QyxlQUFlLE1BQU1OLGtCQUFrQixJQUFJO0FBQUEsUUFDM0Msb0JBQW9CLE1BQU1RLG9CQUFvQixJQUFJO0FBQUEsUUFDbEQsY0FBYyxNQUFNO0FBQ2hCckIsMkJBQWlCLENBQUNpSixNQUFNLENBQUNBLENBQUM7QUFDMUJ0SSx3QkFBYyxFQUFFO0FBQUEsUUFDcEI7QUFBQSxRQUNBLFVBQVUyRTtBQUFBQTtBQUFBQSxNQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVUyQjtBQUFBLEtBR3pCbEQsNkJBQTZCcEUsaUJBQzNCLHVCQUFDLFNBQUksV0FBVSx1QkFBc0IsYUFBVSxVQUFTLGVBQWUsQ0FBQzFCLFVBQVVBLE1BQU00TSxnQkFBZ0IsR0FDbkc5RztBQUFBQSxtQ0FDRztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csV0FBVyx3Q0FBd0NoRSx3QkFBd0Isd0JBQXdCLEVBQUU7QUFBQSxVQUNyRyxNQUFLO0FBQUEsVUFDTCxTQUFTbUs7QUFBQUEsVUFFUnJHLG1DQUF5QixJQUNwQixrQ0FDQSxZQUFZQSxvQkFBb0I7QUFBQTtBQUFBLFFBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsTUFFSGxFLGdCQUNHLHVCQUFDLFNBQUksV0FBVyx3Q0FBd0NFLHNCQUFzQix3QkFBd0IsRUFBRSxJQUNuR0YsMEJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FmUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFHSGdELGVBQ0c7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxNQUFNMkQ7QUFBQUEsUUFDTixTQUFTLE1BQU0xRCxlQUFlLEtBQUs7QUFBQSxRQUNuQyxlQUFlMEY7QUFBQUEsUUFDZixjQUFjSTtBQUFBQSxRQUNkLFlBQVksQ0FBQyxDQUFDM0o7QUFBQUEsUUFDZDtBQUFBLFFBQ0E7QUFBQSxRQUNBLFlBQVlnSztBQUFBQSxRQUNaLGtCQUFrQjdCO0FBQUFBLFFBQ2xCLG9CQUFvQk07QUFBQUE7QUFBQUEsTUFkeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY29DO0FBQUEsSUFJdkMzRSxlQUNHO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxNQUFNeUQ7QUFBQUEsUUFDTixTQUFTLE1BQU14RCxlQUFlLEtBQUs7QUFBQSxRQUNuQyxvQkFBb0J3RjtBQUFBQSxRQUNwQixlQUFlTTtBQUFBQSxRQUNmLFlBQVksQ0FBQyxDQUFDN0o7QUFBQUEsUUFDZCxhQUFhcUs7QUFBQUE7QUFBQUEsTUFUakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU2lDO0FBQUEsSUFJcEMsQ0FBQ3JLLGVBQWUyQyxpQkFDYix1QkFBQyxTQUFJLFdBQVUsb0JBQ1gsaUNBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFPLE1BQUs7QUFBQSxZQUFTLFdBQVU7QUFBQSxZQUM1QixTQUFTLE1BQU07QUFBRUcsMEJBQVksT0FBTztBQUFHUyw0QkFBYyxFQUFFO0FBQUEsWUFBRTtBQUFBLFlBQ3pELFVBQVVWLGFBQWE7QUFBQSxZQUFTO0FBQUE7QUFBQSxVQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFeUM7QUFBQSxRQUN6QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU8sTUFBSztBQUFBLFlBQVMsV0FBVTtBQUFBLFlBQzVCLFNBQVMsTUFBTTtBQUFFQywwQkFBWSxVQUFVO0FBQUdTLDRCQUFjLEVBQUU7QUFBQSxZQUFFO0FBQUEsWUFDNUQsVUFBVVYsYUFBYTtBQUFBLFlBQVk7QUFBQTtBQUFBLFVBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUUrQztBQUFBLFdBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0NBLGFBQWEsVUFDVix1QkFBQyxVQUFLLFdBQVUsY0FBYSxVQUFVZ0YsYUFDbkM7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFDWDtBQUFBLGlDQUFDLFdBQU0sU0FBUSxlQUFjLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQ2xDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FBTSxJQUFHO0FBQUEsY0FBYyxXQUFVO0FBQUEsY0FBYyxNQUFLO0FBQUEsY0FDakQsT0FBTzlFLFVBQVVFO0FBQUFBLGNBQ2pCLFVBQVUsQ0FBQzJDLE1BQU01QyxhQUFhLEVBQUUsR0FBR0QsV0FBV0UsT0FBTzJDLEVBQUV4RyxPQUFPMk0sTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFMkU7QUFBQSxhQUovRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNYO0FBQUEsaUNBQUMsV0FBTSxTQUFRLGtCQUFpQix3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0M7QUFBQSxVQUN4QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQU0sSUFBRztBQUFBLGNBQWlCLFdBQVU7QUFBQSxjQUFjLE1BQUs7QUFBQSxjQUNwRCxPQUFPaEosVUFBVUc7QUFBQUEsY0FDakIsVUFBVSxDQUFDMEMsTUFBTTVDLGFBQWEsRUFBRSxHQUFHRCxXQUFXRyxVQUFVMEMsRUFBRXhHLE9BQU8yTSxNQUFNLENBQUM7QUFBQTtBQUFBLFlBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUU4RTtBQUFBLGFBSmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxnQkFBZSx1QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFdBYjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxjQUFhLFVBQVU5RCxnQkFDbkM7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFDWDtBQUFBLGlDQUFDLFdBQU0sU0FBUSxxQkFBb0Isd0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsVUFDM0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUFNLElBQUc7QUFBQSxjQUFvQixXQUFVO0FBQUEsY0FDcEMsT0FBTzlFLGFBQWFFO0FBQUFBLGNBQ3BCLFVBQVUsQ0FBQ3VDLE1BQU14QyxnQkFBZ0IsRUFBRSxHQUFHRCxjQUFjRSxVQUFVdUMsRUFBRXhHLE9BQU8yTSxNQUFNLENBQUM7QUFBQTtBQUFBLFlBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUVvRjtBQUFBLGFBSnhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ1g7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsa0JBQWlCLHFCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLFVBQ3JDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FBTSxJQUFHO0FBQUEsY0FBaUIsV0FBVTtBQUFBLGNBQWMsTUFBSztBQUFBLGNBQ3BELE9BQU81SSxhQUFhRjtBQUFBQSxjQUNwQixVQUFVLENBQUMyQyxNQUFNeEMsZ0JBQWdCLEVBQUUsR0FBR0QsY0FBY0YsT0FBTzJDLEVBQUV4RyxPQUFPMk0sTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFaUY7QUFBQSxhQUpyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNYO0FBQUEsaUNBQUMsV0FBTSxTQUFRLHFCQUFvQix3QkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQU0sSUFBRztBQUFBLGNBQW9CLFdBQVU7QUFBQSxjQUFjLE1BQUs7QUFBQSxjQUN2RCxPQUFPNUksYUFBYUQ7QUFBQUEsY0FDcEIsVUFBVSxDQUFDMEMsTUFBTXhDLGdCQUFnQixFQUFFLEdBQUdELGNBQWNELFVBQVUwQyxFQUFFeEcsT0FBTzJNLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRW9GO0FBQUEsYUFKeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGdCQUFlLHdCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVEO0FBQUEsV0FuQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUVIM0ssYUFBYSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxtQ0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BQzVEa0MsY0FBYyx1QkFBQyxTQUFJLFdBQVUsZUFBZUEsd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQWpENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtEQSxLQW5ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0RBO0FBQUEsSUFHSix1QkFBQyxVQUFLLFdBQVUsWUFDWjtBQUFBLDZCQUFDLGFBQVEsV0FBVSxZQUFXLGNBQVcsZUFDckM7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSxpQ0FBQyxTQUNHO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFCQUFvQixrQ0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxRQUFHLCtDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DO0FBQUEsZUFGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxnR0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBTHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNYO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVU7QUFBQSxjQUNWLFFBQVFuRjtBQUFBQSxjQUNSLE1BQU07QUFBQSxjQUNOLE9BQU8sRUFBRTZOLFFBQVEsT0FBTztBQUFBLGNBRXhCO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csS0FBSTtBQUFBLG9CQUNKLGFBQVk7QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRW1LO0FBQUEsZ0JBR25LLHVCQUFDLFVBQU8sVUFBVTdOLGlCQUNkLGlDQUFDLFNBQU0scURBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLG9CQUFpQixnQkFBZ0I2RCxnQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxnQkFFL0M7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csUUFBUW9GO0FBQUFBLG9CQUNSLE9BQU9FO0FBQUFBLG9CQUNQLGVBQWV0SCxhQUFhckIsTUFBTTtBQUFBLG9CQUNsQyxZQUFZLENBQUMsQ0FBQ3FCO0FBQUFBLG9CQUNkO0FBQUEsb0JBQ0EsY0FBYzZJO0FBQUFBLG9CQUNkLFlBQVltQjtBQUFBQSxvQkFDWixtQkFBbUJyRztBQUFBQSxvQkFDbkIsWUFBWWpCO0FBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsY0FBYyxNQUFNQSxpQkFBaUIsSUFBSTtBQUFBLG9CQUN6QyxlQUFlNkc7QUFBQUEsb0JBQ2YsZUFBZXRIO0FBQUFBO0FBQUFBLGtCQWJuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYW1DO0FBQUE7QUFBQTtBQUFBLFlBOUJ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQ0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxhQUFZLGVBQVksVUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxhQWxDakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsWUFDeEQsdUJBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsZUFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsMkNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsWUFDdkQsdUJBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFVO0FBQUEsZUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsMENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsZUFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNERBO0FBQUEsTUFFQSx1QkFBQyxXQUFNLFdBQVUsbUJBQ2pCO0FBQUEsK0JBQUMsYUFBUSxXQUFVLG1CQUNmO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBCQUF5QixJQUFHLGlCQUFnQiwrQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBTXNGO0FBQUFBLGNBQ047QUFBQSxjQUNBLGFBQWFtRDtBQUFBQSxjQUNiLFNBQVNHO0FBQUFBLGNBQ1Q7QUFBQSxjQUNBLGNBQWN2STtBQUFBQSxjQUNkO0FBQUEsY0FDQSxtQkFBbUJFO0FBQUFBLGNBQ25CLFlBQVksQ0FBQyxDQUFDeEM7QUFBQUE7QUFBQUEsWUFUbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUzhCO0FBQUEsYUFYbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFFQSx1QkFBQyxhQUFRLFdBQVUsbUJBQ2Y7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEJBQXlCLElBQUcscUJBQW9CLDJCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQzFFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRztBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQSxNQUFNdUg7QUFBQUEsY0FDTjtBQUFBLGNBQ0E7QUFBQSxjQUNBLG9CQUFvQmtDO0FBQUFBO0FBQUFBLFlBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU8rQztBQUFBLGFBVG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsYUFBUSxXQUFVLG1CQUNmO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBCQUF5QixJQUFHLGlCQUFnQiwyQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxVQUMxRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0c7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQSxzQkFBc0JoQjtBQUFBQSxjQUN0QixnQkFBZ0JtRDtBQUFBQSxjQUNoQix1QkFBdUJKO0FBQUFBLGNBQ3ZCLHVCQUF1QkU7QUFBQUEsY0FDdkIsdUJBQXVCQztBQUFBQSxjQUN2QixtQkFBbUJoSTtBQUFBQSxjQUNuQjtBQUFBO0FBQUEsWUFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZNkI7QUFBQSxhQWRqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0E3Q0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThDQTtBQUFBLFNBN0dKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4R0E7QUFBQSxJQUVDMEYsaUJBQ0csdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixTQUFTRyx5QkFDNUM7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUFvQixPQUFPSDtBQUFBQSxRQUFlLFNBQVNHO0FBQUFBLFFBQ2hELFlBQVksQ0FBQyxDQUFDeEo7QUFBQUEsUUFDZCxlQUFlQSxhQUFhckIsTUFBTTtBQUFBLFFBQ2xDLFFBQVErQyxlQUFld0YsSUFBSW1DLGNBQWMxSyxFQUFFO0FBQUEsUUFDM0MsUUFBUTBLLGNBQWM0QyxhQUFhLFFBQVE1QyxjQUFjNEMsYUFBYTVDLGNBQWN4RCxvQkFBb0JkLFVBQVU7QUFBQSxRQUNsSCxRQUFRb0Q7QUFBQUEsUUFDUixTQUFTTTtBQUFBQSxRQUNULGVBQWVHO0FBQUFBLFFBQ2YsbUJBQW1CakY7QUFBQUEsUUFDbkI7QUFBQTtBQUFBLE1BVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU3lCLEtBVjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBSUhsQixpQkFBaUJ6QyxlQUNkLHVCQUFDLFNBQUksV0FBVSx3QkFDWDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csVUFBVXlDO0FBQUFBLFFBQ1YsZUFBZThFO0FBQUFBLFFBQ2YsZ0JBQWdCd0I7QUFBQUEsUUFDaEIsZUFBZUc7QUFBQUEsUUFDZixVQUFVLE1BQU14RyxpQkFBaUIsSUFBSTtBQUFBO0FBQUEsTUFMekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSzJDLEtBTi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBR0hjLGtCQUFrQnhELGVBQ2Y7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFNBQVMsTUFBTXlELGtCQUFrQixLQUFLO0FBQUEsUUFDdEMsa0JBQWtCcUg7QUFBQUE7QUFBQUEsTUFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTJDO0FBQUEsSUFHOUM5RyxvQkFBb0JoRSxlQUNqQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0c7QUFBQSxRQUNBO0FBQUEsUUFDQSxTQUFTLE1BQU1pRSxvQkFBb0IsS0FBSztBQUFBLFFBQ3hDLG9CQUFvQixDQUFDbUUsWUFBWTtBQUM3QnRHLDZCQUFtQnNHLE9BQU87QUFDMUJuRSw4QkFBb0IsS0FBSztBQUFBLFFBQzdCO0FBQUEsUUFDQSxlQUFlLENBQUMyRixhQUFhO0FBQ3pCQyw0QkFBa0JELFFBQVE7QUFDMUIzRiw4QkFBb0IsS0FBSztBQUFBLFFBQzdCO0FBQUEsUUFDQSxjQUFjc0c7QUFBQUEsUUFDZCxlQUFlQztBQUFBQTtBQUFBQSxNQWJuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFhMEM7QUFBQSxJQUc3QzlHLGlCQUNHO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxRQUFRQTtBQUFBQSxRQUNSLGVBQWUxRCxhQUFhckIsTUFBTTtBQUFBLFFBQ2xDO0FBQUEsUUFDQSxpQkFBaUIyRix3QkFBd0I0SCxJQUFJeEksYUFBYSxLQUFLO0FBQUEsUUFDL0QsaUJBQWlCZ0Isd0JBQXdCd0gsSUFBSXhJLGFBQWEsS0FBSztBQUFBLFFBQy9ELHFCQUFxQjRIO0FBQUFBLFFBQ3JCLHVCQUF1QkU7QUFBQUEsUUFDdkIsZ0JBQWdCSTtBQUFBQSxRQUNoQixTQUFTLE1BQU1qSSxpQkFBaUIsSUFBSTtBQUFBO0FBQUEsTUFUeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUzBDO0FBQUEsT0FwVGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1VEE7QUFFUjtBQUFDbEUsSUFsd0JRRCxLQUFHO0FBQUEsTUFBSEE7QUFvd0JULGVBQWVBO0FBQUcsSUFBQTJNLElBQUFDO0FBQUEsYUFBQUQsSUFBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJNYXBDb250YWluZXIiLCJUaWxlTGF5ZXIiLCJNYXJrZXIiLCJQb3B1cCIsInVzZU1hcEV2ZW50cyIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIk1hcE1hcmtlcnMiLCJFdmVudERldGFpbHNTaWRlYmFyIiwiQ3JlYXRlUGFuZWwiLCJGaWx0ZXJQYW5lbCIsIlN1Z2dlc3Rpb25zUGFuZWwiLCJFeHBsb3JlUGFuZWwiLCJQbGFubmVyUGFuZWwiLCJUb3BCYXIiLCJQcm9maWxlTW9kYWwiLCJQdWJsaWNQcm9maWxlTW9kYWwiLCJTdWJzY3JpcHRpb25QYW5lbCIsIlNhdmVkQ29udGVudFBhbmVsIiwiYWRkU2F2ZWRQbGFuIiwiYWRkU2F2ZWRSb3V0ZSIsImVtcHR5U2F2ZWRDb250ZW50IiwibG9hZFNhdmVkQ29udGVudCIsInBlcnNpc3RTYXZlZENvbnRlbnQiLCJyZW1vdmVTYXZlZFBsYW4iLCJyZW1vdmVTYXZlZFJvdXRlIiwiZ2V0QXV0aFRva2VuIiwiZ2V0Q3VycmVudFVzZXIiLCJnZXRFdmVudHMiLCJnZXRGcmllbmRzIiwiZ2V0RnJpZW5kUmVxdWVzdHMiLCJnZXRQbGFucyIsImdldFRhZ3MiLCJhY2NlcHRGcmllbmRSZXF1ZXN0IiwiY2FuY2VsRnJpZW5kUmVxdWVzdCIsImpvaW5FdmVudCIsImxlYXZlRXZlbnQiLCJkZWxldGVFdmVudCIsImRlbGV0ZVBsYW4iLCJyZWplY3RGcmllbmRSZXF1ZXN0IiwicmVtb3ZlRnJpZW5kIiwic2VuZEZyaWVuZFJlcXVlc3QiLCJsb2dpbiIsImxvZ291dCIsImFwaUxvZ291dCIsInJlZ2lzdGVyIiwic29ydFRhZ3NGb3JEaXNwbGF5IiwiYmFyY2Vsb25hQ2VudGVyIiwibWF0Y2hlc1RhZ3MiLCJpdGVtVGFncyIsInNlbGVjdGVkSWRzIiwic2l6ZSIsImlkcyIsIm1hcCIsInQiLCJpZCIsImV2ZXJ5IiwiaW5jbHVkZXMiLCJNYXBDZW50ZXJUcmFja2VyIiwib25DZW50ZXJDaGFuZ2UiLCJfcyIsIm1vdmVlbmQiLCJldmVudCIsImNlbnRlciIsInRhcmdldCIsImdldENlbnRlciIsImxhdCIsImxuZyIsIkFwcCIsIl9zMiIsImV2ZW50cyIsInNldEV2ZW50cyIsInBsYW5zIiwic2V0UGxhbnMiLCJhbGxUYWdzIiwic2V0QWxsVGFncyIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJmcmllbmRzIiwic2V0RnJpZW5kcyIsImZyaWVuZFJlcXVlc3RzIiwic2V0RnJpZW5kUmVxdWVzdHMiLCJpbmNvbWluZyIsIm91dGdvaW5nIiwiZnJpZW5kc0xvYWRpbmciLCJzZXRGcmllbmRzTG9hZGluZyIsImZyaWVuZHNFcnJvciIsInNldEZyaWVuZHNFcnJvciIsImZyaWVuZE5vdGljZSIsInNldEZyaWVuZE5vdGljZSIsImZyaWVuZE5vdGljZUV4aXRpbmciLCJzZXRGcmllbmROb3RpY2VFeGl0aW5nIiwiaW5jb21pbmdOb3RpY2VFeGl0aW5nIiwic2V0SW5jb21pbmdOb3RpY2VFeGl0aW5nIiwiZGlzbWlzc2VkSW5jb21pbmdDb3VudCIsInNldERpc21pc3NlZEluY29taW5nQ291bnQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzaG93U3BsYXNoIiwic2V0U2hvd1NwbGFzaCIsInNwbGFzaEV4aXRpbmciLCJzZXRTcGxhc2hFeGl0aW5nIiwiam9pbmVkRXZlbnRJZHMiLCJzZXRKb2luZWRFdmVudElkcyIsIlNldCIsInNlbGVjdGVkRXZlbnRJZCIsInNldFNlbGVjdGVkRXZlbnRJZCIsIm1hcENlbnRlciIsInNldE1hcENlbnRlciIsInN1Z2dlc3Rpb25Gb2N1cyIsInNldFN1Z2dlc3Rpb25Gb2N1cyIsInNlbGVjdGVkVGFnSWRzIiwic2V0U2VsZWN0ZWRUYWdJZHMiLCJmaWx0ZXJUeXBlIiwic2V0RmlsdGVyVHlwZSIsInJlbGV2YW5jZUZpbHRlciIsInNldFJlbGV2YW5jZUZpbHRlciIsImNsaWNrUG9zaXRpb24iLCJzZXRDbGlja1Bvc2l0aW9uIiwic2hvd0xvZ2luRm9ybSIsInNldFNob3dMb2dpbkZvcm0iLCJhdXRoTW9kZSIsInNldEF1dGhNb2RlIiwibG9naW5Gb3JtIiwic2V0TG9naW5Gb3JtIiwiZW1haWwiLCJwYXNzd29yZCIsInJlZ2lzdGVyRm9ybSIsInNldFJlZ2lzdGVyRm9ybSIsInVzZXJuYW1lIiwibG9naW5FcnJvciIsInNldExvZ2luRXJyb3IiLCJzaG93T3duUHJvZmlsZSIsInNldFNob3dPd25Qcm9maWxlIiwidmlld2luZ1VzZXJJZCIsInNldFZpZXdpbmdVc2VySWQiLCJzaG93RXhwbG9yZSIsInNldFNob3dFeHBsb3JlIiwic2hvd1BsYW5uZXIiLCJzZXRTaG93UGxhbm5lciIsInNob3dTYXZlZENvbnRlbnQiLCJzZXRTaG93U2F2ZWRDb250ZW50Iiwic2F2ZWRDb250ZW50Iiwic2V0U2F2ZWRDb250ZW50IiwiZnJpZW5kSWRzIiwiZnJpZW5kIiwiaW5jb21pbmdSZXF1ZXN0QnlVc2VySWQiLCJNYXAiLCJyZXF1ZXN0IiwicmVxdWVzdGVyX2lkIiwib3V0Z29pbmdSZXF1ZXN0QnlVc2VySWQiLCJyZWNpcGllbnRfaWQiLCJzYXZlZFBsYW5JZHMiLCJwbGFuIiwiaW5jb21pbmdSZXF1ZXN0Q291bnQiLCJsZW5ndGgiLCJzaG93SW5jb21pbmdSZXF1ZXN0Tm90aWNlIiwiQm9vbGVhbiIsInJlZnJlc2hEYXRhIiwidXNlciIsInJlc29sdmVkVXNlciIsInVuZGVmaW5lZCIsImV2ZW50c0RhdGEiLCJwbGFuc0RhdGEiLCJQcm9taXNlIiwiYWxsIiwiam9pbmVkIiwiZmlsdGVyIiwiZSIsImV2ZW50X3BhcnRpY2lwYW50cyIsInNvbWUiLCJwIiwidXNlcl9pZCIsInJlZnJlc2hGcmllbmRzIiwiZGF0YSIsImVyciIsIkVycm9yIiwibWVzc2FnZSIsInJlZnJlc2hGcmllbmRSZXF1ZXN0cyIsImZhZGVUaW1lciIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJyZW1vdmVUaW1lciIsImNsZWFyVGltZW91dCIsImluaXQiLCJ0YWdzRGF0YSIsIm1hdGNoZXNSZWxldmFuY2UiLCJpdGVtIiwidHlwZSIsImNyZWF0b3JfaWQiLCJoYXMiLCJwYXJ0aWNpcGFudCIsImZpbHRlcmVkRXZlbnRzIiwidGFncyIsImZpbHRlcmVkUGxhbnMiLCJ2aXNpYmxlVGFncyIsInRhZyIsIm5hbWUiLCJ0b0xvd2VyQ2FzZSIsInN0YXJ0c1dpdGgiLCJzdWJzY3JpYmVkRXZlbnRzIiwiaGFuZGxlTG9naW4iLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJyZWZyZXNoU29jaWFsU3RhdGUiLCJoYW5kbGVSZWdpc3RlciIsImhhbmRsZUxvZ291dCIsImhhbmRsZUpvaW4iLCJldmVudElkIiwicHJldiIsInVwZGF0ZWQiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVMZWF2ZSIsInMiLCJkZWxldGUiLCJoYW5kbGVEZWxldGVFdmVudCIsImhhbmRsZURlbGV0ZVBsYW4iLCJwbGFuSWQiLCJoYW5kbGVFdmVudENyZWF0ZWQiLCJfZXZlbnQiLCJ1cGRhdGVkRXZlbnRzIiwiaGFuZGxlUGxhbkNyZWF0ZWQiLCJfcGxhbiIsInVwZGF0ZWRQbGFucyIsInNlbGVjdGVkRXZlbnQiLCJmaW5kIiwiaGFuZGxlU2VsZWN0RXZlbnQiLCJoYW5kbGVDbG9zZUV2ZW50RGV0YWlscyIsImhhbmRsZVNlbGVjdFN1Z2dlc3Rpb24iLCJzdWdnZXN0aW9uIiwiaGFuZGxlU2VsZWN0RXhwbG9yZVBsYW4iLCJwb3NpdGlvbiIsImhhbmRsZUNlbnRlck9uTWFwIiwic2V0QW5kUGVyc2lzdFNhdmVkQ29udGVudCIsIm5leHQiLCJoYW5kbGVTYXZlUGxhbiIsInNhdmVkIiwicmVzdWx0Iiwic3RhdGUiLCJkdXBsaWNhdGUiLCJoYW5kbGVTYXZlUm91dGUiLCJyb3V0ZSIsImhhbmRsZVJlbW92ZVNhdmVkUGxhbiIsImhhbmRsZVJlbW92ZVNhdmVkUm91dGUiLCJyb3V0ZUlkIiwiaGFuZGxlVG9nZ2xlVGFnIiwidGFnSWQiLCJhZGQiLCJoYW5kbGVDbGVhckZpbHRlcnMiLCJoYW5kbGVQcm9maWxlVXBkYXRlZCIsInRoZW4iLCJjYXRjaCIsInNob3dGcmllbmROb3RpY2UiLCJjdXJyZW50IiwiZGlzbWlzc0luY29taW5nTm90aWNlIiwiZGlzbWlzc0ZyaWVuZE5vdGljZXMiLCJ0aW1lciIsImhhbmRsZVNlbmRGcmllbmRSZXF1ZXN0IiwidXNlcklkIiwiaGFuZGxlQWNjZXB0RnJpZW5kUmVxdWVzdCIsInJlcXVlc3RJZCIsImhhbmRsZVJlamVjdEZyaWVuZFJlcXVlc3QiLCJoYW5kbGVDYW5jZWxGcmllbmRSZXF1ZXN0IiwiaGFuZGxlUmVtb3ZlRnJpZW5kIiwidiIsInN0b3BQcm9wYWdhdGlvbiIsInZhbHVlIiwiaGVpZ2h0IiwiY2FwYWNpdHkiLCJnZXQiLCJfYyIsIl9jMiJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWFwQ29udGFpbmVyLCBUaWxlTGF5ZXIsIE1hcmtlciwgUG9wdXAsIHVzZU1hcEV2ZW50cyB9IGZyb20gJ3JlYWN0LWxlYWZsZXQnXHJcbmltcG9ydCAnbGVhZmxldC9kaXN0L2xlYWZsZXQuY3NzJ1xyXG5pbXBvcnQgJy4vQXBwLmNzcydcclxuaW1wb3J0IHsgRm9ybUV2ZW50LCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBNYXBNYXJrZXJzIGZyb20gJy4vTWFwTWFya2VycydcclxuaW1wb3J0IEV2ZW50RGV0YWlsc1NpZGViYXIgZnJvbSAnLi9FdmVudERldGFpbHNTaWRlYmFyJ1xyXG5pbXBvcnQgQ3JlYXRlUGFuZWwgZnJvbSAnLi9DcmVhdGVQYW5lbCdcclxuaW1wb3J0IEZpbHRlclBhbmVsLCB7IFJlbGV2YW5jZUZpbHRlciB9IGZyb20gJy4vRmlsdGVyUGFuZWwnXHJcbmltcG9ydCBTdWdnZXN0aW9uc1BhbmVsIGZyb20gJy4vU3VnZ2VzdGlvbnNQYW5lbCdcclxuaW1wb3J0IEV4cGxvcmVQYW5lbCBmcm9tICcuL0V4cGxvcmVQYW5lbCdcclxuaW1wb3J0IFBsYW5uZXJQYW5lbCBmcm9tICcuL1BsYW5uZXJQYW5lbCdcclxuaW1wb3J0IFRvcEJhciBmcm9tICcuL1RvcEJhcidcclxuaW1wb3J0IFByb2ZpbGVNb2RhbCBmcm9tICcuL1Byb2ZpbGVNb2RhbCdcclxuaW1wb3J0IFB1YmxpY1Byb2ZpbGVNb2RhbCBmcm9tICcuL1B1YmxpY1Byb2ZpbGVNb2RhbCdcclxuaW1wb3J0IFN1YnNjcmlwdGlvblBhbmVsIGZyb20gJy4vU3Vic2NyaXB0aW9uUGFuZWwnXHJcbmltcG9ydCBTYXZlZENvbnRlbnRQYW5lbCBmcm9tICcuL1NhdmVkQ29udGVudFBhbmVsJ1xyXG5pbXBvcnQge1xyXG4gICAgYWRkU2F2ZWRQbGFuLFxyXG4gICAgYWRkU2F2ZWRSb3V0ZSxcclxuICAgIGVtcHR5U2F2ZWRDb250ZW50LFxyXG4gICAgbG9hZFNhdmVkQ29udGVudCxcclxuICAgIHBlcnNpc3RTYXZlZENvbnRlbnQsXHJcbiAgICByZW1vdmVTYXZlZFBsYW4sXHJcbiAgICByZW1vdmVTYXZlZFJvdXRlLFxyXG4gICAgU2F2ZWRDb250ZW50U3RhdGUsXHJcbiAgICBTYXZlZFJvdXRlRHJhZnQsXHJcbn0gZnJvbSAnLi9zYXZlZENvbnRlbnQnXHJcbmltcG9ydCB7XHJcbiAgICBnZXRBdXRoVG9rZW4sXHJcbiAgICBnZXRDdXJyZW50VXNlcixcclxuICAgIGdldEV2ZW50cyxcclxuICAgIGdldEZyaWVuZHMsXHJcbiAgICBnZXRGcmllbmRSZXF1ZXN0cyxcclxuICAgIGdldFBsYW5zLFxyXG4gICAgZ2V0VGFncyxcclxuICAgIGFjY2VwdEZyaWVuZFJlcXVlc3QsXHJcbiAgICBjYW5jZWxGcmllbmRSZXF1ZXN0LFxyXG4gICAgam9pbkV2ZW50LFxyXG4gICAgbGVhdmVFdmVudCxcclxuICAgIGRlbGV0ZUV2ZW50LFxyXG4gICAgZGVsZXRlUGxhbixcclxuICAgIHJlamVjdEZyaWVuZFJlcXVlc3QsXHJcbiAgICByZW1vdmVGcmllbmQsXHJcbiAgICBzZW5kRnJpZW5kUmVxdWVzdCxcclxuICAgIGxvZ2luLFxyXG4gICAgbG9nb3V0IGFzIGFwaUxvZ291dCxcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgQXBpRXZlbnQsXHJcbiAgICBBcGlQbGFuLFxyXG4gICAgQXV0aFVzZXIsXHJcbiAgICBGcmllbmQsXHJcbiAgICBGcmllbmRSZXF1ZXN0c1Jlc3BvbnNlLFxyXG4gICAgU3VnZ2VzdGlvblJlc3VsdCxcclxuICAgIFRhZyxcclxufSBmcm9tICcuL2FwaSdcclxuaW1wb3J0IHsgc29ydFRhZ3NGb3JEaXNwbGF5IH0gZnJvbSAnLi9jYXRlZ29yeUljb25zJ1xyXG5cclxuY29uc3QgYmFyY2Vsb25hQ2VudGVyOiBbbnVtYmVyLCBudW1iZXJdID0gWzQxLjM4NTEsIDIuMTczNF1cclxuXHJcbi8vIOKUgOKUgCBGaWx0ZXJpbmcgaGVscGVycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcclxuXHJcbmZ1bmN0aW9uIG1hdGNoZXNUYWdzKGl0ZW1UYWdzOiBUYWdbXSB8IHVuZGVmaW5lZCwgc2VsZWN0ZWRJZHM6IFNldDxudW1iZXI+KTogYm9vbGVhbiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRJZHMuc2l6ZSA9PT0gMCkgcmV0dXJuIHRydWVcclxuICAgIGNvbnN0IGlkcyA9IChpdGVtVGFncyA/PyBbXSkubWFwKCh0KSA9PiB0LmlkKVxyXG4gICAgcmV0dXJuIFsuLi5zZWxlY3RlZElkc10uZXZlcnkoKGlkKSA9PiBpZHMuaW5jbHVkZXMoaWQpKVxyXG59XHJcblxyXG5mdW5jdGlvbiBNYXBDZW50ZXJUcmFja2VyKHsgb25DZW50ZXJDaGFuZ2UgfTogeyBvbkNlbnRlckNoYW5nZTogKGNlbnRlcjogW251bWJlciwgbnVtYmVyXSkgPT4gdm9pZCB9KSB7XHJcbiAgICB1c2VNYXBFdmVudHMoe1xyXG4gICAgICAgIG1vdmVlbmQoZXZlbnQpIHtcclxuICAgICAgICAgICAgY29uc3QgY2VudGVyID0gZXZlbnQudGFyZ2V0LmdldENlbnRlcigpXHJcbiAgICAgICAgICAgIG9uQ2VudGVyQ2hhbmdlKFtjZW50ZXIubGF0LCBjZW50ZXIubG5nXSlcclxuICAgICAgICB9LFxyXG4gICAgfSlcclxuICAgIHJldHVybiBudWxsXHJcbn1cclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICAgIGNvbnN0IFtldmVudHMsIHNldEV2ZW50c10gPSB1c2VTdGF0ZTxBcGlFdmVudFtdPihbXSlcclxuICAgIGNvbnN0IFtwbGFucywgc2V0UGxhbnNdID0gdXNlU3RhdGU8QXBpUGxhbltdPihbXSlcclxuICAgIGNvbnN0IFthbGxUYWdzLCBzZXRBbGxUYWdzXSA9IHVzZVN0YXRlPFRhZ1tdPihbXSlcclxuICAgIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGU8QXV0aFVzZXIgfCBudWxsPihudWxsKVxyXG4gICAgY29uc3QgW2ZyaWVuZHMsIHNldEZyaWVuZHNdID0gdXNlU3RhdGU8RnJpZW5kW10+KFtdKVxyXG4gICAgY29uc3QgW2ZyaWVuZFJlcXVlc3RzLCBzZXRGcmllbmRSZXF1ZXN0c10gPSB1c2VTdGF0ZTxGcmllbmRSZXF1ZXN0c1Jlc3BvbnNlPih7IGluY29taW5nOiBbXSwgb3V0Z29pbmc6IFtdIH0pXHJcbiAgICBjb25zdCBbZnJpZW5kc0xvYWRpbmcsIHNldEZyaWVuZHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW2ZyaWVuZHNFcnJvciwgc2V0RnJpZW5kc0Vycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW2ZyaWVuZE5vdGljZSwgc2V0RnJpZW5kTm90aWNlXSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW2ZyaWVuZE5vdGljZUV4aXRpbmcsIHNldEZyaWVuZE5vdGljZUV4aXRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbaW5jb21pbmdOb3RpY2VFeGl0aW5nLCBzZXRJbmNvbWluZ05vdGljZUV4aXRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbZGlzbWlzc2VkSW5jb21pbmdDb3VudCwgc2V0RGlzbWlzc2VkSW5jb21pbmdDb3VudF0gPSB1c2VTdGF0ZSgwKVxyXG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXHJcbiAgICBjb25zdCBbc2hvd1NwbGFzaCwgc2V0U2hvd1NwbGFzaF0gPSB1c2VTdGF0ZSh0cnVlKVxyXG4gICAgY29uc3QgW3NwbGFzaEV4aXRpbmcsIHNldFNwbGFzaEV4aXRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gICAgY29uc3QgW2pvaW5lZEV2ZW50SWRzLCBzZXRKb2luZWRFdmVudElkc10gPSB1c2VTdGF0ZTxTZXQ8c3RyaW5nPj4obmV3IFNldCgpKVxyXG4gICAgY29uc3QgW3NlbGVjdGVkRXZlbnRJZCwgc2V0U2VsZWN0ZWRFdmVudElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgICBjb25zdCBbbWFwQ2VudGVyLCBzZXRNYXBDZW50ZXJdID0gdXNlU3RhdGU8W251bWJlciwgbnVtYmVyXT4oYmFyY2Vsb25hQ2VudGVyKVxyXG4gICAgY29uc3QgW3N1Z2dlc3Rpb25Gb2N1cywgc2V0U3VnZ2VzdGlvbkZvY3VzXSA9IHVzZVN0YXRlPFtudW1iZXIsIG51bWJlcl0gfCBudWxsPihudWxsKVxyXG5cclxuICAgIC8vIOKUgOKUgCBGaWx0ZXIgc3RhdGUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcbiAgICBjb25zdCBbc2VsZWN0ZWRUYWdJZHMsIHNldFNlbGVjdGVkVGFnSWRzXSA9IHVzZVN0YXRlPFNldDxudW1iZXI+PihuZXcgU2V0KCkpXHJcbiAgICBjb25zdCBbZmlsdGVyVHlwZSwgc2V0RmlsdGVyVHlwZV0gPSB1c2VTdGF0ZTwnYWxsJyB8ICdldmVudHMnIHwgJ3BsYW5zJz4oJ2FsbCcpXHJcbiAgICBjb25zdCBbcmVsZXZhbmNlRmlsdGVyLCBzZXRSZWxldmFuY2VGaWx0ZXJdID0gdXNlU3RhdGU8UmVsZXZhbmNlRmlsdGVyPignYWxsJylcclxuXHJcbiAgICBjb25zdCBbY2xpY2tQb3NpdGlvbiwgc2V0Q2xpY2tQb3NpdGlvbl0gPSB1c2VTdGF0ZTxbbnVtYmVyLCBudW1iZXJdIHwgbnVsbD4obnVsbClcclxuXHJcbiAgICBjb25zdCBbc2hvd0xvZ2luRm9ybSwgc2V0U2hvd0xvZ2luRm9ybV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFthdXRoTW9kZSwgc2V0QXV0aE1vZGVdID0gdXNlU3RhdGU8J2xvZ2luJyB8ICdyZWdpc3Rlcic+KCdsb2dpbicpXHJcbiAgICBjb25zdCBbbG9naW5Gb3JtLCBzZXRMb2dpbkZvcm1dID0gdXNlU3RhdGUoeyBlbWFpbDogJycsIHBhc3N3b3JkOiAnJyB9KVxyXG4gICAgY29uc3QgW3JlZ2lzdGVyRm9ybSwgc2V0UmVnaXN0ZXJGb3JtXSA9IHVzZVN0YXRlKHsgdXNlcm5hbWU6ICcnLCBlbWFpbDogJycsIHBhc3N3b3JkOiAnJyB9KVxyXG4gICAgY29uc3QgW2xvZ2luRXJyb3IsIHNldExvZ2luRXJyb3JdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gICAgY29uc3QgW3Nob3dPd25Qcm9maWxlLCBzZXRTaG93T3duUHJvZmlsZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFt2aWV3aW5nVXNlcklkLCBzZXRWaWV3aW5nVXNlcklkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgICBjb25zdCBbc2hvd0V4cGxvcmUsIHNldFNob3dFeHBsb3JlXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3Nob3dQbGFubmVyLCBzZXRTaG93UGxhbm5lcl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtzaG93U2F2ZWRDb250ZW50LCBzZXRTaG93U2F2ZWRDb250ZW50XSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3NhdmVkQ29udGVudCwgc2V0U2F2ZWRDb250ZW50XSA9IHVzZVN0YXRlPFNhdmVkQ29udGVudFN0YXRlPihlbXB0eVNhdmVkQ29udGVudClcclxuICAgIGNvbnN0IGZyaWVuZElkcyA9IHVzZU1lbW8oKCkgPT4gbmV3IFNldChmcmllbmRzLm1hcCgoZnJpZW5kKSA9PiBmcmllbmQuaWQpKSwgW2ZyaWVuZHNdKVxyXG4gICAgY29uc3QgaW5jb21pbmdSZXF1ZXN0QnlVc2VySWQgPSB1c2VNZW1vKFxyXG4gICAgICAgICgpID0+IG5ldyBNYXAoZnJpZW5kUmVxdWVzdHMuaW5jb21pbmcubWFwKChyZXF1ZXN0KSA9PiBbcmVxdWVzdC5yZXF1ZXN0ZXJfaWQsIHJlcXVlc3RdKSksXHJcbiAgICAgICAgW2ZyaWVuZFJlcXVlc3RzLmluY29taW5nXSxcclxuICAgIClcclxuICAgIGNvbnN0IG91dGdvaW5nUmVxdWVzdEJ5VXNlcklkID0gdXNlTWVtbyhcclxuICAgICAgICAoKSA9PiBuZXcgTWFwKGZyaWVuZFJlcXVlc3RzLm91dGdvaW5nLm1hcCgocmVxdWVzdCkgPT4gW3JlcXVlc3QucmVjaXBpZW50X2lkLCByZXF1ZXN0XSkpLFxyXG4gICAgICAgIFtmcmllbmRSZXF1ZXN0cy5vdXRnb2luZ10sXHJcbiAgICApXHJcbiAgICBjb25zdCBzYXZlZFBsYW5JZHMgPSB1c2VNZW1vKFxyXG4gICAgICAgICgpID0+IG5ldyBTZXQoc2F2ZWRDb250ZW50LnBsYW5zLm1hcCgocGxhbikgPT4gcGxhbi5pZCkpLFxyXG4gICAgICAgIFtzYXZlZENvbnRlbnQucGxhbnNdLFxyXG4gICAgKVxyXG4gICAgY29uc3QgaW5jb21pbmdSZXF1ZXN0Q291bnQgPSBmcmllbmRSZXF1ZXN0cy5pbmNvbWluZy5sZW5ndGhcclxuICAgIGNvbnN0IHNob3dJbmNvbWluZ1JlcXVlc3ROb3RpY2UgPSBCb29sZWFuKGN1cnJlbnRVc2VyICYmIGluY29taW5nUmVxdWVzdENvdW50ID4gMCAmJiBpbmNvbWluZ1JlcXVlc3RDb3VudCAhPT0gZGlzbWlzc2VkSW5jb21pbmdDb3VudClcclxuXHJcbiAgICAvLyDilIDilIAgTG9hZCBkYXRhIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG5cclxuICAgIGNvbnN0IHJlZnJlc2hEYXRhID0gYXN5bmMgKHVzZXI/OiBBdXRoVXNlciB8IG51bGwpID0+IHtcclxuICAgICAgICBjb25zdCByZXNvbHZlZFVzZXIgPSB1c2VyICE9PSB1bmRlZmluZWQgPyB1c2VyIDogY3VycmVudFVzZXJcclxuICAgICAgICBjb25zdCBbZXZlbnRzRGF0YSwgcGxhbnNEYXRhXSA9IGF3YWl0IFByb21pc2UuYWxsKFtnZXRFdmVudHMoKSwgZ2V0UGxhbnMoKV0pXHJcbiAgICAgICAgc2V0RXZlbnRzKGV2ZW50c0RhdGEpXHJcbiAgICAgICAgc2V0UGxhbnMocGxhbnNEYXRhKVxyXG5cclxuICAgICAgICBpZiAocmVzb2x2ZWRVc2VyKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGpvaW5lZCA9IG5ldyBTZXQoXHJcbiAgICAgICAgICAgICAgICBldmVudHNEYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS5ldmVudF9wYXJ0aWNpcGFudHM/LnNvbWUoKHApID0+IHAudXNlcl9pZCA9PT0gcmVzb2x2ZWRVc2VyLmlkKSlcclxuICAgICAgICAgICAgICAgICAgICAubWFwKChlKSA9PiBlLmlkKSxcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICBzZXRKb2luZWRFdmVudElkcyhqb2luZWQpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJlZnJlc2hGcmllbmRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGlmICghZ2V0QXV0aFRva2VuKCkpIHtcclxuICAgICAgICAgICAgc2V0RnJpZW5kcyhbXSlcclxuICAgICAgICAgICAgc2V0RnJpZW5kc0Vycm9yKCcnKVxyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZHNMb2FkaW5nKHRydWUpXHJcbiAgICAgICAgICAgIHNldEZyaWVuZHNFcnJvcignJylcclxuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldEZyaWVuZHMoKVxyXG4gICAgICAgICAgICBzZXRGcmllbmRzKGRhdGEpXHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZHMoW10pXHJcbiAgICAgICAgICAgIHNldEZyaWVuZHNFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCB0byBsb2FkIGZyaWVuZHMuJylcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRGcmllbmRzTG9hZGluZyhmYWxzZSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVmcmVzaEZyaWVuZFJlcXVlc3RzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGlmICghZ2V0QXV0aFRva2VuKCkpIHtcclxuICAgICAgICAgICAgc2V0RnJpZW5kUmVxdWVzdHMoeyBpbmNvbWluZzogW10sIG91dGdvaW5nOiBbXSB9KVxyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRGcmllbmRSZXF1ZXN0cygpXHJcbiAgICAgICAgICAgIHNldEZyaWVuZFJlcXVlc3RzKGRhdGEpXHJcbiAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZFJlcXVlc3RzKHsgaW5jb21pbmc6IFtdLCBvdXRnb2luZzogW10gfSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBmYWRlVGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRTcGxhc2hFeGl0aW5nKHRydWUpLCAyODUwKVxyXG4gICAgICAgIGNvbnN0IHJlbW92ZVRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0U2hvd1NwbGFzaChmYWxzZSksIDMyMDApXHJcblxyXG4gICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQoZmFkZVRpbWVyKVxyXG4gICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHJlbW92ZVRpbWVyKVxyXG4gICAgICAgIH1cclxuICAgIH0sIFtdKVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBbZXZlbnRzRGF0YSwgcGxhbnNEYXRhLCB0YWdzRGF0YV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0RXZlbnRzKCksXHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0UGxhbnMoKSxcclxuICAgICAgICAgICAgICAgICAgICBnZXRUYWdzKCksXHJcbiAgICAgICAgICAgICAgICBdKVxyXG4gICAgICAgICAgICAgICAgc2V0RXZlbnRzKGV2ZW50c0RhdGEpXHJcbiAgICAgICAgICAgICAgICBzZXRQbGFucyhwbGFuc0RhdGEpXHJcbiAgICAgICAgICAgICAgICBzZXRBbGxUYWdzKHRhZ3NEYXRhKVxyXG5cclxuICAgICAgICAgICAgICAgIGlmIChnZXRBdXRoVG9rZW4oKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcigpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKHVzZXIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNhdmVkQ29udGVudChsb2FkU2F2ZWRDb250ZW50KHVzZXIuaWQpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChbcmVmcmVzaEZyaWVuZHMoKSwgcmVmcmVzaEZyaWVuZFJlcXVlc3RzKCldKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBqb2luZWQgPSBuZXcgU2V0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnRzRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUuZXZlbnRfcGFydGljaXBhbnRzPy5zb21lKChwKSA9PiBwLnVzZXJfaWQgPT09IHVzZXIuaWQpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+IGUuaWQpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEpvaW5lZEV2ZW50SWRzKGpvaW5lZClcclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXBpTG9nb3V0KClcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbClcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgc2V0TG9naW5FcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCB0byBsb2FkIGRhdGEnKVxyXG4gICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGluaXQoKVxyXG4gICAgfSwgW10pXHJcblxyXG4gICAgLy8g4pSA4pSAIEZpbHRlcmVkIG1hcmtlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcblxyXG4gICAgY29uc3QgbWF0Y2hlc1JlbGV2YW5jZSA9IChpdGVtOiBBcGlFdmVudCB8IEFwaVBsYW4sIHR5cGU6ICdldmVudCcgfCAncGxhbicpID0+IHtcclxuICAgICAgICBpZiAocmVsZXZhbmNlRmlsdGVyID09PSAnYWxsJykgcmV0dXJuIHRydWVcclxuICAgICAgICBpZiAoIWN1cnJlbnRVc2VyKSByZXR1cm4gZmFsc2VcclxuXHJcbiAgICAgICAgaWYgKHJlbGV2YW5jZUZpbHRlciA9PT0gJ21pbmUnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBpdGVtLmNyZWF0b3JfaWQgPT09IGN1cnJlbnRVc2VyLmlkIHx8ICh0eXBlID09PSAnZXZlbnQnICYmIGpvaW5lZEV2ZW50SWRzLmhhcyhpdGVtLmlkKSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChmcmllbmRJZHMuaGFzKGl0ZW0uY3JlYXRvcl9pZCkpIHJldHVybiB0cnVlXHJcbiAgICAgICAgcmV0dXJuIHR5cGUgPT09ICdldmVudCdcclxuICAgICAgICAgICAgPyAoKGl0ZW0gYXMgQXBpRXZlbnQpLmV2ZW50X3BhcnRpY2lwYW50cyA/PyBbXSkuc29tZSgocGFydGljaXBhbnQpID0+IGZyaWVuZElkcy5oYXMocGFydGljaXBhbnQudXNlcl9pZCkpXHJcbiAgICAgICAgICAgIDogZmFsc2VcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmaWx0ZXJlZEV2ZW50cyA9IChmaWx0ZXJUeXBlID09PSAncGxhbnMnID8gW10gOiBldmVudHMpLmZpbHRlcigoZSkgPT5cclxuICAgICAgICBtYXRjaGVzVGFncyhlLnRhZ3MsIHNlbGVjdGVkVGFnSWRzKSAmJiBtYXRjaGVzUmVsZXZhbmNlKGUsICdldmVudCcpLFxyXG4gICAgKVxyXG4gICAgY29uc3QgZmlsdGVyZWRQbGFucyA9IChmaWx0ZXJUeXBlID09PSAnZXZlbnRzJyA/IFtdIDogcGxhbnMpLmZpbHRlcigocCkgPT5cclxuICAgICAgICBtYXRjaGVzVGFncyhwLnRhZ3MsIHNlbGVjdGVkVGFnSWRzKSAmJiBtYXRjaGVzUmVsZXZhbmNlKHAsICdwbGFuJyksXHJcbiAgICApXHJcbiAgICBjb25zdCB2aXNpYmxlVGFncyA9IHVzZU1lbW8oXHJcbiAgICAgICAgKCkgPT4gc29ydFRhZ3NGb3JEaXNwbGF5KGFsbFRhZ3MuZmlsdGVyKCh0YWcpID0+ICF0YWcubmFtZS50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgoJ2NpLScpKSksXHJcbiAgICAgICAgW2FsbFRhZ3NdLFxyXG4gICAgKVxyXG4gICAgY29uc3Qgc3Vic2NyaWJlZEV2ZW50cyA9IGV2ZW50c1xyXG4gICAgICAgIC5maWx0ZXIoKGV2ZW50KSA9PiBqb2luZWRFdmVudElkcy5oYXMoZXZlbnQuaWQpKVxyXG5cclxuICAgIC8vIOKUgOKUgCBBdXRoIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGU6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+KSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgc2V0TG9naW5FcnJvcignJylcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbG9naW4obG9naW5Gb3JtLmVtYWlsLnRyaW0oKSwgbG9naW5Gb3JtLnBhc3N3b3JkKVxyXG4gICAgICAgICAgICBzZXRDdXJyZW50VXNlcihkYXRhLnVzZXIpXHJcbiAgICAgICAgICAgIHNldFNhdmVkQ29udGVudChsb2FkU2F2ZWRDb250ZW50KGRhdGEudXNlci5pZCkpXHJcbiAgICAgICAgICAgIHNldFNob3dMb2dpbkZvcm0oZmFsc2UpXHJcbiAgICAgICAgICAgIHNldExvZ2luRm9ybSh7IGVtYWlsOiAnJywgcGFzc3dvcmQ6ICcnIH0pXHJcbiAgICAgICAgICAgIGF3YWl0IHJlZnJlc2hEYXRhKGRhdGEudXNlcilcclxuICAgICAgICAgICAgYXdhaXQgcmVmcmVzaFNvY2lhbFN0YXRlKClcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgc2V0TG9naW5FcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0xvZ2luIGZhaWxlZC4nKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZWdpc3RlciA9IGFzeW5jIChlOiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50PikgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgIHNldExvZ2luRXJyb3IoJycpXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlZ2lzdGVyKFxyXG4gICAgICAgICAgICAgICAgcmVnaXN0ZXJGb3JtLnVzZXJuYW1lLnRyaW0oKSxcclxuICAgICAgICAgICAgICAgIHJlZ2lzdGVyRm9ybS5lbWFpbC50cmltKCksXHJcbiAgICAgICAgICAgICAgICByZWdpc3RlckZvcm0ucGFzc3dvcmQsXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIoZGF0YS51c2VyKVxyXG4gICAgICAgICAgICBzZXRTYXZlZENvbnRlbnQobG9hZFNhdmVkQ29udGVudChkYXRhLnVzZXIuaWQpKVxyXG4gICAgICAgICAgICBzZXRTaG93TG9naW5Gb3JtKGZhbHNlKVxyXG4gICAgICAgICAgICBzZXRSZWdpc3RlckZvcm0oeyB1c2VybmFtZTogJycsIGVtYWlsOiAnJywgcGFzc3dvcmQ6ICcnIH0pXHJcbiAgICAgICAgICAgIHNldEF1dGhNb2RlKCdsb2dpbicpXHJcbiAgICAgICAgICAgIGF3YWl0IHJlZnJlc2hEYXRhKGRhdGEudXNlcilcclxuICAgICAgICAgICAgYXdhaXQgcmVmcmVzaFNvY2lhbFN0YXRlKClcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgc2V0TG9naW5FcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ1JlZ2lzdHJhdGlvbiBmYWlsZWQuJylcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgICAgIGFwaUxvZ291dCgpXHJcbiAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbClcclxuICAgICAgICBzZXRGcmllbmRzKFtdKVxyXG4gICAgICAgIHNldEZyaWVuZFJlcXVlc3RzKHsgaW5jb21pbmc6IFtdLCBvdXRnb2luZzogW10gfSlcclxuICAgICAgICBzZXRGcmllbmROb3RpY2UoJycpXHJcbiAgICAgICAgc2V0RGlzbWlzc2VkSW5jb21pbmdDb3VudCgwKVxyXG4gICAgICAgIHNldEZyaWVuZHNFcnJvcignJylcclxuICAgICAgICBzZXRKb2luZWRFdmVudElkcyhuZXcgU2V0KCkpXHJcbiAgICAgICAgc2V0U2hvd0xvZ2luRm9ybShmYWxzZSlcclxuICAgICAgICBzZXRMb2dpbkVycm9yKCcnKVxyXG4gICAgICAgIHNldFNob3dPd25Qcm9maWxlKGZhbHNlKVxyXG4gICAgICAgIHNldFNob3dTYXZlZENvbnRlbnQoZmFsc2UpXHJcbiAgICAgICAgc2V0Vmlld2luZ1VzZXJJZChudWxsKVxyXG4gICAgICAgIHNldFNhdmVkQ29udGVudChlbXB0eVNhdmVkQ29udGVudClcclxuICAgICAgICBzZXRSZWxldmFuY2VGaWx0ZXIoJ2FsbCcpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g4pSA4pSAIEpvaW4gLyBMZWF2ZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcclxuXHJcbiAgICBjb25zdCBoYW5kbGVKb2luID0gYXN5bmMgKGV2ZW50SWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGF3YWl0IGpvaW5FdmVudChldmVudElkKVxyXG4gICAgICAgICAgICBzZXRKb2luZWRFdmVudElkcygocHJldikgPT4gbmV3IFNldChbLi4ucHJldiwgZXZlbnRJZF0pKVxyXG4gICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgZ2V0RXZlbnRzKClcclxuICAgICAgICAgICAgc2V0RXZlbnRzKHVwZGF0ZWQpXHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0pvaW4gZmFpbGVkOicsIGVycilcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlTGVhdmUgPSBhc3luYyAoZXZlbnRJZDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXdhaXQgbGVhdmVFdmVudChldmVudElkKVxyXG4gICAgICAgICAgICBzZXRKb2luZWRFdmVudElkcygocHJldikgPT4geyBjb25zdCBzID0gbmV3IFNldChwcmV2KTsgcy5kZWxldGUoZXZlbnRJZCk7IHJldHVybiBzIH0pXHJcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBnZXRFdmVudHMoKVxyXG4gICAgICAgICAgICBzZXRFdmVudHModXBkYXRlZClcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignTGVhdmUgZmFpbGVkOicsIGVycilcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8g4pSA4pSAIERlbGV0ZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcclxuXHJcbiAgICBjb25zdCBoYW5kbGVEZWxldGVFdmVudCA9IGFzeW5jIChldmVudElkOiBzdHJpbmcpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBhd2FpdCBkZWxldGVFdmVudChldmVudElkKVxyXG4gICAgICAgICAgICBzZXRFdmVudHMoKHByZXYpID0+IHByZXYuZmlsdGVyKChlKSA9PiBlLmlkICE9PSBldmVudElkKSlcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRGVsZXRlIGV2ZW50IGZhaWxlZDonLCBlcnIpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZVBsYW4gPSBhc3luYyAocGxhbklkOiBzdHJpbmcpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBhd2FpdCBkZWxldGVQbGFuKHBsYW5JZClcclxuICAgICAgICAgICAgc2V0UGxhbnMoKHByZXYpID0+IHByZXYuZmlsdGVyKChwKSA9PiBwLmlkICE9PSBwbGFuSWQpKVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdEZWxldGUgcGxhbiBmYWlsZWQ6JywgZXJyKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyDilIDilIAgQ3JlYXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUV2ZW50Q3JlYXRlZCA9IGFzeW5jIChfZXZlbnQ6IEFwaUV2ZW50KSA9PiB7XHJcbiAgICAgICAgc2V0Q2xpY2tQb3NpdGlvbihudWxsKVxyXG4gICAgICAgIGNvbnN0IFt1cGRhdGVkRXZlbnRzLCB0YWdzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtnZXRFdmVudHMoKSwgZ2V0VGFncygpXSlcclxuICAgICAgICBzZXRFdmVudHModXBkYXRlZEV2ZW50cylcclxuICAgICAgICBzZXRBbGxUYWdzKHRhZ3MpXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUGxhbkNyZWF0ZWQgPSBhc3luYyAoX3BsYW46IEFwaVBsYW4pID0+IHtcclxuICAgICAgICBzZXRDbGlja1Bvc2l0aW9uKG51bGwpXHJcbiAgICAgICAgY29uc3QgW3VwZGF0ZWRQbGFucywgdGFnc10gPSBhd2FpdCBQcm9taXNlLmFsbChbZ2V0UGxhbnMoKSwgZ2V0VGFncygpXSlcclxuICAgICAgICBzZXRQbGFucyh1cGRhdGVkUGxhbnMpXHJcbiAgICAgICAgc2V0QWxsVGFncyh0YWdzKVxyXG4gICAgfVxyXG4gICAgY29uc3Qgc2VsZWN0ZWRFdmVudCA9IHNlbGVjdGVkRXZlbnRJZCA/IGV2ZW50cy5maW5kKChldmVudCkgPT4gZXZlbnQuaWQgPT09IHNlbGVjdGVkRXZlbnRJZCkgPz8gbnVsbCA6IG51bGxcclxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdEV2ZW50ID0gKGV2ZW50SWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIHNldFNlbGVjdGVkRXZlbnRJZChldmVudElkKVxyXG4gICAgfVxyXG4gICAgY29uc3QgaGFuZGxlQ2xvc2VFdmVudERldGFpbHMgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRFdmVudElkKG51bGwpXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0U3VnZ2VzdGlvbiA9IChzdWdnZXN0aW9uOiBTdWdnZXN0aW9uUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgc2V0U3VnZ2VzdGlvbkZvY3VzKFtzdWdnZXN0aW9uLmxhdCwgc3VnZ2VzdGlvbi5sbmddKVxyXG4gICAgICAgIGlmIChzdWdnZXN0aW9uLnR5cGUgPT09ICdldmVudCcpIHtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRFdmVudElkKHN1Z2dlc3Rpb24uaWQpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdEV4cGxvcmVQbGFuID0gKHBvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdKSA9PiB7XHJcbiAgICAgICAgc2V0U3VnZ2VzdGlvbkZvY3VzKHBvc2l0aW9uKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNlbnRlck9uTWFwID0gKHBvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdKSA9PiB7XHJcbiAgICAgICAgc2V0U3VnZ2VzdGlvbkZvY3VzKHBvc2l0aW9uKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOKUgOKUgCBTYXZlZCBjb250ZW50IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG5cclxuICAgIGNvbnN0IHNldEFuZFBlcnNpc3RTYXZlZENvbnRlbnQgPSAobmV4dDogU2F2ZWRDb250ZW50U3RhdGUpID0+IHtcclxuICAgICAgICBpZiAoIWN1cnJlbnRVc2VyKSByZXR1cm5cclxuICAgICAgICBzZXRTYXZlZENvbnRlbnQobmV4dClcclxuICAgICAgICBwZXJzaXN0U2F2ZWRDb250ZW50KGN1cnJlbnRVc2VyLmlkLCBuZXh0KVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVNhdmVQbGFuID0gKHBsYW46IEFwaVBsYW4pID0+IHtcclxuICAgICAgICBpZiAoIWN1cnJlbnRVc2VyKSByZXR1cm4geyBzYXZlZDogZmFsc2UsIG1lc3NhZ2U6ICdMb2cgaW4gdG8gc2F2ZSBwbGFucy4nIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYWRkU2F2ZWRQbGFuKHNhdmVkQ29udGVudCwgcGxhbilcclxuICAgICAgICBzZXRBbmRQZXJzaXN0U2F2ZWRDb250ZW50KHJlc3VsdC5zdGF0ZSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc2F2ZWQ6ICFyZXN1bHQuZHVwbGljYXRlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiByZXN1bHQuZHVwbGljYXRlID8gJ1BsYW4gYWxyZWFkeSBzYXZlZC4nIDogJ1BsYW4gc2F2ZWQuJyxcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2F2ZVJvdXRlID0gKHJvdXRlOiBTYXZlZFJvdXRlRHJhZnQpID0+IHtcclxuICAgICAgICBpZiAoIWN1cnJlbnRVc2VyKSByZXR1cm4geyBzYXZlZDogZmFsc2UsIG1lc3NhZ2U6ICdMb2cgaW4gdG8gc2F2ZSByb3V0ZXMuJyB9XHJcbiAgICAgICAgc2V0QW5kUGVyc2lzdFNhdmVkQ29udGVudChhZGRTYXZlZFJvdXRlKHNhdmVkQ29udGVudCwgcm91dGUpKVxyXG4gICAgICAgIHJldHVybiB7IHNhdmVkOiB0cnVlLCBtZXNzYWdlOiAnUm91dGUgc2F2ZWQuJyB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlU2F2ZWRQbGFuID0gKHBsYW5JZDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgc2V0QW5kUGVyc2lzdFNhdmVkQ29udGVudChyZW1vdmVTYXZlZFBsYW4oc2F2ZWRDb250ZW50LCBwbGFuSWQpKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZVNhdmVkUm91dGUgPSAocm91dGVJZDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgc2V0QW5kUGVyc2lzdFNhdmVkQ29udGVudChyZW1vdmVTYXZlZFJvdXRlKHNhdmVkQ29udGVudCwgcm91dGVJZCkpXHJcbiAgICB9XHJcbiAgICAvLyDilIDilIAgRmlsdGVyIGFjdGlvbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcblxyXG4gICAgY29uc3QgaGFuZGxlVG9nZ2xlVGFnID0gKHRhZ0lkOiBudW1iZXIpID0+IHtcclxuICAgICAgICBzZXRTZWxlY3RlZFRhZ0lkcygocHJldikgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KVxyXG4gICAgICAgICAgICBuZXh0Lmhhcyh0YWdJZCkgPyBuZXh0LmRlbGV0ZSh0YWdJZCkgOiBuZXh0LmFkZCh0YWdJZClcclxuICAgICAgICAgICAgcmV0dXJuIG5leHRcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNsZWFyRmlsdGVycyA9ICgpID0+IHtcclxuICAgICAgICBzZXRTZWxlY3RlZFRhZ0lkcyhuZXcgU2V0KCkpXHJcbiAgICAgICAgc2V0RmlsdGVyVHlwZSgnYWxsJylcclxuICAgICAgICBzZXRSZWxldmFuY2VGaWx0ZXIoJ2FsbCcpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g4pSA4pSAIFByb2ZpbGUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcblxyXG4gICAgY29uc3QgaGFuZGxlUHJvZmlsZVVwZGF0ZWQgPSAoKSA9PiB7XHJcbiAgICAgICAgZ2V0Q3VycmVudFVzZXIoKS50aGVuKHNldEN1cnJlbnRVc2VyKS5jYXRjaChjb25zb2xlLmVycm9yKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJlZnJlc2hTb2NpYWxTdGF0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChbcmVmcmVzaEZyaWVuZHMoKSwgcmVmcmVzaEZyaWVuZFJlcXVlc3RzKCldKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHNob3dGcmllbmROb3RpY2UgPSAobWVzc2FnZTogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgc2V0RnJpZW5kTm90aWNlKG1lc3NhZ2UpXHJcbiAgICAgICAgc2V0RnJpZW5kTm90aWNlRXhpdGluZyhmYWxzZSlcclxuICAgICAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZE5vdGljZUV4aXRpbmcodHJ1ZSlcclxuICAgICAgICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RnJpZW5kTm90aWNlKChjdXJyZW50KSA9PiBjdXJyZW50ID09PSBtZXNzYWdlID8gJycgOiBjdXJyZW50KVxyXG4gICAgICAgICAgICAgICAgc2V0RnJpZW5kTm90aWNlRXhpdGluZyhmYWxzZSlcclxuICAgICAgICAgICAgfSwgMzIwKVxyXG4gICAgICAgIH0sIDMwMDApXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZGlzbWlzc0luY29taW5nTm90aWNlID0gKCkgPT4ge1xyXG4gICAgICAgIGlmICghc2hvd0luY29taW5nUmVxdWVzdE5vdGljZSB8fCBpbmNvbWluZ05vdGljZUV4aXRpbmcpIHJldHVyblxyXG4gICAgICAgIHNldEluY29taW5nTm90aWNlRXhpdGluZyh0cnVlKVxyXG4gICAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgc2V0RGlzbWlzc2VkSW5jb21pbmdDb3VudChpbmNvbWluZ1JlcXVlc3RDb3VudClcclxuICAgICAgICAgICAgc2V0SW5jb21pbmdOb3RpY2VFeGl0aW5nKGZhbHNlKVxyXG4gICAgICAgIH0sIDMyMClcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBkaXNtaXNzRnJpZW5kTm90aWNlcyA9ICgpID0+IHtcclxuICAgICAgICBpZiAoZnJpZW5kTm90aWNlICYmICFmcmllbmROb3RpY2VFeGl0aW5nKSB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZE5vdGljZUV4aXRpbmcodHJ1ZSlcclxuICAgICAgICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RnJpZW5kTm90aWNlKCcnKVxyXG4gICAgICAgICAgICAgICAgc2V0RnJpZW5kTm90aWNlRXhpdGluZyhmYWxzZSlcclxuICAgICAgICAgICAgfSwgMzIwKVxyXG4gICAgICAgIH1cclxuICAgICAgICBkaXNtaXNzSW5jb21pbmdOb3RpY2UoKVxyXG4gICAgfVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFzaG93SW5jb21pbmdSZXF1ZXN0Tm90aWNlKSByZXR1cm5cclxuXHJcbiAgICAgICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGRpc21pc3NJbmNvbWluZ05vdGljZSgpXHJcbiAgICAgICAgfSwgNzAwMClcclxuXHJcbiAgICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpXHJcbiAgICB9LCBbaW5jb21pbmdSZXF1ZXN0Q291bnQsIHNob3dJbmNvbWluZ1JlcXVlc3ROb3RpY2UsIGluY29taW5nTm90aWNlRXhpdGluZ10pXHJcblxyXG4gICAgY29uc3QgaGFuZGxlU2VuZEZyaWVuZFJlcXVlc3QgPSBhc3luYyAodXNlcklkOiBzdHJpbmcpID0+IHtcclxuICAgICAgICBhd2FpdCBzZW5kRnJpZW5kUmVxdWVzdCh1c2VySWQpXHJcbiAgICAgICAgYXdhaXQgcmVmcmVzaFNvY2lhbFN0YXRlKClcclxuICAgICAgICBzaG93RnJpZW5kTm90aWNlKCdGcmllbmQgcmVxdWVzdCBzZW50LicpXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQWNjZXB0RnJpZW5kUmVxdWVzdCA9IGFzeW5jIChyZXF1ZXN0SWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGF3YWl0IGFjY2VwdEZyaWVuZFJlcXVlc3QocmVxdWVzdElkKVxyXG4gICAgICAgIGF3YWl0IHJlZnJlc2hTb2NpYWxTdGF0ZSgpXHJcbiAgICAgICAgc2hvd0ZyaWVuZE5vdGljZSgnRnJpZW5kIHJlcXVlc3QgYWNjZXB0ZWQuJylcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZWplY3RGcmllbmRSZXF1ZXN0ID0gYXN5bmMgKHJlcXVlc3RJZDogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgcmVqZWN0RnJpZW5kUmVxdWVzdChyZXF1ZXN0SWQpXHJcbiAgICAgICAgYXdhaXQgcmVmcmVzaFNvY2lhbFN0YXRlKClcclxuICAgICAgICBzaG93RnJpZW5kTm90aWNlKCdGcmllbmQgcmVxdWVzdCByZWplY3RlZC4nKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNhbmNlbEZyaWVuZFJlcXVlc3QgPSBhc3luYyAocmVxdWVzdElkOiBzdHJpbmcpID0+IHtcclxuICAgICAgICBhd2FpdCBjYW5jZWxGcmllbmRSZXF1ZXN0KHJlcXVlc3RJZClcclxuICAgICAgICBhd2FpdCByZWZyZXNoU29jaWFsU3RhdGUoKVxyXG4gICAgICAgIHNob3dGcmllbmROb3RpY2UoJ0ZyaWVuZCByZXF1ZXN0IGNhbmNlbGxlZC4nKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVJlbW92ZUZyaWVuZCA9IGFzeW5jICh1c2VySWQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGF3YWl0IHJlbW92ZUZyaWVuZCh1c2VySWQpXHJcbiAgICAgICAgYXdhaXQgcmVmcmVzaFNvY2lhbFN0YXRlKClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLXNoZWxsXCIgb25Qb2ludGVyRG93bj17ZGlzbWlzc0ZyaWVuZE5vdGljZXN9PlxyXG4gICAgICAgICAgICB7c2hvd1NwbGFzaCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHJvdmUtc3BsYXNoICR7c3BsYXNoRXhpdGluZyA/ICdyb3ZlLXNwbGFzaC0tZXhpdCcgOiAnJ31gfSBhcmlhLWxhYmVsPVwiTG9hZGluZyBSb3ZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3ZlLXNwbGFzaF9fY29udGVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9yb3ZlLW1hcmstd2hpdGUucG5nXCIgYWx0PVwiUm92ZVwiIGNsYXNzTmFtZT1cInJvdmUtc3BsYXNoX19sb2dvXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3ZlLXNwbGFzaF9fcHJvZ3Jlc3NcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxUb3BCYXJcclxuICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyPXtjdXJyZW50VXNlcn1cclxuICAgICAgICAgICAgICAgIG9uT3BlbkV4cGxvcmU9eygpID0+IHNldFNob3dFeHBsb3JlKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgb25PcGVuUGxhbm5lcj17KCkgPT4gc2V0U2hvd1BsYW5uZXIodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICBvbk9wZW5Qcm9maWxlPXsoKSA9PiBzZXRTaG93T3duUHJvZmlsZSh0cnVlKX1cclxuICAgICAgICAgICAgICAgIG9uT3BlblNhdmVkQ29udGVudD17KCkgPT4gc2V0U2hvd1NhdmVkQ29udGVudCh0cnVlKX1cclxuICAgICAgICAgICAgICAgIG9uTG9naW5DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dMb2dpbkZvcm0oKHYpID0+ICF2KVxyXG4gICAgICAgICAgICAgICAgICAgIHNldExvZ2luRXJyb3IoJycpXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgb25Mb2dvdXQ9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIHsoc2hvd0luY29taW5nUmVxdWVzdE5vdGljZSB8fCBmcmllbmROb3RpY2UpICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZnJpZW5kLW5vdGljZS1zdGFja1wiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiIG9uUG9pbnRlckRvd249eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93SW5jb21pbmdSZXF1ZXN0Tm90aWNlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZyaWVuZC1ub3RpY2UgZnJpZW5kLW5vdGljZS0tcmVxdWVzdCAke2luY29taW5nTm90aWNlRXhpdGluZyA/ICdmcmllbmQtbm90aWNlLS1leGl0JyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI2ZyaWVuZHMtcGFuZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17ZGlzbWlzc0luY29taW5nTm90aWNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW5jb21pbmdSZXF1ZXN0Q291bnQgPT09IDFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdZb3UgaGF2ZSAxIG5ldyBmcmllbmQgcmVxdWVzdCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGBZb3UgaGF2ZSAke2luY29taW5nUmVxdWVzdENvdW50fSBuZXcgZnJpZW5kIHJlcXVlc3RzYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAge2ZyaWVuZE5vdGljZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZnJpZW5kLW5vdGljZSBmcmllbmQtbm90aWNlLS1zdWNjZXNzICR7ZnJpZW5kTm90aWNlRXhpdGluZyA/ICdmcmllbmQtbm90aWNlLS1leGl0JyA6ICcnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZyaWVuZE5vdGljZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3Nob3dFeHBsb3JlICYmIChcclxuICAgICAgICAgICAgICAgIDxFeHBsb3JlUGFuZWxcclxuICAgICAgICAgICAgICAgICAgICBldmVudHM9e2V2ZW50c31cclxuICAgICAgICAgICAgICAgICAgICBwbGFucz17cGxhbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgbWFwQ2VudGVyPXttYXBDZW50ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUYWdJZHM9e3NlbGVjdGVkVGFnSWRzfVxyXG4gICAgICAgICAgICAgICAgICAgIHRhZ3M9e3Zpc2libGVUYWdzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dFeHBsb3JlKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdEV2ZW50PXtoYW5kbGVTZWxlY3RFdmVudH1cclxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdFBsYW49e2hhbmRsZVNlbGVjdEV4cGxvcmVQbGFufVxyXG4gICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49eyEhY3VycmVudFVzZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgc2F2ZWRQbGFuSWRzPXtzYXZlZFBsYW5JZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgam9pbmVkRXZlbnRJZHM9e2pvaW5lZEV2ZW50SWRzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uU2F2ZVBsYW49e2hhbmRsZVNhdmVQbGFufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uU3Vic2NyaWJlRXZlbnQ9e2hhbmRsZUpvaW59XHJcbiAgICAgICAgICAgICAgICAgICAgb25VbnN1YnNjcmliZUV2ZW50PXtoYW5kbGVMZWF2ZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7c2hvd1BsYW5uZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFBsYW5uZXJQYW5lbFxyXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50cz17ZXZlbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYW5zPXtwbGFuc31cclxuICAgICAgICAgICAgICAgICAgICBtYXBDZW50ZXI9e21hcENlbnRlcn1cclxuICAgICAgICAgICAgICAgICAgICB0YWdzPXt2aXNpYmxlVGFnc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93UGxhbm5lcihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25PcGVuRXZlbnREZXRhaWxzPXtoYW5kbGVTZWxlY3RFdmVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNlbnRlck9uTWFwPXtoYW5kbGVDZW50ZXJPbk1hcH1cclxuICAgICAgICAgICAgICAgICAgICBpc0xvZ2dlZEluPXshIWN1cnJlbnRVc2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uU2F2ZVJvdXRlPXtoYW5kbGVTYXZlUm91dGV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgeyFjdXJyZW50VXNlciAmJiBzaG93TG9naW5Gb3JtICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wLWF1dGgtcG9wb3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wLWF1dGgtY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtbW9kZS1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInBvcHVwLWJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRBdXRoTW9kZSgnbG9naW4nKTsgc2V0TG9naW5FcnJvcignJykgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YXV0aE1vZGUgPT09ICdsb2dpbid9PkxvZ2luPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwb3B1cC1idXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0QXV0aE1vZGUoJ3JlZ2lzdGVyJyk7IHNldExvZ2luRXJyb3IoJycpIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2F1dGhNb2RlID09PSAncmVnaXN0ZXInfT5SZWdpc3RlcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2F1dGhNb2RlID09PSAnbG9naW4nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwibG9naW4tZm9ybVwiIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi1maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImxvZ2luLWVtYWlsXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJsb2dpbi1lbWFpbFwiIGNsYXNzTmFtZT1cInBvcHVwLWlucHV0XCIgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtsb2dpbkZvcm0uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldExvZ2luRm9ybSh7IC4uLmxvZ2luRm9ybSwgZW1haWw6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJsb2dpbi1wYXNzd29yZFwiPlBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwibG9naW4tcGFzc3dvcmRcIiBjbGFzc05hbWU9XCJwb3B1cC1pbnB1dFwiIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bG9naW5Gb3JtLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRMb2dpbkZvcm0oeyAuLi5sb2dpbkZvcm0sIHBhc3N3b3JkOiBlLnRhcmdldC52YWx1ZSB9KX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJwb3B1cC1zdWJtaXRcIj5TaWduIGluPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJsb2dpbi1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVJlZ2lzdGVyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWZpZWxkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicmVnaXN0ZXItdXNlcm5hbWVcIj5Vc2VybmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cInJlZ2lzdGVyLXVzZXJuYW1lXCIgY2xhc3NOYW1lPVwicG9wdXAtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlZ2lzdGVyRm9ybS51c2VybmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVnaXN0ZXJGb3JtKHsgLi4ucmVnaXN0ZXJGb3JtLCB1c2VybmFtZTogZS50YXJnZXQudmFsdWUgfSl9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi1maWVsZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInJlZ2lzdGVyLWVtYWlsXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJyZWdpc3Rlci1lbWFpbFwiIGNsYXNzTmFtZT1cInBvcHVwLWlucHV0XCIgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWdpc3RlckZvcm0uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlZ2lzdGVyRm9ybSh7IC4uLnJlZ2lzdGVyRm9ybSwgZW1haWw6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJyZWdpc3Rlci1wYXNzd29yZFwiPlBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwicmVnaXN0ZXItcGFzc3dvcmRcIiBjbGFzc05hbWU9XCJwb3B1cC1pbnB1dFwiIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmVnaXN0ZXJGb3JtLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWdpc3RlckZvcm0oeyAuLi5yZWdpc3RlckZvcm0sIHBhc3N3b3JkOiBlLnRhcmdldC52YWx1ZSB9KX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJwb3B1cC1zdWJtaXRcIj5SZWdpc3RlcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nICYmIDxkaXYgY2xhc3NOYW1lPVwibG9naW4taW5mb1wiPkxvYWRpbmcgbWFwIGRhdGEuLi48L2Rpdj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsb2dpbkVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tZXJyb3JcIj57bG9naW5FcnJvcn08L2Rpdj59XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImFwcC1tYWluXCI+XHJcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtYXAtY2FyZFwiIGFyaWEtbGFiZWw9XCJFeHBsb3JlIG1hcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWNhcmRfX2hlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWFwLWNhcmRfX2V5ZWJyb3dcIj5CYXJjZWxvbmEgbGl2ZSBtYXA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDE+RXhwbG9yZSBldmVudHMgYW5kIHBsYW5zIG5lYXJieTwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5DbGljayB0aGUgbWFwIHRvIGNyZWF0ZSBzb21ldGhpbmcgbmV3LCBvciBzZWxlY3QgYW4gZXZlbnQgbWFya2VyIHRvIHNlZSBkZXRhaWxzLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtY2FyZF9fYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TWFwQ29udGFpbmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJsZWFmbGV0LWNvbnRhaW5lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjZW50ZXI9e2JhcmNlbG9uYUNlbnRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHpvb209ezE0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiAnMTAwJScgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRpbGVMYXllclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybD1cImh0dHBzOi8ve3N9LmJhc2VtYXBzLmNhcnRvY2RuLmNvbS9saWdodF9hbGwve3p9L3t4fS97eX17cn0ucG5nXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGlvbj0nJmNvcHk7IDxhIGhyZWY9XCJodHRwczovL3d3dy5vcGVuc3RyZWV0bWFwLm9yZy9jb3B5cmlnaHRcIj5PcGVuU3RyZWV0TWFwPC9hPiBjb250cmlidXRvcnMgJmNvcHk7IDxhIGhyZWY9XCJodHRwczovL2NhcnRvLmNvbS9hdHRyaWJ1dGlvbnNcIj5DQVJUTzwvYT4nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNYXJrZXIgcG9zaXRpb249e2JhcmNlbG9uYUNlbnRlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBvcHVwPkJhcmNlbG9uYSBjZW50ZXI6IFBsYcOnYSBkZSBDYXRhbHVueWEuPC9Qb3B1cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTWFya2VyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNYXBDZW50ZXJUcmFja2VyIG9uQ2VudGVyQ2hhbmdlPXtzZXRNYXBDZW50ZXJ9IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1hcE1hcmtlcnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudHM9e2ZpbHRlcmVkRXZlbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYW5zPXtmaWx0ZXJlZFBsYW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VySWQ9e2N1cnJlbnRVc2VyPy5pZCA/PyBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49eyEhY3VycmVudFVzZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2F2ZWRQbGFuSWRzPXtzYXZlZFBsYW5JZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25EZWxldGVQbGFuPXtoYW5kbGVEZWxldGVQbGFufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2F2ZVBsYW49e2hhbmRsZVNhdmVQbGFufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVmlld1VzZXJQcm9maWxlPXtzZXRWaWV3aW5nVXNlcklkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uTWFwQ2xpY2s9e3NldENsaWNrUG9zaXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpY2tQb3NpdGlvbj17Y2xpY2tQb3NpdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsb3NlQ2xpY2s9eygpID0+IHNldENsaWNrUG9zaXRpb24obnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25FdmVudFNlbGVjdD17aGFuZGxlU2VsZWN0RXZlbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9jdXNQb3NpdGlvbj17c3VnZ2VzdGlvbkZvY3VzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9NYXBDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLXNjcmltXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtbGVnZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWxlZ2VuZF9faXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWFwLWxlZ2VuZF9fZG90IG1hcC1sZWdlbmRfX2RvdC0tZXZlbnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RXZlbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1sZWdlbmRfX2l0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hcC1sZWdlbmRfX2RvdCBtYXAtbGVnZW5kX19kb3QtLXBsYW5cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UGxhbjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWxlZ2VuZF9faXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWFwLWxlZ2VuZF9fZG90IG1hcC1sZWdlbmRfX2RvdC0tb3duXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPllvdXJzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwic2lkZWJhci1vdmVybGF5XCI+XHJcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjb250cm9sLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRyb2wtc2VjdGlvbl9fbGFiZWxcIiBpZD1cImV4cGxvcmUtcGFuZWxcIj5FeHBsb3JlIGZpbHRlcnM8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8RmlsdGVyUGFuZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFncz17dmlzaWJsZVRhZ3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkVGFnSWRzPXtzZWxlY3RlZFRhZ0lkc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25Ub2dnbGVUYWc9e2hhbmRsZVRvZ2dsZVRhZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGVhcj17aGFuZGxlQ2xlYXJGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJUeXBlPXtmaWx0ZXJUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkZpbHRlclR5cGU9e3NldEZpbHRlclR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbGV2YW5jZUZpbHRlcj17cmVsZXZhbmNlRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvblJlbGV2YW5jZUZpbHRlcj17c2V0UmVsZXZhbmNlRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0xvZ2dlZEluPXshIWN1cnJlbnRVc2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29udHJvbC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250cm9sLXNlY3Rpb25fX2xhYmVsXCIgaWQ9XCJzdWdnZXN0aW9ucy1wYW5lbFwiPlN1Z2dlc3Rpb25zPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN1Z2dlc3Rpb25zUGFuZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFwQ2VudGVyPXttYXBDZW50ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkVGFnSWRzPXtzZWxlY3RlZFRhZ0lkc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyVHlwZT17ZmlsdGVyVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFncz17dmlzaWJsZVRhZ3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50cz17ZXZlbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmllbmRJZHM9e2ZyaWVuZElkc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3RTdWdnZXN0aW9uPXtoYW5kbGVTZWxlY3RTdWdnZXN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29udHJvbC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250cm9sLXNlY3Rpb25fX2xhYmVsXCIgaWQ9XCJmcmllbmRzLXBhbmVsXCI+RnJpZW5kcyAmYW1wOyBzdWJzY3JpYmVkIGV2ZW50czwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdWJzY3JpcHRpb25QYW5lbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVkRXZlbnRzPXtzdWJzY3JpYmVkRXZlbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmllbmRzPXtmcmllbmRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmllbmRSZXF1ZXN0cz17ZnJpZW5kUmVxdWVzdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyaWVuZHNMb2FkaW5nPXtmcmllbmRzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZnJpZW5kc0Vycm9yPXtmcmllbmRzRXJyb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uUmVtb3ZlU3Vic2NyaXB0aW9uPXtoYW5kbGVMZWF2ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25SZW1vdmVGcmllbmQ9e2hhbmRsZVJlbW92ZUZyaWVuZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25BY2NlcHRGcmllbmRSZXF1ZXN0PXtoYW5kbGVBY2NlcHRGcmllbmRSZXF1ZXN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvblJlamVjdEZyaWVuZFJlcXVlc3Q9e2hhbmRsZVJlamVjdEZyaWVuZFJlcXVlc3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2FuY2VsRnJpZW5kUmVxdWVzdD17aGFuZGxlQ2FuY2VsRnJpZW5kUmVxdWVzdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25WaWV3VXNlclByb2ZpbGU9e3NldFZpZXdpbmdVc2VySWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyPXtjdXJyZW50VXNlcn1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgPC9tYWluPlxyXG5cclxuICAgICAgICAgICAge3NlbGVjdGVkRXZlbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJldmVudC1kZXRhaWxzLW92ZXJsYXlcIiBvbkNsaWNrPXtoYW5kbGVDbG9zZUV2ZW50RGV0YWlsc30+XHJcbiAgICAgICAgICAgICAgICAgICAgPEV2ZW50RGV0YWlsc1NpZGViYXIgZXZlbnQ9e3NlbGVjdGVkRXZlbnR9IG9uQ2xvc2U9e2hhbmRsZUNsb3NlRXZlbnREZXRhaWxzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0xvZ2dlZEluPXshIWN1cnJlbnRVc2VyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXNlcklkPXtjdXJyZW50VXNlcj8uaWQgPz8gbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgam9pbmVkPXtqb2luZWRFdmVudElkcy5oYXMoc2VsZWN0ZWRFdmVudC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRnVsbD17c2VsZWN0ZWRFdmVudC5jYXBhY2l0eSAhPT0gbnVsbCAmJiBzZWxlY3RlZEV2ZW50LmNhcGFjaXR5IDw9IChzZWxlY3RlZEV2ZW50LmV2ZW50X3BhcnRpY2lwYW50cz8ubGVuZ3RoID8/IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkpvaW49e2hhbmRsZUpvaW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uTGVhdmU9e2hhbmRsZUxlYXZlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZUV2ZW50PXtoYW5kbGVEZWxldGVFdmVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25WaWV3VXNlclByb2ZpbGU9e3NldFZpZXdpbmdVc2VySWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyaWVuZElkcz17ZnJpZW5kSWRzfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBDcmVhdGUgcGFuZWwgKGxlZnQgc2lkZSkgKi99XHJcbiAgICAgICAgICAgIHtjbGlja1Bvc2l0aW9uICYmIGN1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3JlYXRlLXBhbmVsLW92ZXJsYXlcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q3JlYXRlUGFuZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249e2NsaWNrUG9zaXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZVRhZ3M9e3Zpc2libGVUYWdzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkV2ZW50Q3JlYXRlZD17aGFuZGxlRXZlbnRDcmVhdGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvblBsYW5DcmVhdGVkPXtoYW5kbGVQbGFuQ3JlYXRlZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldENsaWNrUG9zaXRpb24obnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3Nob3dPd25Qcm9maWxlICYmIGN1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICAgIDxQcm9maWxlTW9kYWxcclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93T3duUHJvZmlsZShmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25Qcm9maWxlVXBkYXRlZD17aGFuZGxlUHJvZmlsZVVwZGF0ZWR9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7c2hvd1NhdmVkQ29udGVudCAmJiBjdXJyZW50VXNlciAmJiAoXHJcbiAgICAgICAgICAgICAgICA8U2F2ZWRDb250ZW50UGFuZWxcclxuICAgICAgICAgICAgICAgICAgICBzYXZlZENvbnRlbnQ9e3NhdmVkQ29udGVudH1cclxuICAgICAgICAgICAgICAgICAgICBldmVudHM9e2V2ZW50c31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93U2F2ZWRDb250ZW50KGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBvbk9wZW5FdmVudERldGFpbHM9eyhldmVudElkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRXZlbnRJZChldmVudElkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93U2F2ZWRDb250ZW50KGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgb25DZW50ZXJPbk1hcD17KHBvc2l0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNlbnRlck9uTWFwKHBvc2l0aW9uKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93U2F2ZWRDb250ZW50KGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgb25SZW1vdmVQbGFuPXtoYW5kbGVSZW1vdmVTYXZlZFBsYW59XHJcbiAgICAgICAgICAgICAgICAgICAgb25SZW1vdmVSb3V0ZT17aGFuZGxlUmVtb3ZlU2F2ZWRSb3V0ZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHt2aWV3aW5nVXNlcklkICYmIChcclxuICAgICAgICAgICAgICAgIDxQdWJsaWNQcm9maWxlTW9kYWxcclxuICAgICAgICAgICAgICAgICAgICB1c2VySWQ9e3ZpZXdpbmdVc2VySWR9XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudFVzZXJJZD17Y3VycmVudFVzZXI/LmlkID8/IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgZnJpZW5kSWRzPXtmcmllbmRJZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgaW5jb21pbmdSZXF1ZXN0PXtpbmNvbWluZ1JlcXVlc3RCeVVzZXJJZC5nZXQodmlld2luZ1VzZXJJZCkgPz8gbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICBvdXRnb2luZ1JlcXVlc3Q9e291dGdvaW5nUmVxdWVzdEJ5VXNlcklkLmdldCh2aWV3aW5nVXNlcklkKSA/PyBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uU2VuZEZyaWVuZFJlcXVlc3Q9e2hhbmRsZVNlbmRGcmllbmRSZXF1ZXN0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQWNjZXB0RnJpZW5kUmVxdWVzdD17aGFuZGxlQWNjZXB0RnJpZW5kUmVxdWVzdH1cclxuICAgICAgICAgICAgICAgICAgICBvblJlbW92ZUZyaWVuZD17aGFuZGxlUmVtb3ZlRnJpZW5kfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFZpZXdpbmdVc2VySWQobnVsbCl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHBcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXJ0aS9Eb2N1bWVudHMvR2l0SHViL1NvZnR3YXJlLVByb2plY3QtRzEwL1Byb2plY3Qvc3JjL0FwcC50c3gifQ==