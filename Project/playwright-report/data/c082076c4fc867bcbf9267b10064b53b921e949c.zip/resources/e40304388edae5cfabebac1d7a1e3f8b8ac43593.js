import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/FilterPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function FilterPanel({
  tags,
  selectedTagIds,
  onToggleTag,
  onClear,
  filterType,
  onFilterType,
  relevanceFilter,
  onRelevanceFilter,
  isLoggedIn
}) {
  const hasActiveFilters = selectedTagIds.size > 0 || filterType !== "all" || relevanceFilter !== "all";
  return /* @__PURE__ */ jsxDEV("div", { className: "filter-panel", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__header", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "filter-panel__title", children: "🔍 Filter" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
        lineNumber: 52,
        columnNumber: 17
      }, this),
      hasActiveFilters && /* @__PURE__ */ jsxDEV("button", { className: "filter-panel__clear", onClick: onClear, children: "Clear all" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 51,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__type-row", children: ["all", "events", "plans"].map(
      (t) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: `filter-panel__type-btn ${filterType === t ? "filter-panel__type-btn--active" : ""}`,
          onClick: () => onFilterType(t),
          children: t === "all" ? "All" : t === "events" ? "🗓 Events" : "📋 Plans"
        },
        t,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
          lineNumber: 63,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 61,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__section-label", children: "Relevance" }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 73,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__type-row filter-panel__type-row--relevance", children: [
      ["all", "All"],
      ["mine", "Mine"],
      ["friends", "Friends"]
    ].map(([value, label]) => {
      const disabled = !isLoggedIn && value !== "all";
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: `filter-panel__type-btn ${relevanceFilter === value ? "filter-panel__type-btn--active" : ""}`,
          onClick: () => onRelevanceFilter(value),
          disabled,
          title: disabled ? "Log in to use this discovery filter." : void 0,
          children: label
        },
        value,
        false,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
          lineNumber: 82,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 74,
      columnNumber: 13
    }, this),
    !isLoggedIn && /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__hint", children: "Log in to use Mine and Friends discovery filters." }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    tags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__tags", children: tags.map(
      (tag) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: `filter-panel__tag ${selectedTagIds.has(tag.id) ? "filter-panel__tag--active" : ""}`,
          onClick: () => onToggleTag(tag.id),
          children: [
            "#",
            tag.name
          ]
        },
        tag.id,
        true,
        {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
          lineNumber: 104,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    selectedTagIds.size > 0 && /* @__PURE__ */ jsxDEV("div", { className: "filter-panel__hint", children: [
      "Showing markers with",
      " ",
      /* @__PURE__ */ jsxDEV("strong", { children: [...selectedTagIds].map((id) => tags.find((t) => t.id === id)?.name).filter(Boolean).join(", ") }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
        lineNumber: 118,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
      lineNumber: 116,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_c = FilterPanel;
var _c;
$RefreshReg$(_c, "FilterPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/FilterPanel.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NnQjs7Ozs7Ozs7Ozs7Ozs7OztBQWhCaEIsd0JBQXdCQSxZQUFZO0FBQUEsRUFDaENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0csR0FBRztBQUNOLFFBQU1DLG1CQUFtQlIsZUFBZVMsT0FBTyxLQUFLTixlQUFlLFNBQVNFLG9CQUFvQjtBQUVoRyxTQUNJLHVCQUFDLFNBQUksV0FBVSxnQkFDWDtBQUFBLDJCQUFDLFNBQUksV0FBVSx3QkFDWDtBQUFBLDZCQUFDLFVBQUssV0FBVSx1QkFBc0IseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxNQUM5Q0csb0JBQ0csdUJBQUMsWUFBTyxXQUFVLHVCQUFzQixTQUFTTixTQUFTLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNULFdBQUMsT0FBTyxVQUFVLE9BQU8sRUFBWVE7QUFBQUEsTUFBSSxDQUFDQyxNQUN4QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUcsV0FBVywwQkFBMEJSLGVBQWVRLElBQUksbUNBQW1DLEVBQUU7QUFBQSxVQUM3RixTQUFTLE1BQU1QLGFBQWFPLENBQUM7QUFBQSxVQUU1QkEsZ0JBQU0sUUFBUSxRQUFRQSxNQUFNLFdBQVcsY0FBYztBQUFBO0FBQUEsUUFKakRBO0FBQUFBLFFBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsSUFDSCxLQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUE4Qix5QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLElBQ3RELHVCQUFDLFNBQUksV0FBVSw0REFDVDtBQUFBLE1BQ0UsQ0FBQyxPQUFPLEtBQUs7QUFBQSxNQUNiLENBQUMsUUFBUSxNQUFNO0FBQUEsTUFDZixDQUFDLFdBQVcsU0FBUztBQUFBLElBQUMsRUFDZEQsSUFBSSxDQUFDLENBQUNFLE9BQU9DLEtBQUssTUFBTTtBQUNoQyxZQUFNQyxXQUFXLENBQUNQLGNBQWNLLFVBQVU7QUFDMUMsYUFDSTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUcsV0FBVywwQkFBMEJQLG9CQUFvQk8sUUFBUSxtQ0FBbUMsRUFBRTtBQUFBLFVBQ3RHLFNBQVMsTUFBTU4sa0JBQWtCTSxLQUFLO0FBQUEsVUFDdEM7QUFBQSxVQUNBLE9BQU9FLFdBQVcseUNBQXlDQztBQUFBQSxVQUUxREY7QUFBQUE7QUFBQUEsUUFOSUQ7QUFBQUEsUUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxJQUVSLENBQUMsS0FsQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBQ0MsQ0FBQ0wsY0FDRSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLGlFQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUlIUixLQUFLaUIsU0FBUyxLQUNYLHVCQUFDLFNBQUksV0FBVSxzQkFDVmpCLGVBQUtXO0FBQUFBLE1BQUksQ0FBQ08sUUFDUDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUcsV0FBVyxxQkFBcUJqQixlQUFla0IsSUFBSUQsSUFBSUUsRUFBRSxJQUFJLDhCQUE4QixFQUFFO0FBQUEsVUFDN0YsU0FBUyxNQUFNbEIsWUFBWWdCLElBQUlFLEVBQUU7QUFBQSxVQUFFO0FBQUE7QUFBQSxZQUVqQ0YsSUFBSUc7QUFBQUE7QUFBQUE7QUFBQUEsUUFKREgsSUFBSUU7QUFBQUEsUUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxJQUNILEtBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFHSG5CLGVBQWVTLE9BQU8sS0FDbkIsdUJBQUMsU0FBSSxXQUFVLHNCQUFxQjtBQUFBO0FBQUEsTUFDWDtBQUFBLE1BQ3JCLHVCQUFDLFlBQ0ksV0FBQyxHQUFHVCxjQUFjLEVBQ2RVLElBQUksQ0FBQ1MsT0FBT3BCLEtBQUtzQixLQUFLLENBQUNWLE1BQU1BLEVBQUVRLE9BQU9BLEVBQUUsR0FBR0MsSUFBSSxFQUMvQ0UsT0FBT0MsT0FBTyxFQUNkQyxLQUFLLElBQUksS0FKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQTFFUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEVBO0FBRVI7QUFBQ0MsS0E1RnVCM0I7QUFBVyxJQUFBMkI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRmlsdGVyUGFuZWwiLCJ0YWdzIiwic2VsZWN0ZWRUYWdJZHMiLCJvblRvZ2dsZVRhZyIsIm9uQ2xlYXIiLCJmaWx0ZXJUeXBlIiwib25GaWx0ZXJUeXBlIiwicmVsZXZhbmNlRmlsdGVyIiwib25SZWxldmFuY2VGaWx0ZXIiLCJpc0xvZ2dlZEluIiwiaGFzQWN0aXZlRmlsdGVycyIsInNpemUiLCJtYXAiLCJ0IiwidmFsdWUiLCJsYWJlbCIsImRpc2FibGVkIiwidW5kZWZpbmVkIiwibGVuZ3RoIiwidGFnIiwiaGFzIiwiaWQiLCJuYW1lIiwiZmluZCIsImZpbHRlciIsIkJvb2xlYW4iLCJqb2luIiwiX2MiXSwic291cmNlcyI6WyJGaWx0ZXJQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGFnIH0gZnJvbSAnLi9hcGknXHJcblxyXG5leHBvcnQgdHlwZSBSZWxldmFuY2VGaWx0ZXIgPSAnYWxsJyB8ICdtaW5lJyB8ICdmcmllbmRzJ1xyXG5cclxudHlwZSBQcm9wcyA9IHtcclxuICAgIHRhZ3M6IFRhZ1tdXHJcbiAgICBzZWxlY3RlZFRhZ0lkczogU2V0PG51bWJlcj5cclxuICAgIG9uVG9nZ2xlVGFnOiAodGFnSWQ6IG51bWJlcikgPT4gdm9pZFxyXG4gICAgb25DbGVhcjogKCkgPT4gdm9pZFxyXG4gICAgZmlsdGVyVHlwZTogJ2FsbCcgfCAnZXZlbnRzJyB8ICdwbGFucydcclxuICAgIG9uRmlsdGVyVHlwZTogKHR5cGU6ICdhbGwnIHwgJ2V2ZW50cycgfCAncGxhbnMnKSA9PiB2b2lkXHJcbiAgICByZWxldmFuY2VGaWx0ZXI6IFJlbGV2YW5jZUZpbHRlclxyXG4gICAgb25SZWxldmFuY2VGaWx0ZXI6IChmaWx0ZXI6IFJlbGV2YW5jZUZpbHRlcikgPT4gdm9pZFxyXG4gICAgaXNMb2dnZWRJbjogYm9vbGVhblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBGaWx0ZXJQYW5lbCh7XHJcbiAgICB0YWdzLFxyXG4gICAgc2VsZWN0ZWRUYWdJZHMsXHJcbiAgICBvblRvZ2dsZVRhZyxcclxuICAgIG9uQ2xlYXIsXHJcbiAgICBmaWx0ZXJUeXBlLFxyXG4gICAgb25GaWx0ZXJUeXBlLFxyXG4gICAgcmVsZXZhbmNlRmlsdGVyLFxyXG4gICAgb25SZWxldmFuY2VGaWx0ZXIsXHJcbiAgICBpc0xvZ2dlZEluLFxyXG59OiBQcm9wcykge1xyXG4gICAgY29uc3QgaGFzQWN0aXZlRmlsdGVycyA9IHNlbGVjdGVkVGFnSWRzLnNpemUgPiAwIHx8IGZpbHRlclR5cGUgIT09ICdhbGwnIHx8IHJlbGV2YW5jZUZpbHRlciAhPT0gJ2FsbCdcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXBhbmVsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXBhbmVsX19oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZpbHRlci1wYW5lbF9fdGl0bGVcIj7wn5SNIEZpbHRlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtoYXNBY3RpdmVGaWx0ZXJzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImZpbHRlci1wYW5lbF9fY2xlYXJcIiBvbkNsaWNrPXtvbkNsZWFyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2xlYXIgYWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUeXBlIGZpbHRlciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGFuZWxfX3R5cGUtcm93XCI+XHJcbiAgICAgICAgICAgICAgICB7KFsnYWxsJywgJ2V2ZW50cycsICdwbGFucyddIGFzIGNvbnN0KS5tYXAoKHQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmlsdGVyLXBhbmVsX190eXBlLWJ0biAke2ZpbHRlclR5cGUgPT09IHQgPyAnZmlsdGVyLXBhbmVsX190eXBlLWJ0bi0tYWN0aXZlJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRmlsdGVyVHlwZSh0KX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0ID09PSAnYWxsJyA/ICdBbGwnIDogdCA9PT0gJ2V2ZW50cycgPyAn8J+XkyBFdmVudHMnIDogJ/Cfk4sgUGxhbnMnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGFuZWxfX3NlY3Rpb24tbGFiZWxcIj5SZWxldmFuY2U8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGFuZWxfX3R5cGUtcm93IGZpbHRlci1wYW5lbF9fdHlwZS1yb3ctLXJlbGV2YW5jZVwiPlxyXG4gICAgICAgICAgICAgICAgeyhbXHJcbiAgICAgICAgICAgICAgICAgICAgWydhbGwnLCAnQWxsJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgWydtaW5lJywgJ01pbmUnXSxcclxuICAgICAgICAgICAgICAgICAgICBbJ2ZyaWVuZHMnLCAnRnJpZW5kcyddLFxyXG4gICAgICAgICAgICAgICAgXSBhcyBjb25zdCkubWFwKChbdmFsdWUsIGxhYmVsXSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRpc2FibGVkID0gIWlzTG9nZ2VkSW4gJiYgdmFsdWUgIT09ICdhbGwnXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt2YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZpbHRlci1wYW5lbF9fdHlwZS1idG4gJHtyZWxldmFuY2VGaWx0ZXIgPT09IHZhbHVlID8gJ2ZpbHRlci1wYW5lbF9fdHlwZS1idG4tLWFjdGl2ZScgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25SZWxldmFuY2VGaWx0ZXIodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2Rpc2FibGVkID8gJ0xvZyBpbiB0byB1c2UgdGhpcyBkaXNjb3ZlcnkgZmlsdGVyLicgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7IWlzTG9nZ2VkSW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGFuZWxfX2hpbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICBMb2cgaW4gdG8gdXNlIE1pbmUgYW5kIEZyaWVuZHMgZGlzY292ZXJ5IGZpbHRlcnMuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBUYWcgZmlsdGVyICovfVxyXG4gICAgICAgICAgICB7dGFncy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXBhbmVsX190YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3RhZ3MubWFwKCh0YWcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0YWcuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmaWx0ZXItcGFuZWxfX3RhZyAke3NlbGVjdGVkVGFnSWRzLmhhcyh0YWcuaWQpID8gJ2ZpbHRlci1wYW5lbF9fdGFnLS1hY3RpdmUnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVG9nZ2xlVGFnKHRhZy5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICN7dGFnLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7c2VsZWN0ZWRUYWdJZHMuc2l6ZSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGFuZWxfX2hpbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICBTaG93aW5nIG1hcmtlcnMgd2l0aHsnICd9XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1suLi5zZWxlY3RlZFRhZ0lkc11cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGlkKSA9PiB0YWdzLmZpbmQoKHQpID0+IHQuaWQgPT09IGlkKT8ubmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5qb2luKCcsICcpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXJ0aS9Eb2N1bWVudHMvR2l0SHViL1NvZnR3YXJlLVByb2plY3QtRzEwL1Byb2plY3Qvc3JjL0ZpbHRlclBhbmVsLnRzeCJ9