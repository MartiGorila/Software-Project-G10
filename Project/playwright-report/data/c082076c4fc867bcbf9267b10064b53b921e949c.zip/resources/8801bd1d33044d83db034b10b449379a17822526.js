import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PublicProfileModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6a8f91eb"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6a8f91eb"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { getPublicUser } from "/src/api.ts?t=1780399643427";
function Avatar({ url, username, size = 72 }) {
  _s();
  const [imgError, setImgError] = useState(false);
  const initials = username.slice(0, 2).toUpperCase();
  if (url && !imgError) {
    return /* @__PURE__ */ jsxDEV(
      "img",
      {
        src: url,
        alt: username,
        onError: () => setImgError(true),
        style: {
          width: size,
          height: size,
          borderRadius: "50%",
          objectFit: "cover",
          display: "block"
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
        lineNumber: 42,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-fallback", style: { width: size, height: size, fontSize: size * 0.33 }, children: initials }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
}
_s(Avatar, "0doYx/lFKmVVbvtO/eWR8SJrtgo=");
_c = Avatar;
export default function PublicProfileModal({
  userId,
  currentUserId,
  friendIds,
  incomingRequest,
  outgoingRequest,
  onSendFriendRequest,
  onAcceptFriendRequest,
  onRemoveFriend,
  onClose
}) {
  _s2();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [friendActionLoading, setFriendActionLoading] = useState(false);
  const [friendActionError, setFriendActionError] = useState("");
  useEffect(() => {
    let cancelled = false;
    const loadProfile = async () => {
      try {
        setLoading(true);
        setError("");
        setFriendActionError("");
        const data = await getPublicUser(userId);
        if (!cancelled) {
          setProfile(data);
        }
      } catch (loadError) {
        if (!cancelled) {
          setError(loadError instanceof Error ? loadError.message : "Failed to load profile.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };
    loadProfile();
    return () => {
      cancelled = true;
    };
  }, [userId]);
  const memberSince = profile?.created_at ? new Date(profile.created_at).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric"
  }) : null;
  const showFriendControls = Boolean(currentUserId && profile && profile.id !== currentUserId);
  const isFriend = profile ? friendIds.has(profile.id) : false;
  const handleFriendAction = async () => {
    if (!profile)
      return;
    try {
      setFriendActionLoading(true);
      setFriendActionError("");
      if (isFriend) {
        await onRemoveFriend(profile.id);
      } else if (incomingRequest) {
        await onAcceptFriendRequest(incomingRequest.id);
      } else {
        await onSendFriendRequest(profile.id);
      }
    } catch (actionError) {
      setFriendActionError(
        actionError instanceof Error ? actionError.message : "Friend action failed."
      );
    } finally {
      setFriendActionLoading(false);
    }
  };
  const friendButtonText = friendActionLoading ? "Updating..." : isFriend ? "Remove Friend" : incomingRequest ? "Accept request" : outgoingRequest ? "Request sent" : "Send friend request";
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-backdrop", onClick: (event) => event.target === event.currentTarget && onClose(), children: /* @__PURE__ */ jsxDEV("div", { className: "profile-modal profile-modal--public", children: [
    /* @__PURE__ */ jsxDEV("button", { className: "profile-close", type: "button", onClick: onClose, "aria-label": "Close profile", children: "x" }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
      lineNumber: 156,
      columnNumber: 17
    }, this),
    loading && /* @__PURE__ */ jsxDEV("div", { className: "profile-loading", children: "Loading profile..." }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
      lineNumber: 160,
      columnNumber: 29
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "profile-error", children: error }, void 0, false, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
      lineNumber: 161,
      columnNumber: 27
    }, this),
    profile && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "profile-header-band" }, void 0, false, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
        lineNumber: 165,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-wrap profile-avatar-wrap--public", children: /* @__PURE__ */ jsxDEV(Avatar, { url: profile.avatar_url, username: profile.username }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 169,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 168,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "profile-identity", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "profile-username", children: profile.username }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 172,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "profile-public-badge", children: "Public profile" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 173,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 171,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
        lineNumber: 167,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "profile-meta-grid", children: [
        memberSince && /* @__PURE__ */ jsxDEV("div", { className: "profile-meta-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-label", children: "Member since" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 180,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-value", children: memberSince }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 181,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 179,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "profile-meta-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-label", children: "User ID" }, void 0, false, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 185,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "profile-meta-value profile-meta-id", children: [
            profile.id.slice(0, 8),
            "..."
          ] }, void 0, true, {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 186,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 184,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
        lineNumber: 177,
        columnNumber: 25
      }, this),
      showFriendControls && /* @__PURE__ */ jsxDEV("div", { className: "profile-friend-actions", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: `profile-friend-button ${isFriend ? "profile-friend-button--remove" : ""}`,
            disabled: friendActionLoading || Boolean(outgoingRequest),
            onClick: handleFriendAction,
            children: friendButtonText
          },
          void 0,
          false,
          {
            fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
            lineNumber: 192,
            columnNumber: 33
          },
          this
        ),
        isFriend && /* @__PURE__ */ jsxDEV("span", { className: "profile-friend-status", children: "Friends" }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 200,
          columnNumber: 46
        }, this),
        friendActionError && /* @__PURE__ */ jsxDEV("div", { className: "profile-error profile-error--compact", children: friendActionError }, void 0, false, {
          fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
          lineNumber: 202,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
        lineNumber: 191,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
      lineNumber: 164,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
    lineNumber: 155,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx",
    lineNumber: 154,
    columnNumber: 5
  }, this);
}
_s2(PublicProfileModal, "citWQWnsE+wrA0jtTkkllj5zdIo=");
_c2 = PublicProfileModal;
var _c, _c2;
$RefreshReg$(_c, "Avatar");
$RefreshReg$(_c2, "PublicProfileModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/marti/Documents/GitHub/Software-Project-G10/Project/src/PublicProfileModal.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JZLFNBMEhRLFVBMUhSOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCWixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBd0JDLHFCQUFxQjtBQWU3QyxTQUFTQyxPQUFPLEVBQUVDLEtBQUtDLFVBQVVDLE9BQU8sR0FBNEQsR0FBRztBQUFBQyxLQUFBO0FBQ25HLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJUixTQUFTLEtBQUs7QUFDOUMsUUFBTVMsV0FBV0wsU0FBU00sTUFBTSxHQUFHLENBQUMsRUFBRUMsWUFBWTtBQUVsRCxNQUFJUixPQUFPLENBQUNJLFVBQVU7QUFDbEIsV0FDSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csS0FBS0o7QUFBQUEsUUFDTCxLQUFLQztBQUFBQSxRQUNMLFNBQVMsTUFBTUksWUFBWSxJQUFJO0FBQUEsUUFDL0IsT0FBTztBQUFBLFVBQ0hJLE9BQU9QO0FBQUFBLFVBQ1BRLFFBQVFSO0FBQUFBLFVBQ1JTLGNBQWM7QUFBQSxVQUNkQyxXQUFXO0FBQUEsVUFDWEMsU0FBUztBQUFBLFFBQ2I7QUFBQTtBQUFBLE1BVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBVU07QUFBQSxFQUdkO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsMkJBQTBCLE9BQU8sRUFBRUosT0FBT1AsTUFBTVEsUUFBUVIsTUFBTVksVUFBVVosT0FBTyxLQUFLLEdBQzlGSSxzQkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFUjtBQUFDSCxHQTFCUUosUUFBTTtBQUFBLEtBQU5BO0FBNEJULHdCQUF3QmdCLG1CQUFtQjtBQUFBLEVBQ3ZDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNxQixHQUFHO0FBQUFDLE1BQUE7QUFDeEIsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUk5QixTQUErQixJQUFJO0FBQ2pFLFFBQU0sQ0FBQytCLFNBQVNDLFVBQVUsSUFBSWhDLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNpQyxPQUFPQyxRQUFRLElBQUlsQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDbUMscUJBQXFCQyxzQkFBc0IsSUFBSXBDLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUNxQyxtQkFBbUJDLG9CQUFvQixJQUFJdEMsU0FBUyxFQUFFO0FBRTdERCxZQUFVLE1BQU07QUFDWixRQUFJd0MsWUFBWTtBQUVoQixVQUFNQyxjQUFjLFlBQVk7QUFDNUIsVUFBSTtBQUNBUixtQkFBVyxJQUFJO0FBQ2ZFLGlCQUFTLEVBQUU7QUFDWEksNkJBQXFCLEVBQUU7QUFDdkIsY0FBTUcsT0FBTyxNQUFNeEMsY0FBY2tCLE1BQU07QUFDdkMsWUFBSSxDQUFDb0IsV0FBVztBQUNaVCxxQkFBV1csSUFBSTtBQUFBLFFBQ25CO0FBQUEsTUFDSixTQUFTQyxXQUFXO0FBQ2hCLFlBQUksQ0FBQ0gsV0FBVztBQUNaTCxtQkFBU1EscUJBQXFCQyxRQUFRRCxVQUFVRSxVQUFVLHlCQUF5QjtBQUFBLFFBQ3ZGO0FBQUEsTUFDSixVQUFDO0FBQ0csWUFBSSxDQUFDTCxXQUFXO0FBQ1pQLHFCQUFXLEtBQUs7QUFBQSxRQUNwQjtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBRUFRLGdCQUFZO0FBRVosV0FBTyxNQUFNO0FBQ1RELGtCQUFZO0FBQUEsSUFDaEI7QUFBQSxFQUNKLEdBQUcsQ0FBQ3BCLE1BQU0sQ0FBQztBQUVYLFFBQU0wQixjQUFjaEIsU0FBU2lCLGFBQ3ZCLElBQUlDLEtBQUtsQixRQUFRaUIsVUFBVSxFQUFFRSxtQkFBbUIsU0FBUztBQUFBLElBQ3JEQyxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxFQUNWLENBQUMsSUFDRDtBQUNOLFFBQU1DLHFCQUFxQkMsUUFBUWpDLGlCQUFpQlMsV0FBV0EsUUFBUXlCLE9BQU9sQyxhQUFhO0FBQzNGLFFBQU1tQyxXQUFXMUIsVUFBVVIsVUFBVW1DLElBQUkzQixRQUFReUIsRUFBRSxJQUFJO0FBRXZELFFBQU1HLHFCQUFxQixZQUFZO0FBQ25DLFFBQUksQ0FBQzVCO0FBQVM7QUFFZCxRQUFJO0FBQ0FPLDZCQUF1QixJQUFJO0FBQzNCRSwyQkFBcUIsRUFBRTtBQUN2QixVQUFJaUIsVUFBVTtBQUNWLGNBQU03QixlQUFlRyxRQUFReUIsRUFBRTtBQUFBLE1BQ25DLFdBQVdoQyxpQkFBaUI7QUFDeEIsY0FBTUcsc0JBQXNCSCxnQkFBZ0JnQyxFQUFFO0FBQUEsTUFDbEQsT0FBTztBQUNILGNBQU05QixvQkFBb0JLLFFBQVF5QixFQUFFO0FBQUEsTUFDeEM7QUFBQSxJQUNKLFNBQVNJLGFBQWE7QUFDbEJwQjtBQUFBQSxRQUNJb0IsdUJBQXVCZixRQUFRZSxZQUFZZCxVQUFVO0FBQUEsTUFDekQ7QUFBQSxJQUNKLFVBQUM7QUFDR1IsNkJBQXVCLEtBQUs7QUFBQSxJQUNoQztBQUFBLEVBQ0o7QUFFQSxRQUFNdUIsbUJBQW1CeEIsc0JBQ25CLGdCQUNBb0IsV0FDRSxrQkFDQWpDLGtCQUNFLG1CQUNBQyxrQkFDRSxpQkFDQTtBQUVaLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLG9CQUFtQixTQUFTLENBQUNxQyxVQUFVQSxNQUFNQyxXQUFXRCxNQUFNRSxpQkFBaUJuQyxRQUFRLEdBQ2xHLGlDQUFDLFNBQUksV0FBVSx1Q0FDWDtBQUFBLDJCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsTUFBSyxVQUFTLFNBQVNBLFNBQVMsY0FBVyxpQkFBZ0IsaUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUNJLFdBQVcsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixrQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRDtBQUFBLElBQzlERSxTQUFTLHVCQUFDLFNBQUksV0FBVSxpQkFBaUJBLG1CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNDO0FBQUEsSUFFL0NKLFdBQ0csbUNBQ0k7QUFBQSw2QkFBQyxTQUFJLFdBQVUseUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BRXBDLHVCQUFDLFNBQUksV0FBVSxzQkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxtREFDWCxpQ0FBQyxVQUFPLEtBQUtBLFFBQVFrQyxZQUFZLFVBQVVsQyxRQUFRekIsWUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxvQkFDWDtBQUFBLGlDQUFDLFVBQUssV0FBVSxvQkFBb0J5QixrQkFBUXpCLFlBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFDckQsdUJBQUMsVUFBSyxXQUFVLHdCQUF1Qiw4QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxhQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUNWeUM7QUFBQUEsdUJBQ0csdUJBQUMsU0FBSSxXQUFVLHFCQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHNCQUFxQiw0QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxVQUFLLFdBQVUsc0JBQXNCQSx5QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVKLHVCQUFDLFNBQUksV0FBVSxxQkFDWDtBQUFBLGlDQUFDLFVBQUssV0FBVSxzQkFBcUIsdUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsVUFDNUMsdUJBQUMsVUFBSyxXQUFVLHNDQUFzQ2hCO0FBQUFBLG9CQUFReUIsR0FBRzVDLE1BQU0sR0FBRyxDQUFDO0FBQUEsWUFBRTtBQUFBLGVBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsYUFGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVDMEMsc0JBQ0csdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQUs7QUFBQSxZQUNMLFdBQVcseUJBQXlCRyxXQUFXLGtDQUFrQyxFQUFFO0FBQUEsWUFDbkYsVUFBVXBCLHVCQUF1QmtCLFFBQVE5QixlQUFlO0FBQUEsWUFDeEQsU0FBU2tDO0FBQUFBLFlBRVJFO0FBQUFBO0FBQUFBLFVBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUNDSixZQUFZLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUMzRGxCLHFCQUNHLHVCQUFDLFNBQUksV0FBVSx3Q0FBd0NBLCtCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsV0FYakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F4Q1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQTtBQUFBLE9BbkRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxREEsS0F0REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVEQTtBQUVSO0FBQUNULElBbkp1QlYsb0JBQWtCO0FBQUEsTUFBbEJBO0FBQWtCLElBQUE4QyxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJnZXRQdWJsaWNVc2VyIiwiQXZhdGFyIiwidXJsIiwidXNlcm5hbWUiLCJzaXplIiwiX3MiLCJpbWdFcnJvciIsInNldEltZ0Vycm9yIiwiaW5pdGlhbHMiLCJzbGljZSIsInRvVXBwZXJDYXNlIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJvYmplY3RGaXQiLCJkaXNwbGF5IiwiZm9udFNpemUiLCJQdWJsaWNQcm9maWxlTW9kYWwiLCJ1c2VySWQiLCJjdXJyZW50VXNlcklkIiwiZnJpZW5kSWRzIiwiaW5jb21pbmdSZXF1ZXN0Iiwib3V0Z29pbmdSZXF1ZXN0Iiwib25TZW5kRnJpZW5kUmVxdWVzdCIsIm9uQWNjZXB0RnJpZW5kUmVxdWVzdCIsIm9uUmVtb3ZlRnJpZW5kIiwib25DbG9zZSIsIl9zMiIsInByb2ZpbGUiLCJzZXRQcm9maWxlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJlcnJvciIsInNldEVycm9yIiwiZnJpZW5kQWN0aW9uTG9hZGluZyIsInNldEZyaWVuZEFjdGlvbkxvYWRpbmciLCJmcmllbmRBY3Rpb25FcnJvciIsInNldEZyaWVuZEFjdGlvbkVycm9yIiwiY2FuY2VsbGVkIiwibG9hZFByb2ZpbGUiLCJkYXRhIiwibG9hZEVycm9yIiwiRXJyb3IiLCJtZXNzYWdlIiwibWVtYmVyU2luY2UiLCJjcmVhdGVkX2F0IiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwieWVhciIsInNob3dGcmllbmRDb250cm9scyIsIkJvb2xlYW4iLCJpZCIsImlzRnJpZW5kIiwiaGFzIiwiaGFuZGxlRnJpZW5kQWN0aW9uIiwiYWN0aW9uRXJyb3IiLCJmcmllbmRCdXR0b25UZXh0IiwiZXZlbnQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwiYXZhdGFyX3VybCIsIl9jIiwiX2MyIl0sInNvdXJjZXMiOlsiUHVibGljUHJvZmlsZU1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEZyaWVuZFJlcXVlc3QsIGdldFB1YmxpY1VzZXIgfSBmcm9tICcuL2FwaSdcclxuaW1wb3J0IHsgUHVibGljUHJvZmlsZSB9IGZyb20gJy4vdHlwZXMnXHJcblxyXG50eXBlIFB1YmxpY1Byb2ZpbGVNb2RhbFByb3BzID0ge1xyXG4gICAgdXNlcklkOiBzdHJpbmdcclxuICAgIGN1cnJlbnRVc2VySWQ6IHN0cmluZyB8IG51bGxcclxuICAgIGZyaWVuZElkczogU2V0PHN0cmluZz5cclxuICAgIGluY29taW5nUmVxdWVzdDogRnJpZW5kUmVxdWVzdCB8IG51bGxcclxuICAgIG91dGdvaW5nUmVxdWVzdDogRnJpZW5kUmVxdWVzdCB8IG51bGxcclxuICAgIG9uU2VuZEZyaWVuZFJlcXVlc3Q6ICh1c2VySWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxyXG4gICAgb25BY2NlcHRGcmllbmRSZXF1ZXN0OiAocmVxdWVzdElkOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD5cclxuICAgIG9uUmVtb3ZlRnJpZW5kOiAodXNlcklkOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD5cclxuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWRcclxufVxyXG5cclxuZnVuY3Rpb24gQXZhdGFyKHsgdXJsLCB1c2VybmFtZSwgc2l6ZSA9IDcyIH06IHsgdXJsOiBzdHJpbmcgfCBudWxsOyB1c2VybmFtZTogc3RyaW5nOyBzaXplPzogbnVtYmVyIH0pIHtcclxuICAgIGNvbnN0IFtpbWdFcnJvciwgc2V0SW1nRXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBpbml0aWFscyA9IHVzZXJuYW1lLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKClcclxuXHJcbiAgICBpZiAodXJsICYmICFpbWdFcnJvcikge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz17dXJsfVxyXG4gICAgICAgICAgICAgICAgYWx0PXt1c2VybmFtZX1cclxuICAgICAgICAgICAgICAgIG9uRXJyb3I9eygpID0+IHNldEltZ0Vycm9yKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogc2l6ZSxcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IHNpemUsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcclxuICAgICAgICAgICAgICAgICAgICBvYmplY3RGaXQ6ICdjb3ZlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWF2YXRhci1mYWxsYmFja1wiIHN0eWxlPXt7IHdpZHRoOiBzaXplLCBoZWlnaHQ6IHNpemUsIGZvbnRTaXplOiBzaXplICogMC4zMyB9fT5cclxuICAgICAgICAgICAge2luaXRpYWxzfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQdWJsaWNQcm9maWxlTW9kYWwoe1xyXG4gICAgdXNlcklkLFxyXG4gICAgY3VycmVudFVzZXJJZCxcclxuICAgIGZyaWVuZElkcyxcclxuICAgIGluY29taW5nUmVxdWVzdCxcclxuICAgIG91dGdvaW5nUmVxdWVzdCxcclxuICAgIG9uU2VuZEZyaWVuZFJlcXVlc3QsXHJcbiAgICBvbkFjY2VwdEZyaWVuZFJlcXVlc3QsXHJcbiAgICBvblJlbW92ZUZyaWVuZCxcclxuICAgIG9uQ2xvc2UsXHJcbn06IFB1YmxpY1Byb2ZpbGVNb2RhbFByb3BzKSB7XHJcbiAgICBjb25zdCBbcHJvZmlsZSwgc2V0UHJvZmlsZV0gPSB1c2VTdGF0ZTxQdWJsaWNQcm9maWxlIHwgbnVsbD4obnVsbClcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXHJcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gICAgY29uc3QgW2ZyaWVuZEFjdGlvbkxvYWRpbmcsIHNldEZyaWVuZEFjdGlvbkxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbZnJpZW5kQWN0aW9uRXJyb3IsIHNldEZyaWVuZEFjdGlvbkVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlXHJcblxyXG4gICAgICAgIGNvbnN0IGxvYWRQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3IoJycpXHJcbiAgICAgICAgICAgICAgICBzZXRGcmllbmRBY3Rpb25FcnJvcignJylcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRQdWJsaWNVc2VyKHVzZXJJZClcclxuICAgICAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJvZmlsZShkYXRhKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChsb2FkRXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3IobG9hZEVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBsb2FkRXJyb3IubWVzc2FnZSA6ICdGYWlsZWQgdG8gbG9hZCBwcm9maWxlLicpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxvYWRQcm9maWxlKClcclxuXHJcbiAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgY2FuY2VsbGVkID0gdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgIH0sIFt1c2VySWRdKVxyXG5cclxuICAgIGNvbnN0IG1lbWJlclNpbmNlID0gcHJvZmlsZT8uY3JlYXRlZF9hdFxyXG4gICAgICAgID8gbmV3IERhdGUocHJvZmlsZS5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywge1xyXG4gICAgICAgICAgICAgIGRheTogJ251bWVyaWMnLFxyXG4gICAgICAgICAgICAgIG1vbnRoOiAnbG9uZycsXHJcbiAgICAgICAgICAgICAgeWVhcjogJ251bWVyaWMnLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICA6IG51bGxcclxuICAgIGNvbnN0IHNob3dGcmllbmRDb250cm9scyA9IEJvb2xlYW4oY3VycmVudFVzZXJJZCAmJiBwcm9maWxlICYmIHByb2ZpbGUuaWQgIT09IGN1cnJlbnRVc2VySWQpXHJcbiAgICBjb25zdCBpc0ZyaWVuZCA9IHByb2ZpbGUgPyBmcmllbmRJZHMuaGFzKHByb2ZpbGUuaWQpIDogZmFsc2VcclxuXHJcbiAgICBjb25zdCBoYW5kbGVGcmllbmRBY3Rpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFwcm9maWxlKSByZXR1cm5cclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0RnJpZW5kQWN0aW9uTG9hZGluZyh0cnVlKVxyXG4gICAgICAgICAgICBzZXRGcmllbmRBY3Rpb25FcnJvcignJylcclxuICAgICAgICAgICAgaWYgKGlzRnJpZW5kKSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBvblJlbW92ZUZyaWVuZChwcm9maWxlLmlkKVxyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGluY29taW5nUmVxdWVzdCkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgb25BY2NlcHRGcmllbmRSZXF1ZXN0KGluY29taW5nUmVxdWVzdC5pZClcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IG9uU2VuZEZyaWVuZFJlcXVlc3QocHJvZmlsZS5pZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGFjdGlvbkVycm9yKSB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZEFjdGlvbkVycm9yKFxyXG4gICAgICAgICAgICAgICAgYWN0aW9uRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGFjdGlvbkVycm9yLm1lc3NhZ2UgOiAnRnJpZW5kIGFjdGlvbiBmYWlsZWQuJyxcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldEZyaWVuZEFjdGlvbkxvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGZyaWVuZEJ1dHRvblRleHQgPSBmcmllbmRBY3Rpb25Mb2FkaW5nXHJcbiAgICAgICAgPyAnVXBkYXRpbmcuLi4nXHJcbiAgICAgICAgOiBpc0ZyaWVuZFxyXG4gICAgICAgICAgPyAnUmVtb3ZlIEZyaWVuZCdcclxuICAgICAgICAgIDogaW5jb21pbmdSZXF1ZXN0XHJcbiAgICAgICAgICAgID8gJ0FjY2VwdCByZXF1ZXN0J1xyXG4gICAgICAgICAgICA6IG91dGdvaW5nUmVxdWVzdFxyXG4gICAgICAgICAgICAgID8gJ1JlcXVlc3Qgc2VudCdcclxuICAgICAgICAgICAgICA6ICdTZW5kIGZyaWVuZCByZXF1ZXN0J1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWJhY2tkcm9wXCIgb25DbGljaz17KGV2ZW50KSA9PiBldmVudC50YXJnZXQgPT09IGV2ZW50LmN1cnJlbnRUYXJnZXQgJiYgb25DbG9zZSgpfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLW1vZGFsIHByb2ZpbGUtbW9kYWwtLXB1YmxpY1wiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcm9maWxlLWNsb3NlXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ2xvc2V9IGFyaWEtbGFiZWw9XCJDbG9zZSBwcm9maWxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgeFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAge2xvYWRpbmcgJiYgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWxvYWRpbmdcIj5Mb2FkaW5nIHByb2ZpbGUuLi48L2Rpdj59XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWVycm9yXCI+e2Vycm9yfTwvZGl2Pn1cclxuXHJcbiAgICAgICAgICAgICAgICB7cHJvZmlsZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWhlYWRlci1iYW5kXCIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1hdmF0YXItcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtYXZhdGFyLXdyYXAgcHJvZmlsZS1hdmF0YXItd3JhcC0tcHVibGljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF2YXRhciB1cmw9e3Byb2ZpbGUuYXZhdGFyX3VybH0gdXNlcm5hbWU9e3Byb2ZpbGUudXNlcm5hbWV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1pZGVudGl0eVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtdXNlcm5hbWVcIj57cHJvZmlsZS51c2VybmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1wdWJsaWMtYmFkZ2VcIj5QdWJsaWMgcHJvZmlsZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1tZXRhLWdyaWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttZW1iZXJTaW5jZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLW1ldGEtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLW1ldGEtbGFiZWxcIj5NZW1iZXIgc2luY2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtbWV0YS12YWx1ZVwiPnttZW1iZXJTaW5jZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLW1ldGEtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtbWV0YS1sYWJlbFwiPlVzZXIgSUQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1tZXRhLXZhbHVlIHByb2ZpbGUtbWV0YS1pZFwiPntwcm9maWxlLmlkLnNsaWNlKDAsIDgpfS4uLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93RnJpZW5kQ29udHJvbHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWZyaWVuZC1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHJvZmlsZS1mcmllbmQtYnV0dG9uICR7aXNGcmllbmQgPyAncHJvZmlsZS1mcmllbmQtYnV0dG9uLS1yZW1vdmUnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2ZyaWVuZEFjdGlvbkxvYWRpbmcgfHwgQm9vbGVhbihvdXRnb2luZ1JlcXVlc3QpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVGcmllbmRBY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZnJpZW5kQnV0dG9uVGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNGcmllbmQgJiYgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1mcmllbmQtc3RhdHVzXCI+RnJpZW5kczwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZyaWVuZEFjdGlvbkVycm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWVycm9yIHByb2ZpbGUtZXJyb3ItLWNvbXBhY3RcIj57ZnJpZW5kQWN0aW9uRXJyb3J9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9tYXJ0aS9Eb2N1bWVudHMvR2l0SHViL1NvZnR3YXJlLVByb2plY3QtRzEwL1Byb2plY3Qvc3JjL1B1YmxpY1Byb2ZpbGVNb2RhbC50c3gifQ==